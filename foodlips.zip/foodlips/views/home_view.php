<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Foodlips | Food Social Network, Recipe ideas, Restaurant Guides</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
        <meta name="description" content="At Foodlips Social Network you can share your passion for food and cooking, chat with other foodies, find recipes, view videos and find restaurants nearby">
        <meta name="author" content="">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="ico/favicon.png">
        <!-- Le styles -->
        <!--        <link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
                 <link href="css/bootstrap/bootstrap-responsive.css" rel="stylesheet" /> 
                <link href="css/jquery.share.css" rel="stylesheet" type="text/css" /> -->
        <!--<link href="css/style.css" rel="stylesheet" type="text/css">-->
        <link href="<?= base_url(); ?>public/frontend/css/bootstrap.css" rel="stylesheet" />
        <link href="<?= base_url(); ?>public/frontend/css/jquery.share.css" rel="stylesheet" type="text/css" /> 
        <link href="<?= base_url(); ?>public/frontend/css/restaurants_home.css" rel="stylesheet" type="text/css">
        <?php $baseurl = "https://www.foodlips.com/shared/"; ?>
        <link href="<?= $baseurl; ?>public/frontend/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?= $baseurl; ?>public/frontend/css/community.css<?php echo '?v=' . time(); ?> " rel="stylesheet" type="text/css">
        <!--Ajax Loader-->
<!-- 		<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/jquery-1.10.2.min.js"></script>
<!-- 		<script src="<?= $baseurl; ?>public/frontend/js/formvalidation.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/bootstrap.min.js"></script>
<!-- 		<script src="<?= $baseurl; ?>public/frontend/js/foodlips.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/jquery.form.js"></script>
        <!--<script type="text/javascript" src="js/jquery.share.js"></script>-->
        <script type="text/javascript" src="<?= base_url(); ?>public/frontend/js/jquery.share.js"></script>
        <link type="text/css" rel="stylesheet" href="<?= $baseurl; ?>css/ajaxloading/jquery.loadmask.css" />
        <script type="text/javascript" src="<?= $baseurl; ?>js/ajaxloading/jquery.loadmask.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsvalidation.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsrequesthandler.js"></script>
        <!--<script type="text/javascript" src="js/foodlips.js"></script>-->
        <script type="text/javascript" src="<?= base_url(); ?>public/frontend/js/foodlips_restaurants.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/community/communityrequesthandler.js"></script> 
        <!--js for community notifications-->
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/notifications.js"></script>
        <?php /* <script type="text/javascript" src="js/jquery.social.share.1.2.min.js"></script> */ ?>
        <?php /* <script type="text/javascript">var switchTo5x=true;</script>
          <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
          <script type="text/javascript" src="http://s.sharethis.com/loader.js"></script> */ ?>
        <script> var baseurl = "https://www.foodlips.com/shared/";</script>
        <script> var siteurl = "https://www.foodlips.com/";</script>
        <script> var loginurl = baseurl + "auth/login/";</script>
        <script> var communityurl = baseurl + "community/";</script>
        <script type="text/javascript">
            var isLoginPage = false;
        </script>
        <!--[if !IE 8 ]>
                
        <![endif]-->
        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-50424093-1', 'auto');
            ga('send', 'pageview');
        </script>
    </head>
    <body>
        <div id="topmenulogin"></div>
        <?php $base_url = "https://www.foodlips.com/"; ?>
        <?php $recipe = base64_encode("recipe"); ?>
        <?php $recipe_base_url = "https://www.foodlips.com/shared/"; ?>
        <?php //print_r($_SESSION); ?>
        <?php // for FACEBOOK like  ?>
        <div id="fb-root"></div>
        <? /* <div id="social-share"></div> */ ?>
        <div id="header">
            <div id="header_main">
                <div class="container-fluid">
                    <div class="header_top">
                        <div id="search_form"></div>
                        <div class="logo_header">
                            <a href="<?= $base_url; ?>">
                                <img src="<?= $recipe_base_url; ?>images/foodlips_logo1.png" class="logo" alt="FoodLips" />
                            </a>
                        </div>
                        <div id="loginlogout"></div>
                    </div>
                </div>
                <script type="text/javascript">
                    $(document).ready(function () {
                        // $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout");
                        // $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu");
                        jQuery.ajaxSetup({
                            // Disable caching of AJAX responses
                            cache: false
                        });
                        setTimeout(function () {
                            var d = new Date();
                            var n = d.getTime();
                            $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout?t=" + n);
                            $("#search_form").load("https://www.foodlips.com/shared/recipe/searchform?t=" + n);
                            $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu?t=" + n);
                        }, 200);

                    });
                </script>
                <div class="clearfix"></div>
                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <button class="btn share_toggle" type="button"></button>
                        </div>
                        <div id="share_container">
                            <button class="btn share_toggle fixed" type="button"></button>
                            <div id="share"></div>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="navigation">
                            <ul class="nav navbar-nav">
                                <li>
                                    <a class="active" href="<?= $base_url; ?>">Home</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>community">Community</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe">Recipes</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>restaurants">Restaurants</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>wineries">Wineries</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>videos">Videos</a>
                                </li>
                                <li>
                                    <a href="<?= $base_url; ?>blog">Blog</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/aboutus">About</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/contactus">Contact us</a>
                                </li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>
            </div>
        </div>
        <div class="bigcontainer">
            <div class="banner">
                <div id="homecorousel" class="carousel slide">
                    <!-- class of slide for animation -->
                    <div class="carousel-inner">
                        <?php
                        $i = 0;
                        foreach ($slides as $row) {
                            ?>
                            <?php if ($i == 0) { ?>
                                <div class=" active item">
                                    <a href="<?= isset($row['link']) ? $row['link'] : "#"; ?>" target="_blank">
                                    <!-- <img src="<?= $base_url; ?>/images/image1.png" alt="" width="1004" height="400" /> -->
                                        <img src="<?= $recipe_base_url; ?>public/frontend/images/recipe/home/1004x400/<?php echo $row['image']; ?>" />
                                        <div class="carousel-caption">
                                            <!-- Delicious Recipes -->
                                            <?= $row['title']; ?>
                                        </div>
                                    </a>
                                </div>
                            <?php } else { ?>
                                <div class="item">
                                    <a href="<?= isset($row['link']) ? $row['link'] : "#"; ?>" target="_blank" >
                                        <img src="<?= $recipe_base_url; ?>public/frontend/images/recipe/home/1004x400/<?php echo $row['image']; ?>" />
                                        <!-- <img src="<?= $base_url; ?>/images/image2.png" alt="" width="1004" height="400" /> -->
                                        <div class="carousel-caption">
                                            <!-- Get inspired... -->
                                            <?= $row['title']; ?>
                                        </div>
                                    </a>
                                </div>
                            <?php } ?>
                            <?php
                            $i++;
                        }
                        ?>
                    </div>
                    <!--  Next and Previous controls below
                    href values must reference the id for this carousel -->
                    <a class="carousel-control left" href="#homecorousel" data-slide="prev"><span>&lsaquo;</span></a>
                    <a class="carousel-control right" href="#homecorousel" data-slide="next"><span>&rsaquo;</span></a>
                </div>
            </div>
        </div>

        <div class="bigcontainer">
            <div class="container-fluid">
                <!-- <div class="center"> -->
                <div class="center_contain">
                    <h1><p>WELCOME TO THE SOCIAL NETWORK FOODLIPS</h1><h2><em></br>At Foodlips Social Network you can share your passion for food and cooking, chat with other foodies, find recipes, view videos, join groups and find restaurants nearby. Whatever you are looking for Foodlips is our home of food and we invite you to make it yours as well!</em></h2></p>
                </div>
                </br>
                <div class="contain_box">
                    <div class="row">
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $recipe_base_url; ?>community">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/community.jpg" width="130" height="100" alt="community icon">
                                </span>
                                <span class="middle_title">Join the Foodlips</span>
                                <span class="bottom_txt">Community</span>
                            </a>
                        </div>
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $recipe_base_url; ?>recipe">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/recipes.jpg" width="115" height="90" alt="recipes icon">
                                </span>
                                <span class="middle_title">Find Delicious</span>
                                <span class="bottom_txt">Recipes</span>
                            </a>
                        </div>
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $recipe_base_url; ?>restaurants">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/restaurants.jpg" width="135" height="100" alt="restaurants icon">
                                </span>
                                <span class="middle_title">Search and Find</span>
                                <span class="bottom_txt">Restaurants</span>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $recipe_base_url; ?>wineries">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/wineries.jpg" width="125" height="90" alt="wineries icon">
                                </span>
                                <span class="middle_title">Search and Find</span>
                                <span class="bottom_txt">Wineries</span>
                            </a>
                        </div>
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $recipe_base_url; ?>videos">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/videos.jpg" width="110" height="100" alt="videos icon">
                                </span>
                                <span class="middle_title">Explore Recipe</span>
                                <span class="bottom_txt">Videos</span>
                            </a>
                        </div>
                        <div class="col-sm-4">
                            <a class="box_info" href="<?= $base_url; ?>blog">
                                <span class="top_icon">
                                    <img src="<?= $recipe_base_url; ?>public/frontend/images/home/blog.jpg" width="120" height="100" alt="blog icon">
                                </span>
                                <span class="middle_title">Read Our</span>
                                <span class="bottom_txt">Blog</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#newfooter").load("https://www.foodlips.com/shared/community/commonfooter");
            });
        </script>
        <div class="footer_new_bg" >
            <div class="container-fluid">
                <div id="newfooter" class="footer_new row">
                </div>
                <!-- Go to www.addthis.com/dashboard to customize your tools --> <div class="addthis_inline_follow_toolbox"></div>
            </div>
            <div class="footer_new_copyright">
                <div class="container_self">
                    <p class="copyright">2013 Copyright &copy; <a class="whitecolor footerlink" href="https://www.foodlips.com">Foodlips</a></p>
                </div>
            </div>
        </div>
        <!-- Go to www.addthis.com/dashboard to customize your tools -->
        <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-599145be1eb87b29"></script> 
    </body>
</html>