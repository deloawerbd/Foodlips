<script language="JavaScript" type="text/javascript">
	$( document ).ready(function() {
		$("iframe").attr("width","548");
	});
</script>
<div class="page_wrapper">
    <div class="container-fluid">
        <div class="row">
   	        <div class="left_login_area col-sm-6">
                <div class="left_login_boxarea">
                	<?php 
                		if(!empty($frontvideo) && !empty($frontvideo->description))
                		{
                			echo $frontvideo->video;
						}
						else
						{
					?>
					<img src="<?=base_url();?>images/video_img.jpg" width="673" height="388" class="left_login_boxarea" alt="video">
					<?php }?>
                </div>                
                <?php if(!empty($frontvideo) && !empty($frontvideo->description)) { ?>
                    <p>
                        <?=$frontvideo->description;?>
                    </p>
                <?php } else { ?>
                    <div class="left_login_txthead">                	
					   Lorem Ipsum Dolor Sit Amet,
					   Consectetuer Adipiscing Elit. Nam Cursus.				
                    </div>
                <?php } ?>
            </div>
        
        	<div id="registrationContainer" class="right_login_area col-sm-6">
                <?php //echo form_open($this->uri->uri_string(), array('id' => 'register_form'))?>
                <?=form_open("auth/register", array("id" => "register_form"));?>
                    <?php $regisreflag = $this->input->post("register");?>
                   <div class="right_login_txthead">
                        New Member Sign Up
                   </div>
	               
	                <div class="right_login_box row">
	                	<label for="user_name">
	                	    <div class="login_label col-sm-6">
	                	    	<label class="label_txt" for="registerUserName"><?=$this->lang->line("FAL_user_name_label")?>:</label>
	                	        <input type="text" id="registerUserName" class="right_login_input" name="user_name"  value="<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'user_name'} : '')?>" placeholder="User Name">
                	        	<div id="registerUserNameErr" class="hideerr errmsg"></div>
                	        </div>
                	        <div class="login_label col-sm-6">
                	        	<label class="label_txt" for="displayName">Display Name:</label>
                	            <input type="text" id="displayName" class="right_login_input" name="display_name" value="<?php echo $this->input->post("display_name"); //if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'display_name'} : '');?>" placeholder="Display Name" />
	                    		<?php if($regisreflag) echo(isset($this->fal_validation) ? $this->fal_validation->{'user_name'.'_error'} : '');?>
	                    		<div id="displayNameErr" class="hideerr errmsg"></div>
            	            </div>
        	            </label>
	                    
                    	<?php //if($regisreflag) echo(isset($this->fal_validation) ? $this->fal_validation->{'display_name'.'_error'} : '');?>
                		
	                </div>
	                
	                <div class="right_login_box row">
	                	<div class="col-sm-12">
		                	<label class="label_txt" style="margin-top: 0px;" for="email"><?=$this->lang->line('FAL_user_email_label')?>:</label>
		                	<input name="email" id="email" type="text" class="right_login_input1" placeholder="Your Email" value="<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'email'} : '');?>">
	                		<div id="registerEmailErr" class="hideerr errmsg"></div>
		                	<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'email'.'_error'} : '');?>
	                	</div>
	                </div>
	                <div class="right_login_box row">
		                <div class="col-sm-12">
		                	<label class="label_txt" for="password"><?=$this->lang->line('FAL_user_password_label')?>:</label>
		                	<input name="password" id="password" type="password" class="right_login_input1" placeholder="New Password">
		                	<div id="registerPasswordErr" class="hideerr errmsg"></div>
		                	<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'password'.'_error'} : '');?>
		                </div>
	                </div>
	                <div class="right_login_box row">
		                <div class="col-sm-12">
		                	<label class="label_txt" for="password_confirm"><?=$this->lang->line('FAL_user_password_confirm_label')?>:</label>
		                	<input name="password_confirm" id="password_confirm" type="password" class="right_login_input1" placeholder="Confirm Password">
		                	<div id="registerConfirmPasswordErr" class="hideerr errmsg"></div>
		                	<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'password_confirm'.'_error'} : '');?>
		                </div>
	                </div>
	                <div class="right_login_select_box row">
		                <div class="col-sm-12">
			                <?php 
			                if ($this->config->item('FAL_use_country'))
							{?>
								<label class="label_txt"><?=$this->lang->line('FAL_user_country_label')?>:</label>
								<?=form_dropdown('country_id',
												$countries,
												(isset($this->fal_validation) ? $this->fal_validation->country_id : 0))?>
								<div id="registerCountryErr" class="hideerr errmsg"></div>
								<?php if($regisreflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'country_id'.'_error'} : '');?>
							<?php } ?>
						</div>
					</div>
	                <? /* <div class="right_login_box">
	                    <div class="right_login_txt">
	                        Birthday:
	                    </div>
	                    <div class="right_login_select_box">
	                    	<select name="month" class="right_login_select_input">
	                        	<option>Month</option>
	                            <option>January</option>
	                            <option>February</option>
	                            <option>March</option>
	                            <option>April</option>
	                            <option>May</option>
	                            <option>June</option>
	                            <option>July</option>
	                            <option>August</option>
	                            <option>September</option>
	                            <option>October</option>
	                            <option>November</option>
	                            <option>December</option>
	                        </select>
	                        
	                        <select name="month" class="right_login_select_input2">
	                        	<option>Day</option>
	                            <option>1</option>
	                            <option>2</option>
	                            <option>3</option>
	                            <option>4</option>
	                            <option>5</option>
	                            <option>6</option>
	                            <option>7</option>
	                            <option>8</option>
	                            <option>9</option>
	                            <option>10</option>
	                            <option>11</option>
	                            <option>12</option>
	                            <option>13</option>
	                            <option>14</option>
	                            <option>15</option>
	                            <option>16</option>
	                            <option>17</option>
	                            <option>18</option>
	                            <option>19</option>
	                            <option>20</option>
	                            <option>21</option>
	                            <option>22</option>
	                            <option>23</option>
	                            <option>24</option>
	                            <option>25</option>
	                            <option>26</option>
	                            <option>27</option>
	                            <option>28</option>
	                            <option>29</option>
	                            <option>30</option>
	                            <option>31</option>
	                        </select>
	                        
	                        <select name="month" class="right_login_select_input3">
	                        	<option>Year</option>
	                            <option>2001</option>
	                            <option>2002</option>
	                            <option>2003</option>
	                            <option>2004</option>
	                            <option>2005</option>
	                            <option>2006</option>
	                            <option>2007</option>
	                            <option>2008</option>
	                            <option>2009</option>
	                            <option>2010</option>
	                            <option>2011</option>
	                            <option>2012</option>
	                            <option>2013</option>
	                        </select>
	                        <!--<div class="community_login_link">
	                        	<a href="#">
	                        	Why do I need to provide my birthday?
	                            </a>
	                        </div>
	                    </div>
	                </div>
	                <div class="right_login_box">
	                	<div class="community_login_m_f_box">
	                    	<label>
	                			<input name="femal" type="radio" value="">
	                        	Female
	                        </label>
	                        <label>
	                			<input name="femal" type="radio" value="">
	                        	Male
	                        </label>
	                    </div>
	                </div> */ ?>
	                <div class="right_login_box">
	                	<div class="right_community_txt">
	                   		By clicking Sign Up, you agree to our <a href="<?=base_url();?>community/termsandconditions/">Terms</a> and that you have read our <a href="<?=base_url();?>community/datapolicy/"> Data Use Policy </a>, including our <a href="#">Cookie Use</a>.
	               		</div>
	                </div>
	                <div class="right_login_box">
	                	<div id="registerErr" class="hideerr errmsg"></div>
	                	<input type="submit" id="registerSbtBtn" class="sign_up_btn" name="sbt_signup" value="Sign Up" />
	                	<input type="button" id="registerBtn" class="sign_up_btn hideerr" name="btn_signup" value="Sign Up" />
	                </div>
                <?=form_close();?>
            </div>
        </div>							 <!--             end container here    -->
  	</div>
</div>
<? /* old code login refrence
<?=form_open($this->uri->uri_string(), array('id' => 'login_form'))?>
<table  width="600" border="0" cellspacing="0" align="center" cellpadding="0" >
                 
                  <tr>
                    <td height="33" colspan="3" ><h1 class="raleway_font"><?=$heading?></h1>
                    <br /><br />
                    <?=isset($this->fal_validation->login_error_message) ? $this->fal_validation->login_error_message : ''?>					</td>
                  </tr>
                  <tr>
                    <td width="81" align="left" valign="top" class="text6"><strong><label for="user_name"><?=$this->lang->line('FAL_user_name_label')?></label></strong></td>
                    <td width="250" align="left" valign="top" class="text6">
																<?
																$user_name = $this->input->post('user_name');
																?>
																<?=form_input(array('name'=>'user_name', 
																   'id'=>'user_name',
																	   'maxlength'=>'30', 
																   'size'=>'30',
																   'value'=>$user_name))?>
																<?=(isset($this->fal_validation) ? $this->fal_validation->{'user_name'.'_error'} : '')?>					</td>
                    <td width="200" rowspan="4" align="left" valign="top" class="text6">
                    												<p><?=anchor($this->config->item('FAL_forgottenPassword_uri'), $this->lang->line('FAL_forgotten_password_label').' ?',array('class'=>'text_h1'))?>
                    												</p>
                    												<?php
																	if ($this->config->item('FAL_allow_user_registration'))
																	{?>
																	<p style="margin-top:50px"><?=anchor($this->config->item('FAL_register_uri'), $this->lang->line('FAL_register_label'),array('class'=>'text_h1'))?>
					</p>																	<?php }?>                    </td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" class="text6"><strong><label for="password"><?=$this->lang->line('FAL_user_password_label')?>:</label></strong></td>
                    <td align="left" valign="top" class="text6">
																	<?=form_password(array('name'=>'password', 
                                                                                           'id'=>'password',
                                                                                           'maxlength'=>'30', 
                                                                                           'size'=>'30',
                                                                                           'value'=>''))?>
                                                                    
                                                                    <?=(isset($this->fal_validation) ? $this->fal_validation->{'password'.'_error'} : '')?>					</td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" class="text6"><?php
                                                                if ($this->config->item('FAL_use_captcha_login'))
                                                                {?>
                                                                <strong><label for="security"><?=$this->lang->line('FAL_captcha_label')?></label></strong>
                                                                <?
																}
																?>                    </td>
                    <td align="left" valign="top" class="text6"><!--CAPTCHA (security image)-->
																<?php
                                                                if ($this->config->item('FAL_use_captcha_login'))
                                                                {?>
                                                                <?=$this->load->view($this->config->item('FAL_captcha_img_tag_view'), null, true)?>
                                                                <br />
																<?=form_input(array('name'=>'security', 
                                                                                       'id'=>'security',
                                                                                       'maxlength'=>'35', 
                                                                                       'size'=>'30',
                                                                                       'value'=>'Enter above security code here.'))?>
                                                                <?=(isset($this->fal_validation) ? $this->fal_validation->{'security'.'_error'} : '')?>
                                                                
                                                                <?php }?>
                                                                <!-- END CAPTCHA (security image)-->                    </td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr>
                  <!-- <tr>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr> -->
                  <tr>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6"><?=form_submit(array('name'=>'login', 
																					 'id'=>'login','class'=>'submit btn btn-primary', 
																					 'value'=>$this->lang->line('FAL_login_label')))?>
																</label>                    </td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                    <td align="left" valign="top" class="text6">&nbsp;</td>
                  </tr>
                </table>

<?=form_close()?> */ ?>


<?
// reference code 

/*
 
<fieldset><legend accesskey="D" tabindex="1"><?=$heading?></legend>
<?=isset($this->fal_validation->login_error_message) ? $this->fal_validation->login_error_message : ''?>
<?=form_open($this->uri->uri_string(), array('id' => 'login_form'))?>
<!--USERNAME-->
	<p><label for="user_name"><?=$this->lang->line('FAL_user_name_label')?>:</label>
	<?=form_input(array('name'=>'user_name', 
	                       'id'=>'user_name',
	                       'maxlength'=>'30', 
	                       'size'=>'30',
	                       'value'=>''))?>
    <?=(isset($this->fal_validation) ? $this->fal_validation->{'user_name'.'_error'} : '')?>
   </p>
    <!--PASSWORD-->
	<p><label for="password"><?=$this->lang->line('FAL_user_password_label')?>:</label>
	<?=form_password(array('name'=>'password', 
	                       'id'=>'password',
	                       'maxlength'=>'30', 
	                       'size'=>'30',
	                       'value'=>''))?>
    
    <?=(isset($this->fal_validation) ? $this->fal_validation->{'password'.'_error'} : '')?>
    <span class="note"><?=anchor($this->config->item('FAL_forgottenPassword_uri'), $this->lang->line('FAL_forgotten_password_label'))?></span></p>	
    <!--CAPTCHA (security image)-->
	<?php
	if ($this->config->item('FAL_use_captcha_login'))
	{?>
	<p><label for="security"><?=$this->lang->line('FAL_captcha_label')?>:</label>
	<?=form_input(array('name'=>'security', 
	                       'id'=>'security',
	                       'maxlength'=>'45', 
	                       'size'=>'45',
	                       'value'=>''))?>
    <?=(isset($this->fal_validation) ? $this->fal_validation->{'security'.'_error'} : '')?>
    <?=$this->load->view($this->config->item('FAL_captcha_img_tag_view'), null, true)?></p>
    <?php }?>
    <!-- END CAPTCHA (security image)-->
    
	<p><label>
	<?=form_submit(array('name'=>'login', 
	                     'id'=>'login', 'class'=>'submit',
	                     'value'=>$this->lang->line('FAL_login_label')))?>
	</label></p>
    <?php
    if ($this->config->item('FAL_allow_user_registration'))
	{?>
	<p><?=anchor($this->config->item('FAL_register_uri'), $this->lang->line('FAL_register_label'))?></p>
	<?php }?>
<?=form_close()?>
</fieldset>

*/
?>