<?php //form_open($this->uri->uri_string(), array('id' => 'forgotten_password_form'))?>
<?=form_open("auth/forgotten_password", array('id' => 'forgotten_password_form'))?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border: solid 1px #F2F1F0; margin: 0 auto;">
	<tr>
		<td height="33" colspan="3" align="center" style="padding-left: 10px;"><h3><?=$heading?></h3></td>
	</tr>
	<tr>
	    <td align="left" valign="top" class="text6">&nbsp;</td>
	    <td align="left" valign="top" class="text6">&nbsp;</td>
	</tr>
	<? /*<tr>
		<td width="81" align="left" valign="top" class="text6">&nbsp;</td>
		<td width="399" align="left" valign="top" class="text6">&nbsp;</td>
		<td width="355" rowspan="6" align="left" valign="top" class="text6"><p>
			<?=anchor("auth/login", "Login",array('class'=>'text_h1'))?>
		</p>
        <?php if ($this->config->item('FAL_allow_user_registration')) {?>
        	<p style="margin-top:50px">
        		<?=anchor($this->config->item('FAL_register_uri'), $this->lang->line('FAL_register_label'),array('class'=>'text_h1'))?>
        	</p>
        <?php }?></td>
   </tr> */ ?>
	<tr>
	    <td align="left" width="120" valign="top" style="padding-left: 10px;" class="text6"><label for="email">
	      <?=$this->lang->line('FAL_user_email_label')?>
	    </label></td>
	    <td align="left" valign="top" class="text6">
	    	<?=form_input(array('name'=>'email', 
								'id'=>'email',
								'maxlength'=>'100',
								'size'=>'25',
								'value'=>(isset($this->fal_validation) ? $this->fal_validation->{'email'} : '')))?>
			<?=(isset($this->fal_validation) ? $this->fal_validation->{'email'.'_error'} : '')?>
		</td>
		<td align="left" valign="top" class="text6">
			<?=form_submit(array('name'=>'submit',
								 'class'=>'forgotpass_btn',
								 'value'=>$this->lang->line('FAL_submit')))?>
		</td>
	</tr>
	<tr>
		<td align="left" valign="top" class="text6">&nbsp;</td>
		<td align="left" valign="top" class="text6">&nbsp;</td>
	</tr>
  <? /*<tr>
    <td align="left" valign="top" class="text6"><!--CAPTCHA (security image)-->
        <?php
                                                                    if ($this->config->item('FAL_use_captcha_forgot_password'))
                                                                    {?>
        <label for="security">
          <?=$this->lang->line('FAL_captcha_label')?>
      </label>
        <?
																	}
																	?>    </td>
    <td align="left" valign="top" class="text6"><?php
																	if ($this->config->item('FAL_use_captcha_forgot_password'))
																	{?>
        <?=$this->load->view($this->config->item('FAL_captcha_img_tag_view'), null, true)?>
        <br />
        <?=form_input(array('name'=>'security', 
																						   'id'=>'security',
																						   'maxlength'=>'45', 
																						   'size'=>'45',
																						   'value'=>'Enter above security code here.'))?>
        <?=(isset($this->fal_validation) ? $this->fal_validation->{'security'.'_error'} : '')?>
        <?php }
																	?>    </td>
  </tr>
  <tr>
    <td align="left" valign="top" class="text6">&nbsp;</td>
    <td align="left" valign="top" class="text6">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="text6">&nbsp;</td>
    <td align="left" valign="top" class="text6"><?=form_submit(array('name'=>'submit','class'=>'submit',  
	               												      'value'=>$this->lang->line('FAL_submit')))?>    </td>
  </tr>
  <tr>
    <td align="left" valign="top" class="text6">&nbsp;</td>
    <td align="left" valign="top" class="text6">&nbsp;</td>
    <td align="left" valign="top" class="text6">&nbsp;</td>
  </tr> */ ?>
</table>
<?=form_close()?>

<?php /*?>

FOR REFERENCE PURPOSE


<fieldset>
<legend><?=$heading?></legend>
<?=form_open($this->uri->uri_string(), array('id' => 'forgotten_password_form'))?>
	<p><label for="email"><?=$this->lang->line('FAL_user_email_label')?>:</label>
	<?=form_input(array('name'=>'email', 
	                       'id'=>'email',
	                       'maxlength'=>'100', 
	                       'size'=>'60',
	                       'value'=>(isset($this->fal_validation) ? $this->fal_validation->{'email'} : '')))?>
    <?=(isset($this->fal_validation) ? $this->fal_validation->{'email'.'_error'} : '')?></p>
    <!--CAPTCHA (security image)-->
	<?php
	if ($this->config->item('FAL_use_captcha_forgot_password'))
	{?>
	<p><label for="security"><?=$this->lang->line('FAL_captcha_label')?>:</label>
	<?=form_input(array('name'=>'security', 
	                       'id'=>'security',
	                       'maxlength'=>'45', 
	                       'size'=>'45',
	                       'value'=>''))?>
    <?=(isset($this->fal_validation) ? $this->fal_validation->{'security'.'_error'} : '')?>
    <?=$this->load->view($this->config->item('FAL_captcha_img_tag_view'), null, true)?></p>
    <?php }?>
    <!-- END CAPTCHA (security image)-->
	<p><?=form_submit(array('name'=>'submit', 
	                     'value'=>$this->lang->line('FAL_submit')))?>
 </p>
<?=form_close()?>
</fieldset><?php */?>