


	<div class="page_wrapper">
        <div class="container-fluid center_txt">
            <p style="margin-top: 50px;">
				<?=$this->lang->line('FAL_activation_failed_message');?>
                <br />
                <br />
                <?=anchor($this->config->item('FAL_activation_continue_action'), $this->lang->line('FAL_continue_label'))?>
			</p>
        </div>
	</div