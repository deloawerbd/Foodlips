
	<!-- <div class="container">
		<div class="row">
        	<div class="center"> -->
                <?php 
                if (isset($message) AND $message!='')
                {
                    echo $message;
                }?>
                <!--INSTALLER-->
                <?php if (isset($installer) AND $installer!='')
                {
                    echo $installer;
                }?>
                <!--END INSTALLER-->
                <!--START INCLUDED CONTENT-->                
                <?= isset($fal) ? $fal : null;?>
                <?php isset($page) ? $this->load->view($page) : null;?>
                <!--END INCLUDED CONTENT-->
         	<!-- </div>
	   	</div>
	</div> -->
      
