<?php //$this->load->view("template/footer.php")?>  
<?=$this->load->view("template/newfooter.php")?>
 