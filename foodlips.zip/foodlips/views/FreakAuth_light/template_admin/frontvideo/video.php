<style>
	.frntvidform
	{
		width: 28%;
		float: left;
		margin-left: 20px;	
	}
	.frntvidview
	{
		width: 66%;
		float: left;
	}
</style>
<div id="content">
	<div class="container">
		<div class="row">
			<div class="span3">
				<span class="heading">Front Video</span>
			</div>		
		</div>
		<hr>
	</div>
	<div class="container frntvidview">
		<table class="table-strip table-hover">
		<tr>
			<td width="15%"><strong>Title :</strong></td>
			<td width="85%"><?=(!empty($frontvideo->title) ? $frontvideo->title : "");?></td>			
		</tr>
		<tr>			
			<td colspan="2">
				<?=(!empty($frontvideo->video) ? $frontvideo->video : "");?>
			</td>			
		</tr>
		<tr>
			<td valign="top"><strong>Description :</strong></td>
			<td><?=(!empty($frontvideo->description) ? $frontvideo->description : "");?></td>			
		</tr>
		</table>
	</div>
	<div class="well frntvidform" id="frontvideofrm">
		<?php echo form_open_multipart('admin/recipe/frontvideo',array('method'=>'post','name'=>'frm-frontvideo', 'id'=>'frm-frontvideo'));?>
		<table class="table table-borderless">
			<tr>
				<td><?=form_label('Title', 'title');?></td>
				<td>
					<?=form_input(array('name'=>'title', 'id'=>'title', 'maxlength'=>'100', 'size'=>'30', 'placeholder'=>'Video Title'));?>
					<span class="err"><?=form_error('title')?></span>					
				</td>				
			</tr>
			<tr>
				<td><?=form_label('Description', 'description');?></td>
				<td>
					<?=form_textarea(array('name'=>'description', 'id'=>'description', 'cols'=>'43', 'rows'=>'3',));?>
					<span class="err"><?=form_error('description')?></span>
				</td>				
			</tr>
			<tr>
				<td><?=form_label('Front Video', 'video');?></td>
				<td>
					<?=form_textarea(array('name'=>'video', 'id'=>'video', 'cols'=>'43', 'rows'=>'3', 'placeholder'=>'Video Embaded Code'));?>
					<span class="err"><?=form_error('video')?></span>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
					<input class="btn btn-primary" type="submit" name="sbt_save" value="Save"/>
				</td>
			</tr>
		</table>
		<?=form_close();?>
	</div>
	
</div>