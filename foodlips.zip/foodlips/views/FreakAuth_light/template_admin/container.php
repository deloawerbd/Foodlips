<?php
$this->load->view($this->config->item('FAL_template_dir').'template_admin/header');
$this->load->view($this->config->item('FAL_template_dir').'template_admin/menu');
$this->load->view($this->config->item('FAL_template_dir').'template_admin/content');
$this->load->view($this->config->item('FAL_template_dir').'template_admin/footer');
?> 
