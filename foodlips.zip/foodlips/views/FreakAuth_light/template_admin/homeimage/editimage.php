<div id="content">
<div class="container">
	<div class="well span6 offset2">
		<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/homeimage">Back</a>
		</div>
		<span class="smallheading marginbottom20">Edit image</span>
		<br /><br />
		
		<?php if(isset($images)) { 	?>
 			<?php foreach ($images as $img) { ?>
				<?php echo form_open_multipart('admin/recipe/editimage'); ?>		
					<!-- <form action="<?=base_url();?>admin/recipe/editcategory" method="post" enctype="multipart/form-data"> -->			
					<input type="hidden" name="id" value="<?=$img->id?>" />
					<input type="hidden" name="hiddenname" value="<?=$img->image;?>" />
						<table class="table table-borderless">
							<?php if(isset($success) || isset($fail)) { ?>
								<tr id="msg">
									<td>&nbsp;</td>
									<td>
										<?php if(isset($success)) { ?>
											<span class="updatesuccessmsg"><?=$success;?></span>
										<?php } else if(isset($fail)) { ?>
											<span class="updatefailmsg"><?=$fail;?></span>
										<?php } ?>
									</td>
								</tr>
							<?php } ?>
							<tr>
								<td>Title</td>
								<td>
									<input type="text" id="title" name="title" value="<?=$img->title;?>" size="80" />
									<span class="err"><?php echo form_error('title'); ?></span>
									<p id="titleerr" class="hideerr err">The Title field is required</p>
								</td>
							</tr>
							<tr>
								<td>Image</td>
								<td>
									<img name="image" src="<?=base_url();?>public/frontend/images/recipe/home/50x50/<?=$img->image;?>"/><br /><br />
									<input type="file" id="userfile" name="userfile" "/>
									<p id="imageerr" class="hideerr err">The Image field is required</p>
										
								</td>
							</tr>
							<tr>
								<td>Link</td>
								<td>
									<input type="text" name="imglink" value="<?=(isset($img->link) ? $img->link : "");?>" placeholder="http://www.example.com/" /><br/>
									<small>After clicking on slider Image user can redirected to this link.</small>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td>
									<input class="btn btn-primary" type="submit" name="sbt_update" value="Update"  "/>
								</td>
							</tr>
						</table>
					<?=form_close();?>
				<?php } ?>
			<?php } ?>		
	</div>
</div>
</div>