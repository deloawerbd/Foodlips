<div id="content">
<div class="container">
	<div class="row">
		<div class="span3">
			<span class="heading">Home</span>
		</div>
		<div class="span2 offset7 marginbottom5">
			<a class="btn btn-primary pull-right" href="<?=base_url();?>admin/recipe/addimage">
				Add new
			</a>
		</div>
	</div>
	<hr>
	</div>
	<div class="container">
	<table class="table table-strip table-hover">
		<thead>
			<th width="600">
				Title
			</th>
			<th width="200">
				Image
			</th>
			<th width="30">
				Action
			</th>
		</thead>
		
		<?php if(!isset($images)) {	?>
		<tr>
			<td colspan="4" width="100" align="center">
				<span class="noresult">No Images found</span>
			</td>
		</tr>
		<?php }else { ?>
			<?php foreach ($images as $imag) { ?>
			<tr>
				<td align="left">
					<?=substr($imag->title,0,100);?>					
				</td>
				<td align="left">
					<img name="image" src="<?=base_url();?>public/frontend/images/recipe/home/50x50/<?=$imag->image;?>" />
							
							
				</td>
				<td align="left">
					<a href="<?=base_url();?>admin/recipe/editimage/<?=$imag->id;?>">
						<img id="d" src="<?=base_url();?>public/admin/images/pencil.png" title="Edit" alt="Edit" />
					</a>
					&nbsp;|&nbsp;
					<a href="<?=base_url();?>admin/recipe/deleteimage/<?=$imag->id;?>" >
						<img  src="<?=base_url();?>public/admin/images/cross.png" title="Delete" alt="Delete" />
					</a>
					
				</td>
			</tr>
		<?php }	 ?>
	<?php }  ?>
		</table>
	</div>
	
</div>