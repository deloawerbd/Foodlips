<div id="content">
	<div class="container">
		<div class="well span6 offset2">
			<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/homeimage">Back</a>
			</div>

			<span class="smallheading marginbottom20">Add new image</span>
			
			<br /><br />
			
			<?php echo form_open_multipart('admin/recipe/addimage'); ?>
			<table class="table table-borderless">
				<tr>
					<td>Title</td>
					<td>
						<input type="text" id="title" name="title" value="<?=$this->input->post('title')?>" size="80" />
						<span class="err"><?php echo form_error('title'); ?></span>
						<p id="titleerr" class="hideerr err">The Title field is required</p>
					</td>
				</tr>
				<tr>
					<td>Image</td>	
					<td>
						<input type="file" id="userfile" name="userfile" "/>
						<span class="err"><?php echo form_error('userfile'); ?></span>
						<p id="imageerr" class="hideerr err">The Image field is required</p>
						
					</td>
				</tr>
				<tr>
					<td>Link</td>
					<td>
						<input type="text" name="imglink" value="<?=$this->input->post('imglink')?>" placeholder="http://www.example.com/" /><br/>
						<small>After clicking on slider Image user can redirected to this link.</small>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>
						<input class="btn btn-primary" type="submit" name="sbt_add" value="Add" onclick="return checktitle()"/>
					</td>
				</tr>
			</table>
		<?=form_close();?>
		</div>
	</div>
</div>