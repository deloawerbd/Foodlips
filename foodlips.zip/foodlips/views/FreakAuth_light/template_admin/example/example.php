<h2><?=$action?></h2>

<?=$content?>
