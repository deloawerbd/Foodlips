<div id="content">
<div class="container">
	<div class="well span6 offset2">
		<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/methods">Back</a>
		</div>
		<span class="smallheading marginbottom20">Edit methods</span>
		<br /><br />
		
		<?php if(isset($methods)) { 	?>
 			<?php foreach ($methods as $method) { ?>
				<?php echo form_open_multipart('admin/recipe/editmethod'); ?>					
					<input type="hidden" name="id" value="<?=$method->id?>" />
						<table class="table table-borderless">
							<?php if(isset($success) || isset($fail)) { ?>
								<tr id="msg">
									<td>&nbsp;</td>
									<td>
										<?php if(isset($success)) { ?>
											<span class="updatesuccessmsg"><?=$success;?></span>
										<?php } else if(isset($fail)) { ?>
											<span class="updatefailmsg"><?=$fail;?></span>
										<?php } ?>
									</td>
								</tr>
							<?php } ?>
							<tr>
								<td>Title</td>
								<td>
									<input class="textboxwidth" type="text" id="name" name="name"  value="<?=$method->name;?>" />
									<input type="hidden" name="hiddenname" value="<?=$method->name;?>" />
									<span class="err"><?php echo form_error('name'); ?></span>
									<p id="nameerr" class="hideerr err">The Name field is required</p>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td>
									<input class="btn btn-primary" type="submit" name="sbt_update" value="Update"  onclick="return checkname()"/>
								</td>
							</tr>
						</table>
					</form>
				<?php } ?>
			<?php } ?>		
	</div>
</div>
</div>
