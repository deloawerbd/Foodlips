<div id="content">
<div class="container">
	<div class="row">
		<div class="span3">
			<span class="heading">Manage Methods</span>
		</div>
		<div class="span2 offset7 marginbottom5">
			<a class="btn btn-primary pull-right" href="<?=base_url();?>admin/recipe/addmethods">
				Add new
			</a>
		</div>
	</div>
	<hr>
	</div>
	<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
	</div><br /><br />
	
	<div class="container">
	<table class="table table-strip table-hover">
		<thead>
			<th width="800">
				Title
			</th>
			<th width="30">
				Action
			</th>
		</thead>
		
		<?php if(!isset($methods)) {	?>
		<tr>
			<td colspan="4" width="100" align="center">
				<span class="noresult">No Methods found</span>
			</td>
		</tr>
		<?php }else { ?>
			<?php foreach ($methods as $method) { ?>
			<tr>
				<td align="left">
					<?=substr($method->name,0,100);?>					
				</td>
				<td align="left">
					<a href="<?=base_url();?>admin/recipe/editmethod/<?=$method->id?>">
						<img id="d" src="<?=base_url();?>public/admin/images/pencil.png" title="Edit" alt="Edit" />
					</a>
					&nbsp;|&nbsp;
					<a href="<?=base_url();?>admin/recipe/deletemethod/<?=$method->id?>" >
						<img  src="<?=base_url();?>public/admin/images/cross.png" title="Delete" alt="Delete" />
					</a>
				</td>
			</tr>
		<?php }	 ?>
		<?php }  ?>
		</table>
	</div>
	<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
	</div>
</div>