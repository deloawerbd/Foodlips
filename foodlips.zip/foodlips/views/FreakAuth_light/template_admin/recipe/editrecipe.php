<div id="content">
<div class="container">
	<div class="well span8 offset2">
		<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/recipe">Back</a>
		</div>

		<span class="smallheading marginbottom20">Edit recipe</span>
		<br /><br />
		
		<?php  if(isset($recipedetails)) { 	?>
 			<?php foreach ($recipedetails as $row) {  ?>
				<?php echo form_open_multipart('admin/recipe/editrecipe'); ?>					
					<input type="hidden" name="id" value="<?=$row->id?>" />
					<input type="hidden" name="pimagename" id="pimagename" value="<?=$row->images;?>" />
					<input type="hidden" name="pdeleteimages" id="pdeleteimages" value=""/>
						<table class="table table-borderless">
							<?php if(isset($success) || isset($fail)) { ?>
								<tr id="msg">
									<td>&nbsp;</td>
									<td>
										<?php if(isset($success)) { ?>
											<span class="updatesuccessmsg"><?=$success;?></span>
										<?php } else if(isset($fail)) { ?>
											<span class="updatefailmsg"><?=$fail;?></span>
										<?php } ?>
									</td>
								</tr>
							<?php } ?>
							<tr>
								<td width="200">Title</td>
								<td>
									<?php //$row->title;?>
									<input type="text" name="title" value="<?=$row->title;?>" >
								</td>
							</tr>
							
							<tr>
								<td>Category</td>
								<td>
									<?php //$categoryname;?>
									<select name="category">
										<?php foreach($all_categories as $category){ ?>
											<option value="<?=$category->id?>" <?php if($category->name == $categoryname){ echo "selected"; }?>><?=$category->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Course</td>
								<td>
									<?php //$coursename;?>
									<select name="course">
										<?php foreach($all_courses as $course){ ?>
											<option value="<?=$course->id?>" <?php if($course->name == $coursename){ echo "selected";}?>><?=$course->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Type</td>
								<td>
									<?php //$typename;?>
									<select name="type">
										<?php foreach($all_types as $type){ ?>
											<option value="<?=$type->id?>" <?php if($type->name == $typename){ echo "selected";}?>><?=$type->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Cuisine</td>
								<td>
									<?php //$cuisinename;?>
									<select name="cuisine">
										<?php foreach($all_cuisines as $cuisine){ ?>
											<option value="<?=$cuisine->id?>" <?php if($cuisine->name == $cuisinename){ echo "selected";}?>><?=$cuisine->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Season</td>
								<td>
									<?php //$seasonname;?>
									<select name="season">
										<?php foreach($all_seasons as $season){ ?>
											<option value="<?=$season->id?>" <?php if($season->name == $seasonname){ echo "selected";} ?>><?=$season->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Method</td>
								<td>
									<?php //$methodname;?>
									<select name="method">
										<?php foreach($all_methods as $method){ ?>
											<option value="<?=$method->id?>" <?php if($method->name == $methodname){ echo "selected";} ?>><?=$method->name?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Image</td>
								<?php if($row->images == "") { ?>
								<td>
									--
								</td>
								<?php } else {
									$img = explode(",", $row->images);?>
									<td>
										<table>
											<tr>
												<?php foreach($img as $key => $val) { ?>
													<td><!-- <i class="icon-remove icon-white"></i>remove_s btn btn-small btn-danger-->
														<input type="button" class="btn btn-small btn-danger"  id="<?=$key?>" name="<?=$val?>" value="Remove"  onclick="removeimage(this)"/><br><br>
														<a href="<?=base_url();?>public/frontend/images/recipe/1004x400/<?=$val?>" rel="lightbox[food]">
															<img id="img_<?=$key?>" name="pimage" src="<?=base_url();?>public/frontend/images/recipe/50x50/<?=$val?>" border="black"/>
														</a>
													</td>
												<?php } ?>
											</tr>
										</table>
									</td>
								<?php } ?>
							</tr>
							<tr>
								<td>Video</td>
								<?php if($row->video == "") { ?>
									<td>
										--
									</td>
								<?php } else { 
									$video = explode(",", $row->video);?>
									<td>
										<table>
											<?php foreach($video as $val) { ?>
												<tr>
													<a href='<?=$val;?>'> <?=$val;?> </a>
												</tr>
											<?php } ?>
										</table>
									</td>
									
								<?php } ?>
							</tr>
							<tr>
								<td>Preparation Details</td>
								<td>
									<?php //$row->preparationdetails;?>
									<textarea rows="6" cols="50" name="preparation_details" style=" width: 547px !important;">
									 	<?=$row->preparationdetails;?>
									</textarea>
								</td>
							</tr>
							<tr>
								<td>Ingredient Details</td>
								<td>
									<?php //$row->ingredientdetails;?>
									<textarea rows="6" cols="50" name="ingredient_details" style=" width: 547px !important;">
									 	<?=$row->ingredientdetails;?>
									</textarea>
								</td>
							</tr>
							<tr>
								<td>Calories</td>
								<td>
									<?php //$row->calories;?>
									<input type="text" name="calories" value="<?=$row->calories;?>">
								</td>
							</tr>
							<tr>
								<td>Serves</td>
								<td>
									<?php //$row->serves;?>
									<input type="text" name="serves" value="<?=$row->serves;?>">
								</td>
							</tr>
							<tr>
								<td>Approval</td>
								<td>
									<?php if($row->approved == "1") { ?>
										<input type="checkbox" name="papproval" checked="checked"/>
									<?php } else { ?>
										<input type="checkbox" name="papproval" />
									<?php } ?>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td>
									<input class="btn btn-primary" type="submit" name="sbt_update" value="Update"  onclick="return checkname()"/>
								</td>
							</tr>
						</table>
					</form>
				<?php } ?>
			<?php } ?>		
	</div>
</div>
</div>
