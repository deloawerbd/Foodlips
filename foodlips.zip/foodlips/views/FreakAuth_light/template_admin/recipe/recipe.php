	<div id="content">
<div class="container">
	<div class="row">
		<div class="span3">
			<span class="heading">Manage Recipe</span>
		</div>
	</div>
	<hr>
	</div>
	<div class="row">
		<div class="span3 offset0 marginbottom5">
			<?php echo $pagination; ?>
		</div>
		<div class="span9 marginbottom5">
			<p id="recipeMsg" class="err hideerr textright"></p>
		</div>
	</div>
	<br />
	<div class="container">
	<table id="recipeTbl" class="table table-strip table-hover">
		<thead>
			<th width="600">
				Title
			</th>
			<th width="200">
				Category
			</th>
			<th width="150">
				No of Image
			</th>
			<th width="150">
				No of Video
			</th>
			<th width="150">
				Preparation time
			</th>
			<th width="150">
				Serves
			</th>
			<th width="70">
				Action
			</th>
			<th width="150">
				Recipe of the day
			</th>
		</thead>
		<?php if(!isset($records)) {	?>
		<tr>
			<td colspan="4" width="100" align="center">
				<span class="noresult">Recipe not found</span>
			</td>
		</tr>
		<?php }else { ?>
			<?php foreach ($records as $row) { ?>
			<tr>
				<td align="left">
					<?=substr($row->title,0,50);?>				
				</td>
				
				<?php foreach($categoryname as $key => $value) { ?>
					<?php if($key==$row->categoryid) { ?>
						<td align="left">
							<?=$value;?>
						</td>
					<?php } ?>
				<?php } ?>
				<td align="left">
					<?=count(explode(",", $row ->images));?>			
				</td>
				<td align="left">
					<?=count(explode(",", $row ->video));?>			
				</td>
				<td align="left">
					<?=$row->preparationtime;?>			
				</td>
				<td align="left">
					<?=$row->serves;?>			
				</td>
				<td align="left">
					<a href="<?=base_url();?>admin/recipe/editrecipe/<?=$row->id?>">
						<img id="d" src="<?=base_url();?>public/admin/images/pencil.png" title="Edit" alt="Edit" />
					</a>
					<!-- &nbsp;|&nbsp;
					<a href="<?=base_url();?>admin/recipe/viewrecipe/<?=$row->id?>" target="_blank">
						<img id="d" src="<?=base_url();?>public/admin/images/zoom.png" title="View" alt="View" />
					</a> -->
					&nbsp;|&nbsp;
					<a href="<?=base_url();?>admin/recipe/deleterecipe/<?=$row->id?>" >
						<img  src="<?=base_url();?>public/admin/images/cross.png" title="Delete" alt="Delete" />
					</a>
				</td>
				<td style="text-align: center;">
					<?php $checked = ""; ?>
					<?php if($row->recipeofday == "1") { ?>
						<?php $checked = "checked"; ?>
					<?php } ?>
					<input id="<?=$row->id;?>" type="radio" name="recipeofday" <?=$checked;?> onclick="setRecipeOfDay(this.id)" />
				</td>
			</tr>
		<?php }	 ?>
		<?php }  ?>
		</table>
	</div>
	<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
	</div>
</div>