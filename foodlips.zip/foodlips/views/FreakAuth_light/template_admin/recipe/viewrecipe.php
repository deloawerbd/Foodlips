<span class="contentheading">View Recipe</span>
<hr class="hrstyle"/>

<?php if(isset($recipedetails)) { 	
  foreach ($recipedetails as $row) { ?>

	<div class="clearfloat"></div>
	<div class="leftside">
		<span class="tablecontent">Title</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$row->title;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Category</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$categoryname;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Course</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$coursename;?></label>
	</div>
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Type</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$typename;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Cuisine</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$cuisinename;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Season</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$seasonname;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Method</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$methodname;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Image</span>
	</div>
	
	<?php $imagename=explode(",", $row->images) ?>
	<?php foreach ($imagename as $image) {  ?>
	<div class="rightside">
			<img class="imagesize" src="<?=base_url();?>public/frontend/images/<?=$image;?>" alt="No image found" /><br>
	</div>
	<?php } ?>
	
	 
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">video</span>
	</div>
	<div class="rightside">
		<a href="<?=$row->video;?>" ><?=$row->video;?></a>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Preparation Details</span>
	</div>
	<div class="rightside">
		<p  class="showdes" name="description" ><?=$row->preparationdetails;?></p>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Ingredient Details</span>
	</div>
	<div class="rightside">
		<p  class="showdes" name="description" ><?=$row->ingredientdetails;?></p>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Calories</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$row->calories;?></label>
	</div>
	
	<div class="clearfloat"></div>			
	<div class="leftside">
		<span class="tablecontent">Serves</span>
	</div>
	<div class="rightside">
		<label class="lbltxt"><?=$row->serves;?></label>
	</div>
	
 <?php }
 } ?>
 	
</div>