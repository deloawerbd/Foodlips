<!DOCTYPE html>
<html lang="en">
   <head>
	   	<title><?=$this->config->item('FAL_website_name')?> Administration Console &raquo;</title>
   		
   		<meta charset="utf-8">
       	<meta name="viewport" content="width=device-width, initial-scale=1.0">
       	<meta name="description" content="">
       	<meta name="author" content="">

       	<!-- Le styles -->
       	<link href="<?=base_url();?>public/shared/css/bootstrap/bootstrap.css" rel="stylesheet">
       	<link href="<?=base_url();?>public/shared/css/bootstrap/bootstrap-responsive.css" rel="stylesheet">
       	<link type="text/css" rel="stylesheet" href="https://www.foodlips.com/shared/public/frontend/css/font/css/font-awesome.min.css" />
       	<link href="<?=base_url();?>css/lightbox/lightbox.css" rel="stylesheet" />
       	<link href="<?=base_url();?>css/ajaxloading/jquery.loadmask.css" rel="stylesheet">
       	<link href="<?=base_url();?>public/shared/css/admincustom.css" rel="stylesheet">
       	<!--Light Box Plugin css-->
		<link type="text/css" rel="stylesheet" href="https://www.foodlips.com/shared/css/lightbox/lightbox.css" />
		
		<!--Loadmask css for loding mask-->
		<link type="text/css" rel="stylesheet" href="https://www.foodlips.com/shared/css/ajaxloading/jquery.loadmask.css" />

           
      	<script type="text/javascript" charset="utf-8">
      		var baseurl = "<?=base_url();?>";
      		var checkCount = 0;
      		var checkCount1 = 0;
      	</script>
      	
		<script src="<?=base_url();?>js/jquery-1.7.2.min.js"></script>
		 <script src="<?=base_url();?>public/admin/js/wineries/wineriesrequesthandler.js"></script>
           <script src="<?=base_url();?>public/admin/js/restaurants/restaurantsrequesthandler.js"></script>
          <script src="<?=base_url();?>public/admin/js/restaurants/restaurants.js"></script>
           <script src="<?=base_url();?>public/admin/js/wineries/wineries.js"></script>
		<!--jquery ui js-->
		<script type="text/javascript" src="https://www.foodlips.com/shared/public/frontend/js/jquery-ui.js"></script>
		
		<!--jquery Form js-->
		<script type="text/javascript" src="https://www.foodlips.com/shared/public/frontend/js/jquery.form.js"></script>
		
		<!--jquery Lightbox js-->
		<script type="text/javascript" src="https://www.foodlips.com/shared/js/lightbox/lightbox.js"></script>
		
		<!--jquery Loadmask js-->
		<script type="text/javascript" src="https://www.foodlips.com/shared/js/ajaxloading/jquery.loadmask.js"></script>
		 		
  		<!-- block ui js -->
  		<script type="text/javascript" src="https://www.foodlips.com/shared/public/frontend/js/community/jquery.blockUI.js"></script>
  		 		
  		<!--validation js-->
  		<script src="https://www.foodlips.com/shared/public/frontend/js/jquery.validate.js"></script>
		<!--Tinymce Text Editor-->
		<script type="text/javascript" src="https://www.foodlips.com/shared/public/shared/js/tinymce/tinymce.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				tinymce.init({
					selector: "#description , #specialoffer",
					plugins: [
								"advlist autolink lists link image charmap print preview anchor",
								"searchreplace visualblocks code fullscreen"
							],
							toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
				});
			});
		</script>



           
		<!-- <script src="<?=base_url();?>js/lightbox/lightbox.js"></script>
		<script src="<?=base_url();?>js/ajaxloading/jquery.loadmask.js"></script> -->
		
       	<script src="<?=base_url();?>public/shared/js/foodlips.js"></script>
       	<script src="<?=base_url();?>public/shared/js/foodipsrequesthandler.js"></script>
			
       	<script type="text/javascript" charset="utf-8">
	  		$(document).ready(function() {
            	<?php if(isset($success) || isset($fail)) { ?>
              		$("#msg").fadeOut(3000);
               	<?php } ?>
            });
 		</script> 
     	<script type="text/javascript">
			var baseurl = "<?=base_url();?>";
		</script>
             
           <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
           <!--[if lt IE 9]>
             <script src="<?=base_url();?>public/shared/js/html5shiv.js"></script>
           <![endif]-->
       
           <!-- Fav and touch icons -->
       	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?=base_url();?>public/shared/ico/apple-touch-icon-144-precomposed.png">
      	 <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?=base_url();?>public/shared/ico/apple-touch-icon-114-precomposed.png">
      	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?=base_url();?>public/shared/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="<?=base_url();?>public/shared/ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="<?=base_url();?>public/shared/ico/favicon.png">
       </head>
       
       <body>
       <div class="container">
             <div class="masthead">
                    <h3 class="muted">
                           Powered by <a href='http://www.valueit.com/'>ValueIT</a>
                    </h3>
             </div>
                    <br clear="all" />
