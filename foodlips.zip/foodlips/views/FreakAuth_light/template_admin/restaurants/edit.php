<style>
.edittitle{
	font-size:23px;
}
.float-right{
	float: right;
}
</style>
<div class="container">
	<div class="row">
		<div class="span12">
			<span class="edittitle" >Edit Restaurant</span>
			<span class="float-right">
				<a href="<?=base_url()?>admin/restaurants" class="btn btn-primary">Back</a>
			</span> 
		</div>
	</div>
<hr>
<?php if(isset($restaurant)&&!empty($restaurant)) { ?>
<?php $attributes = array("id"=>"frmaddrestaurant", "class"=>"form-horizontal","method"=>"post");?>
<?= form_open_multipart("admin/restaurants/editrestaurant/$restaurant->id",$attributes)?>
	<div class="add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select Country <span class="asterisk">*</span></div>
		<div class="add_restaurant_fild_box">
			<select id="selcountry" name="country">
				<option value="" selected="selected">Select Country</option>
				<?php if(isset($countries) && !empty($countries)) { ?>
					<?php foreach($countries as $country) { ?>
						<?php if($country->id==$restaurant->countryid){ ?>
							<option value="<?=$country->id;?>" selected="selected"><?=$country->name;?></option>
						<?php }else{?>
							<option value="<?=$country->id;?>"><?=$country->name;?></option>
						<?php } ?>
					<?php }?>
				<?php }?>
			</select>
			<i id="sateloader" class="icon-spinner icon-spin" style="display: none"></i>
			<div class="errmsg"><?php echo form_error("country"); ?></div>
		</div>
	</div>
	<div id="satecombo" class="add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select State</div>
		<div class="add_restaurant_fild_box">
			<?php $where = array("country_id"=>$restaurant->countryid);?>
			<?php $state = $this->restmodel->getstatesbycountryid($where);?>
			<?php //print_r($state);exit;?>
			<select id="selstate" name="state">
				<?php if(isset($state)&& !empty($state)){?>
					<?php foreach($state as $state){ ?>
						<?php if($state->id == $restaurant->stateid){ ?>
							<option value="<?=$state->id?>" selected="selected"><?= $state->state_name ?></option>		
						<?php }else{ ?>
							<option value="<?=$state->id?>" ><?= $state->state_name ?></option>
						<?php } ?>
						
					<?php } ?>
				<?php } ?>
			</select>
			<i id="cityloader" class="icon-spinner icon-spin" style="display: none;"></i>
		</div>
	</div>
	<div id="citycombo" class="add_restaurant_outer">
		<div class="add_restaurant_fild_name"> Select City</div>
		<div class="add_restaurant_fild_box">
			<?php $where = array("stateid"=>$restaurant->stateid);?>
			<?php $cities = $this->restmodel->getcitieswhere($where);?>
			<select id="selcity" name="city">
				<?php if(isset($cities)&& !empty($cities)){?>
					<?php foreach($cities as $city){ ?>
						<?php if($city->id == $restaurant->cityid){ ?>
							<option value="<?=$city->id?>" selected="selected"><?= $city->name ?></option>		
						<?php }else{ ?>
							<option value="<?=$city->id?>" ><?= $city->name ?></option>
						<?php } ?>
						
					<?php } ?>
				<?php } ?>
			</select>
		</div>
	</div>
	<div class="add_restaurant_outer">
		<div class="add_restaurant_fild_name">Listing Title <span class="asterisk">*</span></div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="Enter Winery Title" name="title" value="<?=$restaurant->title;?>" class="add_restaurant_txtinput margin_bottom_2">
			<div class="add_restaurant_flashtxt">Restaurant listing title.</div>
			<div class="errmsg"><?php echo form_error("title"); ?></div>
		</div>
	</div>
	<div class="add_restaurant_outer">
		<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script type="text/javascript" src="<?=base_url();?>/public/frontend/js/restaurants/restaurantsetmap.js"></script>
		<div class="add_restaurant_fild_name">Address <span class="asterisk">*</span></div>
		<div class="add_restaurant_fild_box">
			<input type="text" id="geo_address" name="geo_address" class="add_restaurant_txtinput margin_bottom_2" value="<?=$restaurant->geo_address;?>" >
			<div class="add_restaurant_flashtxt">
				Please enter restaurant address. eg. : <span class="font_bold"> 230 Vine Street And locations throughout Old City, Philadelphia, PA 19106</span>
			</div>
			<div class="errmsg"><?php echo form_error("geo_address"); ?></div>
			<div class="add_restaurant_wrap padding_top">
				<input type="button" class="btn" onclick="geocode();initialize();" value="Set address on map">
			</div>
			<div id="map_canvas" class="add_restaurant_map margin_top_20" style="height: 350px; width: 450px;">
				<!-- <img src="<?=base_url();?>public/frontend/images/restaurents/state_map.jpg" alt="banner1" /> -->
			</div>
			<div class="add_restaurant_flashtxt margin_top_10">
				Click on "Set Address on Map" and then you can also drag pinpoint to locate the correct address
			</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">
			Address Latitude
		</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" onblur="changeMap();" class="add_restaurant_txtinput margin_bottom_2" value="<?=$this->input->post("geo_latitude");?>" id="geo_latitude" name="geo_latitude">
		</div>
	</div>
					
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">
			Address Longitude
		</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" onblur="changeMap();" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("geo_longitude");?>" id="geo_longitude" name="geo_longitude">
		</div>
	</div>
		
	<div class = "add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select Cuisine</div>
		<div class="add_restaurant_fild_box">
			<select id="selcuisine" name="selcuisine">
				<option value="0">Select Cuisine</option>
				<?php if(isset($cuisines) && !empty($cuisines)) :?>
					<?php foreach($cuisines as $cuisine) :?>
							<?php if($cuisine->id==$restaurant->cuisineid){ ?>
								<option value="<?=$cuisine->id;?>" selected="selected"><?=$cuisine->name;?></option>
							<?php }?>
						<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
					<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</div>
	</div>
	
	<div class = "add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select Category</div>
		<div class="add_restaurant_fild_box">
			<select id="selcategory" name="selcategory">
				<option value="0">Select Category</option>
				<?php if(isset($categories) && !empty($categories)) :?>
					<?php foreach($categories as $category) :?>
							<?php if($category->id==$restaurant->categoryid){ ?>
								<option value="<?=$category->id;?>" selected="selected"><?=$category->name;?></option>
							<?php }?>
						<option value="<?=$category->id;?>"><?=$category->name;?></option>
					<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</div>
	</div>
		
	<div class = "add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select Features</div>
		<div class="add_restaurant_fild_box">
			<?php $selectedfeatures =  unserialize($restaurant->featureid)?>
			<?php //print_r($selectedfeatures);?>
			<select id="selfeature" name="selfeature[]" multiple="multiple" size="6">
				<?php if(isset($features) && !empty($features)) : ?>
					<?php foreach($features as $feature) : ?>
							<?php if(in_array($feature->id, $selectedfeatures)) {?>
								<option value="<?=$feature->id;?>" selected><?=$feature->name;?></option>
							<?php }else{ ?>
								<option value="<?=$feature->id;?>"><?=$feature->name;?></option>
							<?php } ?>
					<?php endforeach;?>
				<?php endif;?>
			</select>
			<div class="add_restaurant_flashtxt margin_top_10">Hold Down Ctrl for Multiple features selection</div>
		</div>
	</div>		
	<div class="add_restaurant_outer">
		<div class="add_restaurant_fild_name">Select Price</div>
		<div class="add_restaurant_fild_box">
			<select id="selprice" name="selprice">
				<option value="0">Select Price</option>
				<?php if(isset($prices) && !empty($prices)) : ?>
					<?php foreach($prices as $price) : ?>
						<?php if($price->id==$restaurant->price){ ?>
								<option value="<?=$price->id;?>" selected="selected"><?=$price->name;?></option>
							<?php }?>
						<option value="<?=$price->id;?>"><?=$price->name;?></option>
					<?php endforeach;?>
				<?php endif;?>
			</select>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">
			Listing Description <span class="asterisk">*</span>
		</div>
		<div class="add_restaurant_fild_box">
			<div class="add_restaurant_txteditor">
				<!-- <img src="../images/aad_rest_editor.jpg" alt="Add Restaurant Editor" /> -->
				<textarea id="description" style="width:100%" name="description"><?=$restaurant->content;?></textarea>
			</div>
			<div class="add_restaurant_flashtxt margin_top_10">
				Note : Basic HTML tags are allowed
			</div>
			<div class="errmsg"><?php echo form_error("description"); ?></div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">
			Special Offers
		</div>
		<div class="add_restaurant_fild_box">
			<div class="add_restaurant_txteditor">
				<textarea id="specialoffer" style="width:100%" name="specialoffer"><?=$restaurant->special_offers;?></textarea>
			</div>
			<div class="add_restaurant_flashtxt margin_top_10">
				Note: List out any special offers (optional)
			</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Time</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$restaurant->timing;?>" id="timing" name="timing">
			<div class="add_restaurant_flashtxt margin_top_10">
				Enter Business or Listing Timing Information.
				<br />
				eg. : <span class="font_bold">10.00 am to 6 pm every day </span>
			</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Phone <span class="asterisk">*</span></div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$restaurant->contact;?>" id="contact" name="contact">
			<div class="add_restaurant_flashtxt margin_top_10">
				You can enter phone number,cell phone number etc.
			</div>
			<div class="errmsg"><?php echo form_error("contact"); ?></div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Email <span class="asterisk">*</span></div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$restaurant->email;?>" id="txtemail" name="txtemail">
			<div class="errmsg"><?php echo form_error("txtemail"); ?></div>
		</div>
	</div>
		
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Website</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$restaurant->website;?>" id="website" name="website">
			<div class="add_restaurant_flashtxt margin_top_10">
				Enter website URL. eg. : <span class="font_bold">http://sitename.com</span>
			</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Twitter</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2" value="<?=$restaurant->twitter;?>" id="twitter" name="twitter">
			<div class="add_restaurant_flashtxt margin_top_10">
				Enter twitter URL. eg. :  <span class="font_bold">http://twitter.com/mysite</span>
			</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Facebook</div>
		<div class="add_restaurant_fild_box">
			<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2" value="<?=$restaurant->facebook;?>" id="facebook" name="facebook">
			<div class="add_restaurant_flashtxt margin_top_10">
				Enter facebook URL. eg. :  <span class="font_bold"> http://facebook.com/mysite</span>
			</div>
		</div>
	</div>
	<div id="restaurantimageloading" class="add_restaurant_outer margin_bottom_10">
		<div class="well_custom4 padding_top border_bottom_1 margin_bottom_10">
			<div class="add_restaurant_txt">
				Add images : <span style="color:#999999;">(You can upload more than one images to create image gallery on detail page)</span>
			</div>
		</div>
		<div class="add_restaurant_fild_name">Select Images</div>
		<div class="add_restaurant_fild_box">
			<div class="add_restaurant_wrap">
				<input type="file" id="restaurantimgfile" name="userfile"  title="" multiple ="true" />
				<!-- <button class="btn" type="submit">Upload Image</button> -->
				<ul id="image-list">
					<?php if(isset($restaurant->images)&&!empty($restaurant->images)) { ?>
						<?php $images = unserialize($restaurant->images) ?>
						<?php foreach($images as $image){ ?>
<!-- 								<li id="<?= $image?>"> -->
						<?php $imagearray = array(); 
							$imagearray = explode(".",$image) ?>
							<li id="<?=$imagearray[0];?>">
								<span class="selectimg_inner">
                                    <img src="<?=base_url()?>public/frontend/images/restaurents/home/100x100/<?=$image?>" alt=""  width='70' height='70'>
                                </span>
                                <span class="selectimg_innertxt">
                                	<span id = "<?=$image?>,<?= $restaurant->id?>" class='btn btn_remove' onclick="removerestSavedImage(this)"><i class="fa fa-trash"></i></span>
									<input type="hidden" name="imagearray[]" value="<?=$image;?>" />
                                </span>
							</li>
					<?php } ?>
					<?php } ?>
				</ul>
			</div>
			<!-- <div class="add_restaurant_flashtxt margin_top_10">
				Note : You can sort images from Dashboard and then clicking on " Edit" in the listing
			</div> -->
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name">Video code</div>
		<div class="add_restaurant_fild_box">
			<div class="add_restaurant_wrap">
				<textarea style="width:96%; height: 150px;" class="add_rest_txtareainput" id="video" name="video"><?=$restaurant->video;?></textarea>
			</div>
			<div class="add_restaurant_flashtxt margin_top_10">Paste video code here</div>
		</div>
	</div>
	<div class="add_restaurant_outer margin_bottom_10">
		<div class="add_restaurant_fild_name"></div>
		<div class="add_restaurant_fild_box">
			<input type="submit" class="btn" value="Submit" name="sbt_add" />
		</div>
	</div>
		
<?= form_close();?>
<?php }else {?>
	No such restaurant found 
	<?php }?>
</div>