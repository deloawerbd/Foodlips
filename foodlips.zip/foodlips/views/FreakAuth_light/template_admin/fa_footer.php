<!--START FOOTER-->
<div id="footer">
    <p><a href="#top">Top of Page</a></p>
    <p>
        <a href="http://www.codeigniter.com">Code Igniter</a> &nbsp;&middot;&nbsp; Copyright &#169; 2007 &nbsp;&middot;&nbsp;
        <?=anchor('http://www.4webby.com/freakauth/donate.html', 'DONATIONS', array('title' => 'DONATIONS', 'target' =>'_blank'))?>
        &nbsp;&middot;&nbsp;<?=anchor('http://www.4webby.com/freakauth/feed.html', 'RSS UPDATES', array('title' => 'RSS UPDATES', 'target' =>'_blank'))?>
        &nbsp;&middot;&nbsp;<a href="http://www.4webby.com">4webby.com</a>
    </p>
</div>
<!--END FOOTER-->
</body>
</html>
