<div id="content">
	<div class="container">
		<div class="well span6 offset2">
			<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/ingredients">Back</a>
			</div>

			<span class="smallheading marginbottom20">Add new ingredient</span>
			
			<br /><br />
			
			<?php echo form_open_multipart('admin/recipe/addingredient'); ?>
			<!-- <form action="<?=base_url();?>admin/recipe/addingredient" method="post" enctype="multipart/form-data"> -->
			<table class="table table-borderless">
				<tr>
					<td>Name</td>
					<td>
						<input type="text" id="name" name="name" value="<?=$this->input->post('name')?>" size="80" />
						<span class="err"><?php echo form_error('name'); ?></span>
						<p id="nameerr" class="hideerr err">The Name field is required</p>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>
						<input class="btn btn-primary" type="submit" name="sbt_add" value="Add" onclick="return checkname()"/>
					</td>
				</tr>
			</table>
		</form>		
		</div>
	</div>
</div>
