<?php $ci_uri = trim($this -> uri -> uri_string(), '/');
$att = ' class="active" ';
?>

<div class="navbar">
               <div class="navbar-inner">
                <a class="brand" href="<?=base_url();?>"><?=$this -> config -> item('FAL_website_name') ?></a>
                <ul class="nav">
                 <li class="dropdown">
    					<a class="dropdown-toggle"
       					data-toggle="dropdown"
       					href="#">
        				Recipe
        				<b class="caret"></b>
      					</a>
    					<ul class="dropdown-menu">
    						<li<?= (preg_match('|^admin/recipe/category|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcategory|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcategory|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/category', 'Category'); ?></li>
               				<li<?= (preg_match('|^admin/recipe/course|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcourse|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcourse|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/courses', 'Course'); ?></li>
                			<li<?= (preg_match('|^admin/recipe/type|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addtype|', $ci_uri) > 0) || (preg_match('|^admin/recipe/edittype|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/types', 'Type'); ?></li>
                			<li<?= (preg_match('|^admin/recipe/cuisine|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcuisine|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcuisine|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/cuisines', 'Cuisine'); ?></li>
                			<li<?= (preg_match('|^admin/recipe/season|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addseason|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editseason|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/seasons', 'Season'); ?></li>
                			<li<?= (preg_match('|^admin/recipe/methods|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addmethods|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editmethod|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/methods', 'Methods') ?></li>
                			<li<?= (preg_match('|^admin/recipe/recipe|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editrecipe|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/recipe', 'Recipe'); ?></li>
                			<li<?= (preg_match('|^admin/recipe/comments|', $ci_uri) > 0) || (preg_match('|^admin/recipe/viewcomments|', $ci_uri) > 0)  ? $att : '' ?>><?=anchor('admin/recipe/comments', 'Comments') ?></li>
                			<li<?= (preg_match('|^admin/recipe/ingredient|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addingredient|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editingredient|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/ingredients', 'Ingredients'); ?></li>
				 			
    					</ul>
					</li>        
  <!--               <li<?= (preg_match('|^admin/restaurants|', $ci_uri) > 0) || (preg_match('|^admin/restaurants|', $ci_uri) > 0)  ? $att : '' ?>><?=anchor('admin/restaurants', 'Restaurants') ?></li> -->
                 <li class="dropdown">
    					<a class="dropdown-toggle"
       					data-toggle="dropdown"
       					href="<?=base_url();?>admin/restaurants">
        				Restaurants
        				<b class="caret"></b>
      					</a>
    					<ul class="dropdown-menu">
    						<li><?=anchor('admin/restaurants', 'Restaurants') ?></li>
    						<li><?=anchor('admin/restaurants/managephotos', 'Manage Photos'); ?></li>		
    						<li><?=anchor('admin/restaurants/managefeatures', 'Manage Features'); ?></li>	
    						<li><?=anchor('admin/restaurants/suggestions', 'Suggestions'); ?></li>			 			
    					</ul>
					</li>       
  
 <!--                 <li<?= (preg_match('|^admin/wineries|', $ci_uri) > 0) || (preg_match('|^admin/wineries|', $ci_uri) > 0)  ? $att : '' ?>><?=anchor('admin/wineries', 'Wineries') ?></li> -->
 
                 <li class="dropdown">
    					<a class="dropdown-toggle"
       					data-toggle="dropdown"
       					href="<?=base_url();?>admin/wineries">
        				Wineries
        				<b class="caret"></b>
      					</a>
    					<ul class="dropdown-menu">
    						<li><?=anchor('admin/wineries', 'Wineries') ?></li>
    						<li><?=anchor('admin/wineries/managephotos', 'Manage Photos'); ?></li>		
    						<li><?=anchor('admin/wineries/managefeatures', 'Manage Features'); ?></li>	
    						<li><?=anchor('admin/wineries/managefeatures', 'Manage Features'); ?></li>
    						<li><?=anchor('admin/wineries/suggestions', 'Suggestions'); ?></li>			 			
    					</ul>
					</li>                
                <!-- <li<?= (preg_match('|^admin/recipe/category|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcategory|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcategory|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/category', 'Category'); ?></li>
                <li<?= (preg_match('|^admin/recipe/course|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcourse|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcourse|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/courses', 'Course'); ?></li>
                
                <li<?= (preg_match('|^admin/recipe/type|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addtype|', $ci_uri) > 0) || (preg_match('|^admin/recipe/edittype|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/types', 'Type'); ?></li>
                <li<?= (preg_match('|^admin/recipe/cuisine|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addcuisine|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editcuisine|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/cuisines', 'Cuisine'); ?></li>
                <li<?= (preg_match('|^admin/recipe/season|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addseason|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editseason|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/seasons', 'Season'); ?></li>
                
                <li<?= (preg_match('|^admin/recipe/methods|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addmethods|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editmethod|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/methods', 'Methods') ?></li>
                <li<?= (preg_match('|^admin/recipe/recipe|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editrecipe|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/recipe', 'Recipe'); ?></li>
                <li<?= (preg_match('|^admin/recipe/comments|', $ci_uri) > 0) || (preg_match('|^admin/recipe/viewcomments|', $ci_uri) > 0)  ? $att : '' ?>><?=anchor('admin/recipe/comments', 'Comments') ?></li>
                <li<?= (preg_match('|^admin/recipe/ingredient|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addingredient|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editingredient|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/ingredients', 'Ingredients'); ?></li> -->
				
				 <li<?= (preg_match('|^admin/recipe/homeimage|', $ci_uri) > 0) || (preg_match('|^admin/recipe/addimage|', $ci_uri) > 0) || (preg_match('|^admin/recipe/editimage|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/homeimage', 'Home image'); ?></li>
				 <li<?= (preg_match('|^admin/recipe/frontvideo|', $ci_uri) > 0) || (preg_match('|^admin/recipe/frontvideo|', $ci_uri) > 0) || (preg_match('|^admin/recipe/frontvideo|', $ci_uri) > 0) ? $att : '' ?>><?=anchor('admin/recipe/frontvideo', 'Front Video'); ?></li>               
               
                <?
                    if($this->db_session->userdata("id")!=''){
                        ?>
                           <li><a href="<?=base_url(); ?>auth/logout">Logout</a></li>
                        <?
                        }else{
                        ?>
                            <li><a href="<?=base_url(); ?>auth/login">Login</a></li>
                            
                        <?

                        }
                ?>
                </ul>
             </div>
 </div>






<? /*	<div id="icon_box">
		<div id="icon_box_1">
    		<div id="home_bg">
      			<div id="home_icon">
      				<a href="#"><img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/home_icon.png" width="95" height="75" alt="home" /></a>
  				</div>
  				<p>
  					<a href="#">HOME</a>
				</p>
			</div>
      		<div id="home_shadow"></div>
    	</div>
    	
    	<div id="icon_box_2">
    		<div id="email_bg">
      			<div id="email_icon">
      				<a href="<?=base_url()?>admin/cms">	
  						<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/email_icon.png" width="95" height="75" alt="email" />
					</a>
				</div>
				<p>
					<a href="<?=base_url()?>admin/cms">CMS</a>
				</p>
			</div>
      		<div id="email_shadow"></div>
      	</div>
    	
    	<div id="icon_box_3">
    		<div id="services_bg">
      			<div id="services_icon">
      				<a href="#">
      					<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/services_icon.png" width="95" height="75" alt="services" />
  					</a>
				</div>
				<p>
					<a href="#">SERVICES</a>
				</p>
			</div>
      		<div id="services_shadow"></div>
    	</div>
    	
    	<div id="icon_box_4">
     		<div id="blog_bg">
      			<div id="blog_icon">
      				<a href="#">
  						<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/blog_icon.png" width="95" height="75" alt="blog" />
					</a>
				</div>
				<p>
					<a href="#">BLOGS</a>
				</p>
			</div>
			<div id="blog_shadow"></div>
		</div>
    </div>
*/ ?>