                    </div> <!--BODY CLOSE HERE /container --> 
             <div class='container'>
             <div class="footer">
                    <p>
                           <p align="center">&copy; FoodLips 2013</p>
                                 <!-- Copyright © 2011 - 2012 <span class="websitelink"><a href="<?=base_url();?>" target="_blank"><?=$this->config->item('FAL_website_name');?></a></span> -All Right Reserved -->
                           </p>
             </div>
             </div>
       
             <!-- Le javascript
           ================================================== -->
           <!-- Placed at the end of the document so the pages load faster -->
           <!-- <script src="<?=base_url();?>public/shared/js/jquery.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-transition.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-alert.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-modal.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-dropdown.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-scrollspy.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-tab.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-tooltip.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-popover.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-button.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-collapse.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-carousel.js"></script>
           <script src="<?=base_url();?>public/shared/js/bootstrap/bootstrap-typeahead.js"></script> -->
       
       </body>
</html>
