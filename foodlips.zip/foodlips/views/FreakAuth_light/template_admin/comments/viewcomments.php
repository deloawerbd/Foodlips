<div id="content">
<div class="container">
	<div class="well span8 offset2">
		<div class="marginbottom20">
				<a class="btn btn-primary" href="<?=base_url();?>admin/recipe/comments">Back</a>
		</div>
		<span class="smallheading marginbottom20">View comment</span>
		<br /><br />
		
		<?php if(isset($comments)) { 	?>
			<table class="table table-borderless">
				<tr>
					<td width="150px">
						<span>User name</span>
					</td>
					<td>
						<p class="lbltxt"> <?=$username;?></p>
					</td>
				</tr>
				<tr>
					<td>
						<span>Recipe name</span>
					</td>
					<td>
						<p class="lbltxt"> <?=$recipename;?></p>
					</td>
				</tr>
				<tr>
					<!-- <td>
						<span>Image</span>
					</td> -->
					<!-- <td>
						<table>
							<?php $image = explode(",", $recipeimage); ?>
								<?php foreach($image as $img) { ?>
									<tr>
										<a href="<?=base_url();?>public/frontend/images/recipe/1004x400/<?=$img;?>" rel="lightbox[plants]">
											<img  src="<?=base_url();?>public/frontend/images/recipe/275x198/<?=$img;?>"  border="black"/>
										</a>
										<br /><br /><br />
									</tr>							
								<?php } ?>
						</table>
					</td> -->	
				</tr>
				<tr>
					<td>
						<span>Comment</span>
					</td>
					<td>
						<p class="lbltxt"><?=$body;?></p>
						
					</td>
				</tr>
			</table>
		<?php } ?>
	</div>
</div>
</div>