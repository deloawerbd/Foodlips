<div id="content">
<div class="container">
	<div class="row">
		<div class="span3">
			<span class="heading">Manage Comments</span>
		</div>
	</div>
	<hr>
	</div>
	<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
	</div><br /><br />
	
	<div class="container">
	<table class="table table-strip table-hover">
		<thead>
			<th width="150">
				User name
			</th>
			<th width="150">
				Recipe name
			</th>
			<th width="150">
				Image
			</th>
			<th width="550">
				Comment
			</th>
			<th width="50">
				Action
			</th>
		</thead>
		
		<?php if(!isset($comments)) {	?>
		<tr>
			<td colspan="4" width="100" align="center">
				<span class="noresult">No comments found</span>
			</td>
		</tr>
		<?php }else { ?>
			<?php foreach ($comments as $comment) { ?>
			<tr>
				<td>
					<?php foreach($username as $id => $name) { ?>
						<?php if($id==$comment->uid) { ?>
							<?=$name;?>
						<?php } ?>
					<?php } ?>
				</td>
				<td>
					<?php foreach($recipename as $id => $name) { ?>
						<?php if($id==$comment->recipeid) { ?>
							<?=$name;?>
						<?php } ?>
					<?php } ?>
				</td>
				
				<td>
					<table>
						<tr>
							<?php foreach($recipeimage as $id => $image) { ?>
								<?php if($id==$comment->recipeid) { ?>
									<?php $img = explode(",", $image); ?>
										<!-- <a href="<?=base_url();?>public/frontend/images/recipe/50x50/<?=$img[0]?>" rel="lightbox" title="my caption"> -->
											<img name="image" src="<?=base_url();?>public/frontend/images/recipe/50x50/<?=$img[0]?>" width="50" height="50" border="black"/>
										<!-- </a> -->
											<?php break; ?>
								<?php } ?>
							<?php } ?>
						</tr>
					</table>	
				</td>
				<td align="left">
					<!-- <?= word_limiter($comment->comment, 10); ?> -->
					<?=substr($comment->comment,0,90);?>					
				</td>
				<td align="left">
					<a href="<?=base_url();?>admin/recipe/viewcomments/<?=$comment->id?>">
						<img id="d" src="<?=base_url();?>public/admin/images/zoom.png" title="View" alt="View" />
					</a>
					&nbsp;|&nbsp;
					<a href="<?=base_url();?>admin/recipe/deletecomments/<?=$comment->id?>" >
						<img  src="<?=base_url();?>public/admin/images/cross.png" title="Delete" alt="Delete" />
					</a>
				</td>
			</tr>
		<?php }	 ?>
		<?php }  ?>
		</table>
	</div>
	<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
	</div>
</div>
