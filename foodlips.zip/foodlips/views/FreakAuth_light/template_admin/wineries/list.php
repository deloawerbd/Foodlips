<div id="content">
	<div class="container">
      <div class="row">
		<div class="span3">
			<span class="heading">Manage Wineries</span>
		</div>
	  </div>
	  <hr>
    </div>

	<div class="container">
		<input type="hidden" value="<?=$mesg?>" id="mesg">
		<input type="hidden" value="<?=$pickscount?>" id="pickscount">
		<input type="hidden" value="<?=$mostpopularcount?>" id="mostpopularcount">
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
		<?= form_open("admin/wineries");?>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<div id="message" style="display: none;float: right">
			<div class="message"></div>
		</div>
		<table class="table table-strip table-hover">
			<thead>
				<th width="50%">
					Title
				</th>
				<th width="10%">
					Country
				</th width="10%">
				<th width="10%">
					State
				</th>
				<th width="10%">
					Most Popular
				</th>
				<th width="10%">
					Our Picks
				</th>
				<th width="10%">
					Action
				</th>
			</thead>
			<?php if(isset($wineries)){ ?>
			<?php foreach($wineries as $winery){?>
				<tr>
				<td align="left">
					<?= $winery->title?>
				</td>
				<td align="left">
					<?php if(isset($winery->countryname)&&!empty($winery->countryname)){?>
					<?= $winery->countryname?> 
					<?php } ?>
				</td>
				<td align="left">
					<?php if(isset($winery->statename)&&!empty($winery->statename)){ ?>
					<?= $winery->statename?> 
					<?php } ?>
				</td>
				<td align="center">
					<?php if($winery->mostpopular=="1"){ ?>
						<input type="checkbox" id="<?=$winery->id?>" name="check[]" class ="ourpicks" value="<?=$winery->id?>" onclick="setChecksForMostPopular(this)" checked>
					<?php }else { ?>
						<input type="checkbox" id="<?=$winery->id?>" name="check[]" class ="ourpicks" value="<?=$winery->id?>" onclick="setChecksForMostPopular(this)">
				 	<?php }?>
				</td>
				<td align="center">
					<?php if($winery->ourpicks=="1"){ ?>
						<input type="checkbox" id="<?=$winery->id?>" name="check[]" class ="ourpicks" value="<?=$winery->id?>" onclick="setwineryChecks(this)" checked>
					<?php }else { ?>
						<input type="checkbox" id="<?=$winery->id?>" name="check[]" class ="ourpicks" value="<?=$winery->id?>" onclick="setwineryChecks(this)">
				 	<?php }?>
				</td>
				<td align="left">
					<a href="<?=base_url();?>admin/wineries/editwinery/<?=$winery->id?>">
						<img id="d" src="<?=base_url();?>public/admin/images/pencil.png" title="Edit" alt="Edit" />
					</a>
<!-- 					<a href="<?=base_url();?>admin/wineries/editwinery/<?=$winery->id?>" class="btn btn-primary">Edit</a> -->
						<!--<img id="d" src="<?=base_url();?>public/admin/images/pencil.png" title="Edit" alt="Edit" />
					</a> -->
					<!-- <button onclick="<?=base_url();?>admin/wineries/editwinery/<?=$winery->id?>">Edit</button> -->
				</td>
				</tr>
				<?php }?>
				<?php }else 
				echo "No data found";
				?>
		</table>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<input type="hidden" name="checkedarray" id="checkedarray" value = "<?=$selected?>">
		<input type="hidden" name="checkedarray1" id="checkedarray1" value = "<?=$selected1?>">
		<?= form_close();?>
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
	</div>
</div>