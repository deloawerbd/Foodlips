<div id="content">
	<div class="container">
      <div class="row">
		<div class="span3">
			<span class="heading">Manage Winery Features</span>
		</div>
	  </div>
	  <hr>
    </div>

	<div class="container">
		<input type="hidden" value="<?=$mesg?>" id="mesg">
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
		<?= form_open("admin/wineries/managefeatures");?>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<div id="message" style="display: none;float: right">
			<div class="message"></div>
		</div>
		<table class="table table-strip table-hover">
			<thead>
				<th width="60%">
					Name of Winery
				</th>
				<th width="10%">
					Feature
				</th width="10%">
				<th width="10%">
					Approve
				</th>
				<th width="10%">
					Disapprove
				</th>
			</thead>
			<?php if(isset($wineries)){
				$row = 1;
			?>
			<?php foreach($wineries as $winery){
				$features = unserialize($winery->featureid);
				for($i=0; $i<count($features); $i++) {
					if($features[$i] != '') {
				?>
				<tr>
				<td align="left">
					<?= $winery->title?>
				</td>
				<td align="left">
					<?php
					$res = $this->restmodel->getfeaturebyid($features[$i]);
					?>
					<?= $res[0]->name ?>
				</td>	
				<td align="center">
					<input type="radio" id="agree[]<?=$winery->wid . '[]' . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i].'[]'.$winery->datalocation; ?>" name="<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i].'[]'.$winery->datalocation; ?>check[]" class ="ourpicks" value="agree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i].'[]'.$winery->datalocation; ?>" onclick="setChecksForAll(this,'agree')">
				</td>
				<td align="center">
					<input type="radio" id="disagree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i]; ?>" name="<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i].'[]'.$winery->datalocation; ?>check[]" class ="ourpicks" value="disagree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $features[$i]; ?>" onclick="setChecksForAll(this,'disagree')">
				</td>
				</tr>
				<?php 
				}
					$row++;
				}
				}?>
				<?php }else 
				echo "No data found";
				?>
		</table>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<input type="hidden" name="checkedarray" id="checkedarray" value = "">
		<input type="hidden" name="checkedarray1" id="checkedarray1" value = "">
		<?= form_close();?>
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
	</div>
</div>