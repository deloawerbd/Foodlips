<div id="content">
	<div class="container">
      <div class="row">
		<div class="span3">
			<span class="heading" >Manage Winery Photos</span>
		</div>
	  </div>
	  <hr>
    </div>

	<div class="container">
		<input type="hidden" value="<?=$mesg?>" id="mesg">
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
		<?= form_open("admin/wineries/managephotos");?>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<div id="message" style="display: none;float: right">
			<div class="message"></div>
		</div>
		<table class="table table-strip table-hover">
			<thead>
				<th width="60%">
					Name of Winery
				</th>
				<th width="10%">
					Photo
				</th>
				<th width="10%">
					Approve
				</th>
				<th width="10%">
					Disapprove
				</th>
			</thead>
			<?php if(isset($wineries)){
				$row = 1;
			?>
			<?php foreach($wineries as $winery){
				$photos = unserialize($winery->winery_img);
				for($i=0; $i<count($photos); $i++) {
					if($photos[$i] != '') {
				?>
				<tr>
				<td align="left">
					<?= $winery->title?>
				</td>
				<td align="left">
					<img src="<?=base_url().'public/frontend/images/wineries/168x168/'.$photos[$i];?>" height="168" width="168" alt="<?=base_url().'public/frontend/images/wineries/100x100/'.$photos[$i];?>">
				</td>
				<td align="center">
					<input type="radio" id="agree[]<?=$winery->wid . '[]' . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i].'[]'.$winery->datalocation; ?>" name="<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i].'[]'.$winery->datalocation; ?>check[]" class ="ourpicks" value="agree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i].'[]'.$winery->datalocation; ?>" onclick="setChecksForAll(this,'agree')">
				</td>
				<td align="center">
					<input type="radio" id="disagree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i]; ?>" name="<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i].'[]'.$winery->datalocation; ?>check[]" class ="ourpicks" value="disagree[]<?=$winery->wid . '[]'  . $winery->id . '[]' . $winery->uid . '[]' . $row . '[]' . $i . '[]' . $photos[$i]; ?>" onclick="setChecksForAll(this,'disagree')">
				</td>
				</tr>
				<?php 
				}
					$row++;
				}
				}?>
				<?php }else 
				echo "No data found";
				?>
		</table>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitpicks" class="btn btn-primary" value="Update Status" style="float: right; margin: 10px">
			</div>
		</div>
		<input type="hidden" name="checkedarray" id="checkedarray" value = "<?=$selected?>">
		<input type="hidden" name="checkedarray1" id="checkedarray1" value = "<?=$selected1?>">
		<?= form_close();?>
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
	</div>
</div>