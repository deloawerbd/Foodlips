<div id="content">
	<div class="container">
      <div class="row">
		<div class="span3">
			<span class="heading">Approve Suggestions</span>
		</div>
	  </div>
	  <hr>
    </div>

	<div class="container">
		<input type="hidden" value="<?=$mesg?>" id="mesg">
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
		<?= form_open("admin/wineries/suggestions");?>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitsuggestions" class="btn btn-primary" value="Apply" style="float: right; margin: 10px">
			</div>
		</div>
		<div id="message" style="display: none;float: right">
			<div class="message"></div>
		</div>
		<table class="table table-strip table-hover">
			<thead>
				<th width="30%">
					Restaurant
				</th>
				<th width="10%">
					Country
				</th>
				<th width="10%">
					Name
				</th>
				<th width="30%">
					Suggested
				</th>
				<th width="10%">
					Approve
				</th>
				<th width="10%">
					Delete
				</th>
			</thead>
			<?php $radionamearray = "";  ?>
			<?php if(isset($suggestions)){ ?>
			<?php foreach($suggestions as $suggestion){?>
				<?php $radionamearray .= $suggestion->radioname.","; ?>
				<tr>
				<td align="left">
					<?php if(isset($suggestion->winery_name)&&!empty($suggestion->winery_name)){?>
					<?= $suggestion->winery_name?> 
					<?php } ?>
				</td>
				<td align="left">
					<?php if(isset($suggestion->winery_country)&&!empty($suggestion->winery_country)){?>
					<?= $suggestion->winery_country?> 
					<?php } ?>
				</td>
				<td align="left">
					<?php if(isset($suggestion->name)&&!empty($suggestion->name)){ ?>
					<?= $suggestion->name?> 
					<?php } ?>
				</td>
				<td align="left">
					<?php if(isset($suggestion->suggested)&&!empty($suggestion->suggested)){ ?>
					<?= $suggestion->suggested?> 
					<?php } ?>
				</td>
				<td align="center">
						<input type = "radio" name="<?=$suggestion->radioname?>" value="<?=$suggestion->id?>">
				</td>
				<td align="center">
					<input type="checkbox" name="deletesuggestions[]" value="<?=$suggestion->id?>">
				</td>
				</tr>
				<?php }?>
				<?php }else 
				echo "No data found";
				?>
		</table>
		<div class="row">
			<div class="span12">
		<input type="submit" name="submitsuggestions" class="btn btn-primary" value="Apply" style="float: right; margin: 10px">
			</div>
		</div>
		<input type="hidden" name="radionamearray" value="<?= $radionamearray?>">
		<?= form_close();?>
		<div class="span3 offset0 marginbottom5">
		<?php echo $pagination; ?>
		</div><br /><br/>
	</div>
</div>