<div id="welcome"><h2>Welcome To Admin Area</h2>
    	<p>Notepad is a basic text-editing program and it's most commonly used to view or edit text files. A text file is a file type typically identified by the .txt file name extension.</p>
	</div>
	
	<div id="icon_box">
		<? /* <div id="icon_box_1">
    		<div id="home_bg">
      			<div id="home_icon">
      				<a href="#"><img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/home_icon.png" width="95" height="75" alt="home" /></a>
  				</div>
  				<p>
  					<a href="#">HOME</a>
				</p>
			</div>
      		<div id="home_shadow"></div>
    	</div> */ ?>
    	
    	<div id="icon_box_2">
    		<div class="icon_bg">
      			<a href="<?=base_url()?>admin/cms" class="add">add</a>
      			<p>
      				<a href="<?=base_url()?>admin/cms">ADVERTIES</a>
  				</p>
  			</div> 
      		<div class="icon_shadow"></div>
    		
    		<? /*<div class="icon_bg">
      			<div id="email_icon">
      				<a href="<?=base_url()?>admin/cms">	
  						<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/email_icon.png" width="95" height="75" alt="email" />
					</a>
				</div>
				<p>
					<a href="<?=base_url()?>admin/cms">CMS</a>
				</p>
			</div> 
      		<div id="email_shadow"></div>*/?>
      	</div>
    	
    	<div id="icon_box_3">
    		<? /*<div id="services_bg">
      			<div id="services_icon">
      				<a href="<?=base_url()?>admin/cms/utilities">
      					<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/services_icon.png" width="95" height="75" alt="services" />
  					</a>
				</div>
				<p>
					<a href="<?=base_url()?>admin/cms/utilities">USERS</a>
				</p>
			</div>
      		<div id="services_shadow"></div> */ ?>
      		<div class="icon_bg">
      			<a href="#" class="usersicon">users</a>
      			<p>
      				<a href="#">USERS</a>
  				</p>
			</div>
      		<div class="icon_shadow"></div>
    	</div>
    	
    	<div id="icon_box_4">
     		<? /* <div id="blog_bg">
      			<div id="blog_icon">
      				<a href="<?=base_url()?>admin/cms/advertise">
  						<img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/blog_icon.png" width="95" height="75" alt="blog" />
					</a>
				</div>
				<p>
					<a href="<?=base_url()?>admin/cms/advertise">ADVERTISE</a>
				</p>
			</div>
			<div id="blog_shadow"></div> */ ?>
			<div class="icon_bg">
      <a href="#" class="cmsicon">cms</a>
      <p><a href="#">CMS</a></p></div>
      <div class="icon_shadow"></div>
		</div>
		
		<div id="icon_box_1">
    		<? /* <div id="home_bg">
      			<div id="home_icon">
      				<a href="<?=base_url()?>admin/cms/others"><img src="<?=base_url().$this->config->item('FAL_assets_admin')?>/images/images/home_icon.png" width="95" height="75" alt="others" /></a>
  				</div>
  				<p>
  					<a href="<?=base_url()?>admin/cms/others">OTHERS</a>
				</p>
			</div>
      		<div id="home_shadow"></div>*/ ?>
      		<div class="icon_bg">
     <a href="#" class="othericon">other</a>
      <p><a href="#">OTHERS</a></p></div>
      <div class="icon_shadow"></div>
    	</div>
    	
    </div>