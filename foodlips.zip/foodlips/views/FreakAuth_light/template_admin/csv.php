<?php
	header("Content-type: text/csv");
	header("Content-Disposition: attachment; filename=file.csv");
	header("Pragma: no-cache");
	header("Expires: 0");
	
	/* if (isset($_POST['sendToValue'])) {
		$search = $_POST['sendToValue'];
	}
	else {
		$search = "";
	}*/
	
	$con = mysql_connect("localhost","root","");
	if (!$con) {
  		die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("snibble", $con);
	
	if($search != "") {
		$search = str_replace($search, ",", " ");
		$sql = "SELECT * FROM registration WHERE id IN(".$search.")";
	}
	else {
		$sql = "SELECT * FROM registration";
	}
	
	$sql = "SELECT * FROM registration";
	
	$data = array();
	
	$usersresult = mysql_query($sql);
	$isHeading = false;
	
	echo "data: "; print_r($usersresult);
	exit();
	
	if(count($usersresult) > 0) {
		while($user = mysql_fetch_array($usersresult)) {
			if(!$isHeading) {
				$data[] = array(
					"First Name","Surname","Mailing Address","Email","Phone Number", "Date Of Membership Registration", "Active/Unsubscribed", "Date Membership Was Cancelled"
				);
				$isHeading = true;	
			}
			$data[] = array(
				//$user->name,$user->address,$user->email,$user->phone
				$user["fname"],$user["sname"],"mailing address",$user["email"],$user["phone"],"date","active/unsub","date"
			);
		}
	}
	
	outputCSV($data);
	
	function outputCSV($data) {
	    $outstream = fopen("php://output", "w");
	    function __outputCSV(&$vals, $key, $filehandler) {
	        fputcsv($filehandler, $vals); // add parameters if you want
	    }
	    array_walk($data, "__outputCSV", $outstream);
	    fclose($outstream);
	}
	
	$response = array();
	$temparr['result'] = $row['success'];
	array_push($response, $temparr);
	echo json_encode(array('csvdata' => $response));
?>