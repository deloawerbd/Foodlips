<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?= $title; ?></title>
</head>

<body>
<h1> <?= $heading; ?> </h1>


<?php if ($query->num_rows()>0): ?>	
    
    <?php foreach ($query->result() as $row): ?>
    
    <p><?=$row->body;?></p>
    <p><?=$row->author;?></p>
    
    <hr />
    
    <?php endforeach;  ?>
    
    <p><?=anchor('blog','Back to blog')?></p>

<?php endif;?>

<?=form_open("blog/comments_insert");?>

<?= form_hidden("entry_id",$this->uri->segment(3));?>

<p><textarea rows="10" name="body"></textarea></p>
<p><input type="text" name="author"  /></p>
<p><input type="submit" value="Submit Comments" /></p>



</form>


</body>
</html>
