<?php $siteurl = "https://www.foodlips.com/";?>
<div class="page_wrapper">
	<div class="container-fluid margin_top_10">
	<!--Country Wise Flags view-->
	<?php if(!isset($hideslider)){
		  	$this->load->view("wineries/templates/changecountry.php");
	      }?>
	
    <!--Carsual Slider view-->
    <?php if(!isset($hideslider)){
            $this->load->view("wineries/templates/topwineriesslider.php");
          }?>	
		
	<!--Google Map county view-->
	<?php //$this->load->view("wineries/templates/countriesmap.php");?>
	
	<div class="margin_top_10">
    <div class="row">
		<!--Left div-->
		<div class="col-md-3 col-sm-4"><?php $this->load->view("wineries/templates/sidebar-left"); ?></div>
			
		<div class="col-md-9 col-sm-8">
			<? /*<div class="dropdown_category">
				<div class="sorting btn-group">
					<button class="btn dropdown_my">
						Order by : Most viewed
					</button>
					<button class="btn dropdown_my dropdown-toggle" data-toggle="dropdown">
						<span class="caret"></span>
					</button>
					<ul class="dropdown-menu dropdown_my1 action_my pull-left">
						<li><a href="#">Profile</a></li>
						<li><a href="#">Setting</a></li>
						<li><a href="#">Logout</a></li>
					</ul>
				</div>
			</div> */?>
			
            <?php if(isset($hideslider)){ ?>
				<div class="search_result">
					Search Results: 
				</div>
			<?php } ?>
			<!-- Wineries listing-->
			<div class="winery_wraper margin_top_20">
				<?php if(isset($pagination_links)) { ?>
                    <div class="custom-pagination" style="margin-bottom: 10px;">
                    	<?=$pagination_links;?>
                    </div>
                <?php } ?>
				
				<div class="well_custom">
					
					<?php if(!empty($wineries)) { ?>
						<?php foreach($wineries as $winery): ?>  <!--upper for loop-->
							<div class="rest_co_inner_wrp">
								<div class="rest_cofood_img">
									<?php if(isset($winery)) {
									       if($winery->from =="api") {
								    ?>
											<img class="icon" src="<?=$winery->image;?>" alt="profile img">
									<?php }
                                          else
                                          {
                                    ?>
											<img class="icon" src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$winery->image?>"/>
									<?php }
									      } ?>
								</div>
								<div class="rest_co_contain">
									<span class="rest_co_headtxt">
										<a target="_blank" href="<?=base_url();?>winery/details/<?=$winery->res_link;?>">
											<?=$winery->title;?>
										</a>
									</span>
									<div class="rest_co_minihead">
										Type : 
											<span class="font_italic"><?=$winery->category;?></span>
									</div>
									<div class="rest_co_minihead">
										Price: 
											<span class="font_italic"><?=$winery->price;?></span>
									</div>

									<div class="home_likes">
										<span class="like_main">
											<span style="font-size: 20px"><?=$winery->calculated_likes?></span>
											<span style="font-size: 11px;margin-left: 4px">/ 10</span>
										</span>
										<span>people like this.</span>
									</div>

								</div>
							</div>
						<?php endforeach; ?>
					<?php }else{
						echo "Wineries Not Found! ";
					}?>
				</div>
				
				<?php if(isset($pagination_links)) { ?>
					<div class="custom-pagination" style="margin-bottom: 10px;">
                		<?=$pagination_links;?>
                	</div>
            	<?php } ?>
				
			</div>

		</div>
       </div>
      </div>
	</div><!--End container here-->
</div>