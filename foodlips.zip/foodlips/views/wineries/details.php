<style>
	tr {
    height: 1%;
    width : 1%;
	}
	td {
    text-align: center;
    vertical-align: middle;
    padding:2px
	}
	.hoursdropdown{
		width: 100px;
	}
	.tooltip-inner  {
		background: yellow!important;
		color: black;
		font-weight:900;
	}
	.tooltip.bottom .tooltip-arrow {
	  /*bottom: 0;
	  left: 50%;
	  margin-left: -5px;
	  border-width: 5px 5px 0;*/
	 border-bottom-color: yellow;
	 background: yellow!important;
	}
</style>
<div class="page_wrapper">
	<?php
		$limit = "";
		$order_by = "";
		$where["wid"] = $wineries->id;
		$where["isapproved"] = "1";
		$where["name"] = "Address";
		$addressobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($addressobj)){
			$suggestedaddress = $addressobj[0]->suggested;
		}
		$where["name"] = "Website";
		$websiteobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($websiteobj)){
			$suggestedwebsite = $websiteobj[0]->suggested;
		}
		$where["name"] = "Facebook";
		$aFacebookobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($aFacebookobj)){
			$suggestedfacebook = $aFacebookobj[0]->suggested;
		}
		$where["name"] = "Twitter";
		$Twitterobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($Twitterobj)){
			$suggestedtwitter = $Twitterobj[0]->suggested;
		}
		$where["name"] = "Phone";
		$Phoneobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($Phoneobj)){
			$suggestedphone = $Phoneobj[0]->suggested;
		}
		$where["name"] = "Opening Hours";
		$openobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($openobj)){
			$suggestedtiming = $openobj[0]->suggested;
		}
		
		
	?>
	<?php if(isset($wineries) && !empty($wineries)) : ?>
		<!--Winery Title-->
		<div class="container-fluid margin_top_10">
			<input type="hidden" id="wineryid" name="wineryid" value="<?= $wineries->id;?>" />
			<input type="hidden" id="userid" name="userid" value="<?=$this->db_session->userdata("id");?>" />
			<input type="hidden" id="segment3" name="segment3" value="<?=$segment3?>"/>
			<div class="wrapper_self">
				<div class="res_contry_flaghead margin_top_20">
					<?=$wineries->title;?>,&nbsp;<?=$country->name;?>
				</div>
			</div>
		</div>
		
		<div class="container-fluid margin_top_10">
			<div class="col-md-9">
				
				<!-- Winery Map-->
				<div class="wrapper_self padding_bottom_none">
					<div class="state_map">
						<?php 
						echo $topmap["js"];
						echo $topmap["html"];
						?>
					</div>
				</div>
				
				<!--Image slider-->
				<?php if(isset($images) && count($images) > 1) :?>
					<?php //print_r($images);?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_rpl_bannersld">
							<div id="details_slider" class="carousel slide margin_bottom">
								<div class="carousel-inner margin_bottom">
									<?php $slidecount = 0;?>
									<?php foreach($images as $image) : ?>
										<div class="<?=$slidecount === 0 ? 'active item' : 'item';?>" >
											<img src="<?=base_url();?>public/frontend/images/wineries/1004x500/<?=$image;?>" />
										</div>
										<?php $slidecount++;?>
									<?php endforeach;?> 
								</div>
								<a class="left carousel-control" href="#details_slider" data-slide="prev"><span>&lsaquo;</span></a>
								<a class="right carousel-control" href="#details_slider" data-slide="next"><span>&rsaquo;</span></a>
							</div>
						</div> 
					</div>
				<?php endif;?>
				
				<!--Prices-->
				<div class="wrapper_self margin_top_20">
					<div class="rest_price">
						<h4>Price</h4><h3><?=isset($price->name) ? $price->name : "";?></h3>
					</div>
					<div class="rest_cuisine">
						<h4>Cuisine</h4><h3><?=isset($cuisine->name) ? $cuisine->name : "";?></h3>
					</div>
					<?php if($this->db_session->userdata("id") != ""):?>
						<div class="rest_addphoto float_right">
							<a href="#" id="btnaddphoto" class="btn" data-toggle="modal" data-target="#wineryimageloading">Add Photo</a>
						</div>
						<div style="display: none" id="errphotoupload" class="add_restaurant_flashtxt"></div>

						<!-- Modal -->
				        <div id="wineryimageloading" class="modal fade" role="dialog">
				          <div class="modal-dialog">
				        
				            <!-- Modal content-->
				            <div class="modal-content">
				              <div class="modal-header">
				                <button type="button" class="close" data-dismiss="modal">&times;</button>
				                <h4 class="modal-title">Add Wineries Photo</h4>
				              </div>
				              <div class="modal-body">
			        			<form id="frmaddwineriesphoto">
									<div class="common_box">
										<label class="common_height">Photo:</label>
										<input type="file" id="wineryimgfile" name="userfile" multiple  placeholder="Select Picture"/>
									</div>
									<div class="common_box">
										<span class="add_restaurant_flashtxt">you can upload multiple images</span>
									</div>
									
									<div class="common_box">
										<div class="selectimg">
											<ul id="image-list">
												<? /*
												<li>
													<span class="selectimg_inner">
														<img width="50px" height="50px" onclick="changeProfileimg(this.id)" id="pip-boy_6863-480x3601373274793.jpg" src="https://www.foodlips.com/shared/public/frontend/images/user/40x40/pip-boy_6863-480x3601373274793.jpg">
													</span>
													<span class="selectimg_innertxt">
														<span style="margin-left: 0px; margin-top: 5px;" onclick="deleteProfileImage(this)" class="btn btn-mini btn-danger remove_btn1" id="pip-boy_6863-480x3601373274793jpg">Remove</span>
													</span>
												</li> */ ?>
											</ul>
										</div>
									</div>
				              </div>
				              <div class="modal-footer">
									<input type="button" class="btn" value="Add Photos" onclick="addWineriesExtraPhotos();"/>
								</form>
				              </div>
				            </div>
				        
				          </div>
				        </div><!-- End Modal -->
					<?php endif;?>
				</div>
				
				<!--Features-->
				<?php if(isset($features) && !empty($features)) : ?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_links">
							<?php foreach($features as $feature) : ?>
								<span><?=$feature->name;?></span>
							<?php endforeach;?>
						</div>
					</div>
				<?php endif;?>
				
				<?php if($this->db_session->userdata("id") != ""):?>
					<div class="wrapper_self">
						<a href="#" data-toggle="modal" data-target="#extarfeature" class="btn float_right">Add Features</a>
					</div>
					<div style="display: none" id="errextarfeature" class="add_restaurant_flashtxt"></div>

					<!-- Modal -->
			        <div id="extarfeature" class="modal fade" role="dialog">
			          <div class="modal-dialog">
			        
			            <!-- Modal content-->
			            <div class="modal-content">
			              <div class="modal-header">
			                <button type="button" class="close" data-dismiss="modal">&times;</button>
			                <h4 class="modal-title">Add Features</h4>
			              </div>
			              <div class="modal-body">
		        			<form id="frmextrafeatures">
								<div class="common_box">
									<label class="common_height">Features:</label>
									<select id="selfeature" name="selfeature[]" multiple="multiple" size="6">
										<?php if(isset($allfeatures) && !empty($allfeatures)) : ?>
											<?php foreach($allfeatures as $allfeature) : ?>
												<option value="<?=$allfeature->id;?>"><?=$allfeature->name;?></option>
											<?php endforeach;?>
										<?php endif;?>
									</select>
									<span class="add_restaurant_flashtxt">Hold down Ctrl for multiple selection</span>
									<div id="errextarfeature" class="add_restaurant_flashtxt"></div>
								</div>
			              </div>
			              <div class="modal-footer">
								<input type="button" class="btn" id="restaurant" value="Add Features" onclick="addFeatures(this.id);"/>
							</form>
			              </div>
			            </div>
			        
			          </div>
			        </div><!-- End Modal -->
				<?php endif;?>
				
				<!--Description-->
				<div class="wrapper_self margin_top_20">
					<div class="rest_rpl_containt">
						<h3><?=$wineries->title;?> Overview</h3>
						<?=isset($wineries->content) ? $wineries->content : "" ;?>
					</div>
				</div>
				
				<!--Special Offers-->
				<?php if(isset($wineries->special_offers)) : ?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_rpl_containt" style="background-color: #F7F6F4;">
							<h3>Special Offers</h3>
							<?=$wineries->special_offers;?>
						</div>
					</div>
				<?php endif;?>
				
				<!--Video Code-->
				<?php if(isset($wineries->video)) : ?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_rpl_containt">
							<?=$wineries->video;?>
						</div>
					</div>
				<?php endif;?>
				
				<!--Extra Info-->
				<div class="wrapper_self margin_top_20">
					<div class="rest_rplweekly_heading">
						Extra Information About Wineries
					</div>
                    <div class="row">
					<div class="col-sm-6 rest_rpl_weekly">
						<h3>Opening Hours</h3>
						<?php $days = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");?>
						<?php $types = array("Bfast","Lunch","Dinner"); ?>
						<!-- First table starts from here... -->
						<?php foreach($days as $day){ 
								  $where = array("wid"=>$wineries->id,
										    //"isapproved"=>'1',
											"day"=>$day);
								  $opening_hours_data = $this->winemodel->getopeninghours($where);
								  //print_r($data);
								  	if(!empty($opening_hours_data)){
								  		  $Bfast[$day] = $opening_hours_data[0]->breakfast;
										  $Lunch[$day] = $opening_hours_data[0]->lunch;
										  $Dinner[$day] = $opening_hours_data[0]->dinner; 
										  if(!empty($opening_hours_data[0]->openingtime)){
										  	$openingtime[$day] = $opening_hours_data[0]->openingtime;
										  }
										  if(!empty($opening_hours_data[0]->closingtime)){
										  	$closingtime[$day] = $opening_hours_data[0]->closingtime;
										  }
								  	}else{
								  		$Bfast[$day] ="";
										$Lunch[$day] ="";
										$Dinner[$day] ="";
										$openingtime[$day] ="";
										$closingtime[$day] ="";
								  	}
							 } ?>
							<table>
								<tr>
									<th></th>
									<th>M</th>
									<th>T</th>
									<th>W</th>
									<th>T</th>
									<th>F</th>
									<th>S</th>
									<th>S</th>
								</tr>
								<?php foreach($types as $type){ ?>
								<tr>
									<th><?=$type;?></th>
									<?php foreach($days as $day){ ?>
										<?php  $t = $$type;?>
										<td style="border: 2px solid;border-color: gainsboro;">
											<?php if(!empty($t[$day])){ ?>
												<?php if($t[$day] == 1){?>
													<img src="<?= base_url()?>public/frontend/css/font/css/symbol_check1.jpeg" alt="1">
												<?php }else{ ?>
													
												<?php } ?>
											<?php } ?>
										</td>
									<?php } ?>
								</tr>
								<?php } ?>
								<tr>
									<th>Time</th>
									<?php foreach($days as $day) { ?>
								
								<?php 
									  $where = array("wid"=>$wineries->id,
													 //"isapproved"=>'1',
													 "day"=>$day);
									  $data = $this->winemodel->getopeninghours($where);
									  // print_r($data);
									  // print_r($data[0]->openingtime);
									  // print_r($data[0]->closingtime); 
									  
									  if(!empty($data[0]->openingtime)){
									  	$openingtime = $this->winemodel->gethours(array("id"=>$data[0]->openingtime));
										$finalopeningtime = $openingtime[0]->name;  
									  }else{
									  	$finalopeningtime = "-";
									  }
									  if(!empty($data[0]->closingtime)){
									  	$closingtime = $this->winemodel->gethours(array("id"=>$data[0]->closingtime));
										$finalclosingtime = $closingtime[0]->name;  
									  }else{
									  	$finalclosingtime = "-";
									  }
									  if($finalopeningtime=="CLOSED" || $finalclosingtime=="CLOSED"){
									  	$title = "Closed";
									  }else if($finalopeningtime=="OPEN ALL DAY" || $finalclosingtime=="OPEN ALL DAY"){
									  	$title = "Open All Day";
									  }else{
									  	$title = "Opening Time : ".$finalopeningtime."<br>"."Closing Time : ".$finalclosingtime;
									  }
									  
									 // $secondline = "Closing Time : ".$finalclosingtime;
									  ?>
									  
									<td style="border: 2px solid;border-color: gainsboro;">
										<!-- <a href="#" id="example" rel="tooltip" data-title="This is the body of Popover">
											<i class="icon-time"></i>
										</a> -->
										<span rel="tooltip"  data-toggle="tooltip" class = "timepopup" data-placement="bottom" data-html = "true" data-title = "<?= $title?>" cursor:auto; ><i class="icon-time"></i></span>
										 <!-- <a  rel="tooltip" href="#" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Tooltip on bottom" class="timepopup"><i class="icon-time"></i></a> -->
									</td>
								<?php } ?>
								</tr>
						 	</table>
						
						<div style="color: rgb(128, 123, 123);">Seasonal variations may occur</div>
						<!-- <img src="<?=base_url();?>public/frontend/images/restaurents/foot_calender.jpg" alt="food calender" /> -->
						<div style="display: none" id="erropeninghours" class="add_restaurant_flashtxt"></div>
					</div>
					<div class="col-sm-6 rest_rpl_menu">
						<h3>Menu</h3>
						<div class="rest_rpl_innermenu">
							<ul>
								<?php if(!empty($breakfast_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($breakfast_imgs as $breakfast_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries/<?= $breakfast_img?>" data-lightbox="breakfast_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$breakfast_img?>" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries/<?=$breakfast_img?>" data-lightbox="breakfast_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/breakfast_default.jpg" data-lightbox="breakfast_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/breakfast_default.jpg" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<?php if(!empty($lunch_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($lunch_imgs as $lunch_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries/<?= $lunch_img?>" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$lunch_img?>" style="width: 100%;height: 122px" alt="food Menu" /></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries<?=$lunch_img?>" data-lightbox="lunch_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/lunch_default.png" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/lunch_default.png" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<?php if(!empty($dinner_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($dinner_imgs as $dinner_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries<?= $dinner_img?>" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$dinner_img?>" style="width: 100%;height: 122px" alt="food Menu" /></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries<?=$dinner_img?>" data-lightbox="dinner_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/dinner_default.jpg" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/dinner_default.jpg" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<!-- <a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a> -->
								<!-- <li><a href="<?=base_url();?>public/frontend/images/restaurents/home/menu-sample1409223784.jpg" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu"/></a></li> -->
								<!-- <li><a href="<?=base_url();?>public/frontend/images/restaurents/home/menu-sample1409223784.jpg" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu"/></a></li> -->
								<!-- <li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li> -->
								<!-- <li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li> -->
							</ul>
						</div>
					</div>
                    </div>
				</div>
				<!-- menu button and popup -->
				<?php if($this->db_session->userdata("id") != "") { ?>
					<a href="#" id="btnaddmenu"  class="btn float_right" data-toggle="modal" data-target="#addmenu">Upload menu</a>
					<div style="display: none" id="erraddmenu" class="add_restaurant_flashtxt"></div>

					<!-- Modal -->
			        <div id="addmenu" class="modal fade" role="dialog">
			          <div class="modal-dialog">
			        
			            <!-- Modal content-->
			            <div class="modal-content">
			              <div class="modal-header">
			                <button type="button" class="close" data-dismiss="modal">&times;</button>
			                <h4 class="modal-title">Add Menu</h4>
			              </div>
			              <div class="modal-body">
		        			<form id="addmenuform">
								<div class="common_box">
									<span class="add_restaurant_flashtxt float_left">Simply upload the image files(jpg,jpeg,png) of the menus</span>
								</div>
								<div class="common_box">
									<label class="common_height">Breakfast:</label>
									<input type="file" class="winerymenu" id="breakfast" name="userfile" multiple  placeholder="Select Picture"/>
								</div>
								<div class="common_box">
									<label class="common_height">Lunch:</label>
									<input type="file" class="winerymenu" id="lunch" name="userfile" multiple  placeholder="Select Picture"/>
								</div>
								<div class="common_box">
									<label class="common_height">Dinner:</label>
									<input type="file" class="winerymenu" id="dinner" name="userfile" multiple  placeholder="Select Picture"/>
								</div>
								<div class="common_box">
									<div class="selectimg">
										<ul id="menu-list">
										</ul>
									</div>
								</div>
			              </div>
			              <div class="modal-footer">
								<input type="button" class="btn" id="restaurant" value="Submit" onclick="addmenu(this.id);"/>
							</form>
			              </div>
			            </div>
			        
			          </div>
			        </div><!-- End Modal -->
				<?php } ?>
				
				<!-- opening hours button and popup -->
				<?php if($this->db_session->userdata("id") != ""):?>
					<div class="wrapper_self margin_top_20">
						<a href="#" id="btnaddopeninghours" class="btn" data-toggle="modal" data-target="#addopeninghours">Add opening hours</a>

						<!-- Modal -->
				        <div id="addopeninghours" class="modal fade" role="dialog">
				          <div class="modal-dialog">
				        
				            <!-- Modal content-->
				            <div class="modal-content">
				              <div class="modal-header">
				                <button type="button" class="close" data-dismiss="modal">&times;</button>
				                <h4 class="modal-title">Add Opening Hours</h4>
				              </div>
				              <div class="modal-body">
			        		  	<div id="addopeninghours" class="common_box">
									<form id="openinghoursform">
										<table>
											<tr>
												<td></td>
												<td>
													Bfast
												</td>
												<td>
													Lunch
												</td>
												<td>
													Dinner
												</td>
												<td>
													Opening Time
												</td>
												<td>
													Closing Time
												</td>	
											</tr>
											<?php $days = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");?>
												<?php foreach($days as $day){ ?>
												<?php $where = array('wid'=>$wineries->id,'day'=>$day);?>
												<?php $data = $this->winemodel->getopeninghours($where);?>
											<tr>
												<td>
													<?= $day ?>
												</td>
												<td>
													<input type="checkbox" id="checkbox<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="breakfast" <?php if($data!=false && $data[0]->breakfast=="1")echo "checked"?>/>
		     										<label for="checkbox<?= $day ?>" name="checkbox<?= $day ?>_lbl" class="css-label lite-green-check"></label>
												</td>
												<td>
													<input type="checkbox" id="checkbox2<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="lunch"<?php if($data!=false && $data[0]->lunch=="1")echo "checked"?>/>
		     										<label for="checkbox2<?= $day ?>" name="checkbox2<?= $day ?>_lbl" class="css-label lite-green-check"></label>
												</td>
												<td>
													<input type="checkbox" id="checkbox3<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="dinner" <?php if($data!=false && $data[0]->dinner=="1")echo "checked"?>/>
		     										<label for="checkbox3<?= $day ?>" name="checkbox3<?= $day ?>_lbl" class="css-label lite-green-check"></label>
												</td>
												<td>
													
													<select class="hoursdropdown" name="<?= $day ?>[opening_time]">
														<option value="">Select</option>
														<?php if(!empty($hours)) {?>
															<?php foreach($hours as $hour){ ?>
																<option value="<?= $hour->id?>"<?php if($data!=false && $data[0]->openingtime==$hour->id)echo "selected"?>><?= $hour->name?></option>
															<?php } ?>
														<?php } ?>
													</select>
												</td>
												<td>
													<select class="hoursdropdown" name="<?= $day ?>[closing_time]">
														<option value="">Select</option>
														<?php if(!empty($hours)) {?>
															<?php foreach($hours as $hour){ ?>
																<option value="<?= $hour->id?>"<?php if($data!=false && $data[0]->closingtime==$hour->id)echo "selected"?>><?= $hour->name?></option>
															<?php } ?>
														<?php } ?>
													</select>
												</td>
											</tr>
											<?php } ?>
										</table>
										<input type="checkbox" id="checkbox22" class="css-checkbox " name="selectall"/>
	     								<label for="checkbox22" name="checkbox22_lbl" class="css-label lite-green-check">Select All</label>
								</div>
				              <div class="modal-footer">
										<input type="button" class="btn" id="winery" value="Submit" onclick="addwineryopeninghours(this.id);"/>
									</form>
				              </div>
				            </div>
				        
				          </div>
				        </div><!-- End Modal -->
				    </div>
				<?php endif;?>				
				<div class="wrapper_self margin_top_20">
					<div class="rest_rpl_commentwrap">
						<div id="allcomments">
							<?php if(isset($comments) && !empty($comments)) : ?>
								<?php foreach($comments as $comment):?>
									<div class="rest_rpl_comment">
										<?php $this->load->model("communitymodel");?>
										<?php $user = $this->communitymodel->getuser(array("id"=>$comment->uid));?>
										<div class="rest_comment_img">
											<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>" >
												<img src="<?=base_url();?>public/frontend/images/user/40x40/<?=isset($user->image) ? $user->image : "noavatar.png";?>" />
											</a>
										</div>
										<div class="rest_comment_containt">
											<h4><?=$user->name;?>,&nbsp;<?=date_format(date_create($comment->date), 'l jS F Y \a\t g:ia');?></h4>
											<? /*<div class="rest_comment_stars">
												<ul>
													<li>
														<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
													</li>
													<li>
														<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
													</li>
													<li>
														<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
													</li>
													<li>
														<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
													</li>
													<li>
														<a href="#"><img src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green star" /></a>
													</li>
												</ul>
											</div>*/ ?>
											<p><?=$comment->comment;?></p>
										</div>
									</div>
								<?php endforeach;?>
							<?php endif;?>
						</div>
						<div id="container_comment" class="rest_comment_replycontaint margin_top_40">
							<h2>Post Your Review</h2>
							<? /*<p class="margin_top_20">Rate this by clicking a star below:</p>
							
							<div class="rest_comment_stars">
								<ul>
									<li>
										<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
									</li>
									<li>
										<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
									</li>
									<li>
										<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
									</li>
									<li>
										<a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" alt="green star" /></a>
									</li>
								</ul>
							</div>
							<p>Logged in as <a href="#" class="text_link">Trine</a>. <a href="#" class="text_link">Log out >></a></p> */?>
							<p>Review</p>
							<textarea id="txtcomment" name="txtcomment" class="rest_comment_txtarea"></textarea>
							<div id="commenterror" class="wrapper_self"></div>
							<div class="wrapper_self">
								<button type="submit" id="wine" class="btn float_right margin_bottom_10" onclick="commentOnRestaurant(this.id);" >Post</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!--Right Side Bar-->
			<div class="col-md-3">
				<div class="winery_wraper" id="likedislike">
					<div class="community_head2">
							<span class="like_main"><span style="font-size: 20px"><?=$calculated_likes?></span><span style="font-size: 11px;margin-left: 4px; margin-right:4px;">/ 10</span></span><span class="head2">People like this.</span>
					</div>
					<?php if(isset($liked) && $liked != -1) {
						if($liked=="1"){ ?>
						<div class="community_head2">
							<span class="head2">You liked this! Unlike it</span><span class="likewinery" id="<?=$wineries->id;?>_0" style="margin-left: 5px"><img src="<?=base_url();?>public/frontend/images/dislike.png" width="40px" alt="dislike" style="cursor:pointer"></span>
						</div>
						
					<?php } else {?>
						<div class="community_head2">
							<span class="head2">You unliked this place! Like it </span><span class="likewinery" id="<?=$wineries->id;?>_1"><img src="<?=base_url();?>public/frontend/images/like.png" width="40px" alt="like" style="cursor:pointer"></span>
						</div>
					<?php }}else{ ?>
						<div class="community_head2">
							<span class="likewinery" id="<?=$wineries->id;?>_1"><img src="<?=base_url();?>public/frontend/images/like.png" width="40px" alt="like" style="cursor:pointer"></span><span class="likewinery" id="<?=$wineries->id;?>_0" style="margin-left: 5px"><img src="<?=base_url();?>public/frontend/images/dislike.png" width="40px" alt="dislike" style="cursor:pointer"></span><span class="head2">Do you like this place?</span>
						</div>
					<?php } ?>
					<div class="community_head2" id="errlike">
						<span class="rest_comment_rank float_left"></span>
					</div>
				</div>
				<div class="winery_wraper">
					<?php /* if($this->db_session->userdata("id") != "") {?>
									<div class="rest_addphoto float_right">
										<a href="javascript:void(0)" id="btnsuggestions" class="btn" onclick="blockui('EditSuggestions');">Edit Suggestions</a>
									</div>
					<?php } */ ?>
					<div class="well_custom">
						<div class="rest_rpl_detail_group">
							<ul>
								<li>
									<i class="icon-map-marker icon-large"></i>
									<span class="rest_rpl_head_small"> Address :</span>
									<?php if(isset($suggestedaddress)){ ?>
										<span class="rest_rpl_color_gry"><?=$suggestedaddress?></span>
									<?php }else{ ?>
										<span class="rest_rpl_color_gry"><?=isset($wineries->geo_address) ? $wineries->geo_address : "";?></span>
									<?php } ?>
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_color_red rest_rpl_head_small"> Website :</span>
									<?php if(isset($suggestedwebsite)){ ?>
										<span class="rest_rpl_head_small"><?=isset($suggestedwebsite) ? '<a style="display: inline;" href="'.$suggestedwebsite.'" />'.$suggestedwebsite.'</a>' : "";?></span>
									<?php }else{ ?>
										<span class="rest_rpl_head_small"><?=isset($wineries->website) ? '<a style="display: inline;" href="'.$wineries->website.'" />'.$wineries->website.'</a>' : "";?></span>
									<?php } ?>
									
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_head_small"> Facebook :</span>
									<?php if(isset($suggestedfacebook)){ ?>
										<span class="rest_rpl_head_small"><?=isset($suggestedfacebook) ? '<a style="display: inline;" href="'.$suggestedfacebook.'" />'.$suggestedfacebook.'</a>' : "";?></span>
									<?php }else{ ?>
										<span class="rest_rpl_head_small"><?=isset($wineries->facebook) ? '<a style="display: inline;" href="https://www.facebook.com'.$wineries->facebook.'" />'.$wineries->facebook.'</a>' : "";?></span>
									<?php } ?>
									
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_head_small"> Twitter :</span>

									<?php if(isset($suggestedtwitter)){ ?>
										<span class="rest_rpl_head_small"><?=isset($suggestedtwitter) ? '<a style="display: inline;" href="'.$suggestedtwitter.'" />'.$suggestedtwitter.'</a>' : "";?></span>
									<?php }else{ ?>
										<span class="rest_rpl_head_small"><?=isset($wineries->twitter) ? '<a style="display: inline;" href="https://twitter.com'.$wineries->twitter.'" />'.$wineries->twitter.'</a>' : "";?></span>
									<?php } ?>
									
								</li>
								<li>
									<i class="icon-phone icon-large"></i>
									<span class="rest_rpl_head_small"> Phone :</span>
									<?php if(isset($suggestedphone)){ ?>
										<span class="rest_rpl_head_small"><?=isset($suggestedphone) ? '<a style="display: inline;" href="'.$suggestedphone.'" />'.$suggestedphone.'</a>' : "";?></span>
									<?php }else{ ?>
										<span class="rest_rpl_head_small rest_rpl_color_gry"><?=isset($wineries->contact) ? $wineries->contact : "";?></span>
									<?php } ?>
									
								</li>
								<? /*<li>
									<i class="icon-food icon-large"></i>
									<span class="rest_rpl_head_small"> Lunch Hours :</span>
									<span class="rest_rpl_head_small">Tuesday - Sunday 11am - 3pm</span>
								</li>*/ ?>
								<li>
									<i class="icon-food icon-large"></i>
									<span class="rest_rpl_head_small"> Opening Hours :</span>
									<?php if(isset($suggestedtiming)){ ?>
										<span class="rest_rpl_head_small"><?=isset($suggestedtiming) ? '<a style="display: inline;" href="'.$suggestedtiming.'" />'.$suggestedtiming.'</a>' : "";?></span>
									<?php }else{ ?>
										<span class="rest_rpl_head_small"><?=isset($wineries->timing) ? $wineries->timing : "";?></span>
									<?php } ?>
									
								</li>
								<li id="li_addtofavorites">
									<a href="javascript:void(0);" id="wine" onclick="addtofavorites(this.id);" >Add to Favorites</a>
								</li>
								<li id="errfavorite" style="display: none;">
									
								</li>
							</ul>
						</div>
						
						<div class="rest_rpl_detail_group" style="background:none;">
							<ul>
								<li id="li_rating">
									<i class="icon-star-empty icon-large float_left"></i>
									<span class="rest_rpl_head_small float_left margin_left5"> Rating :</span>
									<div class="rest_comment_rank">
										<ul>
											<?php $userrating = round($this->winemodel->takerating($wineries->id));
											$greystarts = 5 - $userrating;
											$i = 0; $globalcount = 1;
											
											while($i < $userrating) { ?>
												<li>
													<img id="rt_<?=$globalcount;?>_<?=$wineries->id;?>" class="ratewine" src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star" style="cursor:pointer" />
												</li>
											<?php $i++; $globalcount++; }
											$i = 0;
											while($i < $greystarts) { ?>
												<li>
													<img id="rt_<?=$globalcount;?>_<?=$wineries->id;?>" class="ratewine" src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star" style="cursor:pointer" />
												</li>
											<?php $i++; $globalcount++; } ?>
										</ul>
									</div>
								</li>
								<li id="errrating">
									<span class="rest_comment_rank"></span>
								</li>
								<? /*<li>
									<i class="icon-share icon-large"></i>
									<span class="rest_rpl_color_gry rest_rpl_head_small"> Share </span>
								</li>*/ ?>
								<li>
									<i class="icon-envelope icon-large"></i>
									<span class="rest_rpl_head_small"><a id="restaurant" href="#" style="display: inline" data-toggle="modal" data-target="#mailtofriend">Mail to a friend</a></span>

									<!-- Modal -->
							        <div id="mailtofriend" class="modal fade" role="dialog">
							          <div class="modal-dialog">
							        
							            <!-- Modal content-->
							            <div class="modal-content">
							              <div class="modal-header">
							                <button type="button" class="close" data-dismiss="modal">&times;</button>
							                <h4 class="modal-title">Suggest this winery to your friend</h4>
							              </div>
							              <div class="modal-body">
						        		  	<form id="mailtofriendform">
												<div class="common_box">
													<label class="common_height">To:</label>
													<input type="text" name="sendto" placeholder="Enter email address here">
												</div>
												<div class="common_box">
													<label class="common_height">Subject:</label>
													<input type="text" name="subject" value="Suggestion for a winery">
												</div>
												<div class="common_box">
													<label class="common_height">Body:</label>
													<textarea name="body" rows="10" cols="100"> Hi,
														<?= $this->db_session->userdata("user_name");?> has recommended you a winery.Click below the link : <?= base_url().$this->uri->uri_string();?></textarea> 
												</div>
										  </div>
							              <div class="modal-footer">
							              		<input type="button" class="btn" id="restaurant" value="Send" onclick="mailtofriend();"/>
												<div id="errsendingreport" class="add_restaurant_flashtxt"></div>
											</form>
							              </div>
							            </div>
							        
							          </div>
							        </div><!-- End Modal -->
								</li>
								
							<?php // if($this->db_session->userdata("id") != "") {?>
								<li>
									<i class="icon-edit icon-large"></i>
									<span class="rest_rpl_head_small"><a id="suggestionswinery" style="display: inline" data-toggle="modal" data-target="#editsuggestions">Suggest an Edit</a></span>
									<?php // } ?>

									<!-- Modal -->
							        <div id="editsuggestions" class="modal fade" role="dialog">
							          <div class="modal-dialog">
							        
							            <!-- Modal content-->
							            <div class="modal-content">
							              <div class="modal-header">
							                <button type="button" class="close" data-dismiss="modal">&times;</button>
							                <h4 class="modal-title">Suggest an Edit</h4>
							              </div>
							              <div class="modal-body">
						        		  	<form id="editsuggestionsformwinery">
												<input type="hidden" name="wineryidsuggestion" value="<?= $wineries->id;?>">
												<div class="common_box">
													<label class="common_height">Address :</label>
													<?php if(isset($suggestedaddress)){ ?>
													<textarea name="address" rows="5" cols="150"><?=isset($suggestedaddress) ? $suggestedaddress : "";?></textarea>
													<?php }else{ ?>
														<textarea name="address" rows="5" cols="150"><?=isset($wineries->geo_address) ? $wineries->geo_address : "";?></textarea>													
													<?php } ?> 
												</div>
												<div class="common_box">
													<label class="common_height">Website:</label>
													<?php if(isset($suggestedwebsite)){ ?>
														<input type="text" name="website" value="<?=isset($suggestedwebsite) ? $suggestedwebsite : "";?>">
													<?php }else{ ?>
														<input type="text" name="website" value="<?=isset($wineries->website) ? $wineries->website : "";?>">													
													<?php }?>
												</div>
												<div class="common_box">
													<label class="common_height">FaceBook :</label>
													<?php if(isset($suggestedfacebook)){ ?>
														<input type="text" name="facebook" placeholder="Facebook Name" value="<?=isset($suggestedfacebook) ? $suggestedfacebook : "";?>">
													<?php }else{ ?>
														<input type="text" name="facebook" placeholder="Facebook Name" value="<?=isset($wineries->facebook) ? $wineries->facebook : "";?>">
													<?php } ?> 
												</div>
												<div class="common_box">
													<label class="common_height">Twitter :</label>
													<?php if(isset($suggestedtwitter)){ ?>
														<input type="text" name="twitter" value="<?=isset($suggestedtwitter) ? $suggestedtwitter : "";?>">
													<?php }else{ ?>
														<input type="text" name="twitter" value="<?=isset($wineries->twitter) ? $wineries->twitter : "";?>">
													<?php } ?> 
													
												</div>
												<div class="common_box">
													<label class="common_height">Phone :</label>
													<?php if(isset($suggestedphone)){ ?>
														<input type="text" name="contact" value="<?=isset($suggestedphone) ? $suggestedphone : "";?>">
													<?php }else{ ?>
														<input type="text" name="contact" value="<?=isset($wineries->contact) ? $wineries->contact : "";?>">
													<?php } ?> 
													
												</div>
												<div class="common_box">
													<label class="common_height">Opening Hours :</label>
													<?php if(isset($suggestedtiming)){ ?>
														<input type="text" name="timing" value="<?=isset($suggestedtiming) ? $suggestedtiming : "";?>">
													<?php }else{ ?>
														<input type="text" name="timing" value="<?=isset($wineries->timing) ? $wineries->timing : "";?>">
													<?php } ?> 
													
												</div>
										  </div>
							              <div class="modal-footer">
							              		<input type="button" class="btn" id="restaurant" value="Submit" onclick="editsuggestionswinery();"/>
											</form>
							              </div>
							            </div>
							        
							          </div>
							        </div><!-- End Modal -->
								</li>
								<li id="suggestionsreportli" style="display: none;" >
									<div id="errsuggestionsreport" class="add_restaurant_flashtxt"></div>
								</li>
								
								<? /*<li>
									<i class="icon-envelope icon-large"></i>
									<span class="rest_rpl_head_small rest_rpl_color_gry">Send Inquiry</span>
								</li>*/ ?>
							</ul>
						</div>
					</div>
				</div>				
				
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="community_head2">Get Directions</div>
						<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
						<script type="text/javascript" src="<?=base_url();?>/public/frontend/js/restaurants/getDirectionsMap.js"></script>
						<div class="rest_rpl_getdirection_map">
							
							<div id="map_canvas_2"></div>
							
							<div id="directionsDiv" class="winery_wraper margin_top_20">
								
							</div>
							<div class="winery_wraper margin_top_20">
								<form id="calculate-route" name="calculate-route" action="#" method="get">
									<input type="hidden" id="destination" name="destination" value="<?=$wineries->geo_address;?>"/>
									<input type="hidden" id="latlang" name="latlang" value="<?=$wineries->latitude;?>,<?=$wineries->longitude;?>" />
									
									<input type="text" id="fromAddress" name="fromAddress" required class="" />
									<div class="get_direction_btn_cont"><input type="submit" value="Get Direction" class="btn"/></div>
								</form>
							</div>
						</div>
					</div>
				</div>
				
				<? /*
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="community_head2">
							<span class="head2">QUICK RESTAURANT SEARCH</span>
						</div>
						<form>
							<div class="winery_wraper margin_top_10">
								<div class="winery_wraper margin_left5 margin_bottom_5">Search for :</div>
								<input type="text" placeholder="Search Restaurant" class="float_left input_150 margin_left5" />
								<button type="submit" class="btn float_right margin_right_5">Search</button>
							</div>
						</form>
					</div>
				</div> */ ?>
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="community_head2">IN THE NEIGHBORHOOD</div>
						<?php if(isset($neighbors) && !empty($neighbors)):?>
							<?php foreach($neighbors as $neighbor) :?>
								<div class="winery_inner_wrp margin_bottom_none">
									<div class="winery_pick_img">
										<?php if(!empty($neighbor->images)){
											$images = unserialize($neighbor->images); ?>
											<img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$images[0];?>"/>
										<?php }else{ ?>
											<img class="icon" src="<?=base_url();?>public/frontend/images/wineries/100x100/winedefault.jpg"/>
										<?php }?>
									</div>
									<div class="winery_contain">
										<a href="<?=base_url();?>winery/details/<?=$neighbor->seo;?>">
											<span class="winery_headtxt"><?=isset($neighbor->title) ? $neighbor->title : "";?></span>
										</a>
										
										<? /*
										<div class="rest_comment_rank margin_left_none">
											<ul>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/gray_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/gray_star.png" /></a></li>
											</ul>
										</div> */ ?>
										<span class="winery_containt_txt" >
											<?php 
											$content = isset($neighbor->content) ? $neighbor->content : "";
											/*if($content !=="" && strlen($content) > 50){
												echo substr(strip_tags($content),0,50);
											}else{
												echo $content;
											}*/
											echo (strlen($content) > 50) ? substr(strip_tags($content),0,50).'...' : $content;
											?>
										</span>
									</div>
								</div>
							<?php endforeach;?>
						<?php endif;?>
					</div>
				</div>
			</div>
		</div>
	<?php endif;?>
</div>
 