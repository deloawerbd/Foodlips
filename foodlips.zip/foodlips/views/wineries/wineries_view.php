<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Foodlips | Winery Guide</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="ico/favicon.png">

        <!-- <link href='http://fonts.googleapis.com/css?family=Port+Lligat+Sans' rel='stylesheet' type='text/css'> -->
        <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css' media="" />
        <link href='http://fonts.googleapis.com/css?family=Marcellus+SC&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Quintessential&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Scada:400,700&subset=latin,latin-ext,cyrillic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Elsie+Swash+Caps|Roboto+Condensed:300|Julius+Sans+One|Anaheim|Advent+Pro|Open+Sans|Yanone+Kaffeesatz' rel='stylesheet' type='text/css'>

        <!-- Le styles -->
        <!--        <link href="../css/bootstrap/bootstrap.css" rel="stylesheet" />
                <link href="../css/jquery.share.css" rel="stylesheet" type="text/css" /> 
                <link href="../css/style.css" rel="stylesheet" type="text/css">-->
        <link href="<?= base_url(); ?>public/frontend/css/bootstrap.css" rel="stylesheet" />
        <link href="<?= base_url(); ?>public/frontend/css/jquery.share.css" rel="stylesheet" type="text/css" /> 
        <link href="<?= base_url(); ?>public/frontend/css/restaurants_home.css" rel="stylesheet" type="text/css">


        <?php $baseurl = "https://www.foodlips.com/shared/"; ?>

        <!-- Load Mask css-->
        <link type="text/css" rel="stylesheet" href="<?= $baseurl; ?>css/ajaxloading/jquery.loadmask.css" />

        <link href="<?= $baseurl; ?>public/frontend/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <link href="<?= $baseurl; ?>public/frontend/css/community.css" rel="stylesheet" type="text/css">
        <!--Ajax Loader-->


<!-- 		<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/jquery-1.10.2.min.js"></script>
<!-- 		<script src="<?= $baseurl; ?>public/frontend/js/formvalidation.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/bootstrap.min.js"></script>

        <? /* <script type="text/javascript" src="js/jquery.social.share.1.2.min.js"></script> */ ?>

        <? /* <script type="text/javascript">var switchTo5x=true;</script>
        <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
        <script type="text/javascript" src="http://s.sharethis.com/loader.js"></script> */ ?>

        <script> var baseurl = "https://www.foodlips.com/shared/";</script>
        <script> var siteurl = "https://www.foodlips.com/";</script>
        <script> var loginurl = baseurl + "auth/login/";</script>
        <script> var communityurl = baseurl + "community/";</script>
        <!--[if !IE 8 ]>
                
        <![endif]-->
        <!--<script type="text/javascript" src="../js/jquery.share.js"></script>-->
        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.share.js"></script>

        <script type="text/javascript" src="<?= $baseurl; ?>js/ajaxloading/jquery.loadmask.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsvalidation.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsrequesthandler.js"></script>

        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/community/communityrequesthandler.js"></script> 

        <!--<script type="text/javascript" src="../js/foodlips.js"></script>-->
        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlips_restaurants.js"></script>
        <!--js for community notifications-->
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/notifications.js"></script>

        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-50424093-1', 'auto');
            ga('send', 'pageview');

        </script>

    </head>

    <body>
        <div id="topmenulogin">

        </div>
        <?php $base_url = "https://www.foodlips.com/"; ?>
        <?php $recipe = base64_encode("recipe"); ?>
        <?php $recipe_base_url = "https://www.foodlips.com/shared/"; ?>
        <?php $winery_url = $base_url . 'shared/wineries/'; ?>

        <?php //print_r($_SESSION);?>
        <?php // for FACEBOOK like ?>
        <div id="fb-root"></div>
        <div id="header">
            <div id="header_main">

                <div class="container-fluid">

                    <div class="header_top">

                        <div id="search_form"></div>

                        <div class="logo_header">
                            <a href="<?= $base_url; ?>">
                                <img src="<?= $recipe_base_url; ?>images/foodlips_logo1.png" class="logo" alt="FoodLips" />
                            </a>
                        </div>

                        <div id="loginlogout"></div>

                    </div>

                </div>

                <script type="text/javascript">
                    $(document).ready(function () {
                        // $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout");
                        // $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu");
                        jQuery.ajaxSetup({
                            // Disable caching of AJAX responses
                            cache: false
                        });
                        setTimeout(function () {
                            var d = new Date();
                            var n = d.getTime();
                            $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout?t=" + n);
                            $("#search_form").load("https://www.foodlips.com/shared/recipe/searchform?t=" + n);
                            $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu?t=" + n);
                        }, 200);

                    });
                </script>

                <div class="clearfix"></div>

                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <button class="btn share_toggle" type="button"></button>

                        </div>

                        <div id="share_container">
                            <button class="btn share_toggle fixed" type="button"></button>
                            <div id="share"></div>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="navigation">
                            <ul class="nav navbar-nav">
                                <li>
                                    <a href="<?= $base_url; ?>">Home</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>community">Community</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe">Recipes</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>restaurants">Restaurants</a>
                                </li>
                                <li>
                                    <a class="active" href="<?= $base_url; ?>wineries">Wineries</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>videos">Videos</a>
                                </li>
                                <li>
                                    <a href="<?= $base_url; ?>blog">Blog</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/aboutus">About</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/contactus">Contact us</a>
                                </li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>

            </div>
        </div>

        <!-- Main Container -->
        <div class="page_wrapper">
            <div class="container-fluid">
                <div class="single_img_banner center_txt">
                        <!-- <img src="<?= $base_url; ?>wineries/images/winery_head.png" /> -->
                    <h2 class="about_heading">
                        WELCOME TO OUR WINERY GUIDE
                    </h2>
                </div>
            </div>

            <!--<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <div class="well_custom padding_bottom_none">
                <div class="community_box_in3">
                    <div class="winery_img_box">
                        <img src="<?= $base_url; ?>wineries/images/Winery_img_1.jpg" alt="community_img">
                    </div>
                </div>
            </div>
        </div>
                            <script type="text/javascript">
            $(document).ready(function() {
                 $("#picks").load(baseurl+"community/winerypicks");
            });
            
        </script>
                    
        <div class="col-md-12">
            <div class="winery_wraper">
                <div class="well_custom">
                    <div class="community_head2">
                        <span class="head2">OUR PICKS</span>
                    </div>
                    <div id="picks">
                    </div>
                    
                </div>
            </div>
        </div>
        
    </div>
            </div>-->
            <div class="container-fluid">
                <div class="winery_middle_contain">
                    Here you can find Wineries from around the world. If you are a member of Foodlips you can add your favorite wines and Wineries to your profile.
                </div>
                <div class="winery_middle_contain">
                    <h2 class="about_heading">Click on the Country below you wish to visit for the Winery Guide</h2>
                </div>
            </div>

            <div class="container-fluid"><!--Div left-->
                <div class="row">
                    <div class="col-md-8">
                        <div class="well_custom padding_bottom_none">
                            <div class="winery_flag_box">
                                <ul>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Argentina">
                                            <div class="flag_txt">
                                                <span>Argentina</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/AR.png" alt="flag img" title="Argentina"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_argentina.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Australia">
                                            <div class="flag_txt">
                                                <span>Australia</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/AU.png" alt="flag img" title="Australia"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_australia.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Brazil">
                                            <div class="flag_txt">
                                                <span>Brazil</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/BR.png" alt="flag img" title="Brazil"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_brazil.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Chile">
                                            <div class="flag_txt">
                                                <span>Chile</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/CL.png" alt="flag img" title="Chile"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_chile.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>France">
                                            <div class="flag_txt">
                                                <span>France</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/FR.png" alt="flag img" title="France"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_france.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Germany">
                                            <div class="flag_txt">
                                                <span>Germany</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/DE.png" alt="flag img" title="Germany"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_germany.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Italy">
                                            <div class="flag_txt">
                                                <span>Italy</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/IT.png" alt="flag img" title="Italy"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_italy.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>New-Zealand">
                                            <div class="flag_txt">
                                                <span>New Zealand</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/NZ.png" alt="flag img" title="New Zeeland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_new_zeland.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Portugal">
                                            <div class="flag_txt">
                                                <span>Portugal</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/PT.png" alt="flag img" title="Portugal"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_portugal.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>South-Africa">
                                            <div class="flag_txt">
                                                <span>South Africa</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/ZA.png" alt="flag img" title="South Africa"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_south_africa.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>Spain">
                                            <div class="flag_txt">
                                                <span>Spain</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/ES.png" alt="flag img" title="Spain"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_spain.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $winery_url; ?>United-States">
                                            <div class="flag_txt">
                                                <span>United States</span>
                                                <img src="public/frontend/images/flags_icons_set/24x24/US.png" alt="flag img" title="United States"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="public/frontend/images/countries_plates/flg_united_states.jpg" />
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="winery_wraper">
                            <div class="well_custom">
                                <div class="community_head2">
                                    <span class="head2">HIGHEST RATED</span>
                                </div>
                                <div id="highestrated"></div>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function () {
                                $("#mostpopular").load(baseurl + "community/winemostpopular");
                            })
                        </script>
                        <div class="winery_wraper">
                            <div class="well_custom">
                                <div class="community_head2">
                                    <span class="head2">MOST POPULAR</span>
                                </div>
                                <div id="mostpopular">
                                </div>
                            </div>
                        </div>
                    </div>

                    <script>
                        $(document).ready(function () {
                            $("#highestrated").load(baseurl + "community/winehighestrated");
                        })
                    </script>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#newfooter").load(baseurl + "community/commonfooter");
            });
        </script>

        <div class="footer_new_bg margin_top_20" >
            <div class="container_fluid">
                <div id="newfooter" class="footer_new">
                </div>
                <!-- Go to www.addthis.com/dashboard to customize your tools --> <div class="addthis_inline_follow_toolbox"></div>
            </div>
            <div class="footer_new_copyright">
                <div class="container_fluid">
                    <p class="copyright">2017 Copyright &copy; <a class="whitecolor footerlink" href="https://www.foodlips.com">Foodlips</a></p>
                </div>
            </div>
        </div>

        <!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-599145be1eb87b29"></script> 
    </body>
</html>
