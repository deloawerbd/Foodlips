<?php if(isset($wineries) && !empty($wineries)) : ?>
	<?php foreach($wineries as $winery) : ?>
		<div class="rest_co_inner_wrp">
			<div class="rest_cofood_img">
				<?php if(!empty($winery->images)){ ?>
				<?php $images = unserialize($winery->images);?>
				<?php } ?>
				<?php if(isset($images[0])){?>
					<img class="icon" src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$images[0];?>"/>
				<?php }else{?>
					<img class="icon" src="<?=base_url();?>public/frontend/images/wineries/100x100/winedefault.jpg"/>
				<?php }?>
			</div>
			<div class="rest_co_contain">
				<span class="rest_co_headtxt">
					<a target="_blank" href="<?=base_url();?>winery/details/<?=$winery->seo;?>"><?=$winery->title;?></a>
				</span>
				<? /*<div class="rest_co_minihead font_italic">
					Box Hill Restaurants VIC
				</div> */ ?>
				<?php if($winery->categoryid > 0) {?>
				<div class="rest_co_minihead">
					<?php 
						$where = array("id"=>$winery->categoryid);
						$res = $this->winemodel->getcategorybyid($where);
						$res = $res->name;
						if(isset($res))
						{
					 		echo "Type : ".$res;
						}
					?>
				</div>
				<?php } ?>
				<span class="rest_co_containt_txt">
					<?=$winery->content;?>
				</span>
			</div>
		</div>
	<?php endforeach;?>
<?php endif;?>