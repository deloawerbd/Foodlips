<div class="rest_country_290">
	<?php if($this->db_session->userdata("id") != "") :
		$where = array(
						"id" => $this->db_session->userdata("id"),
						"user_name" => $this->db_session->userdata("user_name")
					);
		$loginuser = $this->communitymodel->getuser($where); ?>
		<div class="well_custom">
			<div class="community_head2">Welcome, <?=!empty($loginuser->name) ? $loginuser->name : $loginuser->user_name;?></div>
			<div class="rest_country_box">
				<a href="<?=base_url();?>winery/add">Add New Winery</a>
			</div>
		</div>
	<?php endif; ?>
	<?php $countryname = !empty($country->name) ? str_replace(" ", "-", $country->name) : "Australia"; ?>
	<?php $attribute = array("method"=>"GET");?>
	<?=form_open("wineries/$countryname/",$attribute);?>
	<?php
	/*
	<div class="well_custom padding_bottom_none">
		<div class="community_box_in3">
			<input type="text" name="keyword" value="<?php if(isset($searchkeyword)){ echo $searchkeyword; }?>"  class="margin_10 width_256" placeholder="Search by keyword">
			<input type="submit" class="btn login_link3" value="Search">
		</div>
	</div>
	 */
	 ?>
	<div class="well_custom padding_bottom_none">
		<div class="community_box_in3">
			<div id = "sidebar">
			<div class="community_head2">Search For Winery</div>
			<div class="rest_country_box">
				<a href="https://www.foodlips.com/shared/wineries">
					<span><img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="close" /></span>
					<span><?=$countryname;//!empty($country->name) ? str_replace(" ", "-", $country->name) : "Australia";?></span>
				</a>
			</div>
			<div id="satecombo" class="styled-select">
                <?php if(isset($states) && !empty($states)) :?>
                    <select  id="selstateforsearch" name="state">
                        <!-- <option value="0">STATE</option> -->
                        <?php foreach($states as $state) : ?>
                            <?php if(isset($searchstate) && $state->state_name==$searchstate) { ?>
                                <option value="<?=$state->state_name;?>"selected><?=$state->state_name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$state->state_name;?>"><?=$state->state_name;?></option>
                            <?php } ?>
                        <?php endforeach;?>
                    </select>
                <?php endif;?>
            </div>
            <div id="cityloader" style="display: none">Loading Cities..</div>
			<div id="citycombo" class="styled-select">
                <select id="selcity" name="city">
                    <!-- <option  value="0" selected>CITY</option> -->
                    <!-- <option value="0">CITY</option> -->
                    <?php if(isset($cities)&& !empty($cities)){ ?>
                        <!-- <option value="0">CITY</option> -->
                    <?php foreach($cities as $city){ ?>
                        <?php if(isset($searchcity) && $city->name==$searchcity) { ?>
                                <option value="<?=$city->name;?>"selected><?=$city->name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$city->name;?>"><?=$city->name;?></option>
                            <?php } ?>
                    <?php } ?>
                    <?php } ?>
                </select>
            </div>
		<!--	<div class="styled-select">
                <select name="cuisine">
                    <option value="0">CUISINE</option>
                    <?php foreach($cuisines as $cuisine) :?>
                        <?php if(isset($searchcuisine) && $cuisine->id==$searchcuisine) { ?>
                                <option value="<?=$cuisine->id;?>"selected><?=$cuisine->name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
                            <?php } ?>
                    <?php endforeach;?>
                </select>
            </div>  -->
			<div class="styled-select">
                <select name="feature">
                    <option value="0">FEATURE</option>
                    <?php foreach($features as $feature) :?>
                        <?php if(isset($searchfeature) && $feature->id==$searchfeature) { ?>
                                <option value="<?=$feature->id;?>"selected><?=$feature->name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$feature->id;?>"><?=$feature->name;?></option>
                            <?php } ?>
                        
                    <?php endforeach;?>
                </select>
            </div>
		<!--	<div class="styled-select">
                <select name="price">
                    <option value="0">PRICE</option>
                    <?php foreach($prices as $price) : ?>
                        <?php if(isset($searchprice) && $price->id==$searchprice) { ?>
                                <option value="<?=$price->id;?>"selected><?=$price->name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$price->id;?>"><?=$price->name;?></option>
                            <?php } ?>
                    <?php endforeach;?>
                </select>
            </div> -->
            
			<!-- <div class="styled-select">
				<?php if(isset($states) && !empty($states)) :?>
					<select name="state">
						<option  value="0" selected>STATE</option>
						<?php foreach($states as $state) : ?>
							<option value="<?=$state->state_name;?>"><?=$state->state_name;?></option>
						<?php endforeach;?>
					</select>
				<?php endif;?>
			</div> -->
			<!-- Cities are not completed yet wating for detail table statewise-->
			<!-- <div class="styled-select">
				<?php if(isset($cities) && !empty($cities)) :?>
					<select name="city">
						<option  value="0" selected>CITIES</option>
						<?php foreach($cities as $city) : ?>
							<option value="<?=$city->name;?>"><?=$city->name;?></option>
						<?php endforeach;?>
					</select>
				<?php endif;?>
			</div> -->
			<? /*
			<div class="styled-select">
				<select name="cuisine">
					<option value="0" selected>CUISINE</option>
					<?php foreach($cuisines as $cuisine) :?>
						<option value="<?=$cuisine->name;?>"><?=$cuisine->name;?></option>
					<?php endforeach;?>
				</select>
			</div>
			<div class="styled-select">
				<select name="feature">
					<option value="0" selected>FEATURE</option>
					<?php foreach($features as $feature) :?>
						<option value="<?=$feature->name;?>"><?=$feature->name;?></option>
					<?php endforeach;?>
				</select>
			</div>
			<div class="styled-select">
				<select name="price">
					<option value="0" selected>PRICE</option>
					<?php foreach($prices as $price) : ?>
						<option value="<?=$price->id;?>"><?=$price->name;?></option>
					<?php endforeach;?>
				</select>
			</div> */ ?>
			<div class="container_inner margin_top_10">
				<input type="text" name="keyword" value="<?php if(isset($searchkeyword)){ echo $searchkeyword; }?>" placeholder="Or Search by keyword">
				<input type="submit" value="Search" class="btn login_link3" /> 
			</div>
			</div>		
			<div class="rest_co_add margin_top_20">
				<img src="<?=base_url();?>public/frontend/images/restaurents/re_co_leftadd.jpg" alt="add" />
			</div>
		</div>
	</div>
	<?=form_close();?>
</div><!--left here-->