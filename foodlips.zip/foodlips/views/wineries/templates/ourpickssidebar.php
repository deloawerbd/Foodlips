	<?php if(isset($ourpicks)&&!empty($ourpicks)){ ?>
	<?php foreach($ourpicks as $ourpick) { ?>
	<div class="winery_inner_wrp padding_bottom_none">
		<div class="winery_pick_img">
			<?php if(isset($ourpick->images)&&!empty($ourpick->images)){
				$images = unserialize($ourpick->images); ?>
				<img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$images[0];?>"/>
			<?php }else{ ?>
				<img class="icon" src="<?=base_url();?>public/frontend/images/wineries/100x100/winedefault.jpg"/>
			<?php }?>
		</div>
		<div class="winery_contain">
			<a href="<?=base_url();?>winery/details/<?=$ourpick->seo;?>">
			<span class="winery_headtxt"><?= $ourpick->title ?></span>
			</a>
			<span class="winery_containt_txt">
				<?php 
				$content = isset($ourpick->content) ? $ourpick->content : "";
				echo (strlen($content) > 50) ? substr(strip_tags($content),0,50).'...' : $content;
				?>
			</span>
		</div>
		<div class="both_clear"></div>
		<div class="winery_grp_txt">
		<?php	$discount = isset($ourpick->special_offers)? $ourpick->special_offers : "";
			    echo (strlen($discount) > 50) ? substr(strip_tags($discount),0,50).'...' : $discount;?>
		</div>
	</div> 
	<?php } ?>
	<?php }?>