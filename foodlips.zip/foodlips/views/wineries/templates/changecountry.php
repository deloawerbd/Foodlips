<div class="res_contry_flagbox">
    <img src="https://www.foodlips.com/images/flags/flag_<?=$country->iso_3;?>.jpg" alt="countryflag" />
    <span><a href="https://www.foodlips.com/shared/wineries">Change Country</a></span>
</div>
<div class="res_contry_flaghead">
    Welcome to the <?=$country->name;?> Winery Guide
</div>