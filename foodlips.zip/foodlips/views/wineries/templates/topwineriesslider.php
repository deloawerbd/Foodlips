<div class="margin_top_10">
	<div class="banner">
		<?php if(isset($venues) && !empty($venues)) { ?>
			<div id="myCarousel" class="carousel slide">
				<!-- class of slide for animation -->
				<div class="carousel-inner">
					<?php $slidecount = 0;?>
					<?php foreach ($venues as $venue) {
						
						if(isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) { ?>
							<?php $image = $venue->venue->photos->groups[0]->items[0]->prefix."original".$venue->venue->photos->groups[0]->items[0]->suffix; ?>
							<div class="<?=$slidecount === 0 ? 'active item' : 'item';?>" >
								<img src="<?=$image;?>" alt="banner">
								<div class="carousel-caption">
									<div class="recipe_b_txt">
										<span class="recipe_b_txt_1">
											<? /*<a target="_blank" href="<?=base_url();?>restaurant/details/venue/<?=$venue->venue->id;?>"><?=isset($venue->venue->name) ? $venue->venue->name : "No Name";?></a>*/?>
											<a href="#"><?=isset($venue->venue->name) ? $venue->venue->name : "No Name";?></a>
										</span>
										<span class="recipe_b_txt_2">
											<?php if(property_exists($venue->venue->categories['0'],"name")){ ?>
												<?=$venue->venue->categories['0']->name;?>
											<?php } ?>
										</span>
									</div>
								</div>
							</div>
							<?php }else{ ?>
								<div class="<?=$slidecount === 0 ? 'active item' : 'item';?>" >
									<img src="<?=base_url();?>public/frontend/images/wineries/winebanner.jpg" alt="banner">
								</div>
							<?php } ?>
						 
						<?php $slidecount++; 
						if($slidecount == 5) { break;}
					} ?>
				</div>
				<a class="left carousel-control" href="#myCarousel" data-slide="prev"><span>&lsaquo;</span></a>
				<a class="right carousel-control" href="#myCarousel" data-slide="next"><span>&rsaquo;</span></a>
			</div><!-- /.carousel -->
		<?php } ?>
	</div>
</div>

<? /*<div class="container_self margin_top_10">
	<div class="banner">
		<div id="myCarousel" class="carousel slide margin_bottom">
			<div class="carousel-inner margin_bottom">
				<div class="item active">
					<img src="<?=base_url();?>public/frontend/images/restaurents/resta_c_banner.jpg" alt="banner1">
				</div>
				<div class="item">
					<img src="<?=base_url();?>public/frontend/images/restaurents/banner-img2.jpg" alt="banner1">
				</div>
				<div class="item">
					<img src="<?=base_url();?>public/frontend/images/restaurents/banner-img3.jpg" alt="banner1">
				</div>
			</div>
			<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
			<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
		</div>
	</div>
</div> */ ?>