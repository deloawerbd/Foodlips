<div class="container-fluid margin_top_20">
	<div class="wrapper_self">
		<div class="res_satellite_map">
			<?php echo $countrymap['html']; ?>
			<!-- <img src="<?=base_url();?>public/frontend/images/restaurents/main_map.jpg" alt="banner1" /> -->
		</div>
	</div>
</div>