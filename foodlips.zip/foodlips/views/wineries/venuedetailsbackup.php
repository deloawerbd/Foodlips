<?php
 /*--------------------------------------------------------------------------------------------------
  |	This view is used to display venue details Venue Data are comes From Fouresquare API
  |
  ---------------------------------------------------------------------------------------------------
 */
?>
<style>
	tr {
    height: 1%;
    width : 1%;
	}
	td {
    text-align: center;
    vertical-align: middle;
    padding:2px
	}
	.hoursdropdown{
		width: 100px;
	}
	.tooltip-inner  {
		background: yellow!important;
		color: black;
		font-weight:900;
	}
	.tooltip.bottom .tooltip-arrow {
	  /*bottom: 0;
	  left: 50%;
	  margin-left: -5px;
	  border-width: 5px 5px 0;*/
	 border-bottom-color: yellow;
	 background: yellow!important;
	}
</style>
<div class="center_bg">
	<?php
		$limit = "";
		$order_by = "";
		$where["wid"] = $venue->id;
		$where["isapproved"] = "1";
		$where["name"] = "Address";
		$addressobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($addressobj)){
			$suggestedaddress = $addressobj[0]->suggested;
		}
		$where["name"] = "Website";
		$websiteobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($websiteobj)){
			$suggestedwebsite = $websiteobj[0]->suggested;
		}
		$where["name"] = "Facebook";
		$aFacebookobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($aFacebookobj)){
			$suggestedfacebook = $aFacebookobj[0]->suggested;
		}
		$where["name"] = "Twitter";
		$Twitterobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($Twitterobj)){
			$suggestedtwitter = $Twitterobj[0]->suggested;
		}
		$where["name"] = "Phone";
		$Phoneobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($Phoneobj)){
			$suggestedphone = $Phoneobj[0]->suggested;
		}
		$where["name"] = "Opening Hours";
		$openobj = $this->winemodel->getsuggestions($where,$limit,$order_by);
		if(!empty($openobj)){
			$suggestedtiming = $openobj[0]->suggested;
		}
		
		
	?>
	<?php if(isset($venue) && !empty($venue)) : ?>
		 	<?php //echo "<pre>"?>
		 	<?php //print_r($venue);exit;?>
			<?//php if(property_exists($venue->attributes->groups[0]->items[0], "priceTier")){print_r($venue->attributes->groups[0]->items[0]->priceTier);}exit;?>
		<!--Winery Title-->
		<div class="container_self margin_top_10">
			<input type="hidden" id="wineryid" name="wineryid" value="<?=$venue->id;?>" />
			<input type="hidden" id="userid" name="userid" value="<?=$this->db_session->userdata("id");?>"  />
			<input type="hidden" id="venue_title" value="<?=$venue->name;?>" />
			<input type="hidden" id="segment3" name="segment3" value="<?=$segment3?>"/>
			<div class="wrapper_self">
				<div class="res_contry_flaghead margin_top_20">
					<?=$venue->name;?>,&nbsp;<?=(property_exists($venue->location,"country")) ? $venue->location->country : ""; ?>
				</div>
			</div>
		</div>
		
		<div class="container_self margin_top_10">
			<div class="rest_country_710 custome_bg float_left">
				
				<!-- winery Map-->
				<div class="wrapper_self padding_bottom_none">
					<div class="state_map">
						<?php 
						echo $topmap["js"];
						echo $topmap["html"];
						?>
					</div>
				</div>
				
				<!--Image slider-->
				<?php //echo count($venue->photos->groups[0]->items);?>
				<?php if(isset($venue->photos->groups[0]->items) && !empty($venue->photos->groups[0]->items) && count($venue->photos->groups[0]->items) > 1 ) : ?>
					<?php $imgcounter = count($venue->photos->groups[0]->items); ?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_rpl_bannersld">
							<div id="details_slider" class="carousel slide margin_bottom">
								<div class="carousel-inner margin_bottom">
									<?php for($i = 0; $i < $imgcounter; $i++){ ?>
										<?php $image = $venue->photos->groups[0]->items[$i]->prefix."640x640".$venue->photos->groups[0]->items[$i]->suffix; ?>
										<div class="<?=$i === 0 ? 'active item' : 'item';?>"  style="height: 390px;" >
											<img src="<?=$image;?>" />
										</div>
									<?php }?> 
								<?php if(isset($images)&&!empty($images)){ ?>
									<?php $slidecount = 0;?>
									<?php foreach($images as $image) : ?>
								 		<div class='item'  style="height: 390px" >
											<img src="<?=base_url();?>public/frontend/images/wineries/1004x500/<?=$image;?>" />
										</div>
										<?php $slidecount++;?>
									<?php endforeach;?> 
									<?php } ?>
								</div>
								<a class="left carousel-control" href="#details_slider" data-slide="prev" style="top: 50%;">&lsaquo;</a>
								<a class="right carousel-control" href="#details_slider" data-slide="next" style="top: 50%;">&rsaquo;</a>
							</div>
						</div> 
					</div>
				<?php endif;?>
				
				<!--Prices-->
				<div class="wrapper_self margin_top_20">
					<div class="rest_price">
						<h4>Price</h4>
						<h3>
						<?php if(!empty($priceappend)){
							echo $priceappend;
						}else{
								if(!empty($venue->attributes->groups) && property_exists($venue->attributes->groups[0]->items[0],"priceTier")){
								$priceid = $venue->attributes->groups[0]->items[0]->priceTier;
								$display_name = $this->restmodel->getprices(array("id"=>$priceid));
								echo $display_name->name;	
							 	} 
							 }?>
					   </h3>
					</div>
					<div class="rest_cuisine">
						<h4>Cuisine</h4>
						<h3>
							<?php if(isset($venue->categories['0']->name) && property_exists($venue->categories['0'],"name")){ 
								echo $venue->categories['0']->name;
							 } 
							 if(isset($venue->categories['1']->name) && property_exists($venue->categories['1'],"name")){ 
								 if(isset($venue->categories['2']->name)){
								  		echo ", ".$venue->categories['1']->name;		
								  }else{
								  		echo " and ".$venue->categories['1']->name;
								  }
								
							 } 
							 if(isset($venue->categories['2']->name) && property_exists($venue->categories['2'],"name")){ 
								  if(isset($venue->categories['3']->name)){
								  		echo ", ".$venue->categories['2']->name;		
								  }else{
								  		echo " and ".$venue->categories['2']->name;
								  }
							 }
							 if(isset($venue->categories['3']->name) && property_exists($venue->categories['3'],"name")){ 
								  if(isset($venue->categories['4']->name)){
								  		echo ", ".$venue->categories['3']->name;		
								  }else{
								  		echo " and ".$venue->categories['3']->name;
								  }
							 } 
							 if(isset($venue->categories['4']->name) && property_exists($venue->categories['4'],"name")){ 
								  if(isset($venue->categories['5']->name)){
								  		echo ", ".$venue->categories['4']->name;		
								  }else{
								  		echo " and ".$venue->categories['4']->name;
								  }
							 } ?>
						</h3>
					</div>
					<?php if($this->db_session->userdata("id") != ""):?>
						<div class="rest_addphoto float_right">
							<a href="javascript:void(0)" id="btnaddphoto" class="btn" onclick="blockui('wineryimageloading');">Add Photo</a>
						</div>
						
						<div id="wineryimageloading" class="profile_box_inner2" style="display: none;">
							<form id="frmaddwineriesphoto">
								<span class="pull-right close_btn" onclick="unblockui()" style="font-size: 11px; font-style: italic; color: #bcbcbc; cursor: pointer;">
									<img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="Close" />
								</span>
								<div class="common_box">
									<p class="heading_color">Add Wineries Photo</p>
								</div>
								<div class="common_box">
									<label class="common_height">Photo:</label>
									<input type="file" id="wineryimgfile" name="userfile" multiple="true"  placeholder="Select Picture"/>
								</div>
								<div class="common_box">
									<span class="add_restaurant_flashtxt margin_left_90">you can upload multiple images</span>
								</div>
								
								<div class="common_box">
									<div class="selectimg margin_left_90">
										<ul id="image-list">
											
										</ul>
									</div>
								</div>
								<div id="errphotoupload" class="common_box"></div>
								<div class="common_box">
									<input type="button" class="btn margin_left_90" value="Add Photos" onclick="addWineriesExtraPhotos();"/>
								</div>
							</form>
						</div>
					<?php endif;?>
				</div>
				
				<!--Features-->
				<?php if(isset($features) && !empty($features)) : ?>
					<div class="wrapper_self margin_top_20">
						<div class="rest_links">
							<?php foreach($features as $feature) : ?>
								<span><?=$feature->name;?></span>
							<?php endforeach;?>
						</div>
					</div>
				<?php endif;?>
				<?php if($this->db_session->userdata("id") != ""):?>
					<div class="wrapper_self">
						<a href="javascript:void(0);" onclick="blockui('extarfeature');" class="btn float_right">Add Features</a>
					</div>
					<div id="extarfeature" class="profile_box_inner2" style="display: none;">
						<form id="frmextrafeatures">
							<span class="pull-right close_btn" onclick="unblockui()" style="font-size: 11px; font-style: italic; color: #bcbcbc; cursor: pointer;">
								<img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="Close" />
							</span>
							<div class="common_box">
								<p class="heading_color">Add Wineries Features</p>
							</div>
							<div class="common_box">
								<label class="common_height">Features:</label>
								<select id="selfeature" name="selfeature[]" multiple="multiple" size="6">
									<?php if(isset($allfeatures) && !empty($allfeatures)) : ?>
										<?php foreach($allfeatures as $allfeature) : ?>
											<option value="<?=$allfeature->id;?>"><?=$allfeature->name;?></option>
										<?php endforeach;?>
									<?php endif;?>
								</select>
								<span class="add_restaurant_flashtxt margin_left_90">Hold down Ctrl for multiple selection</span>
								<div id="errextarfeature" class="add_restaurant_flashtxt margin_left_90"></div>
							</div>
							<div class="common_box margin_top_20">
								<input type="button" class="btn margin_left_90" value="Add Features" onclick="addFeatures('wine');"/>
							</div>
						</form>
					</div>
				<?php endif;?>
				
				<!--Description-->
				<div class="wrapper_self margin_top_20">
					<div class="rest_rpl_containt">
						<h3><?=$venue->name;?> Overview</h3>
						<?=isset($venue->page->pageInfo->description) ? @$venue->page->pageInfo->description : "" ;?>
					</div>
				</div>
				
				<!--Extra Info-->
				<? /*<div class="wrapper_self margin_top_20">
					<div class="rest_rplweekly_heading">
						Extra Information About Wineries
					</div>
					<div class="rest_rpl_weekly">
						<h3>Opening Hours</h3>
						<img src="<?=base_url();?>public/frontend/images/restaurents/foot_calender.jpg" alt="food calender" />
					</div>
					<div class="rest_rpl_menu">
						<h3>Menu</h3>
						<div class="rest_rpl_innermenu">
							<ul><li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li>
								<li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li>
								<li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li>
							</ul>
						</div>
					</div>
				</div> */ ?>
				
				<div class="wrapper_self margin_top_20">
					<div class="rest_rplweekly_heading">
						Extra Information About Wineries
					</div>
					<div class="rest_rpl_weekly">
						<h3>Opening Hours</h3>
						<?php $days = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");?>
						<?php $types = array("Bfast","Lunch","Dinner"); ?>
						<!-- First table starts from here... -->
						<?php foreach($days as $day){ 
								  $where = array("wid"=>$venue->id,
										    //"isapproved"=>'1',
											"day"=>$day);
								  $opening_hours_data = $this->winemodel->getopeninghours($where);
								  //print_r($data);
								  	if(!empty($opening_hours_data)){
								  		  $Bfast[$day] = $opening_hours_data[0]->breakfast;
										  $Lunch[$day] = $opening_hours_data[0]->lunch;
										  $Dinner[$day] = $opening_hours_data[0]->dinner; 
										  if(!empty($opening_hours_data[0]->openingtime)){
										  	$openingtime[$day] = $opening_hours_data[0]->openingtime;
										  }
										  if(!empty($opening_hours_data[0]->closingtime)){
										  	$closingtime[$day] = $opening_hours_data[0]->closingtime;
										  }
								  	}else{
								  		$Bfast[$day] ="";
										$Lunch[$day] ="";
										$Dinner[$day] ="";
										$openingtime[$day] ="";
										$closingtime[$day] ="";
								  	}
							 } ?>
							<table>
								<tr>
									<th></th>
									<th>M</th>
									<th>T</th>
									<th>W</th>
									<th>T</th>
									<th>F</th>
									<th>S</th>
									<th>S</th>
								</tr>
								<?php foreach($types as $type){ ?>
								<tr>
									<th><?=$type;?></th>
									<?php foreach($days as $day){ ?>
										<?php  $t = $$type;?>
										<td style="width:20px; border: 2px solid;border-color: gainsboro;">
											<?php if(!empty($t[$day])){ ?>
												<?php if($t[$day] == 1){?>
													<img src="<?= base_url()?>public/frontend/css/font/css/symbol_check1.jpeg" alt="1">
												<?php }else{ ?>
													
												<?php } ?>
											<?php } ?>
										</td>
									<?php } ?>
								</tr>
								<?php } ?>
								<tr>
									<th>Time</th>
									<?php foreach($days as $day) { ?>
								
								<?php 
									  $where = array("wid"=>$venue->id,
													 //"isapproved"=>'1',
													 "day"=>$day);
									  $data = $this->winemodel->getopeninghours($where);
									  // print_r($data);
									  // print_r($data[0]->openingtime);
									  // print_r($data[0]->closingtime); 
									  
									  if(!empty($data[0]->openingtime)){
									  	$openingtime = $this->winemodel->gethours(array("id"=>$data[0]->openingtime));
										$finalopeningtime = $openingtime[0]->name;  
									  }else{
									  	$finalopeningtime = "-";
									  }
									  if(!empty($data[0]->closingtime)){
									  	$closingtime = $this->winemodel->gethours(array("id"=>$data[0]->closingtime));
										$finalclosingtime = $closingtime[0]->name;  
									  }else{
									  	$finalclosingtime = "-";
									  }
									  if($finalopeningtime=="CLOSED" || $finalclosingtime=="CLOSED"){
									  	$title = "Closed";
									  }else if($finalopeningtime=="OPEN ALL DAY" || $finalclosingtime=="OPEN ALL DAY"){
									  	$title = "Open All Day";
									  }else{
									  	$title = "Opening Time : ".$finalopeningtime."<br>"."Closing Time : ".$finalclosingtime;
									  }
									  
									 // $secondline = "Closing Time : ".$finalclosingtime;
									  ?>
									  
									<td style="width:20px; border: 2px solid;border-color: gainsboro;">
										<!-- <a href="#" id="example" rel="tooltip" data-title="This is the body of Popover">
											<i class="icon-time"></i>
										</a> -->
										<span rel="tooltip"  data-toggle="tooltip" class = "timepopup" data-placement="bottom" data-html = "true" data-title = "<?= $title?>" cursor:auto; ><i class="icon-time"></i></span>
										 <!-- <a  rel="tooltip" href="#" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Tooltip on bottom" class="timepopup"><i class="icon-time"></i></a> -->
									</td>
								<?php } ?>
								</tr>
						 	</table>
						
						<div style="color: rgb(128, 123, 123);">Seasonal variations may occur</div>
						<!-- <img src="<?=base_url();?>public/frontend/images/restaurents/foot_calender.jpg" alt="food calender" /> -->
						<div style="display: none" id="erropeninghours" class="add_restaurant_flashtxt"></div>
					</div>
					<div class="rest_rpl_menu">
						<h3>Menu</h3>
						<div class="rest_rpl_innermenu">
							<ul>
								<?php if(!empty($breakfast_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($breakfast_imgs as $breakfast_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries/<?= $breakfast_img?>" data-lightbox="breakfast_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$breakfast_img?>" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries/<?=$breakfast_img?>" data-lightbox="breakfast_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/breakfast_default.jpg" data-lightbox="breakfast_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/breakfast_default.jpg" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<?php if(!empty($lunch_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($lunch_imgs as $lunch_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries/<?= $lunch_img?>" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$lunch_img?>" style="width: 100%;height: 122px" alt="food Menu" /></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries/<?=$lunch_img?>" data-lightbox="lunch_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/lunch_default.png" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/lunch_default.png" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<?php if(!empty($dinner_imgs)){ ?>
										<?php $count=0;?>
										<?php foreach($dinner_imgs as $dinner_img){?>
											<?php if($count==0){ ?>
												<li><a href="<?=base_url();?>public/frontend/images/wineries/<?= $dinner_img?>" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/wineries/100x100/<?=$dinner_img?>" style="width: 100%;height: 122px" alt="food Menu" /></a></li>
											<?php }else {?>
												<a href="<?=base_url();?>public/frontend/images/wineries/<?=$dinner_img?>" data-lightbox="dinner_image"></a>
											<?php } ?>
											<?php $count++ ?>
											<?php } ?>
								<?php }else{ ?>
										<li><a href="<?=base_url();?>public/frontend/images/restaurents/default_images/dinner_default.jpg" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/restaurents/default_images/dinner_default.jpg" style="width: 100%;height: 122px" alt="food Menu"/></a></li>
								<?php } ?>
								<!-- <a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a> -->
								<!-- <li><a href="<?=base_url();?>public/frontend/images/restaurents/home/menu-sample1409223784.jpg" data-lightbox="lunch_image"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu"/></a></li> -->
								<!-- <li><a href="<?=base_url();?>public/frontend/images/restaurents/home/menu-sample1409223784.jpg" data-lightbox="dinner_image"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu"/></a></li> -->
								<!-- <li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li> -->
								<!-- <li><a href="#"><img src="<?=base_url();?>public/frontend/images/restaurents/food_menu.jpg" alt="food Menu" /></a></li> -->
							</ul>
						</div>
					</div>
				</div>
				<!-- menu button and popup -->
				<?php if($this->db_session->userdata("id") != "") { ?>
					<a href="javascript:void(0)" id="btnaddmenu"  class="btn float_right" onclick="blockui('addmenu');">Upload menu</a>
					<div style="display: none" id="erraddmenu" class="add_restaurant_flashtxt margin_left_520"></div>
					<div id="addmenu" class="profile_box_inner2" style="display: none">
						<span class="pull-right close_btn" onclick="unblockui()" style="font-size: 11px; font-style: italic; color: #bcbcbc; cursor: pointer;">
							<img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="Close" />
						</span>
						<form id="addmenuform">
						<div class="common_box">
							<p class="heading_color">Add Restaurant Extra Info</p>
						</div>
						<div class="common_box">	
							<p class="heading_color float_left">Add Menu</p>
						</div>
						<div class="common_box">
							<span class="add_restaurant_flashtxt float_left">Simply upload the image files(jpg,jpeg,png) of the menus</span>
						</div>
						<div class="common_box">
							<label class="common_height">Breakfast:</label>
							<input type="file" class="winerymenu" id="breakfast" name="userfile" multiple="true"  placeholder="Select Picture"/>
						</div>
						<div class="common_box">
							<label class="common_height">Lunch:</label>
							<input type="file" class="winerymenu" id="lunch" name="userfile" multiple="true"  placeholder="Select Picture"/>
						</div>
						<div class="common_box">
							<label class="common_height">Dinner:</label>
							<input type="file" class="winerymenu" id="dinner" name="userfile" multiple="true"  placeholder="Select Picture"/>
						</div>
						<div class="common_box">
							<div class="selectimg margin_left_90">
								<ul id="menu-list">
								</ul>
							</div>
						</div>
						<!-- <div id="erraddmenu" class="add_restaurant_flashtxt margin_left_90"></div> -->
						<input type="button" class="btn" id="winery" value="Submit" onclick="addWineryMenu(this.id);"/>
						</form>
					</div>
					
				<?php } ?>
				
				<!-- opening hours button and popup -->
				<?php if($this->db_session->userdata("id") != ""):?>
					<div class="wrapper_self margin_top_20">
<!-- 						<button type="submit" class="btn float_right">Add more info </button> -->
						<a href="javascript:void(0)" id="btnaddopeninghours"  class="btn" onclick="blockui('addopeninghours');">Add opening hours</a>
						
						<div id="addopeninghours" class="profile_box_inner2" style="display: none">
							<span class="pull-right close_btn" onclick="unblockui()" style="font-size: 11px; font-style: italic; color: #bcbcbc; cursor: pointer;">
								<img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="Close" />
							</span>
							<div class="common_box">
								<p class="heading_color">Add Restaurant Extra Info</p>
							</div>
							<div class="common_box">	
								<p class="heading_color float_left">Add Opening Hours</p>
							</div>
							<div id="addopeninghours" class="common_box">
								<form id="openinghoursform">
								<table>
									<tr>
										<td></td>
										<td>
											Bfast
										</td>
										<td>
											Lunch
										</td>
										<td>
											Dinner
										</td>
										<td>
											Opening Time
										</td>
										<td>
											Closing Time
										</td>	
									</tr>
									<?php $days = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");?>
										<?php foreach($days as $day){ ?>
										<?php $where = array('wid'=>$venue->id,'day'=>$day);?>
										<?php $data = $this->winemodel->getopeninghours($where);?>
									<tr>
										<td>
											<?= $day ?>
										</td>
										<td>
											<input type="checkbox" id="checkbox<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="breakfast" <?php if($data!=false && $data[0]->breakfast=="1")echo "checked"?>/>
     										<label for="checkbox<?= $day ?>" name="checkbox<?= $day ?>_lbl" class="css-label lite-green-check"></label>
										</td>
										<td>
											<input type="checkbox" id="checkbox2<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="lunch"<?php if($data!=false && $data[0]->lunch=="1")echo "checked"?>/>
     										<label for="checkbox2<?= $day ?>" name="checkbox2<?= $day ?>_lbl" class="css-label lite-green-check"></label>
										</td>
										<td>
											<input type="checkbox" id="checkbox3<?= $day ?>" class="css-checkbox" name="<?= $day ?>[]" value="dinner" <?php if($data!=false && $data[0]->dinner=="1")echo "checked"?>/>
     										<label for="checkbox3<?= $day ?>" name="checkbox3<?= $day ?>_lbl" class="css-label lite-green-check"></label>
										</td>
										<td>
											
											<select class="hoursdropdown" name="<?= $day ?>[opening_time]">
												<option value="">Select</option>
												<?php if(!empty($hours)) {?>
													<?php foreach($hours as $hour){ ?>
														<option value="<?= $hour->id?>"<?php if($data!=false && $data[0]->openingtime==$hour->id)echo "selected"?>><?= $hour->name?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</td>
										<td>
											<select class="hoursdropdown" name="<?= $day ?>[closing_time]">
												<option value="">Select</option>
												<?php if(!empty($hours)) {?>
													<?php foreach($hours as $hour){ ?>
														<option value="<?= $hour->id?>"<?php if($data!=false && $data[0]->closingtime==$hour->id)echo "selected"?>><?= $hour->name?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</td>
									</tr>
									<?php } ?>
								</table>
								<input type="checkbox" id="checkbox22" class="css-checkbox " name="selectall"/>
     										<label for="checkbox22" name="checkbox22_lbl" class="css-label lite-green-check">Select All</label>
								<!-- <div id="erropeninghours" class="add_restaurant_flashtxt margin_left_90"></div> -->
							</div>
								<input type="button" class="btn" id="winery" value="Submit" onclick="addwineryopeninghours(this.id);"/>
							</form>	
							</div>
						</div>
				<?php endif;?>	
				<div class="wrapper_self margin_top_20">
					<div class="rest_rpl_commentwrap">
						<div id="allcomments">
							<?php if(isset($comments) && !empty($comments)) : ?>
								<?php foreach($comments as $comment):?>
									<div class="rest_rpl_comment">
										<?php $this->load->model("communitymodel");?>
										<?php $user = $this->communitymodel->getuser(array("id"=>$comment->uid));?>
										<div class="rest_comment_img">
											<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>" >
												<img src="<?=base_url();?>public/frontend/images/user/40x40/<?=isset($user->image) ? $user->image : "noavatar.png";?>" />
											</a>
										</div>
										<div class="rest_comment_containt">
											<h4><?=$user->name;?>,&nbsp;<?=date_format(date_create($comment->date), 'l jS F Y \a\t g:ia');?></h4>
											<p><?=$comment->comment;?></p>
										</div>
									</div>
								<?php endforeach; ?>
							<?php endif;?>
						</div>
						
						<div id="container_comment" class="rest_comment_replycontaint margin_top_40">
							<h2>Post Your Review</h2>
							<p>Review</p>
							<textarea id="txtcomment" name="txtcomment" class="rest_comment_txtarea"></textarea>
							<div id="commenterror" class="wrapper_self"></div>
							<div class="wrapper_self">
								<button type="submit" class="btn float_right margin_bottom_10" onclick="commentOnRestaurant('wine');">Post</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!--Right Side Bar-->
			<div class="rest_country_290 float_left margin_left_20">
				<div class="winery_wraper" id="likedislike">
					<div class="community_head2" style="height: 40px">
							<span class="like_main"><span style="font-size: 20px"><?=$calculated_likes?></span><span style="font-size: 11px;margin-left: 4px; margin-right:4px;">/ 10</span></span><span class="head2">People like this.</span>
					</div>
					<?php if(isset($liked) && $liked != -1) {
						if($liked=="1"){ ?>
						<div class="community_head2" style="height: 40px">
							<span class="head2">You liked this! Unlike it</span><span class="likewinery" id="<?=$venue->id;?>_0" style="margin-left: 5px"><img src="<?=base_url();?>public/frontend/images/dislike.png" width="40px" alt="dislike" style="cursor:pointer"></span>
						</div>
						
					<?php } else {?>
						<div class="community_head2" style="height: 40px">
							<span class="head2">You unliked this place! Like it </span><span class="likewinery" id="<?=$venue->id;?>_1"><img src="<?=base_url();?>public/frontend/images/like.png" width="40px" alt="like" style="cursor:pointer"></span>
						</div>
					<?php }}else{ ?>
						<div class="community_head2" style="height: 40px">
							<span class="likewinery" id="<?=$venue->id;?>_1"><img src="<?=base_url();?>public/frontend/images/like.png" width="40px" alt="like" style="cursor:pointer"></span><span class="likewinery" id="<?=$venue->id;?>_0" style="margin-left: 5px"><img src="<?=base_url();?>public/frontend/images/dislike.png" width="40px" alt="dislike" style="cursor:pointer"></span><span class="head2">Do you like this place?</span>
						</div>
					<?php } ?>
					<div class="community_head2" style="height: 40px" id="errlike">
						<span class="rest_comment_rank float_left"></span>
					</div>
				</div>
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="rest_rpl_detail_group">
							<ul>
								<li>
									<i class="icon-map-marker icon-large"></i>
									<span class="rest_rpl_head_small"> Address :</span>
									<span class="rest_rpl_color_gry">
										<?=property_exists($venue->location,"address") ? $venue->location->address : "";?>,&nbsp;
										<?=property_exists($venue->location,"city") ? $venue->location->city : "";?>,&nbsp;
										<?=property_exists($venue->location,"state") ? $venue->location->state : "";?>
									</span>
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_color_red rest_rpl_head_small"> Website :</span>
									<span class="rest_rpl_head_small"><?=property_exists($venue,"url") ? '<a style="display: inline;" href="'.$venue->url.'" />'.$venue->url.'</a>' : "";?></span>
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_head_small"> Facebook :</span>
									<span class="rest_rpl_head_small"><?=isset($venue->contact->facebook) ? '<a style="display: inline;" href="'.$venue->contact->facebook.'" />'.$venue->contact->facebook.'</a>' : "";?></span>
								</li>
								<li>
									<i class="icon-globe icon-large"></i>
									<span class="rest_rpl_head_small"> Twitter :</span>
									<span class="rest_rpl_head_small"><?=isset($venue->contact->twitter) ? '<a style="display: inline;" href="https://twitter.com/'.$venue->contact->twitter.'" />'.$venue->contact->twitter.'</a>' : "";?></span>
								</li>
								<li>
									<i class="icon-phone icon-large"></i>
									<span class="rest_rpl_head_small"> Phone :</span>
									<span class="rest_rpl_head_small rest_rpl_color_gry"><?=property_exists($venue->contact,"phone") ? $venue->contact->formattedPhone : "";?></span>
								</li>
								<? /*<li>
									<i class="icon-food icon-large"></i>
									<span class="rest_rpl_head_small"> Lunch Hours :</span>
									<span class="rest_rpl_head_small">Tuesday - Sunday 11am - 3pm</span>
								</li>*/ ?>
								<li>
									<i class="icon-food icon-large"></i>
									<span class="rest_rpl_head_small"> Opening Hours :</span>
									<span><?=isset($venue->hours->status) ? $venue->hours->status : "";?></span>
								</li>
								<li id="li_addtofavorites">
									<?php if(isset($venue->photos->groups[0]->items[0]->prefix) && !empty($venue->photos->groups[0]->items[0]->prefix)){
										$image_url = $venue->photos->groups[0]->items[0]->prefix."100x100".$venue->photos->groups[0]->items[0]->suffix;
									}else{
										$image_url = base_url()."public/frontend/images/wineries/winedefault.jpg";
									}?>
									<a href="javascript:void(0);" id="winevenue" onclick="addtofavorites(this.id);" >Add to Favorites</a>
									<input type="hidden" id="image_url" value="<?=$image_url?>" />
									
								</li>
								<li id="errfavorite" style="display: none;">
									
								</li>
								 
							</ul>
						</div>
						
						<div class="rest_rpl_detail_group" style="background:none;">
							<ul>
								<li id="li_rating">
									<i class="icon-star-empty icon-large float_left"></i>
									<span class="rest_rpl_head_small float_left margin_left5"> Rating :</span>
									<div class="rest_comment_rank float_left">
										<ul>
											<?php $userrating = round($this->winemodel->takerating($venue->id));
											$greystarts = 5 - $userrating;
											$i = 0; $globalcount = 1;
											
											while($i < $userrating) { ?>
												<li>
													<img id="rt_<?=$globalcount;?>_<?=$venue->id;?>" class="ratewine" src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star" style="cursor:pointer" />
												</li>
											<?php $i++; $globalcount++; }
											$i = 0;
											while($i < $greystarts) { ?>
												<li>
													<img id="rt_<?=$globalcount;?>_<?=$venue->id;?>" class="ratewine" src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star" style="cursor:pointer" />
												</li>
											<?php $i++; $globalcount++; } ?>
										</ul>
									</div>
								</li>
								<li id="errrating">
									<span class="rest_comment_rank float_left"></span>
								</li>
								<? /*<li>
									<i class="icon-share icon-large"></i>
									<span class="rest_rpl_color_gry rest_rpl_head_small"> Share </span>
								</li>*/ ?>
								<li>
									<i class="icon-envelope icon-large"></i>
									<span class="rest_rpl_head_small"><a id="restaurant" href="javascript:void(0)" style="display: inline" onclick="blockui('mailtofriend')">Mail to a friend</a></span>
									<div id="mailtofriend" class="profile_box_inner2" style="display: none">
										<form id="mailtofriendform">
										<span class="pull-right close_btn" onclick="unblockui()" style="font-size: 11px; font-style: italic; color: #bcbcbc; cursor: pointer;">
											<img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="Close" />
										</span>
										<div class="common_box">
											<p class="heading_color">Suggest this winery to your friend</p>
										</div>
										<div class="common_box">
											<label class="common_height">To:</label>
											<input type="text" name="sendto" placeholder="Enter email address here">
										</div>
										<div class="common_box">
											<label class="common_height">Subject:</label>
											<input type="text" name="subject" value="Suggestion for a winery">
										</div>
										<div class="common_box">
											<label class="common_height">Body:</label>
											<textarea name="body" rows="10" cols="100"> Hi,<?= $this->db_session->userdata("user_name");?> has recommended you a winery. Click below the link : <?= base_url().$this->uri->uri_string();?></textarea> 
										</div>
										<div class="common_box margin_top_20">
											<input type="button" class="btn margin_left_90" id="restaurant" value="Send" onclick="mailtofriend();"/>
										</div>
										<div id="errsendingreport" class="add_restaurant_flashtxt margin_left_90"></div>
										</form>
									</div>
								</li>
								<? /*<li>
									<i class="icon-envelope icon-large"></i>
									<span class="rest_rpl_head_small rest_rpl_color_gry">Send Inquiry</span>
								</li>*/ ?>
							</ul>
						</div>
					</div>
				</div>
				
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="community_head2">
							<span class="head2">Get Directions</span>
						</div>
						<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
						<script type="text/javascript" src="<?=base_url();?>/public/frontend/js/restaurants/getDirectionsMap.js"></script>
						<div class="rest_rpl_getdirection_map">
							
							<div id="map_canvas_2" style="height: 400px; width: 275px;"></div>
							
							<div id="directionsDiv" class="winery_wraper margin_top_20">
								
							</div>
							<div class="winery_wraper margin_top_20">
								<form id="calculate-route" name="calculate-route" action="#" method="get">
									<?php 
									$geo_address = isset($venue->location->address) ? $venue->location->address."," : "";
									$geo_address .= isset($venue->location->city) ? $venue->location->city."," : " ";
									$geo_address .= isset($venue->location->state) ? $venue->location->state : "";
									?>							
									<input type="hidden" id="destination" name="destination" value="<?=$geo_address;?>"/>
									<?php /*
									<input type="hidden" id="latlang" name="latlang" value="<?=isset($venue->location->lat) ? $venue->location->lat : "";?>,<?=isset($venue->location->lng) ? $venue->location->lng : "";?>" />
									 */?>
									 <input type="hidden" name="lat" id="lat" value="<?=isset($venue->location->lat) ? $venue->location->lat : "";?>"/>
									 <input type="hidden" name="lng" id="lng" value="<?=isset($venue->location->lng) ? $venue->location->lng : "";?>" />
									<input type="text" id="fromAddress" name="fromAddress" required="required" class="float_left input_150" />
									<input type="submit" value="Get Direction" class="btn float_right"/>
								</form>
								<p id="error"></p>
							</div>
						</div>
					</div>
				</div>
				
				<div class="winery_wraper">
					<div class="well_custom">
						<div class="community_head2">
							<span class="head2">IN THE NEIGHBORHOOD</span>
						</div>
						<?php if(isset($neighborvenues) && !empty($neighborvenues)) : ?>
							<?php foreach($neighborvenues as $neighborvenue) :?>
								
								<div class="winery_inner_wrp margin_bottom_none">
									<div class="winery_pick_img">
										<?php if(isset($neighborvenue->venue->photos->groups[0])){ ?>
											<?php @$image = $neighborvenue->venue->photos->groups[0]->items["0"]->prefix."100x100".$neighborvenue->venue->photos->groups[0]->items["0"]->suffix; ?>
											<img src="<?=$image;?>"/>
										<?php }else{?>
											<img src="<?=base_url();?>public/frontend/images/restaurents/Restaurantdefault.jpg"/>
										<?php } ?>
									</div>
									<div class="winery_contain">
									<?php $titleforurl = !empty($neighborvenue->venue->name) ? $neighborvenue->venue->name : "NoName";
												if(!empty($neighborvenue->venue->name)){
													$specialchars = array("'", "|", "%", ",", "!", "@", "$", "^", "*", "&","-");
													$titleforurl = str_replace($specialchars, "",$titleforurl);
													$titleforurl = preg_replace('/\s+/', '_',$titleforurl);	
												}
												//print_r($titleforurl);
												//echo"<br>";
												$titleforurl = filter_var($titleforurl, FILTER_SANITIZE_URL);?>
										<a href="<?=base_url();?>winery/details/venue/<?=$titleforurl."-".$neighborvenue->venue->id;?>">
											<span class="winery_headtxt"><?=$neighborvenue->venue->name;?></span>
										</a>
										<? /*
										<div class="rest_comment_rank margin_left_none">
											<ul>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/green_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/gray_star.png" /></a></li>
												<li><a href="#"><img src="<?=base_url();?>public/frontend/images/gray_star.png" /></a></li>
											</ul>
										</div>*/ ?>
										<?php if(isset($neighborvenue->tips[0]->likes->count)){ ?>
										<span class="winery_containt_txt margin_top_10" >Likes: <?=$neighborvenue->tips[0]->likes->count;?></span>
										<?php } ?>
									</div>
								</div>
							<?php endforeach;?>
						<?php endif;?>
					</div>
				</div>
				
			</div>
		</div>
	<?php endif;?>
</div>