
<script src="jquery.js" type="text/javascript"></script>
<link rel="stylesheet" href="rating.css" />
<script type="text/javascript" src="rating.js"></script>

<div class="product">
           Rate Item 1
            <div id="rating_1" class="ratings">
            	<div class="star_1  ratings_stars ratings_vote"></div>
            	<div class="star_2  ratings_stars ratings_vote"></div>
            	<div class="star_3  ratings_stars ratings_vote"></div>
            	<div class="star_4  ratings_stars ratings_vote"></div>
            	<div class="star_5 ratings_stars ratings_blank"></div> 
            	<div class="total_votes"><p class="voted"> Rating: <strong>4</strong>/5 (543  vote(s) cast) 
            </div>
        </div><div class="product">
           Rate Item 2
            <div id="rating_2" class="ratings">
            	<div class="star_1  ratings_stars ratings_vote"></div>
            	<div class="star_2  ratings_stars ratings_vote"></div>
            	<div class="star_3  ratings_stars ratings_vote"></div>
            	<div class="star_4  ratings_stars ratings_vote"></div>
            	<div class="star_5 ratings_stars ratings_blank"></div> 
            	<div class="total_votes"><p class="voted"> Rating: <strong>4</strong>/5 (537  vote(s) cast) 
            </div>
        </div><div class="product">
           Rate Item 3
            <div id="rating_3" class="ratings">
            	<div class="star_1  ratings_stars ratings_vote"></div>
            	<div class="star_2  ratings_stars ratings_vote"></div>
            	<div class="star_3  ratings_stars ratings_vote"></div>
            	<div class="star_4  ratings_stars ratings_vote"></div>
            	<div class="star_5 ratings_stars ratings_blank"></div> 
            	<div class="total_votes"><p class="voted"> Rating: <strong>4</strong>/5 (513  vote(s) cast) 
            </div>
        </div></body></html>
<!-- Hosting24 Analytics Code -->
<script type="text/javascript" src="http://stats.hosting24.com/count.php"></script>
<!-- End Of Analytics Code -->
</div>
