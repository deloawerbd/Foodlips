<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Link Preview - LeoCardz</title>
		<link rel="stylesheet" class="cssStatics" type="text/css" href="<?=base_url();?>public/linkpreview/css/stylesheet.css" />
		<link rel="stylesheet" class="cssButtons" type="text/css" href="<?=base_url();?>public/linkpreview/css/linkPreview.css" />
		<script type="text/javascript" src="<?=base_url();?>public/linkpreview/js/jquery.js" ></script>
		<script type="text/javascript" src="<?=base_url();?>public/linkpreview/js/linkPreview.js" ></script>
		<script>
			$(document).ready(function() {
				//$('.linkPreview').linkPreview();
				
				// setting max number of images $('.linkPreview').linkPreview({imageQuantity: "put here the number"});
				// e.g. $('.linkPreview').linkPreview({imageQuantity: 15});
				$('.linkPreview').linkPreview({imageQuantity: 3});
				
				//saveDataURL($("#can"));
			});
			
			/* function saveDataURL(canvas) {
    			var request = new XMLHttpRequest();
    			request.onreadystatechange = function () {
        			if (request.readyState === 4 && request.status === 200) {
            			window.location.href = request.responseText;
        			}
    			};
    			request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    			request.open("POST", "https://www.foodlips.com/recipes/community/saveDataURL", true);
    			request.send("dataURL=" + canvas.toDataURL());
			} */
			
		</script>
	</head>
	<body >
		<? /* <canvas id="can">
			https://www.foodlips.com/recipes/community
		</canvas> */ ?>s
		
		<div class="bar">
			<img src="<?=base_url();?>public/linkpreview/img/leocardz.png" />
		</div>
		<div class="center">
			<div class="linkPreview">
				<div id="previewLoading"></div>
				<div>
					<textarea type="text" id="text" style="text-align: left" placeholder="What's in your mind"></textarea>
					<div style="clear: both"></div>
				</div>
				
				<div id="preview">
					<div id="previewImages">
						<div id="previewImage">
							<img src="<?=base_url();?>public/linkpreview/img/loader.gif" />
						</div>
						<input type="hidden" id="photoNumber" value="0" />
					</div>
					<div id="previewContent">
						<div id="closePreview" title="Remove" ></div>
						<div id="previewTitle"></div>
						<div id="previewUrl"></div>
						<div id="previewDescription"></div>
						<div id="hiddenDescription"></div>
						<div id="previewButtons" >
							<div id="previewPreviousImg" class="buttonLeftDeactive" ></div><div id="previewNextImg" class="buttonRightDeactive"  ></div>
							<div class="photoNumbers" ></div>
							<div class="chooseThumbnail">
								Choose a thumbnail
							</div>
						</div>
						<input type="checkbox" id="noThumb" class="noThumbCb" />
						<div class="nT"  >
							<span id="noThumbDiv" >No thumbnail</span>
						</div>
					</div>
					<div style="clear: both"></div>
				</div>
				<div style="clear: both"></div>
				<div id="postPreview">
					<input class="postPreviewButton" type="submit" value="Post" />
					<div style="clear: both"></div>
				</div>
				<div class="previewPostedList"></div>
			</div>
		</div>
		
		
	<?php function LoadJpeg($imgname) {
    	/* Attempt to open */
    	//$im = @imagecreatefromjpeg($imgname);

    	/* See if it failed */
    	//if(!$im) {
        	/* Create a black image */
        	/*$im  = imagecreatetruecolor(150, 30);
        	$bgc = imagecolorallocate($im, 255, 255, 255);
        	$tc  = imagecolorallocate($im, 0, 0, 0);

        	imagefilledrectangle($im, 0, 0, 150, 30, $bgc);*/

        	/* Output an error message */
        	//imagestring($im, 1, 5, 5, 'Error loading ' . $imgname, $tc);
    	//}

    	//return $im;
	}

	//header('Content-Type: image/jpeg');

	//$img = LoadJpeg('https://www.foodlips.com/recipes/community/publicwall');
	//imagejpeg($img);
	//imagedestroy($img); */
?>

		
	</body>
</html>
