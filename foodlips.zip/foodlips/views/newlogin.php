    
    <div class="center_bg">
        <div class="container_self">
       	  <div class="left_login_area">
           	
                <div class="left_login_boxarea">
					<img src="<?=base_url();?>images/video_img.jpg" width="673" height="388" class="left_login_boxarea" alt="video">
                </div>
                <div class="left_login_txthead">
                	Connect with friends and the
					world around you on Facebook.
                
                </div>
            </div>
        
        	<div class="right_login_area">
        		<?=form_open("");?>
	            	<div class="right_login_txthead">
	                	Sign Up
	                </div>
	               
	                <div class="right_login_box">
	                	<input name="emal" type="text" class="right_login_input" placeholder="First Name">
	                    <input name="emal" type="text" class="right_login_input" placeholder="Last Name">
	                </div>
	                <div class="right_login_box">
	                	<input name="email" type="text" class="right_login_input1" placeholder="Your Email">
	                </div>
	                <div class="right_login_box">
	                	<input name="email" type="text" class="right_login_input1" placeholder="Re-enter Email">
	                </div>
	                <div class="right_login_box">
	                	<input name="email" type="password" class="right_login_input1" placeholder="New Password">
	                </div>
	                <div class="right_login_box">
	                    <div class="right_login_txt">
	                        Birthday:
	                    </div>
	                    <div class="right_login_select_box">
	                    	<select name="month" class="right_login_select_input">
	                        	<option>Month</option>
	                            <option>January</option>
	                            <option>February</option>
	                            <option>March</option>
	                            <option>April</option>
	                            <option>May</option>
	                            <option>June</option>
	                            <option>July</option>
	                            <option>August</option>
	                            <option>September</option>
	                            <option>October</option>
	                            <option>November</option>
	                            <option>December</option>
	                        </select>
	                        
	                        <select name="month" class="right_login_select_input2">
	                        	<option>Day</option>
	                            <option>1</option>
	                            <option>2</option>
	                            <option>3</option>
	                            <option>4</option>
	                            <option>5</option>
	                            <option>6</option>
	                            <option>7</option>
	                            <option>8</option>
	                            <option>9</option>
	                            <option>10</option>
	                            <option>11</option>
	                            <option>12</option>
	                            <option>13</option>
	                            <option>14</option>
	                            <option>15</option>
	                            <option>16</option>
	                            <option>17</option>
	                            <option>18</option>
	                            <option>19</option>
	                            <option>20</option>
	                            <option>21</option>
	                            <option>22</option>
	                            <option>23</option>
	                            <option>24</option>
	                            <option>25</option>
	                            <option>26</option>
	                            <option>27</option>
	                            <option>28</option>
	                            <option>29</option>
	                            <option>30</option>
	                            <option>31</option>
	                        </select>
	                        
	                        <select name="month" class="right_login_select_input3">
	                        	<option>Year</option>
	                            <option>2001</option>
	                            <option>2002</option>
	                            <option>2003</option>
	                            <option>2004</option>
	                            <option>2005</option>
	                            <option>2006</option>
	                            <option>2007</option>
	                            <option>2008</option>
	                            <option>2009</option>
	                            <option>2010</option>
	                            <option>2011</option>
	                            <option>2012</option>
	                            <option>2013</option>
	                        </select>
	                        <!--<div class="community_login_link">
	                        	<a href="#">
	                        	Why do I need to provide my birthday?
	                            </a>
	                        </div>-->
	                    </div>
	                </div>
	                <div class="right_login_box">
	                	<div class="community_login_m_f_box">
	                    	<label>
	                			<input name="femal" type="radio" value="">
	                        	Female
	                        </label>
	                        <label>
	                			<input name="femal" type="radio" value="">
	                        	Male
	                        </label>
	                    </div>
	                </div>
	                <div class="right_login_box">
	                	<div class="right_community_txt">
	                   		By clicking Sign Up, you agree to our <a href="#">Terms</a> and that you have read our <a href="#">Data Use Policy</a>, including our <a href="#">Cookie Use</a>.
	               		</div>
	                </div>
	                <div class="right_login_box">
	                	<input type="submit" class="sign_up_btn" name="sbt_signup" value="Sign Up" />
	                </div>
                <?=form_close();?>
            </div>
        </div>							 <!--             end container here    -->
  	</div>
  	