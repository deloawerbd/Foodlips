<div class="page_wrapper">
	<div class="container-fluid margin_top_10">
    <div class="row">
    	<div class="col-md-2"></div>
        <div class="col-md-8">
		<div class="add_restaurant_main custome_bg">
			<div class="well_custom padding_bottom_none">
				<div class="community_head2">Add Restaurant</div>
				<?php $attributes = array("id" => "frmaddrestaurant", "class" => "form-horizontal", "method" => "post","style"=>"margin-left:40px;"); ?>
				<?=form_open_multipart("restaurant/add/", $attributes);?>
					<div class="well_custom4 padding_top">
						<div class="add_restaurant_txt">
							<strong>Note : </strong>Fields marked with
							<i class="icon-asterisk asterisk"></i>
							are required.
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Select Country <span class="asterisk">*</span></div>
						<div class="add_restaurant_fild_box">
							<select id="selcountry" name="country">
								<option value="" selected="selected">Select Country</option>
								<?php if(isset($countries) && !empty($countries)) : ?>
									<?php foreach($countries as $country) : ?>
										<option value="<?=$country->id;?>"><?=$country->name;?></option>
									<?php endforeach;?>
								<?php endif;?>
							</select>
							<i id="sateloader" class="icon-spinner icon-spin" style="display: none;"></i>
							<div class="errmsg"><?php echo form_error("country"); ?></div>
						</div>
					</div>
					<div id="satecombo" class="add_restaurant_outer" style="display: none;">
						<div class="add_restaurant_fild_name">Select State</div>
						<div class="add_restaurant_fild_box">
							<select id="selstate" name="state">
							</select>
							<i id="cityloader" class="icon-spinner icon-spin" style="display: none;"></i>
							<div class="errmsg"><?php echo form_error("state"); ?></div>
						</div>
					</div>
					
					<div id="citycombo" class="add_restaurant_outer" style="display: none;">
						<div class="add_restaurant_fild_name"> Select City</div>
						<div class="add_restaurant_fild_box">
							<select id="selcity" name="city">
							</select>
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Listing Title <span class="asterisk">*</span></div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="Enter Restaurant Title" name="title" value="<?=$this->input->post("title");?>" class="add_restaurant_txtinput margin_bottom_2">
							<div class="add_restaurant_flashtxt">Restaurant listing title.</div>
							
							<div class="errmsg"><?php echo form_error("title"); ?></div>
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
						<script type="text/javascript" src="<?=base_url();?>/public/frontend/js/restaurants/restaurantsetmap.js"></script>
						<div class="add_restaurant_fild_name">Address <span class="asterisk">*</span></div>
						
						<div class="add_restaurant_fild_box">
							<input type="text" id="geo_address" name="geo_address" class="add_restaurant_txtinput margin_bottom_2" value="<?=$this->input->post("geo_address");?>" >
							<div class="add_restaurant_flashtxt">
								Please enter restaurant address. eg. : <span class="font_bold"> 230 Vine Street And locations throughout Old City, Philadelphia, PA 19106</span>
							</div>
							<div class="errmsg"><?php echo form_error("geo_address"); ?>	</div>
							<div class="add_restaurant_wrap padding_top">
								<input type="button" class="btn" onclick="geocode();initialize();" value="Set address on map">
							</div>
							<div id="map_canvas" class="add_restaurant_map margin_top_20" style="height: 350px; width: 450px;">
								<!-- <img src="<?=base_url();?>public/frontend/images/restaurents/state_map.jpg" alt="banner1" /> -->
							</div>
							<div class="add_restaurant_flashtxt margin_top_10">
								Click on "Set Address on Map" and then you can also drag pinpoint to locate the correct address
							</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">
							Address Latitude
						</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" onblur="changeMap();" class="add_restaurant_txtinput margin_bottom_2" value="<?=$this->input->post("geo_latitude");?>" id="geo_latitude" name="geo_latitude">
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">
							Address Longitude
						</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" onblur="changeMap();" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("geo_longitude");?>" id="geo_longitude" name="geo_longitude">
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Select Cuisine</div>
						<div class="add_restaurant_fild_box">
							<select id="selcuisine" name="selcuisine">
								<option value="0">Select Cuisine</option>
								<?php if(isset($cuisines) && !empty($cuisines)) :?>
									<?php foreach($cuisines as $cuisine) :?>
										<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
									<?php endforeach; ?>
								<?php endif; ?>
							</select>
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Select Category</div>
						<div class="add_restaurant_fild_box">
							<select id="selcuisine" name="selcategory">
								<option value="0">Select Category</option>
								<?php if(isset($categories) && !empty($categories)) :?>
									<?php foreach($categories as $category) :?>
										<option value="<?=$category->id;?>"><?=$category->name;?></option>
									<?php endforeach; ?>
								<?php endif; ?>
							</select>
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Select Features</div>
						<div class="add_restaurant_fild_box">
							<select id="selfeature" name="selfeature[]" multiple="multiple" size="6">
								<?php if(isset($features) && !empty($features)) : ?>
									<?php foreach($features as $feature) : ?>
										<option value="<?=$feature->id;?>"><?=$feature->name;?></option>
									<?php endforeach;?>
								<?php endif;?>
							</select>
							<div class="add_restaurant_flashtxt margin_top_10">Hold Down Ctrl for Multiple features selection</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer">
						<div class="add_restaurant_fild_name">Select Price</div>
						<div class="add_restaurant_fild_box">
							<select id="selprice" name="selprice">
								<option value="0">Select Price</option>
								<?php if(isset($prices) && !empty($prices)) : ?>
									<?php foreach($prices as $price) : ?>
										<option value="<?=$price->id;?>"><?=$price->name;?></option>
									<?php endforeach;?>
								<?php endif;?>
							</select>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">
							Listing Description <span class="asterisk">*</span>
						</div>
						<div class="add_restaurant_fild_box">
							<div class="add_restaurant_txteditor">
								<!-- <img src="../images/aad_rest_editor.jpg" alt="Add Restaurant Editor" /> -->
								<textarea id="description" style="width:100%" name="description"><?=$this->input->post("description");?></textarea>
							</div>
							<div class="add_restaurant_flashtxt margin_top_10">
								Note : Basic HTML tags are allowed
							</div>
							<div class="errmsg"><?php echo form_error("description"); ?></div>
						</div>
					</div>
					
					<? /*<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Google Map View*</div>
						<div class="add_restaurant_fild_box">
							<div class="add_restaurant_mapview">
								<div class="add_rest_mapview1">
									<label class="radio">
										<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
										Default Map
									</label>
								</div>
								<div class="add_rest_mapview1">
									<label class="radio">
										<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
										Satellite Map
									</label>
								</div>
								<div class="add_rest_mapview1">
									<label class="radio">
										<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
										Hybrid Map
									</label>
								</div>
							</div>
						</div>
					</div> */ ?>
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">
							Special Offers
						</div>
						<div class="add_restaurant_fild_box">
							<div class="add_restaurant_txteditor">
								<textarea id="specialoffer" style="width:100%" name="specialoffer"><?=$this->input->post("specialoffer");?></textarea>
							</div>
							<div class="add_restaurant_flashtxt margin_top_10">
								Note: List out any special offers (optional)
							</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Time</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("timing");?>" id="timing" name="timing">
							<div class="add_restaurant_flashtxt margin_top_10">
								Enter Business or Listing Timing Information.
								<br />
								eg. : <span class="font_bold">10.00 am to 6 pm every day </span>
							</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Phone <span class="asterisk">*</span></div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("contact");?>" id="contact" name="contact">
							<div class="add_restaurant_flashtxt margin_top_10">
								You can enter phone number,cell phone number etc.
							</div>
							<div class="errmsg"><?php echo form_error("contact"); ?></div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Email <span class="asterisk">*</span></div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("txtemail");?>" id="txtemail" name="txtemail">
							<div class="errmsg"><?php echo form_error("txtemail"); ?></div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Website</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2 " value="<?=$this->input->post("website");?>" id="website" name="website">
							<div class="add_restaurant_flashtxt margin_top_10">
								Enter website URL. eg. : <span class="font_bold">http://sitename.com</span>
							</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Twitter</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2" value="<?=$this->input->post("twitter");?>" id="twitter" name="twitter">
							<div class="add_restaurant_flashtxt margin_top_10">
								Enter twitter URL. eg. :  <span class="font_bold">http://twitter.com/mysite</span>
							</div>
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Facebook</div>
						<div class="add_restaurant_fild_box">
							<input type="text" placeholder="" class="add_restaurant_txtinput margin_bottom_2" value="<?=$this->input->post("facebook");?>" id="facebook" name="facebook">
							<div class="add_restaurant_flashtxt margin_top_10">
								Enter facebook URL. eg. :  <span class="font_bold"> http://facebook.com/mysite</span>
							</div>
						</div>
					</div>
					
					<div id="restaurantimageloading" class="add_restaurant_outer margin_bottom_10">
						<div class="well_custom4 padding_top border_bottom_1 margin_bottom_10">
							<div class="add_restaurant_txt">
								Add images : <span style="color:#999999;">(You can upload more than one images to create image gallery on detail page)</span>
							</div>
						</div>
						<div class="add_restaurant_fild_name">Select Images</div>
						<div class="add_restaurant_fild_box">
							<div class="add_restaurant_wrap">
								<input type="file" id="restaurantimgfile" name="userfile"  title="" multiple ="true" />
								<!-- <button class="btn" type="submit">Upload Image</button> -->
								<ul id="image-list">
									
								</ul>
							</div>
							<!-- <div class="add_restaurant_flashtxt margin_top_10">
								Note : You can sort images from Dashboard and then clicking on " Edit" in the listing
							</div> -->
						</div>
					</div>
					
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name">Video code</div>
						<div class="add_restaurant_fild_box">
							<div class="add_restaurant_wrap">
								<textarea style="height: 150px;" class="add_rest_txtareainput" id="video" name="video"><?=$this->input->post("video");?></textarea>
							</div>
							<div class="add_restaurant_flashtxt margin_top_10">Paste video code here</div>
						</div>
					</div>
					<div class="add_restaurant_outer margin_bottom_10">
						<div class="add_restaurant_fild_name"></div>
						<div class="add_restaurant_fild_box">
							<input type="submit" class="btn" value="Submit" name="sbt_add" />
						</div>
					</div>
				<?=form_close();?>
			</div>
		</div>
        </div>
        <div class="col-md-2"></div>
        
        </div>
	</div>
</div>