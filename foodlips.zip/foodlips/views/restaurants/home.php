<?php $siteurl = "https://www.foodlips.com/";?>

<div class="page_wrapper">
	<div class="container-fluid margin_top_10">
		
	<!--Country Wise Flags view-->
	<?php if(!isset($hideslider)){
		  	$this->load->view("restaurants/templates/changecountry.php");
	      }?>
	<!--Carsual Slider view-->
	<?php if(!isset($hideslider)){
		  	$this->load->view("restaurants/templates/toprestaurantsslider.php");
	      }?>
	      			
	<!--Search by state on map-->

	<!--Google Map county view-->
	<?php //$this->load->view("restaurants/templates/countriesmap.php");?>
	
    <div class="margin_top_40">
	<div class="row">
		<!--Left div-->
		<div class="col-md-3"><?php $this->load->view("restaurants/templates/sidebar-left"); ?></div>
			
		<div class="col-md-9">
			
			<?php if(isset($hideslider)){ ?>
				<div class="search_result">
					Search Results: 
				</div>
			<?php } ?>
			<?php if(isset($pagination_links)) { ?>
				<div class="custom-pagination" style="margin-bottom: 10px;">
                	<?=$pagination_links;?>
                </div>
            <?php } ?>

			<!-- Restaurants listing-->
			<div class="winery_wraper margin_top_20">
				<div class="well_custom">
					<?php if(!empty($restaurants)) { ?>
						<?php foreach($restaurants as $restaurant): ?>  <!--upper for loop-->
							<?php //echo"<pre>";?>
							<?php //print_r($restaurant)?>
							<div class="rest_co_inner_wrp">
								<div class="rest_cofood_img">
									<?php if(isset($restaurant)) {
									       if($restaurant->from =="api") {
								    ?>
											<img class="icon" src="<?=$restaurant->image;?>" alt="profile img">
									<?php }
                                          else
                                          {
                                    ?>
											<img class="icon" src="<?=base_url();?>public/frontend/images/restaurents/home/100x100/<?=$restaurant->image?>"/>
									<?php }
									      } ?>
								</div>
								<div class="rest_co_contain">
									<span class="rest_co_headtxt">
										<a target="_blank" href="<?=base_url();?>restaurant/details/<?=$restaurant->res_link;?>">
											<?=$restaurant->title;?>
										</a>
									</span>
									<div class="rest_co_minihead">
										Type : 
											<span class="font_italic"><?=$restaurant->category;?></span>
									</div>
									<div class="rest_co_minihead">
										Price: 
											<span class="font_italic"><?=$restaurant->price;?></span>
									</div>

									<div class="home_likes">
										<span class="like_main">
											<span style="font-size: 20px"><?=$restaurant->calculated_likes?></span>
											<span style="font-size: 11px;margin-left: 4px">/ 10</span>
										</span>
										<span>people like this.</span>
									</div>

								</div>
							</div>
						<?php endforeach; ?>
					<?php }else{
						echo "Restaurants Not Found! ";
					}?>
				</div>
			</div>
			
			<?php if(isset($pagination_links)) { ?>
				<div class="custom-pagination" style="margin-bottom: 10px;">
                	<?=$pagination_links;?>
                </div>
            <?php } ?>
			</div>
		</div>
	</div><!--End container here-->
   </div>
</div>