<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Foodlips | Restaurant Guide</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
          <script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="ico/favicon.png">

        <!-- <link href='http://fonts.googleapis.com/css?family=Port+Lligat+Sans' rel='stylesheet' type='text/css'> -->
        <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css' media="" />
        <link href='https://fonts.googleapis.com/css?family=Marcellus+SC&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Quintessential&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Scada:400,700&subset=latin,latin-ext,cyrillic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Elsie+Swash+Caps|Roboto+Condensed:300|Julius+Sans+One|Anaheim|Advent+Pro|Open+Sans|Yanone+Kaffeesatz' rel='stylesheet' type='text/css'>

        <!-- Le styles -->
        <link href="<?=base_url();?>public/frontend/css/bootstrap.css" rel="stylesheet" />
        <link href="<?=base_url();?>public/frontend/css/jquery.share.css" rel="stylesheet" type="text/css" />
        <link href="<?=base_url();?>public/frontend/css/restaurants_home.css" rel="stylesheet" type="text/css">
<!--        <link href="../../css/bootstrap/bootstrap.css" rel="stylesheet" />
        <link href="../../css/jquery.share.css" rel="stylesheet" type="text/css" />
        <link href="../../css/style.css" rel="stylesheet" type="text/css">-->

        <?php $baseurl = "https://www.foodlips.com/shared/"; ?>

        <!-- Load Mask css-->
        <link type="text/css" rel="stylesheet" href="<?= $baseurl; ?>css/ajaxloading/jquery.loadmask.css" />

        <link href="<?= $baseurl; ?>/public/frontend/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <link href="<?= $baseurl; ?>public/frontend/css/community.css" rel="stylesheet" type="text/css">

        <!-- 		<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/jquery-1.10.2.min.js"></script>
<!-- 		<script src="<?= $baseurl; ?>public/frontend/js/formvalidation.js"></script> -->
        <script src="<?= $baseurl; ?>public/frontend/js/bootstrap.min.js"></script>

        <? /* <script type="text/javascript" src="js/jquery.social.share.1.2.min.js"></script> */ ?>

        <? /* <script type="text/javascript">var switchTo5x=true;</script>
        <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
        <script type="text/javascript" src="http://s.sharethis.com/loader.js"></script> */ ?>

        <script> var baseurl = "https://www.foodlips.com/shared/";</script>
        <script> var siteurl = "https://www.foodlips.com/";</script>
        <script> var loginurl = baseurl + "auth/login/";</script>
        <script> var communityurl = baseurl + "community/";</script>

        <!--[if !IE 8 ]>

        <![endif]-->
        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.share.js"></script>
        <!--<script type="text/javascript" src="../../js/jquery.share.js"></script>-->

        <script type="text/javascript" src="<?= $baseurl; ?>js/ajaxloading/jquery.loadmask.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsvalidation.js"></script>
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/foodlipsrequesthandler.js"></script>

        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/community/communityrequesthandler.js"></script>

        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlips_restaurants.js"></script>
        <!--<script type="text/javascript" src="../../js/foodlips.js"></script>-->
        <!--js for community notifications-->
        <script type="text/javascript" src="<?= $baseurl; ?>public/frontend/js/notifications.js"></script>

        <script>
                    (function (i, s, o, g, r, a, m) {
                        i['GoogleAnalyticsObject'] = r;
                        i[r] = i[r] || function () {
                            (i[r].q = i[r].q || []).push(arguments)
                        }, i[r].l = 1 * new Date();
                        a = s.createElement(o),
                                m = s.getElementsByTagName(o)[0];
                        a.async = 1;
                        a.src = g;
                        m.parentNode.insertBefore(a, m)
                    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

                    ga('create', 'UA-50424093-1', 'auto');
                    ga('send', 'pageview');

        </script>

    </head>

    <body>
        <div id="topmenulogin">
        </div>
        <?php $base_url = "https://www.foodlips.com/"; ?>
        <?php $recipe = base64_encode("recipe"); ?>
        <?php $recipe_base_url = "https://www.foodlips.com/shared/"; ?>
        <?php $restaurants_url = $base_url . 'shared/restaurants/'; ?>
        <?php //print_r($_SESSION);?>
        <?php // for FACEBOOK like ?>
        <div id="fb-root"></div>
        <div id="header">
            <div id="header_main">

                <div class="container-fluid">

                    <div class="header_top">

                        <div id="search_form"></div>

                        <div class="logo_header">
                            <a href="<?= $base_url; ?>">
                                <img src="<?= $recipe_base_url; ?>images/foodlips_logo1.png" class="logo" alt="FoodLips" />
                            </a>
                        </div>

                        <div id="loginlogout"></div>

                    </div>

                </div>
                <script type="text/javascript">
                    $(function () {
                        $("[rel='tooltip']").tooltip();
                    });

                </script>
                <script type="text/javascript">
                    $(document).ready(function () {
                        // $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout");
                        // $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu");
                        jQuery.ajaxSetup({
                            // Disable caching of AJAX responses
                            cache: false
                        });
                        setTimeout(function () {
                            var d = new Date();
                            var n = d.getTime();
                            $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout?t=" + n);
                            $("#search_form").load("https://www.foodlips.com/shared/recipe/searchform?t=" + n);
                            $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu?t=" + n);
                        }, 200);

                    });
                </script>

                <div class="clearfix"></div>

                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <button class="btn share_toggle" type="button"></button>

                        </div>

                        <div id="share_container">
                            <button class="btn share_toggle fixed" type="button"></button>
                            <div id="share"></div>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="navigation">
                            <ul class="nav navbar-nav">
                                <li>
                                    <a href="<?= $base_url; ?>">Home</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>community">Community</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe">Recipes</a>
                                </li>
                                <li>
                                    <a class="active" href="<?= $recipe_base_url; ?>restaurants">Restaurants</a>
                                </li>
                                <li>
                                    <a href="<?= $base_url; ?>wineries">Wineries</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>videos">Videos</a>
                                </li>
                                <li>
                                    <a href="<?= $base_url; ?>blog">Blog</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/aboutus">About</a>
                                </li>
                                <li>
                                    <a href="<?= $recipe_base_url; ?>recipe/contactus">Contact us</a>
                                </li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>

            </div>
        </div>

        <!-- Main Container -->
        <div class="center_bg">
            <div class="container-fluid">
                <div class="center_txt">
                        <!-- <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/Restaurant_head.png" alt="winer-head-txt" /> -->
                    <h2 class="about_heading">
                        WELCOME TO OUR RESTAURANT GUIDE
                    </h2>
                </div>
            </div>

            <!--<div class="container-fluid">
    <div class="row">

        <div class="col-sm-8">
            <div class="well_custom padding_bottom_none">
                <div class="community_box_in3">
                    <div class="winery_img_box">
                        <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/Restaurant_banner.jpg" alt="community_img">
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                $(document).ready(function() {
                    $("#picks").load(baseurl+"community/restaurantpicks");
                });
            </script>
        </div>
        <div class="col-sm-12">
            <div class="winery_wraper">
                <div class="well_custom">
                    <div class="community_head2">
                        <span class="head2">OUR PICKS</span>
                    </div>
                    <div id="picks"></div>
                </div>
            </div>
        </div>
    </div>
</div>-->
            <div class="container-fluid">
                <div class="winery_middle_contain">
                    <p>Here you can find restaurants from around the world. If you are a member of Foodlips you can add restaurants, restaurant images and save your favorite restaurants to your profile.</p>
                </div>
            </div>
            <div class="container-fluid"><!--Div left-->
                <div class="row">
                    <div class="col-sm-8">
                        <div class="well_custom">
                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">NORTH AMERICA</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>United-States">
                                            <div class="flag_txt_1">
                                                <span>United States</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/US.png" alt="flag img" title="United States"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_united_states.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Canada">
                                            <div class="flag_txt_1">
                                                <span>Canada</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/CA.png" alt="flag img" title="Canada"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_canada.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">SOUTH AMERICA</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Argentina">
                                            <div class="flag_txt_1">
                                                <span>Argentina</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/AR.png" alt="flag img" title="Argentina"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_argentina.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Brazil">
                                            <div class="flag_txt_1">
                                                <span>Brazil</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/BR.png" alt="flag img" title="Brazil"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_brazil.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">OCEANIA</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Australia">
                                            <div class="flag_txt_1">
                                                <span>Australia</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/AU.png" alt="flag img" title="Australia"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_australia.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>New-Zealand">
                                            <div class="flag_txt_1">
                                                <span>New Zealand</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/NZ.png" alt="flag img" title="New Zeeland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_new_zeland.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">EUROPE</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Austria">
                                            <div class="flag_txt_1">
                                                <span>Austria</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/AT.png" alt="flag img" title="Austria"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_austria.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Belgium">
                                            <div class="flag_txt_1">
                                                <span>Belgium</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/BE.png" alt="flag img" title="Belgium"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_belgium.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Czech-Republic">
                                            <div class="flag_txt_1">
                                                <span>Czech Republic</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/CR.png" alt="flag img" title="Czech Republic"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_czech_republic.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Denmark">
                                            <div class="flag_txt_1">
                                                <span>Denmark</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/DK.png" alt="flag img" title="Denmark"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_denmark.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Finland">
                                            <div class="flag_txt_1">
                                                <span>Finland</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/FI.png" alt="flag img" title="Finland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_finland.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>France">
                                            <div class="flag_txt_1">
                                                <span>France</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/FR.png" alt="flag img" title="France"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_france.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Germany">
                                            <div class="flag_txt_1">
                                                <span>Germany</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/DE.png" alt="flag img" title="Germany"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_germany.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>United-Kingdom">
                                            <div class="flag_txt_1">
                                                <span>Great Britain</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/GB.png" alt="flag img" title="Great Britain"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_grean_britain.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Hungary">
                                            <div class="flag_txt_1">
                                                <span>Hungary</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/HU.png" alt="flag img" title="Hungary"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_hungary.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Iceland">
                                            <div class="flag_txt_1">
                                                <span>Iceland</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/IS.png" alt="flag img" title="Iceland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_iceland.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Netherlands">
                                            <div class="flag_txt_1">
                                                <span>Netherlands</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/NL.png" alt="flag img" title="Netherlands"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_netherlands.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Norway">
                                            <div class="flag_txt_1">
                                                <span>Norway</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/NO.png" alt="flag img" title="Norway"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_norway.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Ireland">
                                            <div class="flag_txt_1">
                                                <span>Ireland</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/IE.png" alt="flag img" title="Ireland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_ireland.jpg" alt="profile img" />
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Italy">
                                            <div class="flag_txt_1">
                                                <span>Italy</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/IT.png" alt="flag img" title="Italy"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_italy.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Poland">
                                            <div class="flag_txt_1">
                                                <span>Poland</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/PL.png" alt="flag img" title="Poland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_poland.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Portugal">
                                            <div class="flag_txt_1">
                                                <span>Portugal</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/PT.png" alt="flag img" title="Portugal"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_portugal.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Spain">
                                            <div class="flag_txt_1">
                                                <span>Spain</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/ES.png" alt="flag img" title="Spain"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_spain.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Sweden">
                                            <div class="flag_txt_1">
                                                <span>Sweden</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/SE.png" alt="flag img" title="Sweden"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_sweden.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Switzerland">
                                            <div class="flag_txt_1">
                                                <span>Switzerland</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/CH.png" alt="flag img" title="Switzerland"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_switzerland.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">AFRICA</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>South-Africa">
                                            <div class="flag_txt_1">
                                                <span>South Africa</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/ZA.png" alt="flag img" title="South Africa"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flg_south_africa.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="restaurant_flag_box">
                                <div class="flag_txt_head">
                                    <a href="#">ASIA</a>
                                </div>
                                <ul>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>China">
                                            <div class="flag_txt_1">
                                                <span>China</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/CN.png" alt="flag img" title="China"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_china.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Hong-Kong">
                                            <div class="flag_txt_1">
                                                <span>Hong Kong</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/HK.png" alt="flag img" title="Hong Kong"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_hong_kong.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>India">
                                            <div class="flag_txt_1">
                                                <span>India</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/IN.png" alt="flag img" title="India"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_india.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Japan">
                                            <div class="flag_txt_1">
                                                <span>Japan</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/JP.png" alt="flag img" title="Japan"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_japan.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $restaurants_url; ?>Singapore">
                                            <div class="flag_txt_1">
                                                <span>Singapore</span>
                                                <img src="<?= $baseurl; ?>public/frontend/images/flags_icons_set/24x24/SG.png" alt="flag img" title="Singapore"/>
                                            </div>
                                            <div class="flag_img">
                                                <img src="<?= $baseurl; ?>public/frontend/images/countries_plates/flag_singapore.jpg" alt="profile img">
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div><!--community_recent_left3-->
                    </div><!--Div right end-->
                    <script>
                        $(document).ready(function () {
                            $("#highestrated").load(baseurl + "community/resthighestrated");
                        })
                    </script>

                    <div class="col-sm-4">
                        <div class="winery_wraper">
                            <div class="well_custom">
                                <div class="community_head2">
                                    <span class="head2">HIGHEST RATED</span>
                                </div>
                                <div id="highestrated"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#newfooter").load(baseurl + "community/commonfooter");
            });
        </script>

        <div class="footer_new_bg margin_top_20" >
            <div class="container-fluid">
                <div id="newfooter" class="footer_new">
                </div>
                <!-- Go to www.addthis.com/dashboard to customize your tools --> <div class="addthis_inline_follow_toolbox"></div>
            </div>
            <div class="footer_new_copyright">
                <div class="container-fluid">
                    <p class="copyright">2017 Copyright &copy; <a class="whitecolor footerlink" href="https://www.foodlips.com">Foodlips</a></p>
                </div>
            </div>
        </div>
        <!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-599145be1eb87b29"></script>
    </body>
</html>
