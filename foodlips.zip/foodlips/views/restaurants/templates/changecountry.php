<div class="res_contry_flagbox">
    <img src="https://www.foodlips.com/images/flags/flag_<?=$country->iso_3;?>.jpg" alt="aus_flag" />
    <span><a href="https://www.foodlips.com/shared/restaurants">Change Country</a></span>
</div>
<div class="res_contry_flaghead">
    Welcome to the <?=$country->name;?> Restaurant Guide
</div>