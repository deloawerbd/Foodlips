<script type="text/javascript">
//   $(function () {
//   		alert "<?php //echo base_url(); ?>//restaurantsrequesthandler/getcities_and_states";
//    	var getData = '<?php //echo $getallcities_of_country; ?>//';
//    	alert(getData);
//
//    var selectItem = function (event, ui) {
//        $("#cities_states").val(ui.item.label);
//        return false;
//    }
//
//    $("#cities_states").autocomplete({
//        source: getData,
//        select: selectItem,
//        minLength: 0
//    });
//});
</script>
	<div  class="rest_country_290">
	<?php if($this->db_session->userdata("id") != "") :
		$where = array(
						"id" => $this->db_session->userdata("id"),
						"user_name" => $this->db_session->userdata("user_name")
					);
		$loginuser = $this->communitymodel->getuser($where); ?>
		<div class="well_custom">
			<div class="community_head2">Welcome, <?=!empty($loginuser->name) ? $loginuser->name : $loginuser->user_name;?></div>
			<div class="rest_country_box">
				<a href="<?=base_url();?>restaurant/add">
					<span>Add New Restaurant</span>
				</a>
			</div>
		</div>
	<?php endif; ?>
	<?php $countryname = !empty($country->name) ? str_replace(" ", "-", $country->name) : "Australia"; ?>
	<?php $attribute = array("method"=>"GET");?>
	<?=form_open("restaurants/$countryname/",$attribute);?>
	<?php
	/*
	<div class="well_custom padding_bottom_none">
		<div class="community_box_in3">
			<input type="text" name="keyword" value="<?php if(isset($searchkeyword)){ echo $searchkeyword; }?>"  class="margin_10 width_256" placeholder="Search by keyword">
			<input type="submit" class="btn login_link3" value="Search">
		</div>
	</div>
	*/?>
	<div class="well_custom padding_bottom_none">
		<div class="community_box_in3">
			<div id = "sidebar">
			<div class="community_head2">Search For Restaurant</div>
			<div class="rest_country_box">
				<a href="https://www.foodlips.com/shared/restaurants">
					<span><img src="<?=base_url();?>public/frontend/images/closebtn.png" alt="close" /></span>
					<span><?=$countryname;//!empty($country->name) ? str_replace(" ", "-", $country->name) : "Australia";?></span>
				</a>
			</div>
			<!-- <div class="styled-select">
				<input type="text" name="keyword" value="<?php if(isset($searchkeyword)){ echo $searchkeyword; }?>"  class="margin_10 width_256" placeholder="Search by keyword">
			</div> -->

            <!--<div id="states">
                <input type='text'
                       placeholder='State'
                       class='flexdatalist'
                       data-selection-required='true'
                       data-min-length='0'
                       data-limit-of-values='1'
                       list='states_list'
                       multiple='multiple'
                       id='selstateforsearch'>

                <datalist id="states_list">
                        <?php foreach($states as $state) : ?>
                            <?php if(isset($searchstate) && $state->state_name==$searchstate) { ?>
                                <option value="<?=$state->state_name;?>" selected><?=$state->state_name;?></option>
                            <?php }else{ ?>
                                <option value="<?=$state->state_name;?>"><?=$state->state_name;?></option>
                            <?php } ?>
                        <?php endforeach;?>
                </datalist>
            </div>-->

			<div id="satecombo" class="styled-select">
				<?php if(isset($states) && !empty($states)) :?>
					<select id="selstateforsearch" name="state">
						<option value="0" selected disabled>STATE</option>
						<?php foreach($states as $state) : ?>
							<?php if(isset($searchstate) && $state->state_name==$searchstate) { ?>
								<option value="<?=$state->state_name;?>"selected><?=$state->state_name;?></option>
							<?php }else{ ?>
								<option value="<?=$state->state_name;?>"><?=$state->state_name;?></option>
							<?php } ?>
						<?php endforeach;?>
					</select>
				<?php endif;?>
			</div>
			<!-- <div id="cityloader" style="display: none">Loading Cities..</div> -->
			<!-- <i id="cityloader" class="icon-spinner icon-spin" style="display: none;"></i> -->
			<div id="citycombo" class="styled-select">
				<select id="selcity" name="city">
					<option  value="0" selected disabled>CITY</option>
					<!-- <option value="0">CITY</option> -->
					<?php if(isset($cities) && !empty($cities)){ ?>
						<!-- <option value="0">CITY</option> -->
					<?php foreach($cities as $city){ ?>
						<?php if(isset($searchcity) && $city->name==$searchcity) { ?>
								<option value="<?=$city->name;?>" selected><?=$city->name;?></option>
							<?php }else{ ?>
								<option value="<?=$city->name;?>"><?=$city->name;?></option>
							<?php } ?>
					<?php } ?>
					<?php }else{echo '<option value="0" disabled>Please select the state!</option>';} ?>
				</select>
			</div>
			<!-- <div id="citycombo" class="styled-select"> -->
			<!-- </div> -->
			<div class="styled-select">
				<select name="cuisine">
					<option value="0">CUISINE</option>
					<?php foreach($cuisines as $cuisine) :?>
						<?php if(isset($searchcuisine) && $cuisine->id==$searchcuisine) { ?>
								<option value="<?=$cuisine->id;?>" selected><?=$cuisine->name;?></option>
							<?php }else{ ?>
								<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
							<?php } ?>
					<?php endforeach;?>
				</select>
			</div>
			<div class="styled-select">
				<select name="feature">
					<option value="0">FEATURE</option>
					<?php foreach($features as $feature) :?>
						<?php if(isset($searchfeature) && $feature->id==$searchfeature) { ?>
								<option value="<?=$feature->id;?>" selected><?=$feature->name;?></option>
							<?php }else{ ?>
								<option value="<?=$feature->id;?>"><?=$feature->name;?></option>
							<?php } ?>

					<?php endforeach;?>
				</select>
			</div>
			<div class="styled-select">
				<select name="price">
					<option value="0">PRICE</option>
					<?php foreach($prices as $price) : ?>
						<?php if(isset($searchprice) && $price->id==$searchprice) { ?>
						    <option value="<?=$price->id;?>" selected><?=$price->name;?></option>
					    <?php }else{ ?>
						     <option value="<?=$price->id;?>"><?=$price->name;?></option>
					     <?php } ?>
					<?php endforeach;?>
				</select>
			</div>
			<div class="container_inner margin_top_10">
				<input type="text" name="keyword" value="<?php if(isset($searchkeyword)){ echo $searchkeyword; }?>" placeholder="Or Search by keyword">
				<input type="submit" value="Search" class="btn login_link3"/>
			</div>

            <!--<div class="container_inner margin_top_10 something">
                <input type="text" class='mySearch' id="ls_query" placeholder="Type to start searching ...">
                <div id="suggestions">
                    <div id="autoSuggestionsList"></div>
                </div>
                <input type="submit" value="Search" class="btn login_link3"/>
            </div>-->

            <!--<div class="container_inner margin_top_10 something">
                <input name="search_data" id="search_data" type="text" onkeyup="ajaxSearch();" placeholder="Search for restaurants or cuisines...">
                <div id="suggestions">
                    <div id="autoSuggestionsList"></div>
                </div>
                <input type="submit" value="Search" class="btn login_link3"/>
            </div>-->

			</div>
			<? /* accordion not supporting to drop down box
			<div class="accordion">
				<div>
					<!-- <input id="ac-1" name="accordion-1" type="checkbox" /> -->
					<label for="ac-1">STATE</label>
					<div class="article ac-small">
						<?php if(isset($states) && !empty($states)) :?>
							<ul><select>
								<?php foreach($states as $state) : ?>
									<li><option>
										<a href="<?=base_url();?>restaurants/<?=!empty($country->name) ? $country->name : "Australia";?>/<?=$state->state_name;?>">
											<span><?=$state->state_name;?></span>
											<span>[3595]</span>
										</a></option>
									</li>
								<?php endforeach;?>
								</select>
							</ul>
						<?php endif;?>
					</div>
				</div>

				<div>
					<input id="ac-2" name="accordion-1" type="checkbox" />
					<label for="ac-2">CUISINE</label>
					<div class="article ac-small">
						<ul>
							<?php foreach($cuisines as $cuisine) :?>
								<li>
									<a href="#">
										<span><?=$cuisine->name;?></span>
									</a>
								</li>
							<?php endforeach;?>
						</ul>
					</div>
				</div>

				<div>
					<input id="ac-3" name="accordion-1" type="checkbox" />
					<label for="ac-3">FEATURE</label>
					<div class="article ac-small">
						<ul>
							<?php foreach($features as $feature) :?>
								<li>
									<a href="#">
										<span><?=$feature->name;?></span>
									</a>
								</li>
							<?php endforeach;?>
						</ul>
					</div>
				</div>

				<div>
					<input id="ac-4" name="accordion-1" type="checkbox" />
					<label for="ac-4">PRICE</label>
					<div class="article ac-small">
						<ul>
							<?php foreach($prices as $price) : ?>
								<li>
									<a href="">
										<span><?=$price->name;?></span>
									</a>
								</li>
							<?php endforeach;?>
						</ul>
					</div>
				</div>
		</div> */?>
			<div class="rest_co_add margin_top_20">
				<img src="<?=base_url();?>public/frontend/images/restaurents/re_co_leftadd.jpg" alt="add" />
			</div>
		</div>
	</div>
	<?=form_close();?>
</div><!--left here-->