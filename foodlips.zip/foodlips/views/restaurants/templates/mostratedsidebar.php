	<?php foreach($mostrated as $rated) { ?>
	<div class="winery_inner_wrp padding_bottom_none">
		<div class="winery_pick_img">
			<?php if(!empty($rated->images)){
				$images = unserialize($rated->images); ?>
				<img src="<?=base_url();?>public/frontend/images/restaurents/home/100x100/<?=$images[0];?>"/>
			<?php }else{ ?>
				<img src="<?=base_url();?>public/frontend/images/restaurents/Restaurantdefault.jpg" alt="profile img" />
			<?php }?>
		</div>
		<div class="winery_contain">
			<a href="<?=base_url();?>restaurant/details/<?=$rated->seo;?>">
			<span class="winery_headtxt"><?= $rated->title ?></span>
			</a>
			<span class="winery_containt_txt">
				<?php 
				$content = isset($rated->content) ? $rated->content : "";
				echo (strlen($content) > 50) ? substr(strip_tags($content),0,50).'...' : $content;
				?>
			</span>
		</div>
		<div class="both_clear"></div>
		<div class="winery_grp_txt">
		<?php	$discount = isset($rated->special_offers)? $rated->special_offers : "";
			    echo (strlen($discount) > 50) ? substr(strip_tags($discount),0,50).'...' : $discount;?>
		</div>
	</div> 
	<?php } ?>