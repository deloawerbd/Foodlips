<?php if(isset($restaurants) && !empty($restaurants)) : ?>
	<?php foreach($restaurants as $restaurant) : ?>
		<div class="rest_co_inner_wrp">
			<div class="rest_cofood_img">
				<?php $images = unserialize($restaurant->images);?>
				<?php if(isset($images[0])){?>
					<img class="icon" src="<?=base_url();?>public/frontend/images/restaurents/home/100x100/<?=$images[0];?>"/>
				<?php }else{?>
					<img class="icon" src="<?=base_url();?>public/frontend/images/restaurents/Restaurantdefault.jpg"/>
				<?php }?>
			</div>
			<div class="rest_co_contain">
				<span class="rest_co_headtxt">
					<a target="_blank" href="<?=base_url();?>restaurant/details/<?=$restaurant->seo;?>"><?=$restaurant->title;?></a>
				</span>
				<? /*<div class="rest_co_minihead font_italic">
					Box Hill Restaurants VIC
				</div> */ ?>
				<?php if($restaurant->categoryid > 0) {?>
				<div class="rest_co_minihead">
					<?php 
						$where = array("id"=>$restaurant->categoryid);
						$res = $this->restmodel->getcategorybyid($where);
						$res = $res->name;
						if(isset($res))
						{
					 		echo "Type : ".$res;
						}
					?>
				</div>
				<?php } ?>
				<span class="rest_co_containt_txt">
					<?=$restaurant->content;?>
				</span>
			</div>
		</div>
	<?php endforeach;?>
<?php endif;?>