  <div class="container">
    	<div class="row">
        	<div class="center">
            	<div class="thumbnail login_page_box">
                	<div class="login_head">Login</div>
                	
                        <form class="form-horizontal form_box_control" method="post" action="<?=base_url()?>recipe/login">
                            <div class="control-group">
                            <label class="control_txt_box" for="inputEmail">Email</label>
                            <div class="control_input_box">
                            <input type="text" id="inputEmail" placeholder="Email" name="email">
                            </div>
                            </div>
                            <div class="control-group">
                            <label class="control_txt_box" for="inputPassword">Password</label>
                            <div class="control_input_box">
                            <input type="password" id="inputPassword" placeholder="Password" name="password">
                            </div>
                            </div>
                            <div class="control-group">
                            <div class="control_check_box">
                            <label class="checkbox">
                            <input type="checkbox"> Remember me
                            </label>
                            <button type="submit" class="btn btn-primary" name="sbt_login" value="login">Sign in</button>
                            </div>
                            </div>
                       </form>
                    
                </div>
            	
            </div>
        </div>
    </div>