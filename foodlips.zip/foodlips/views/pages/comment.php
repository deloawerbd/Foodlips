			<div class="container">
    			<div class="row">
        			<div class="center">
            			<div class="span6 offset3">
							<form method="post" action="<?=base_url();?>recipe/comment">
								<input type="hidden" name="recipeid" value="<?=isset($recipeid) ? $recipeid : 0;?>"/>
								<textarea name="comment" cols="100" rows="5" placeholder="Type your commnent"></textarea><br>
								<input type="submit" name="sbt_comment" value="Submit" />
								<input type="reset" name="reset" value="Clear" />
							</form>
						</div>
					</div>
				</div>
			</div>