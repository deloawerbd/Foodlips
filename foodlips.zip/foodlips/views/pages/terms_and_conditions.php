			<div class="page_wrapper">

    			<div class="container-fluid">

        			<div class="center">

            			<h2 class="about_heading">

            				TERMS AND CONDITIONS

                		</h2>

                		<div class="about_txt">

							<p>At FOODLIPS we have a profound belief that FOOD can INSPIRE, that food can UNITE and break down the barriers that separate us. Through food we have the ability to COMMUNICATE in ways much stronger than just words and it is this unity that drives what we do.</p>
						  <p>We have a burning DESIRE to share our experiences and passion for food and believe everyone should have a SAFE and FRIENDLY environment to do the same. Regardless of where we are from we can all speak the language of food and its food that we believe can help unite us all. </p>
							<p>We LOVE everything about FOOD and we wanted to create a place that allow for other food lovers to hang out and have fun with likeminded people by SHARING their PASSION and CONNECT with people from all over the WORLD. </p>
							<p><br>
							  <strong>WHAT MAKES FOODLIPS DIFFERENT TO OTHER WEBSITES AND SOCIAL NETWORKS?</strong><br>
						    The creators of FOODLIPS are highly passionate about food and being able to share and express their LOVE for food and cooking with others. We have found many different food sites online that allow for foodies to connect, but none that are able to fulfil our need of having the ONE PLACE where we can store all our recipes, favourite wines, favourite restaurants, favourite food blogs, share our cooking pictures, participate in groups and meetups at the same time as having a fully functional SOCIAL NETWORK for foodies only. At FOODLIPS we allow people to come together to share and celebrate their experiences with others in an open, excepting and safe environment. </p>
						  <p><br>
							  <strong>WHAT DO WE OFFER?</strong><br>
						    Get INSPIRED by having a read of our BLOG or perhaps CHAT with other foodies on our food SOCIAL NETWORK, maybe you would like to enjoy our growing recipe database, view VIDEOS of food, store other great RECIPES you find online or perhaps you are looking for a good RESTAURANT nearby, whatever you are looking for FOODLIPS is our HOME OF FOOD and we invite you to make it yours as well.</p>
							<p><br>
						    Have a look around and feel free to <a href="https://www.foodlips.com/shared/community" target="new">join our new growing community of foodies</a> and create a food social network group of likeminded people,<a href="https://www.foodlips.com/shared/recipe" target="new"> search our database of recipes</a> or <a href="https://www.foodlips.com/shared/videos">cooking videos</a>, find a <a href="https://www.foodlips.com/shared/restaurants" target="new">restaurant</a> or <a href="https://www.foodlips.com/shared/wineries" target="new">winery</a>, perhaps enjoy a read of our FOODLIPS <a href="https://www.foodlips.com/blog" target="new">blog</a> but most of all keep the PASSION FOR FOOD BURNING inside you and ENJOY your time here at FOODLIPS.</p>
							<p><strong>VALUE FOR OUR MEMBERS</strong><br>
						    FOODLIPS is a social network made by foodies for foodies. We have a strong desire to make this YOUR HOME OF FOOD so we are very appreciative of feedback both good and bad.</p>
							<p>We will be continuously developing FOODLIPS to make the experience more FUN and ENJOYABLE and encourage your feedback so feel free <a href="https://www.foodlips.com/shared/recipe/contactus" target="new">contact us by clicking here</a>. We look forward to hearing from you. </p>

		                </div>

            		</div>

        		</div>

    		</div>