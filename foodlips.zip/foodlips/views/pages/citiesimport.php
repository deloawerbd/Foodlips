<?php

if(isset($_POST["Import"])){
	$filename=$_FILES["file"]["tmp_name"];
	if($_FILES["file"]["size"] > 0){
		$file = fopen($filename, "r");
		while (($excelrow = fgetcsv($file,1000,",","'")) !== FALSE){
			
			$where = array("name"=>$excelrow[0]);
			if($this->restmodel->getcountryidbyname($where)!=FALSE){
				$excelrow[0] = $this->restmodel->getcountryidbyname($where);
			}
			// $patterns = array (
								// '/\W+/', // match any non-alpha-numeric character sequence, except underscores
								// '/\s+/'  // match any number of white spaces
							// );
			// $replaces = array ('-', '-' );
			
			//$excelrow[1] = trim(preg_replace($patterns, $replaces,$excelrow[1]));
			$where = array("state_name"=>$excelrow[1]);
			if($this->restmodel->getstateidbyname($where)!=FALSE){
				$excelrow[1] = $this->restmodel->getstateidbyname($where);
			}
			$data = array("countryid"=>$excelrow[0],
						  "stateid"=>$excelrow[1],
						  "name"=>$excelrow[2],
						  "latitude"=>$excelrow[3],
						  "longitude"=>$excelrow[4],
			     			);
			$insertid = $this->restmodel->addcities($data);
		}
		fclose($file);
		echo "CSV File has been successfully Imported";
	}else{
		echo "Invalid File:Please Upload CSV File";
	}
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Import CSV/Excel file</title>
	</head>
	<body>
		<form enctype="multipart/form-data" method="post">
			<table border="1" width="40%" align="center">
				<tr >
					<td colspan="2" align="center"><strong>Import CSV/Excel file</strong></td>
				</tr>
				<tr>
					<td align="center">CSV/Excel File:</td><td><input type="file" name="file" id="file"></td></tr>
					<tr >
						<td colspan="2" align="center"><input type="submit" name="Import" value="Import"></td>
					</tr>
			</table>
		</form>
	</body>
</html>