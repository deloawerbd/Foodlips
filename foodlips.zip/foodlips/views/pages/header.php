<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<?php 
		$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$images = ""; $imagefolder = "1004x400/";
		if(isset($recipe)){
			if(isset($recipe->images) || $recipe->images != "") {
				$images = explode(",", $recipe->images);
				if(count($images)) { $i = 0;
					foreach ($images as $image) { ?>
						<meta property="og:type" content="article" />
						<meta property="og:image" content="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$image;?>" />
						<meta property="og:url" content="<?php echo $url; ?>"/>
					<?php }
				}
			}
		} ?>

		<title><?=$recipe->title;?></title>
		
		<!-- Le styles -->
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/bootstrap.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/font-awesome/css/font-awesome.min.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>css/lightbox/lightbox.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>css/ajaxloading/jquery.loadmask.css" />
		
		<!-- Datepicker start -->
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/ui-lightness/jquery-ui.css" />
	 	<!-- Datepicker end -->
	 	
	 	<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/jquery.alt-checkbox.icon-font.min.css" />
	  	<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/jquery.alt-checkbox.min.css" />
	  	<? /* <link type="text/css" rel="stylesheet" href="<?=base_url();?>public/shared/css/jquery-ui-1.10.2.custom.css" rel="stylesheet"> */ ?>
	  	<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/jquery.share.css" />
	  	
	  	<link type="text/css" rel="stylesheet" href="<?=base_url();?>css/style.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/rating.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/notification.css" />
		<?php $segment = $this->uri->segment("1");
		//if($segment != "videos") { ?>
			<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/community.css<?php echo '?v='.time().'"'; ?> />
		<?php //} ?>
				
		<!--for video slider-->
		<!--for youtube video slider-->
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>public/frontend/css/ytv.css" />
		
		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<!-- Fav and touch icons -->
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="../ico/apple-touch-icon-144-precomposed.png">
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="../ico/apple-touch-icon-114-precomposed.png">
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="../ico/apple-touch-icon-72-precomposed.png">
		<link rel="apple-touch-icon-precomposed" href="../ico/apple-touch-icon-57-precomposed.png">
		<link rel="shortcut icon" href="../ico/favicon.png">
		<!-- <link href='http://fonts.googleapis.com/css?family=Port+Lligat+Sans' rel='stylesheet' type='text/css'> -->
		<link href='http://fonts.googleapis.com/css?family=Marcellus+SC&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Marcellus&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Quintessential&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Scada:400,700&subset=latin,latin-ext,cyrillic' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
		<?php $recipe = base64_encode("recipe"); ?>
		
		<script> var baseurl = "<?=base_url();?>"; </script>
		<script> var siteurl = "https://www.foodlips.com/"; </script>
		<script> var loginurl = baseurl + "auth/login/"; </script>
		<script> var communityurl = baseurl + "community/"; </script>
		<script> var isNewsFeed = "<?=$this->uri->segment("2") == "newsfeed" ? "true" : "false";?>"; </script>
    	<script> var recipe = "<?=$recipe;?>"; </script>
    	<script type="text/javascript">
			var isLoginPage = false;
		</script>
    	
		<style>
			.selected {
				font-size: 18px;
				color: #005dbd;
				background: #FFF;
				border-radius: 6px 6px 0px 0px;
			}
			.selected a {
				font-size: 18px;
				color: #005dbd;
				background: #FFF;
				border-radius: 6px 6px 0px 0px;
			}
		</style>
		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.10.2.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.1.1.js"></script>
        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/bootstrap.min.js"></script>
	 	<? /* <script type="text/javascript" src="<?=base_url();?>public/frontend/js/bootstrap.min.js"></script> */ ?>
	 	
	 	<!-- Datepicker start -->
	 	<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-ui-1.8.9.custom.js"></script>
		<!-- Datepicker end -->
		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-ui.js"></script>
		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.form.js"></script>
		<script type="text/javascript" src="<?=base_url();?>js/ajaxloading/jquery.loadmask.js"></script>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.multiFieldExtender-2.0.js"></script>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.alt-checkbox.min.js"></script>
  		<? /* <script type="text/javascript" src="<?=base_url();?>public/shared/js/jquery-ui-1.10.2.custom.js"></script> */ ?>
  		
  		<!-- block ui start -->
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/community/jquery.blockUI.js"></script>
  		<!-- block ui end -->
  		
  		<!--validation-->
  		<script src="<?=base_url();?>public/frontend/js/jquery.validate.js"></script>
  		<? /* <script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.social.share.1.2.min.js"></script> */ ?>
  		<? /* <script type="text/javascript">var switchTo5x=true;</script>
		<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
		<script type="text/javascript" src="http://s.sharethis.com/loader.js"></script> */ ?>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery.share.js"></script>
  		
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlipsrequesthandler.js"></script>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlipsplugins.js"></script>
  		<? /* <script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlipssocial.js"></script> */ ?>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlipsvalidation.js"></script>
  		
  		<? /* <script type="text/javascript" src="<?=base_url();?>public/frontend/js/community/timeago.js"></script> */ ?>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/community/community.js"></script>
  		<? /* <script type="text/javascript" src="<?=base_url();?>public/frontend/js/community/communityvalidation.js"></script>*/ ?>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/community/communityrequesthandler.js"></script>
  		
  		<?php //if($segment != "videos") { ?>
	  		<!--for video slider-->
	  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/ytv.js"></script>
  		<?php //} ?>
  		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/base64.js"></script>
		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/foodlips.js"></script>
		
		<!--js for community notifications-->
		<script type="text/javascript" src="<?=base_url();?>public/frontend/js/notifications.js"></script>
			
  		<script type="text/javascript">
  			$(document).ready(function() {
  				<?php if(isset($msg)) { ?>
					$("#msg").fadeOut(5000);
				<?php } ?>
				
				// this is to hide the unknown div coming at footer,
				// this div is not in html so it need to add this line of code,
				// this have id 'ui-datepicker-div'
				
				$("#ui-datepicker-div").hide();
				
			  	//$("abbr.timeago").timeago();
			  	/* $('abbr.timeago').each(function() {
    				var $this = $(this);
    				$this.attr('title', $this.data('ts'));
				}).timeago(); */
  			});
		</script>

		<script>
			jQuery(document).ready(function() {
				$.post(
				    'https://graph.facebook.com',
				    {
				        id: '<?php echo $url; ?>',
				        scrape: true
				    },
				    function(response){
				        console.log(response);
				    }
				);
			});
		</script>

		<script>
	        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	        ga('create', 'UA-50424093-1', 'auto');
	        ga('send', 'pageview');

	    </script>
	    
	</head>
	
	<body>
    	<?php $base_url = "https://www.foodlips.com/"; ?>
		<?php $recipe = base64_encode("recipe"); ?>
  		<?php $recipe_base_url = "https://www.foodlips.com/shared/"; ?>
        
		<?php if($this->db_session->userdata("id") != ""):?>
			<?php $this->load->view("community/template/topmenu"); ?>
		<?php endif;?>
		<div id="header">
				<div id="header_main">

					<div class="container-fluid">

						<div class="header_top">

							<div id="search_form"></div>

							<div class="logo_header">
								<a href="<?=$base_url;?>">
									<img src="<?=$recipe_base_url;?>images/foodlips_logo1.png" class="logo" alt="FoodLips" />
								</a>
							</div>

							<div id="loginlogout"></div>

						</div>
                        
                        <script type="text/javascript">
							$(document).ready(function() {
								// $("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout");
							   // $("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu");
								jQuery.ajaxSetup ({
								// Disable caching of AJAX responses
									cache: false
								});
								setTimeout(function(){
									var d = new Date();
									var n = d.getTime();
									$("#loginlogout").load("https://www.foodlips.com/shared/recipe/loginlogout?t="+n);
									$("#search_form").load("https://www.foodlips.com/shared/recipe/searchform?t="+n);
									$("#topmenulogin").load("https://www.foodlips.com/shared/recipe/sitetopmenu?t="+n);
								},200);
								
							});
						</script>

					</div>
                    
                 <div class="clearfix"></div>

					<nav class="navbar navbar-default">
						<div class="container-fluid">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation" aria-expanded="false">
							    <span class="sr-only">Toggle navigation</span>
							    <span class="icon-bar"></span>
							    <span class="icon-bar"></span>
							    <span class="icon-bar"></span>
							  </button>

							  <?php if($this->db_session->userdata("id") != "") : ?>
                                <button class="btn share_toggle" type="button"></button>
                              <?php endif; ?>

							</div>

							<?php if($this->db_session->userdata("id") != "") : ?>
                                <div id="share_container">
                                    <button class="btn share_toggle fixed" type="button"></button>
                                    <div id="share"></div>
                                </div>
                            <?php endif; ?>

							<!-- Collect the nav links, forms, and other content for toggling -->
							<div class="collapse navbar-collapse" id="navigation">
							  <ul class="nav navbar-nav">
									<li><a href="https://www.foodlips.com/">Home</a></li>
                                    <li><a href="<?=base_url();?>community">Community</a></li>
                                    <li><?php if($this->uri->segment("1") == "recipe" && $this->uri->segment("2") != "aboutus" && $this->uri->segment("2") != "contactus") { ?>
                                            <a class="active" href="<?=base_url();?>recipe">Recipes</a>
                                        <?php } else if($this->uri->segment("1") == "") { ?>
                                            <a class="active" href="<?=base_url();?>recipe">Recipes</a>
                                        <?php } else { ?>
                                                <a href="<?=base_url();?>recipe">Recipes</a>
                                        <?php } ?>
                                    </li>
                                    <li><a href="https://www.foodlips.com/shared/restaurants">Restaurants</a></li>
                                    <li><a href="https://www.foodlips.com/shared/wineries">Wineries</a></li>
                                    <li>
                                        <a <?=$this->uri->segment("1") == "videos" ? "class='active'" : "";?> href="<?=base_url();?>videos">
                                            Videos
                                        </a>
                                    </li>
                                    <li><a href="https://www.foodlips.com/blog">Blog</a></li>
                                    <li>
                                        <a <?=$this->uri->segment("2") == "aboutus" ? "class='active'" : "";?> href="<?=base_url();?>recipe/aboutus">
                                            About
                                        </a>
                                    </li>
                                    <li>
                                        <a <?=$this->uri->segment("2") == "contactus" ? "class='active'" : "";?> href="<?=base_url();?>recipe/contactus">
                                            Contact us
                                        </a>
                                    </li>
							  </ul>
							</div><!-- /.navbar-collapse -->
						</div><!-- /.container-fluid -->
					</nav>
			</div>
		</div>