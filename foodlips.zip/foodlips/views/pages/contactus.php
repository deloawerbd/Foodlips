			<div class="page_wrapper">
    			<div class="container-fluid margin_top_10">
                    <div class="row">
                    	<div class="col-sm-3"></div>
                        <div class="col-sm-6">
                            <h2 class="about_heading">
                                Contact us
                            </h2>
                            <div class="contact_form">
                                <div class="contact_form_in_contain">
                                    <?php $attributes = array("class" => "contact_form_bg"); ?>
                                    <?=form_open("recipe/contactus", $attributes);?>
                                    <? /* <form class="thumbnail form-horizontal contact_form_bg"> */ ?>
                                        <div class="control-group">
                                            <?php if(isset($msg)) { ?>
                                                <?php if($msg == "success") { ?>
                                                    <p id="msg" class="successmsg">Mail sent successully.</p>
                                                <?php } else if($msg == "fail") { ?>
                                                    <p id="msg" class="errmsg">Fail to send mail.</p>
                                                <?php } ?>
                                            <?php } ?>
                                            
                                            <label class="control-label" for="inputEmail">Email</label>
                                            <div class="controls">
                                                <input type="text" id="emailTxtFld" name="email" value="<?=$this->input->post("email");?>" placeholder="Email" />
                                                <span class="errmsg"><?=form_error("email");?></span>
                                                <div id="emailErr" class="errmsg hideerr">The Email field is required.</div>
                                                <div id="invalidEmailErr" class="errmsg hideerr">The Email field must contain a valid email address.</div>
                                            </div>
                                            
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label" for="inputSubject">Subject</label>
                                            <div class="controls">
                                                <input type="text" id="subjectTxtFld" name="subject" value="<?=$this->input->post("subject");?>" placeholder="Subject" />
                                                <span class="errmsg"><?=form_error("subject");?></span>
                                                <div id="subjectErr" class="errmsg hideerr">The Subject field is required.</div>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label" for="inputMassage">Message</label>
                                            <div class="controls">
                                                <textarea id="messageTxtArea" name="message" placeholder="Message" rows="3"><?=$this->input->post("message");?></textarea>
                                                <span class="errmsg"><?=form_error("message");?></span>
                                                <div id="messageErr" class="errmsg hideerr">The Message field is required.</div>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <div class="controls">
                                                <input type="submit" class="btn green_btn" name="sbt_contact" value="Submit" onclick="return validateContact()" />
                                            </div>
                                        </div>
                                    <?=form_close();?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3"></div>
                    </div>
            	</div>
        	</div>