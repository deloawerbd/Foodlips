<div class="container-fluid">
    	<div class="row">
        	<div class="col-md-12">
            	<div class="well_custom submit_recipe_box">
                	<div class="sub_recipe_head">  NEW RECIPE</div>
                	<form class="form-horizontal form_box_control">
                    
                    	 <div class="control-group recipe_images_box">
                         <div class="recipe_images">
                    	<span class="recipe_images_txt">Add images file</span>
                        <input name="images" type="file" size="25">
                        <ul>
                        	<li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                                <img src="images/generic-profile1.png" alt="geral profile img">
                                <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                            <li>
                            <img src="images/generic-profile1.png" alt="geral profile img">
                            <a href="#" class="btn btn-danger remove_btn1">Remove</a>
                            </li>
                         
                        </ul>
                        </div>
                        <div class="clearboth"></div>
                    	</div>
                        <div class="control-group">
                           <label class="sub_recipe_txtbox_2 recipe_images_txt"> Video URL</label>
                            <div class="control_input_box">
                            <input class="span3" type="text" placeholder="Video URL">
                            </div>
                            </div>
                           <div class="control-group">
                           <div class="sub_recipe_head_2"> Ingredients Details :</div>
                            <div class="control_textarea">
                            <textarea type="textarea" class="span4" id="inputEmail" placeholder="Title">
                            </textarea>
                            </div>
                            </div>
                            
                            <div class="control-group">
                           <div class="sub_recipe_head_2">  Preparation Details :</div>
                            <div class="control_textarea">
                            <textarea type="textarea" class="span4" id="inputEmail" placeholder="Title">
                            </textarea>
                            </div>
                            </div>
                         
                            <div class="sub_recipe_head_2">  Ingredients for search :</div>
                            <div class="sub_check_box"> 
                            
                            	<ul>
                                	<li><label class="checkbox">
										<input type="checkbox"> Alcohol
										</label>
                                    </li>
                                    <li><label class="checkbox">
										<input type="checkbox">  Bacon
										</label>
                                    </li>
                                    <li><label class="checkbox">
										<input type="checkbox">  Beans
										</label>
                                    </li>
                                    <li><label class="checkbox">
										<input type="checkbox"> Capsicum
										</label>
                                    </li>
                                    <li><label class="checkbox">
										<input type="checkbox">  Cauliflower
										</label>
                                    </li>
                                </ul>
                            </div>
                            <div class="control-group">
                            <div class="recipe_submit_btn_1">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="submit" class="btn btn-danger">Cancel</button>
                            </div>
                            </div>
                       </form>
                </div>
            	
            </div>
        </div>
    </div>