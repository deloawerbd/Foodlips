 		<div class="page_wrapper">	
            <div class="container-fluid">
    			<div class="row">
                	<div class="col-md-2"></div>
    				<div class="col-md-8">
            			<div class="well_custom submit_recipe_box">
                			<div class="community_head2 margin_bottom_none sub_recipe_head">New recipe</div>
                			<?php $attributes = array("class" => "form-horizontal form_box_control"); ?>
                			<?=form_open("recipe/submitrecipe", $attributes);?>
            					<input type="hidden" name="recipeid" value ="<?php if(isset($recipeid)) { echo $recipeid; }?>" />
                        		<div class="control-group">
                            		<label class="sub_recipe_txtbox">Title</label>
                        			<div class="control_input_box">
                            			<input name="title" type="text" id="title" title="Your recipe title here" placeholder="Title" value="<?php if($this->input->post("title")) { echo $this->input->post("title"); } else { if(isset($recipe)) { echo $recipe->title; } } ?>" size="35" ><br />
		                   				<script type="text/javascript">
		                   					$(function() {
		                   						$("#title").focus();
		                   					});
		                   				</script>
		                   				<span class="errmsg"><?php echo form_error("title"); ?></span>
		                    			<span id="titleerr" class="errmsg hideerr marginbottom5">Title field is required.</span>
                            		</div>
                        		</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Category</label>
                            		<div class="control_input_box">
                            			<select name="categories" id="categories" title="Category of your recipe">
                                 			<option value="0">Select Category</option>
			                  				<?php if(isset($recipe)) { ?>
							 					<?php foreach ($categories as $category) { ?>
							 						<?php if($recipe->categoryid == $category->id) { ?>
														<option value="<?=$category->id;?>" selected="true"><?=$category->name;?></option>
													<?php } else { ?>
														<option value="<?=$category->id;?>"><?=$category->name;?></option>
													<?php } ?>
												<?php } ?>
											<?php } else { ?>
							 					<?php foreach ($categories as $category) { ?>
													<option value="<?=$category->id;?>"><?=$category->name;?></option>
												<?php } ?>
											<?php } ?>
										</select><br />
										<span id="categorieserr" class="errmsg hideerr marginbottom5">Category field is required.</span>
										<?php if(isset($categoryerr)) { ?>
											<div class="errmsg"><?=$categoryerr;?></div>
										<?php } ?>
                            		</div>
                            	</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Course</label>
                            		<div class="control_input_box">
                            			<select name="courses" id="courses" title="Course of your recipe">
                     		 				<option value="0">Select Course</option>
	                      					<?php if(isset($recipe)) { ?>
					         					<?php foreach ($courses as $course) { ?>
					         						<?php if($recipe->courseid == $course->id) { ?>
														<option value="<?=$course->id;?>" selected="true"><?=$course->name;?></option>
													<?php } else { ?>
														<option value="<?=$course->id;?>"><?=$course->name;?></option>
													<?php } ?>
												<?php } ?>
					     					<?php } else { ?>
					         					<?php foreach ($courses as $course) { ?>
													<option value="<?=$course->id;?>"><?=$course->name;?></option>
												<?php } ?>
											<?php } ?>
	         							</select><br />
		         						<?php if(isset($courseerr)) { ?>
		         							<div class="errmsg"><?=$courseerr;?></div>
         								<?php } ?>
		         						<span id="courseerr" class="errmsg hideerr marginbottom5">Course field is required.</span>
                            		</div>
                            	</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Type</label>
                            		<div class="control_input_box">
                            			<select name="types" id="types" title="Type of your recipe">
		                      				<option value="0">Select Type</option>
		                      				<?php if(isset($recipe)) {  echo "welcome";?>
		         								<?php foreach ($types as $type) { ?>
					         						<?php if($recipe->typeid == $type->id) { ?>
														<option value="<?=$type->id;?>" selected="true"><?=$type->name;?></option>
													<?php } else { ?>
														<option value="<?=$type->id;?>"><?=$type->name;?></option>
													<?php } ?>
												<?php } ?>
					     					<?php } else { ?>
					         					<?php foreach ($types as $type) { ?>
													<option value="<?=$type->id;?>"><?=$type->name;?></option>
												<?php } ?>
											<?php } ?>
			     						</select><br />
		         						<?php if(isset($typeerr)) { ?>
		         							<div class="errmsg"><?=$typeerr; ?></div>
	         							<?php } ?>
		         						<span id="typeerr" class="errmsg hideerr marginbottom5">Type field is required.</span>
	         						</div>
                            	</div>
                             	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Cuisine</label>
                            		<div class="control_input_box">
                           				<select name="cuisines" id="cuisines" title="Cuisine of your recipe">
						                     <option value="0">Select Cuisine</option>
						                      <?php if(isset($recipe)) {  echo "welcome";?>
						         					<?php foreach ($cuisines as $cuisine) { ?>
						         						<?php if($recipe->cuisineid == $cuisine->id) { ?>
															<option value="<?=$cuisine->id;?>" selected="true"><?=$cuisine->name;?></option>
														<?php } else { ?>
															<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
														<?php } ?>
													<?php } ?>
						     					<?php } else { ?>
						         					<?php foreach ($cuisines as $cuisine) { ?>
														<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
													<?php } ?>
												<?php } ?>
					         			</select><br />
	         							<?php if(isset($cuisineerr)) { ?>
	         								<div class="errmsg"><?=$cuisineerr; ?></div>
         								<?php } ?>
		         			 			<span id="cuisineerr" class="errmsg hideerr marginbottom5">Cuisine field is required.</span>
                            		</div>
                            	</div>
                            	<div class="control-group">
		                            <label class="sub_recipe_txtbox">Season /Occasion</label>
		                            <div class="control_input_box">
			                            <select name="seasons" id="season" title="Season /Occasion of your recipe">
					                      <option value="0">Select Season</option>
					                      <?php if(isset($recipe)) {  echo "welcome";?>
					         					<?php foreach ($seasons as $season) { ?>
					         						<?php if($recipe->seasonid == $season->id) { ?>
														<option value="<?=$season->id;?>" selected="true"><?=$season->name;?></option>
													<?php } else { ?>
														<option value="<?=$season->id;?>"><?=$season->name;?></option>
													<?php } ?>
												<?php } ?>
					     					<?php } else { ?>
					         					<?php foreach ($seasons as $season) { ?>
													<option value="<?=$season->id;?>"><?=$season->name;?></option>
												<?php } ?>
											<?php } ?>
					         			</select><br />
		         						<?php if(isset($seasonerr)) { ?>
		         							<div class="errmsg"><?=$seasonerr; ?></div>
	         							<?php } ?>
		         						<? /*<span id="seasonerr" class="errmsg hideerr marginbottom5">Season field is required.</span> */?>
                            		</div>
                            	</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Preparation Method</label>
                        			<div class="control_input_box">
                        				<select name="methods" id="methods" title="Preparation method of your recipe">
				                      		<option value="0">Select Method</option>
					                      	<?php if(isset($recipe)) { ?>
					     						<?php foreach ($methods as $method) { ?>
				     								<?php if($recipe->methodid == $method->id) { ?>
														<option value="<?=$method->id;?>" selected="true"><?=$method->name;?></option>
													<?php } else { ?>
														<option value="<?=$method->id;?>"><?=$method->name;?></option>
													<?php }?>
												<?php } ?>
					 						<?php } else {?>
					     						<?php foreach ($methods as $method) { ?>
													<option value="<?=$method->id;?>"><?=$method->name;?></option>
												<?php } ?>
											<?php } ?>
						         		</select><br />
	     								<?php if(isset($methoderr)) { ?>
	     									<div class="errmsg"><?=$methoderr; ?></div>
     									<?php } ?>
	     								<span id="methoderr" class="errmsg hideerr marginbottom5">Method field is required.</span>
                        			</div>
                        		</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Preparation Time</label>
                            		<div class="control_input_box">
                            			<input name="preparationtime" type="text" id="preparationtime" title="Time required to make recipe (in minutes)" placeholder="Time in minutes" class="span3" value="<?php if($this->input->post("preparationtime")) { echo $this->input->post("preparationtime"); } else { if(isset($recipe)) { echo $recipe->preparationtime; } } ?>">
                            			<br />
                            			<span class="errmsg"><?php echo form_error("preparationtime"); ?></span>
                						<span id="preparationtimeerr" class="errmsg hideerr marginbottom5">Preparation time field is required.</span> 
                            		</div>
                            	</div>
                             	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Calories</label>
                            		<? /*<div class="control_input_box">
                            			<input name="calories" type="text" id="calories" class="span3" title="Calories of your recipe" placeholder="Calories" value="<?php if($this->input->post("calories")) { echo $this->input->post("calories"); } else { if(isset($recipe)) { echo $recipe->calories; } } ?>">
                            			<br />
                            			<span id="calorieserr" class="errmsg hideerr marginbottom5">Calories field is required.</span>  
                            		</div> */ ?>
                            		<?php //if($this->input->post("calories")) { echo $this->input->post("calories"); } else { if(isset($recipe)) { echo $recipe->calories; } } ?>
                            		<div class="control_input_box">
                            			<select name="calories" id="calories" title="Calories of your recipe">
                            				<option value="none">Select Calories</option>
                            				<option value="high">High</option>
                            				<option value="medium">Medium</option>
                            				<option value="low">Low</option>
                            			</select><br />
                            		</div>
                            	</div>
                            	<div class="control-group">
                            		<label class="sub_recipe_txtbox">Serves</label>
                            		<div class="control_input_box">
                            			<input name="serves" type="text" id="serves" class="span3" title="Number of people to be serve" placeholder="No of people" value="<?php if($this->input->post("serves")) { echo $this->input->post("serves"); } else { if(isset($recipe)) { echo $recipe->serves; } } ?>">
                            			<span class="errmsg"><?php echo form_error("serves"); ?></span>
                            			<br />
                    					<span id="serveerr" class="errmsg hideerr marginbottom5">Serves field is required.</span>
                            		</div>
                            	</div>
                        		<div class="control-group">
                            		<div class="recipe_submit_btn">
                            			<button type="submit" class="btn btn-success" name="sbt_recipe" onclick="return validateRecipe()" value="continue">Continue</button>
                            			<button type="submit" class="btn btn-danger" name="sbt_cancel" value = "cancel">Cancel</button>
                            		</div>
                            	</div>
                       		<?=form_close();?>
                		</div>
            		</div>
                    <div class="col-md-2"></div>
        		</div>
    		</div>
		</div>