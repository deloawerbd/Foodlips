			<div class="page_wrapper">
    			<div class="container-fluid">
        			<div class="row">
            			<div class="col-sm-4 col-md-3 left_span_3">
                			<div class="recipe_left">
                    			<!--<div class="profile_detail">
                        		</div>-->
                        		<div class="profile_box_left">
                        			<span class="profile_left_image">
                        				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
											$userimg = "defaultuser.jpg";
											if($user != "") {
												if($user->image != "") {
													$userimg = $user->image;
												} 
											} ?>
                        				<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user->name;?>" title="<?=$user->name;?>" /><br />
                    					<p><?=$user->name;?></p>
                        			</span>
       								<ul class="nav border_none">
		                            	<li class="active">
		                            		<a href="<?=base_url();?>recipe/profile/" class="text_link_poem">
		                            			My recipes
	                            			</a>
	                            		</li>
		       							<li>
		       								<a href="<?=base_url();?>recipe/books/" class="text_link_poem selected">
		       									My books
	       									</a>
	       								</li>
	       								<li>
		       								<a href="<?=base_url();?>recipe/shoppinglist/" class="text_link_poem">
		       									My shopping list
	       									</a>
	       								</li>
		       						  	<? /* <li>
		       						  		<a href="<?=base_url();?>recipe/profile/changepassword" data-toggle="tab" class="text_link_poem">
		       						  			Change password
	       						  			</a>
	       						  		</li>
		                                <li>
		                                	<a href="" data-toggle="tab" class="text_link_poem">Change profile image</a>
	                                	</li> */ ?>
       					  			</ul>
                       			</div>
                    		</div>
                		</div>
                		<div class="col-sm-8 col-md-9">
	                		<div class="profile_books tab-pane" id="tab2">
								<span class="recipe_btn_profile">
									<a href="<?=base_url();?>recipe/addbook/">
	                    				<span class="btn btn-primary">
	                    					Create book
	                					</span>
	            					</a>
	                			</span>
	                			<?php if(isset($books) && count($books) > 0) { ?>
	                				<ul>
	                					<?php $imagefolder = "275x198/"; ?>
                						<?php foreach($books as $book) {
	                						if($book->recipeid != "") {
											
	        									$recipes = $this->crudmodel->getbookrecipesbyrecipeids($book->recipeid);
	        								
	        									if(isset($recipes) && count($recipes) > 0) { ?>
			    									<?php foreach($recipes as $recipe) { ?>
			    										<li>
															<?php if($recipe->images != "") {
																$images = explode(",", $recipe->images); ?>
																<a href="<?=base_url();?>recipe/bookdetails/<?=$book->name;?>">
																	<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" style="width: 130px; height: 100px;" />
																</a>
		        											<?php } else { ?>
																<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" style="width: 130px; height: 100px;" />
		    												<?php } ?>
		    												<span class="profile_text1">
			                    								<a href="#">
		    														<?=$book->name;?>
	    														</a>
															</span>
    													</li>
													<?php } ?>
												<?php } else { ?>
													<a href="<?=base_url();?>recipe/bookdetails/<?=$book->name;?>">
        												<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" style="width: 130px; height: 100px;" />
    												</a>
	        									<?php } ?>
											<?php } else { ?>
												<li>
													<a href="<?=base_url();?>recipe/bookdetails/<?=$book->name;?>">
														<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" style="width: 130px; height: 100px;" />
													</a>
													<span class="profile_text1">
	                    								<a href="#">
    														<?=$book->name;?>
														</a>
													</span>
												</li>
											<?php } ?>
										<?php } ?>
									</ul>
								<?php } else { ?>
									<ul>
										<li>
											No books created by you.
										</li>
									</ul>
								<?php } ?>
							</div>
						</div>
            		</div>
    			</div>
			</div>
			
    		<? /* <div class="span7">
    			<p>
					<span class="submit_recipes_logo">
   	    				<a href="<?=base_url();?>recipe/addbook/mybooks">
   	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe" />
    					</a>
    				</span>
					<span class="submit_recipes_txt">
    					<a href="<?=base_url();?>recipe/addbook/">
    						Create book
						</a>
  					</span>
				</p>
    			<?php if(isset($books) && count($books) > 0) { ?>
					<?php foreach($books as $book) { ?>
    					<div style="float: left; width: 200px; height: 200px;">
    						<?php $imagefolder = "275x198/";
    							if($book->recipeid != "") {
    								//$recipes = explode(",", $book->recipeid);
    								$recipes = $this->crudmodel->getbookrecipesbyrecipeids($book->recipeid);
    								if(isset($recipes) && count($recipes) > 0) {
    									foreach($recipes as $recipe) {
    										if($recipe->images != "") {
												$images = explode(",", $recipe->images); ?>
												<a href="<?=base_url();?>recipe/bookdetails/<?=$book->name;?>">
													<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" width="200" height="200" />
												</a>
    										<?php break; } else { ?>
												<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" width="200" height="200" />
    										<?php } ?>
										<?php } ?>
									<?php } else { ?>
        								<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" width="200" height="200" />
    								<?php } ?>
    						<?php } else { ?>
    							<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$book->name;?>" title="<?=$book->name;?>" width="200" height="200" />
							<?php } ?>
							<br /><span style="font-size: 16px;"><?=$book->name;?></span>
						</div>
					<?php } ?>
				<?php } else { ?>
					<p style="font-size: 20px;">No books created by you. Start creating now.</p>
					<p>
						<span class="submit_recipes_logo">
       	    				<a href="<?=base_url();?>recipe/addbook/mybooks">
       	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe" />
   	    					</a>
        				</span>
						<span class="submit_recipes_txt">
   	    					<a href="<?=base_url();?>recipe/addbook/">
   	    						Create book
    						</a>
      					</span>
					</p>
				<?php } ?>
			</div>*/ ?>
    				