<div class="page_wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4 col-md-3 left_span_3">
				<div class="recipe_left">
					<!--<div class="profile_detail">
					</div>-->
					<div class="profile_box_left">
						<span class="profile_left_image">
							<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
							$userimg = "defaultuser.jpg";
							if($user != "") {
								if($user->image != "") {
										$userimg = $user->image;
								} 
							} ?>
							<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user->name;?>" title="<?=$user->name;?>" /><br />
							<p><?=$user->name;?></p>
						</span>
						<ul class="nav border_none">
							<li class="active">
							<a href="<?=base_url();?>recipe/profile/" class="text_link_poem">
								My recipes
							</a>
							</li>
							<li>
								<a href="<?=base_url();?>recipe/books/" class="text_link_poem">
								My books
							</a>
							</li>
							<li>
								<a href="<?=base_url();?>recipe/shoppinglist/" class="text_link_poem selected">
								My shopping list
							</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="col-sm-8 col-md-9"> 
				<?php //echo "data: "; print_r($shoppinglist); ?>
            	<?php if(isset($shoppinglist) && count($shoppinglist) > 0) { ?>
					<div class="table table-hover">
						<?php $imagefolder = "275x198/"; ?>
						<?php foreach($shoppinglist as $list) {
							$list->recipeid;
							$recipe = $this->crudmodel->getrecipebyid($list->recipeid);
							if(isset($recipe)) { ?>
								<?php $image = "defaultrecipe.png"; ?>
								<div class="blog_post">
									<div class="blog_post_img">
										<span class="img_box_profile">
											<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
											<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
                							<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
												<?php if($recipe->images != "") {
													$images = explode(",", $recipe->images);
													$image = $images[0];
												} ?>
												<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$image;?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" style="width: 130px; height: 100px;" />
											</a>
										</span>
									</div>
									<div>
										<span class="profile_contain">
											<span class="recipe_txt_head">
												<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
												<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
													<?=$recipe->title;?>
												</a>
											</span><br />
											<span style="margin-top: 10px; margin-bottom: 5px; color: #005DBD;">Ingredient list</span>
											<div>
												<ul type="circle">
													<?php
														$ingredientlist = $this->crudmodel->getingredientsbyrecipeid($list->recipeid);
														foreach($ingredientlist as $ingredientlist) {
															$expingredient =  explode("|",$ingredientlist->ingredients);
															foreach($expingredient as $ingredient) { ?>
																<li>
																	<?=$ingredient;?>
																</li>
															<?php }	?>
													<?php } ?>
												</ul>
											</div>
										</span>
									</div>
								</div>
							<?php } ?>
						<?php } ?>
					</div>
					<?php } else { ?>
						<p style="font-size: 20px;">No Ingredients added by you.</p>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>