			<div class="container">
    			<div class="row">
        			<div class="center">
            			<div class="span3 left_span_3">
                			<div class="recipe_left">
                    			<!--<div class="profile_detail">
                        		</div>-->
                        		<div class="profile_box_left">
                        			<span class="profile_left_image">
                        				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
											$userimg = "defaultuser.jpg";
											if($user != "") {
												if($user->image != "") {
													$userimg = $user->image;
												} 
											} ?>
                        				<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user->name;?>" title="<?=$user->name;?>" /><br />
                    					<p><?=$user->name;?></p>
                        			</span>
       								<ul class="nav border_none">
		                            	<li class="active">
		                            		<a href="<?=base_url();?>recipe/profile/" class="text_link_poem selected">
		                            			My recipes
	                            			</a>
	                            		</li>
		       							<li>
		       								<a href="<?=base_url();?>recipe/books/" class="text_link_poem">
		       									My books
	       									</a>
	       								</li>
	       								<li>
		       								<a href="<?=base_url();?>recipe/shoppinglist/" class="text_link_poem">
		       									My shopping list
	       									</a>
	       								</li>
       					  			</ul>
                       			</div>
                    		</div>
                		</div>
                		
                		<div class="span7">
                			<?php if(isset($recipes) && count($recipes) > 0) { ?>
	                			<div class="span7">
		                			<table width="100%" cellpadding="0" cellspacing="0" class="table table-hover">
		                				<?php foreach($recipes as $recipe) { ?>
			     							<tr class="tr_bg_color">
			                        			<td width="5">&nbsp;</td>
			                    				<td width="100" height="70">
			                    					<span class="img_box_profile">
			                    						<? /* <a href="<?=base_url(); ?>recipe/details/<?=$recipe->id;?>"> */ ?>
		                    							<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
		                    							<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
					                    					<?php if($recipe->images != "") {
					                    							$imagefolder = "275x198/";
			                										$images = explode(",", $recipe->images); ?>
																	<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" />
			                									<?php } else { ?>
			            											<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" width="200" height="200" />
			                									<?php } ?>
					                        				<? /* <img src="images/recipe_img_1.jpg" alt="recipe_1"> */ ?>
				                        				</a>
				                    				</span>
			                        			</td>
			                        			<td width="5"></td>
			                        			<td>
			                        				<span class="profile_contain">
			                            				<span class="recipe_txt_head">
			                        						<? /* <a href="<?=base_url(); ?>recipe/details/<?=$recipe->id;?>"> */ ?>
		                        							<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
			                        							<?=$recipe->title;?>
		                        							</a>
			                            				</span><br />
														<span class="recipe_txt_1">in 
	                           								<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>">
	                           									<?=$categoryname;?>
	                       									</a>
			                        					</span>
			                        					<!--<p class="post_detail_txt"><span class="seemore"><a href="#">See more</a></span></p>-->
			                        				</span>
			                        				<span class="ranking_profile">
			                        					<?//=$rating;?>
		                    							<?php $userrating = round($this->crudmodel->takerating($recipe->id));
															$greystarts = 5 - $userrating;
															$i = 0; $globalcount = 1;
															while($i < $userrating) { ?>
																<span class="small_star">
																	<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star green-rating"></i>
																</span>
															<?php $i++; $globalcount++; }
															$i = 0;
															while($i < $greystarts) { ?>
																<span class="small_star">
																	<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star grey-rating"></i>
																</span>
															<?php $i++; $globalcount++; } ?>
			                        				</span>
			                        				<span class="btn_like_made">
			                        					<span class="iconlike">
			                            					<img src="<?=base_url();?>public/frontend/images/like_thumbsup1.png" alt="like_thumbs" />
			                            				</span>
			                            				Like <span class="add_like_no">
			                            						(<span id=<?="likecount_".$recipe->id;?>><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>)
		                            						</span>
			                        				</span>
			                        				<span class="btn_like_made">
			                            				<span class="iconlike">
			                                				<img src="<?=base_url();?>public/frontend/images/recipe_made_icon1.png" alt="like_thumbs" />
			                            				</span>
			                        					I made this <span class="add_like_no">
			                        									(<span id=<?="madecount_".$recipe->id;?>><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>)
		                        									</span>
			                        				</span>
			                        				<span class="btn_like_made">
			                            				<span class="iconlike">
			                                				<img src="<?=base_url();?>public/frontend/images/comment1.png" alt="like_thumbs" />
			                            				</span>
			                            				Comments 
			                            				<span class="add_like_no">
			                            					(<?=$this->crudmodel->getcommentcountbyrecipeid($recipe->id);?>)
		                            					</span>
			                        				</span>
													<!--<span><a href="#" class="btn btn-success rpl_btnlink">Reply</a></span> -->
			                        			</td>
			                        			<td width="5">&nbsp;</td> 
			                  				</tr>
		                  					<tr class="height_tr">&nbsp;</tr>
	              						<?php } ?>
		            				</table>
	            				</div>
		        			<?php } else { ?>
	        					<p style="font-size: 20px;">No recipes submitted by you. Start submitting now.</p>
	        					<p>
	        						<span class="submit_recipes_logo">
		           	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
		           	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe" />
		       	    					</a>
	                				</span>
	        						<span class="submit_recipes_txt">
	           	    					<a href="<?=base_url();?>recipe/submitrecipe/recipe">
	           	    						Submit Recipes
	       	    						</a>
	              					</span>
	        					</p>
		        			<?php } ?>
	        			</div>
        			</div>
        		</div>
    		</div>