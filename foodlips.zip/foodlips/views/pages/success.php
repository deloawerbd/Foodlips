			



			<div id="container" class="page_wrapper">
    			<div class="container-fluid center_txt margin_top_50">
                    <p>
                        <strong>
                            Your recipe has been submitted successfully.<br />
                            Your recipe will be available on site with in 3-6 hours.
                        </strong>
                    </p>
                    <p>
                        <span class="submit_recipes_txt">
                            <a href="<?=base_url();?>recipe/submitrecipe/recipe">
                                Submit Another Recipe
                            </a>
                        </span>
                        <span class="submit_recipes_txt">
                            <a href="<?=base_url();?>community">
                                Go To Community
                            </a>
                        </span>
                    </p>
				</div>
			</div>