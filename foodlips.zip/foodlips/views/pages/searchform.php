<script> var siteurl = "https://www.foodlips.com/"; </script>
<script>
	jQuery("#advance_search_trigger").on("focus", function() {
		jQuery("#advance_search_link").fadeIn();
	});
	jQuery("#advance_search_trigger").on("blur", function() {
		jQuery("#advance_search_link").fadeOut();
	});
</script>
			<div class="search_box_in" id="search_header_box">
			<?=form_open("recipe/freetextsearch");?>
				<span class="search_btn_box">
					<!-- <input type="submit" name="search_btn" class="btn btn_color btn_height" value="Search" /> -->
					<button name="search_btn" type="submit" class="btn search_btn" value=""><i class="fa fa-search"></i></button>
				</span>
				<span class="search_input_box">
					<!-- <input name="search" type="text" class="search_input" style="margin-bottom: 0px;" placeholder="Enter recipe keyword" /> -->
					<input name="search" type="text" class="search_input" id="advance_search_trigger" placeholder="Search" />
				</span>
				<span class="advance_txt" id="advance_search_link">
					<a href="<?=base_url()?>recipe/advancesearch">Advance search</a>
				</span>
			<?=form_close();?>
			</div>
                
			<? /*	<?php $recipe = base64_encode("recipe"); ?>
				
				 <?php $offset1 = "offset1";
				if($this->db_session->userdata("id") != "") {
					$offset1 = "";
				} ?>
				<?php $attribute = array("class" => "searchform"); ?>
				<?=form_open("recipe", $attribute);?>
					<div class="span4 <?=$offset1?> margin_search_top" style="margin-right: 0px;">
						<span class="search_input">
							<input type="text" name="search" value="<?=$this->input->post("search");?>" title="Recipe to search" placeholder="Enter recipe keyword" />
						</span>
						<span>
							<input type="submit" class="btn login_link2" name="sbt_search" value="Search" />
						</span>
						<br />
						<span class="advance_txt">
							<a href="<?=base_url();?>recipe/advancesearch">Advance search</a>
						</span>
					</div>
				<?=form_close();?> 
				
				<?php if($this->db_session->userdata("id") == "") { ?>
        			<div class="span1 offset5 login_header_box">
						<!-- <a href="https://www.foodlips.com/community?<?=$recipe."=".$recipe;?>" class="btn login_link"> -->
							<a href="https://www.foodlips.com/recipes/auth/login" class="btn login_link">
							Login
						</a>
      				</div>
          		<?php } else { ?>
      				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
					$userimg = "defaultuser.jpg";
					if($user != "") {
						if($user->image != "") {
							$userimg = $user->image;
						} 
					} ?>
								
					<div class="span1 btn-group login_header_box">
						<a href="<?=base_url();?>recipe/profile" class="btn login_link">
							<span class="login_img">
								<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />
							</span>
	            			Profile
	    				</a>
					</div>
					<div class="span1 btn-group login_header_box" style="margin-left: 7px;">
						<a href="<?=base_url();?>recipe/logout" class="btn login_link">
                			Logout
            			</a>
					</div>
				<?php } ?> */ ?>
