<?php
function makeslugs($string, $maxlen = 0) {
  		$newStringTab = array();
      	$string = strtolower(nodiacritics($string));
      	//$string = $this->_nodiacritics($string);
      	if(function_exists("str_split")) {
     		$stringTab=str_split($string);
		}
      	else {
     		$stringTab = mystrsplit($string);
		}

      	$numbers=array("0","1","2","3","4","5","6","7","8","9","-");
      	//$numbers=array("0","1","2","3","4","5","6","7","8","9");

      	foreach($stringTab as $letter) {
     		if(in_array($letter, range("a", "z")) || in_array($letter, $numbers)) {
        		$newStringTab[]=$letter;
            	//print($letter);
         	}
         	elseif($letter == " ") {
        		$newStringTab[] = "-";
			}
      	}

      	if(count($newStringTab)) {
     		$newString = implode($newStringTab);
         	if($maxlen > 0) {
            	$newString = substr($newString, 0, $maxlen);
			}
         
 			$newString = removeduplicates('--', '-', $newString);
		}
      	else {
     		$newString='';
		}
  		$newString = str_replace("-", " ", $newString);
		$newString = ucwords($newString);
		
  		return $newString;
		
	}
function nodiacritics($string) {
		//cyrylic transcription
      	$cyrylicFrom = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я');
      	$cyrylicTo = array('A', 'B', 'W', 'G', 'D', 'Ie', 'Io', 'Z', 'Z', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'Ch', 'C', 'Tch', 'Sh', 'Shtch', '', 'Y', '', 'E', 'Iu', 'Ia', 'a', 'b', 'w', 'g', 'd', 'ie', 'io', 'z', 'z', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'ch', 'c', 'tch', 'sh', 'shtch', '', 'y', '', 'e', 'iu', 'ia'); 
      
		$from = array("Á", "À", "Â", "Ä", "Ă", "Ā", "Ã", "Å", "Ą", "Æ", "Ć", "Ċ", "Ĉ", "Č", "Ç", "Ď", "Đ", "Ð", "É", "È", "Ė", "Ê", "Ë", "Ě", "Ē", "Ę", "Ə", "Ġ", "Ĝ", "Ğ", "Ģ", "á", "à", "â", "ä", "ă", "ā", "ã", "å", "ą", "æ", "ć", "ċ", "ĉ", "č", "ç", "ď", "đ", "ð", "é", "è", "ė", "ê", "ë", "ě", "ē", "ę", "ə", "ġ", "ĝ", "ğ", "ģ", "Ĥ", "Ħ", "I", "Í", "Ì", "İ", "Î", "Ï", "Ī", "Į", "Ĳ", "Ĵ", "Ķ", "Ļ", "Ł", "Ń", "Ň", "Ñ", "Ņ", "Ó", "Ò", "Ô", "Ö", "Õ", "Ő", "Ø", "Ơ", "Œ", "ĥ", "ħ", "ı", "í", "ì", "i", "î", "ï", "ī", "į", "ĳ", "ĵ", "ķ", "ļ", "ł", "ń", "ň", "ñ", "ņ", "ó", "ò", "ô", "ö", "õ", "ő", "ø", "ơ", "œ", "Ŕ", "Ř", "Ś", "Ŝ", "Š", "Ş", "Ť", "Ţ", "Þ", "Ú", "Ù", "Û", "Ü", "Ŭ", "Ū", "Ů", "Ų", "Ű", "Ư", "Ŵ", "Ý", "Ŷ", "Ÿ", "Ź", "Ż", "Ž", "ŕ", "ř", "ś", "ŝ", "š", "ş", "ß", "ť", "ţ", "þ", "ú", "ù", "û", "ü", "ŭ", "ū", "ů", "ų", "ű", "ư", "ŵ", "ý", "ŷ", "ÿ", "ź", "ż", "ž");
      	$to = array("A", "A", "A", "A", "A", "A", "A", "A", "A", "AE", "C", "C", "C", "C", "C", "D", "D", "D", "E", "E", "E", "E", "E", "E", "E", "E", "G", "G", "G", "G", "G", "a", "a", "a", "a", "a", "a", "a", "a", "a", "ae", "c", "c", "c", "c", "c", "d", "d", "d", "e", "e", "e", "e", "e", "e", "e", "e", "g", "g", "g", "g", "g", "H", "H", "I", "I", "I", "I", "I", "I", "I", "I", "IJ", "J", "K", "L", "L", "N", "N", "N", "N", "O", "O", "O", "O", "O", "O", "O", "O", "CE", "h", "h", "i", "i", "i", "i", "i", "i", "i", "i", "ij", "j", "k", "l", "l", "n", "n", "n", "n", "o", "o", "o", "o", "o", "o", "o", "o", "o", "R", "R", "S", "S", "S", "S", "T", "T", "T", "U", "U", "U", "U", "U", "U", "U", "U", "U", "U", "W", "Y", "Y", "Y", "Z", "Z", "Z", "r", "r", "s", "s", "s", "s", "B", "t", "t", "b", "u", "u", "u", "u", "u", "u", "u", "u", "u", "u", "w", "y", "y", "y", "z", "z", "z");
      
      	$from = array_merge($from, $cyrylicFrom);
		$to = array_merge($to, $cyrylicTo);

      $newstring = str_replace($from, $to, $string);
      return $newstring;
   	}
	
	function mystrsplit($string) {
  		$slen = strlen($string);
  		for($i = 0; $i < $slen; $i++) {
     		$sArray[$i] = $string{$i};
		}
      	return $sArray;
	}
	
	function removeduplicates($sSearch, $sReplace, $sSubject) {
		$i = 0;
      	do {
     		$sSubject = str_replace($sSearch, $sReplace, $sSubject);
			$pos = strpos($sSubject, $sSearch);
			$i++;
			if($i > 100) {
            	die('removeduplicates() loop error');
			}
      	}
      	while($pos !== false);
		return $sSubject;
	}
// function to cerate seo link
	function _createseo($postval) {
        $specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
        return $seo = strtolower(str_replace($specialchars, "-", $postval)."-".md5(time()));
    }

// if(isset($_POST["Import"])){
	// $filename = $_FILES["file"]["tmp_name"];
	// if($_FILES["file"]["size"]>0){
		// $file = fopen($filename,"r");
		// while (($excelrow = fgetcsv($file,1000,",","'")) !== FALSE){
			// //	user
// 			
			// $where = array("name"=>$excelrow[0]);
			// $table = "fa_user";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $user_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[0],
								// "user_name"=>$excelrow[0],
								// "country_id"=>"90",
								// "password"=>"07f83cf03f0c7af02f11fa2f1b0d1043",
								// "role"=>"user",
								// "email"=>"test@test.com",
								// "image"=>"",
								// "banned"=>"0",
								// "publicwall"=>"0"
							 // );
				// $user_id = $this->importcsvmodel->addItem($table,$data);
				// //print_r($data);
			// }
			// //Title
			 // $excelrow[1] = makeslugs($excelrow[1]);
			 // $title = $excelrow[1];
			 // $seo = _createseo($title);
			// //category
			// $excelrow[2] = makeslugs($excelrow[2]);
			// $where = array("name"=>$excelrow[2]);
			// $table = "categories";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $category_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[2],
							 // );
				// $category_id = $this->importcsvmodel->addItem($table,$data);
				// //print_r($data);
			// }
		  // //course
		   // $excelrow[3] = makeslugs($excelrow[3]);
			// $where = array("name"=>$excelrow[3]);
			// $table = "courses";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $course_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[3],
							 // );
				// $course_id = $this->importcsvmodel->addItem($table,$data);
				// //print_r($data);
			// }
// 			
			// //Dish type
			// $excelrow[4] = makeslugs($excelrow[4]);
			// $where = array("name"=>$excelrow[4]);
			// $table = "types";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $type_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[4],
							 // );
				// $type_id = $this->importcsvmodel->addItem($table,$data);
				// //print_r($data);
			// }
			// //Occasion
			// $excelrow[5] = makeslugs($excelrow[5]);
			// $where = array("name"=>$excelrow[5]);
			// $table = "seasons";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $season_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[5],
							 // );
				// $season_id = $this->importcsvmodel->addItem($table,$data);
			// }
			// //Cusine
			// $excelrow[6] = makeslugs($excelrow[6]);
			// $where = array("name"=>$excelrow[6]);
			// $table = "cuisines";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $cuisine_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[6],
							 // );
				// $cuisine_id = $this->importcsvmodel->addItem($table,$data);
			// }
			// //Special Diets
			// $excelrow[7] = makeslugs($excelrow[7]);
			// $where = array("name"=>$excelrow[7]);
			// $table = "special_diets";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $special_diet_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[7],
							 // );
				// $special_diet_id = $this->importcsvmodel->addItem($table,$data);
			// }
			// //Methods
			// $excelrow[8] = makeslugs($excelrow[8]);
			// $where = array("name"=>$excelrow[8]);
			// $table = "methods";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $method_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[8],
							 // );
				// $method_id = $this->importcsvmodel->addItem($table,$data);
			// }
			// //Preparation Time
			// $excelrow[9] = makeslugs($excelrow[9]);
			// $preparation_time = $excelrow[9];
// 			
			// //Cooking Time
			// $excelrow[10] = makeslugs($excelrow[10]);
			// $cooking_time = $excelrow[10];
// 			
			// //Calories
			// $excelrow[11] = makeslugs($excelrow[11]);
			// $where = array("name"=>$excelrow[11]);
			// $table = "calories";
			// if($this->importcsvmodel->isEntryExists($where,$table)){
				// $calory_id = $this->importcsvmodel->getUserIdByName($where,$table);
			// }else{
				// $data = array(
								// "name"=>$excelrow[11],
							 // );
				// $calory_id = $this->importcsvmodel->addItem($table,$data);
			// }
// 			
			// //Serves
			// $excelrow[12] = makeslugs($excelrow[12]);
			// $serves = $excelrow[12];
// 			
			// //Ingredients
			// $excelrow[13] = makeslugs($excelrow[13]);
			// $ingredients = $excelrow[13];
// 			
			// //Prepartion Details
			// $excelrow[14] = makeslugs($excelrow[14]);
			// $preparation_details = $excelrow[14];
// 			
			// //Image
			// $excelrow[15] = makeslugs($excelrow[15]);
			// $image= $excelrow[15];
// 			
			// //video
			// $excelrow[16] = makeslugs($excelrow[16]);
			// $video= $excelrow[16];
// 			
			// //Enter into Recipe
			// $data = array(
							// "uid"=>$user_id,
							// "categoryid"=>$category_id,
							// "courseid"=>$course_id,
							// "typeid"=>$type_id,
							// "cuisineid"=>$cuisine_id,
							// "seasonid"=>$season_id,
							// "methodid"=>$method_id,
							// "ingredientid"=>"0",
							// "ratingid"=>"0",
							// "title"=>$title,
							// "images"=>$image,
							// "video"=>$video,
							// "isyoutube"=>"0",
							// "preparationtime"=>$preparation_time,
							// "cookingtime"=>$cooking_time,
							// "calories"=>$calory_id,
							// "serves"=>$serves,
							// "preparationdetails"=>$preparation_details,
							// "ingredientdetails"=>$ingredients,
							// "seo"=>$seo,
							// "date"=>date("Y-m-d h:i:s"),
							// "isnew"=>"1",
							// "approved"=>"0",
							// "recipeofday"=>"0",
							// "notified"=>"0"
						  // );
		  	// $table = "recipes1";
			// $recipe_id = $this->importcsvmodel->addItem($table,$data);
		// }
		// fclose($file);
		// echo "CSV File has been successfully Imported";
	// }else{
		// echo "Invalid file : Please upload csv file";
	// }
// 	
// 	
// }
	//http://webexplorar.com/read-excel-file-and-save-details-to-database-using-php-repost/
	if(isset($_POST["Import"])){
		set_include_path(get_include_path() . PATH_SEPARATOR . 'public/Classes/');
		include 'PHPExcel/IOFactory.php';
		$filename = $_FILES["file"]["tmp_name"];
		
		$inputFileName = $filename;
		try {
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader->load($inputFileName);
		} catch(Exception $e) {
			die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
		}
		//  Get worksheet dimensions
		$sheet = $objPHPExcel->getSheet(0); // get sheet 1 / active sheet
		$highestRow = $sheet->getHighestRow(); // max row count
		$highestColumn = $sheet->getHighestColumn(); // max column count
		//  Loop through each row of the worksheet in turn
		for ($row = 1; $row <= $highestRow; $row++){ 
				//  Read a row of data into an array
				$excelrow = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,NULL,TRUE,FALSE);
				$where = array("name"=>$excelrow[0][0]);
			$table = "fa_user";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$user_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][0],
								"user_name"=>$excelrow[0][0],
								"country_id"=>"90",
								"password"=>"07f83cf03f0c7af02f11fa2f1b0d1043",
								"role"=>"user",
								"email"=>"test@test.com",
								"image"=>"",
								"banned"=>"0",
								"publicwall"=>"0",
							 );
				$user_id = $this->importcsvmodel->addItem($table,$data);
				//print_r($data);
			}
			//Title
			// $excelrow[0][1] = makeslugs($excelrow[0][1]);
			 $title = $excelrow[0][1];
			 $seo = _createseo($title);
			//category
			//$excelrow[0][2] = makeslugs($excelrow[0][2]);
			$where = array("name"=>$excelrow[0][2]);
			$table = "categories";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$category_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][2],
							 );
				$category_id = $this->importcsvmodel->addItem($table,$data);
				//print_r($data);
			}
		  //course
		  // $excelrow[0][3] = makeslugs($excelrow[0][3]);
			$where = array("name"=>$excelrow[0][3]);
			$table = "courses";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$course_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][3],
							 );
				$course_id = $this->importcsvmodel->addItem($table,$data);
				//print_r($data);
			}
			
			//Dish type
			//$excelrow[0][4] = makeslugs($excelrow[0][4]);
			$where = array("name"=>$excelrow[0][4]);
			$table = "types";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$type_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][4],
							 );
				$type_id = $this->importcsvmodel->addItem($table,$data);
				//print_r($data);
			}
			//Occasion
			//$excelrow[0][5] = makeslugs($excelrow[0][5]);
			$where = array("name"=>$excelrow[0][5]);
			$table = "seasons";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$season_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][5],
							 );
				$season_id = $this->importcsvmodel->addItem($table,$data);
			}
			//Cusine
			//$excelrow[0][6] = makeslugs($excelrow[0][6]);
			$where = array("name"=>$excelrow[0][6]);
			$table = "cuisines";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$cuisine_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][6],
							 );
				$cuisine_id = $this->importcsvmodel->addItem($table,$data);
			}
			//Special Diets
			//$excelrow[0][7] = makeslugs($excelrow[0][7]);
			$where = array("name"=>$excelrow[0][7]);
			$table = "special_diets";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$special_diet_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][7],
							 );
				$special_diet_id = $this->importcsvmodel->addItem($table,$data);
			}
			//Methods
			//$excelrow[0][8] = makeslugs($excelrow[0][8]);
			$where = array("name"=>$excelrow[0][8]);
			$table = "methods";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$method_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][8],
							 );
				$method_id = $this->importcsvmodel->addItem($table,$data);
			}
			//Preparation Time
			//$excelrow[0][9] = makeslugs($excelrow[0][9]);
			$preparation_time = $excelrow[0][9];
			
			//Cooking Time
			//$excelrow[0][10] = makeslugs($excelrow[0][10]);
			$cooking_time = $excelrow[0][10];
			
			//Calories
			//$excelrow[0][11] = makeslugs($excelrow[0][11]);
			$where = array("name"=>$excelrow[0][11]);
			$table = "calories";
			if($this->importcsvmodel->isEntryExists($where,$table)){
				$calory_id = $this->importcsvmodel->getUserIdByName($where,$table);
			}else{
				$data = array(
								"name"=>$excelrow[0][11],
							 );
				$calory_id = $this->importcsvmodel->addItem($table,$data);
			}
			
			//Serves
			//$excelrow[0][12] = makeslugs($excelrow[0][12]);
			$serves = $excelrow[0][12];
			
			//Ingredients
			//$excelrow[0][13] = makeslugs($excelrow[0][13]);
			$ingredients = $excelrow[0][13];
			
			//Prepartion Details
			//$excelrow[0][14] = makeslugs($excelrow[0][14]);
			$preparation_details = $excelrow[0][14];
			
			//Image
			//$excelrow[0][15] = makeslugs($excelrow[0][15]);
			$image= $excelrow[0][15];
			
			//video
			//$excelrow[0][16] = makeslugs($excelrow[0][16]);
			$video= $excelrow[0][16];
			
			//Enter into Recipe
			$data = array(
							"uid"=>$user_id,
							"categoryid"=>$category_id,
							"courseid"=>$course_id,
							"typeid"=>$type_id,
							"cuisineid"=>$cuisine_id,
							"seasonid"=>$season_id,
							"methodid"=>$method_id,
							"ingredientid"=>"0",
							"ratingid"=>"0",
							"title"=>$title,
							"images"=>$image,
							"video"=>$video,
							"isyoutube"=>"0",
							"preparationtime"=>$preparation_time,
							"cookingtime"=>$cooking_time,
							"calories"=>$calory_id,
							"serves"=>$serves,
							"preparationdetails"=>$preparation_details,
							"ingredientdetails"=>$ingredients,
							"seo"=>$seo,
							"date"=>date("Y-m-d h:i:s"),
							"isnew"=>"1",
							"approved"=>"1",
							"recipeofday"=>"0",
							"notified"=>"0"
						  );
		  	$table = "recipes";
			$recipe_id = $this->importcsvmodel->addItem($table,$data);
		}
		}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Import Recipe CSV/Excel file</title>
	</head>
	<body>
		<form enctype="multipart/form-data" method="post" style="padding: 100px">
			<table border="1" width="40%" align="center">
				<tr >
					<td colspan="2" align="center"><strong>Import Recipe CSV/Excel file</strong></td>
				</tr>
				<tr>
					<td align="center">CSV/Excel File:</td><td><input type="file" name="file" id="file"></td></tr>
					<tr >
						<td colspan="2" align="center"><input type="submit" name="Import" value="Import"></td>
					</tr>
			</table>
		</form>
	</body>
</html>