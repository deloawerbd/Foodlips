	
			<script>
			    $("document").ready(function(){
			        $(".admin_special").load("https://www.foodlips.com/blog/admin-special/");
			    });
			</script>
					
			<!-- <script>(function(d,s){var js=d.createElement(s);js.src="//www.foodlips.com/shared/public/frontend/js/community/fs.js";
			d.getElementsByTagName(s)[0].parentNode.appendChild(js);}(document,"script"));</script>
			<div id="fShare"></div> -->
			
			<? /* <div id="sendToCommunity" style="display:none;">
				this div is just to send notification on community
		    </div> */ ?>
		    <input type="hidden" id="username" name="username" value="<?=$this->db_session->userdata("user_name");?>" />
			
			<div id="container" class="page_wrapper">
    			<div class="container-fluid">
        			<div class="row">
            			<div class="col-sm-4 col-md-3 left_recipe_home">
                			<div class="blog_sidebar">
                    			<!-- <div class="category_title">CATEGORIES</div>
                				<?php if(isset($categories) && count($categories)) { ?>
                    				<ul>
										<?php foreach($categories as $category) { ?>
                    						<li>
                    							<a <?php if(isset($categoryid)) { if($category->id == $categoryid) { echo "class='active_menu'"; } } ?> href="<?=base_url()?>recipe/category/<?=$category->name;?>">
                    								<?=$category->name; ?>
                    							</a>
                							</li>
                    					<?php } ?>
                    					<li>
                    						<? /* <a href="#" onclick="window.open('https://www.foodlips.com/recipes/community/share/' + $.base64.encode(location.href), 'foodlips-share-dialog', 'width=600,height=500'); return false;"> */ ?>
                							<? /* <a href="#" onclick="window.open('https://www.foodlips.com/recipes/community/share/' + encodeURIComponent(location.href), 'foodlips-share-dialog', 'width=600,height=500'); return false;">
												<img src="<?=base_url();?>public/frontend/images/foodlips_button_small.png" title="Share on FoodLips" alt="Share on FoodLips" />
											</a> */ ?>
                    					</li>
                        			</ul> -->
                    			<?php } ?>
                			</div>
            				<div class="submit_recipes">
                				<span class="submit_recipes_logo">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">
           	    					</a>
                    			</span>
                    			<span class="submit_recipes_txt">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					Submit Recipes
           	    					</a>
                  				</span>
                			</div>
                			
                			<div class="admin_special">
                			</div>
                			
                			<?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>
		                    <?php if(isset($featuredmember)) { ?>
		                    	<?php //echo "data: "; print_r($featuredmember); ?>
		                    	<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>
			                    <div class="featured_member">
			                    	<div class="category_title">Featured Member</div>
			                    	<?php
			                    		$userimg = "defaultuser.jpg";
										if($featuredmemberuser != "") {
											if($featuredmemberuser->image != "") {
												$userimg = $featuredmemberuser->image;
											}
										}
			                    	?>
			                        <div class="admin_special_img featured_member_cont">
			                        	<a class="featured_member_img" href="<?=base_url();?>community/profile/<?=$featuredmemberuser->user_name;?>" title="<?=$featuredmemberuser->name;?>">
			                           		<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" width="75" height="75" />
		                           		</a>
                                        <div class="featured_member_txt">
                                            <span class="featured_member_txt2">
                                                <a href="<?=base_url();?>community/profile/<?=$featuredmemberuser->user_name;?>">
                                                    <?=$featuredmemberuser->name;?>
                                                </a>
                                            </span>
                                            <span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>
                                            <?php $date = explode(" ", $featuredmemberuser->created); ?>
                                            <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>
                                        </div>
			                        </div>
			                    </div>
		                    <?php } ?>
                			<? /* <div class="featured_member">
                				<span class="admin_special_txt">Featured Member</span>
                    			<span class="admin_special_img">
                    				<a href="<?=base_url();?>">
                       					<img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="featured_member">
                   					</a>
                    				<span class="featured_member_txt2">Monique</span>
									<span class="featured_member_txt3">Recipe Submitted: 99</span>
                    				<span class="featured_member_txt3">Member Since: 14 Feb 2013</span>
                    			</span>
                			</div> */ ?>
                			<? /* 
                			<div class="advertisement">
                				<span class="admin_special_txt">Advertisement</span>
                			</div> */ ?>
            			</div>
                		<div class="col-sm-8 col-md-9 right_recipe_home">
                			<?php if(isset($top5recipes) && count($top5recipes)) { ?>
                				<div class="recipe_box_slider">
	                				<div class="banner_img">
										<div id="this-carousel-id" class="carousel slide">
											<!-- class of slide for animation -->
											<div class="carousel-inner">
													<?php //$i = 0; $imagefolder = "650x350/";
													$i = 0; $imagefolder = "1004x400/";
													foreach ($top5recipes as $recipe) {
														if($recipe->images != "") {
														 	$images = explode(",", $recipe->images);
															if(count($images)) { ?>
																<div <?=$i == 0 ? "class='active item'" : "class='item'"; ?>>
																	<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0]; ?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" />
																	<? /* <div class="carousel-caption recipe_b_contain"> */ ?>
																	<div class="carousel-caption">
																		<?php $user = $this->crudmodel->getuserbyid($recipe->uid); ?>
																		<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>" class="recipe_b_img_cont" title="<?=$user != '' ? $user->name : '';?>">
																			<div class="recipe_b_img">
																				<?php
																					$userimg = "defaultuser.jpg";
																					if($user != "") {
																						if($user->image != "") {
																							$userimg = $user->image;
																						}
																					}
																				?>
											                					<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" />
											            					</div>
										            					</a>
										                    			<div class="recipe_b_txt">
										                    				<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
										                    				<span class="recipe_b_txt_1">
										                    					<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"><?=$recipe->title;?></a> */ ?>
										                    					<? /* <a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>"><?=$recipe->title;?></a> */ ?>
										                    					<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>"><?=$recipe->title;?></a>
										                					</span>
										                        			<span class="recipe_b_txt_2">
										                        				<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>
										                    				</span>
										                    				<span class="recipe_b_txt_3">
									                    						<?php $ratings = $this->crudmodel->takerating($recipe->id);
																					$myrating = "";
					              													if($ratings != "") {
																						$ratings = trim($ratings);
																						$ratings = explode(',', $ratings);
																						$sum = "0"; $i = "0";
																						foreach($ratings as $rating) { $i++;
																							$sum += $rating;
																						}
																						$avgrating = $sum / $i;
																						$myrating = round($avgrating);
								  													}
																					$greystarts = 5 - $myrating;
																					$i = 0; $globalcount = 1;
																					while($i < $myrating) { ?>
																						<span class="ratingsmall">
																							<i <?=($this->db_session->userdata("id")!='') ? " class='fa fa-star green-rating' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>'></i>
																						</span>
																						<?php $i++; $globalcount++;
																					}
																					$i = 0;
																					while($i < $greystarts) { ?>
																						<span class="ratingsmall">
																							<i <?=($this->db_session->userdata("id")!='') ? " class='fa fa-star grey-rating' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>'></i>
																						</span>
																					<?php $i++; $globalcount++; } ?>
										                					</span>
										                    			</div>
																	</div>
																</div>
															<?php } ?>
														<?php } else { ?>
															<div class="active item">
																<img src="<?=base_url();?>public/frontend/images/defaultrecipe.png" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" />
															</div>
														<?php } ?>
													<?php $i++; } ?>
												</div>
												<!--  Next and Previous controls below
												href values must reference the id for this carousel -->
												<a class="carousel-control left" href="#this-carousel-id" data-slide="prev"><span>&lsaquo;</span></a>
												<a class="carousel-control right" href="#this-carousel-id" data-slide="next"><span>&rsaquo;</span></a>
											</div><!-- /.carousel -->
										</div>
		                    			<? /* <div class="recipe_b_contain">
			                				<div class="recipe_b_img">
			                					<img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="cook">
			            					</div>
			                    			<div class="recipe_b_txt">
			                    				<span class="recipe_b_txt_1">
			                    					<a href="#">Pasta with Sun dried tomatos</a>
			                					</span><br>
			                        			<span class="recipe_b_txt_2">
			                        				<a href="#">Category Pizza/Pasta</a>
			                    				</span><br>
			                    				<span class="recipe_b_txt_3">
			                    					<a href="#">Visitor Rating (4)</a>
			                					</span><br>
			                    			</div>
		              					</div> */ ?>
	                    			</div>
                    		<?php } ?>
                    		<div class="dropdown_category">
                    			<div class="sorting btn-group margin_right_15 margin_bottom_10">
    								<button class="btn login">
                    					Sort by > Top 10 Recipes
                    				</button>
    								<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<ul class="dropdown-menu action_my pull-left">
				                    	<?/* <li>
			                    			<a href="/">Item 1</a>
		                    			</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li> */ ?>
    								</ul>
    							</div>
                				<div class="showingall btn-group">
    								<button class="btn login">
    									<?php $isselected = false; ?>
    									<?php if(isset($categories)) { ?>
    										<?php foreach($categories as $category) { ?>
    											<?php if($category->name == $this->uri->segment(3)) { ?>
    												<?=$category->name;?>
    												<?php $isselected = true; ?>
												<?php } ?> 
											<?php } ?>
										<?php } ?>
										<?php if(!$isselected) { ?>
                							Showing > All
            							<?php } ?>
                    				</button>
									<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<?php if(isset($categories) && count($categories)) { ?>
    									<ul class="dropdown-menu action_my pull-left">
											<?php foreach($categories as $category) { ?>
                        						<li>
                        							<a class="<?=($category->name == $this->uri->segment(3)) ? 'active_menu' : '' ?>" href="<?=base_url()?>recipe/category/<?=$category->name;?>" id="<?=$category->id;?>">
                        								<?=$category->name; ?>
                    								</a>
                								</li>
                        					<?php } ?>
                        					<li>
                        						<a href="<?=base_url()?>recipe/category/All">All</a>
                    						</li>
										</ul>
									<?php } ?>
    							</div>
                    		</div>
                    		
                    		<?php if(isset($pagination_links)) { ?>
                    			<div class="custom-pagination" style="margin-bottom: 10px;">
                    				<?=$pagination_links;?>
                    			</div>
                			<?php } ?>
                			
                    		<?php if($this->input->post("search")) { ?>
                    			<div class="search_for_box">
                                	<span class="search_head_txt">Search result for :</span>
                        			<span class="search_head_txt2"><?=$this->input->post("search");?></span>
                				</div>
                			<?php } else if(isset($advancesearchfor)) { ?>
            					<div class="search_for_box">
                                	<span class="search_head_txt">Search result for: </span>
                        			<span class="search_head_txt2"><?=$advancesearchfor;?></span>
                				</div>
            				<?php } ?>
                    		<?php if(isset($recipes) && count($recipes)) { ?>
                				<div class="table recipe_post_table" id="recipesdetails" style="margin-bottom: 0px;">
									<?php //$isrowbg = 0; $imagefolder = "275x198/";
											$isrowbg = 0; $imagefolder = "1004x400/";
										foreach($recipes as $recipe) { ?>
											<div id=<?="notificationloading_".$recipe->id;?> class='recipe_post_table_row'>
	                    						<div class="recipe_post_left_cell">
	                    							<? /* <a href="<?=base_url(); ?>recipe/details/<?=$recipe->id;?>"> */ ?>
                    								<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
                    								<? /* <a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>" title="<?=$recipe->title;?>"> */ ?>
                									<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>">
	                    								<?php if($recipe->images != "") {
	                    										$images = explode(",", $recipe->images); ?>
																<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$recipe->title;?>"/>
	                									<?php } else { ?>
	                											<img src="<?=base_url();?>public/frontend/images/defaultrecipe.png" alt="<?=$recipe->title;?>" />
	                									<?php } ?>
	                								</a>
	            								</div>  
	                        					<div class="recipe_post_right_cell">
	                        						<span class="recipe_contain">
	                        							<?php $user = $this->crudmodel->getuserbyid($recipe->uid);
															$userimg = "defaultuser.jpg";
															if($user != "") {
																if($user->image != "") {
																	$userimg = $user->image;
																}
														} ?>
	                        							<span class="recipe_img">
	                        								<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>" title="<?=$user != '' ? $user->name : '';?>">
	                        									<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" />
	                    									</a>
	                    								</span>
	                            						<span class="recipe_txt_head">
	                        								<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
                        									<? /* <a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>"> */ ?>
                    										<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>">
	                        									<?=$recipe->title;?>
	                    									</a>
	                            						</span><br />
														<span class="recipe_txt_1"> by 
															<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>"><?=$user != "" ? $user->name : "user";?></a> in
															<?php //$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
	                           								<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>
	                            						</span>
	                        							<p class="post_detail_txt">
	                        								<span class="seemore">
	                        									<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>">See more</a> */ ?>
	                        									<? /* <a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">See more</a> */ ?>
	                        									<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>">
	                        										See more
                        										</a>
	                    									</span>
	                									</p>
	                        							<p class="post_detail_txt">
	                        								<span class="seemore">
	                        									<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
                        										<? /* <a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>"> */ ?>
                    											<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>">
	                        										Comment (<?=$this->crudmodel->getcommentcountbyrecipeid($recipe->id);?>)
	                    										</a><br />
	                    										<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>">
	                        										I like this (<?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?>)
	                    										</a><br />
	                    										<a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>">
	                        										I made this (<?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?>)
	                    										</a> */ ?>
	                    									</span>
	                									</p>
	                        						</span>
	                        						<span class="ranking">
	                    								<?//=$rating;?>
	                        							<?php $userrating = round($this->crudmodel->takerating($recipe->id));
															$greystarts = 5 - $userrating;
															$i = 0; $globalcount = 1;
															while($i < $userrating) { ?>
																<span class="small_star">
																	<? /* <img <?=($this->db_session->userdata("id") != "") ? "style='cursor:pointer' class='giverating' ": "";?> id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star">*/ ?>
																	<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star green-rating giverating"></i>
																</span>
															<?php $i++; $globalcount++; }
															$i = 0;
															while($i < $greystarts) { ?>
																<span class="small_star">
																	<? /* <img <?=($this->db_session->userdata("id") != "") ? "style='cursor:pointer' class='giverating' " : "";?> id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star"> */ ?>
																	<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star grey-rating giverating"></i>
																</span>
															<?php $i++; $globalcount++; } ?>
	                        						</span>
	                        						<? /* <span id="<?="like_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft" onclick="like(this) , exportlike('<?=$recipe->id;?>')"> */ ?>
                        							<span id="<?="like_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft btn_bg" onclick="recipelike(this)">
	                        							<span class="iconlike">
	                            							<i class="fa fa-thumbs-up"></i>
	                        							</span>
	                        							Like
	                        							<span class="add_like_no">(<span id=<?="likecount_".$recipe->id;?>><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>)</span>
	                        						</span>
	                        						<span id="<?="made_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft btn_bg" onclick="made(this)">
	                            						<span class="iconlike">
	                                						<i class="fa fa-coffee"></i>
	                        							</span>
	                    								I made this
	                    								<span class="add_like_no">(<span id=<?="madecount_".$recipe->id;?>><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>)</span>
	                        						</span>
	                        						
	                        						<? /* <span id="<?="favorites_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft" onclick="isloggedin(this)">
	                            						<span class="iconlike">
	                                						<img src="<?=base_url()?>public/frontend/images/i_made.png" alt="like_thumbs" />
	                        							</span>
	                    								<span class="dropdown-toggle" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>
                    										Add to favorites
                    									</span>
	                    								<ul class="dropdown-menu">
							                        		<li>
									                        	<a href="<?=base_url();?>recipe/addbook">Create book</a>
								                        	</li>
								                        	<li class="divider"></li>
	                    									<?php if(isset($books) && count($books) > 0) { ?>
	                    										<?php foreach($books as $book) { ?>
										                    		<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">
									                    				<span style="color: #000;"><?=$book->name;?></span>
								                    				</li>
							                    				<?php } ?>
								                        	<?php } ?>
					    								</ul>
	                        						</span> */ ?>
	                        						
	                        						<span id="<?="favorites_".$recipe->id;?>" class="btn_floteleft btn-group" onclick="addtofavorites(this)">
                                						<span class="btn btn-mini btn-primary btn-group btn_bg">
								                            <span class="iconlike">
								                                <i class="fa fa-heart"></i>
								                            </span>
								                            <span class="btn_chek">Add to favorite</span>
                                                          </span>
                                                     </span>
	                        						<? /*<span id="<?="favorites_".$recipe->id;?>" class="btn_floteleft btn-group" onclick="isloggedin(this)">
                                						<span class="btn btn-mini btn-primary btn-group">
								                            <span class="iconlike">
								                                <img src="<?=base_url()?>public/frontend/images/add_to_fab.png" alt="add">
								                            </span>
                           
								                            <span class="btn_chek dropdown-toggle" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>
								                           	 	Add to favorite
                                                            </span>

                            								<ul class="dropdown-menu">
                            									<li>
									                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>
								                        		</li>
								                        		<li class="divider"></li>
								                                <?php if(isset($books) && count($books) > 0) { ?>
	                    											<?php foreach($books as $book) { ?>
										                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">
									                    					<a><span style="color: #000;"><?=$book->name;?></span></a>
								                    					</li>
							                    					<?php } ?>
								                        		<?php } ?>
                           	 								</ul>
                    									</span>
                        							</span> */ ?>
													
													<span id=<?="notification_".$recipe->id;?>></span>
													<span id=<?="ratingnotification_".$recipe->id;?>></span>
	                        					</div>
	                  						</div>
                    				<?php $isrowbg++; } ?>
                        		</div>
                        		
							<?php } else if($this->input->post("search") || isset($advancesearchfor)) { ?>
									<p class="notfound">No recipes found for your selection.</p>
								<?php } else { ?>
									<?php $segment = $this->uri->segment("2"); ?>
									<?php if($segment == "submitted" || $segment == "made" || $segment == "favourite" || $segment == "reviewed" || $segment == "likes") { ?>
										<p class="notfound">No recipe found</p>
									<?php } else { ?> 
										<p class="notfound">No recipes present for selected category.</p>
									<?php } ?>
								<?php } ?>
								<?php if(isset($pagination_links)) { ?>
									<div class="custom-pagination" style="margin-bottom: 10px;">
										<?=$pagination_links;?>
									</div>
								<?php } ?>
            			</div>
        			</div>
    			</div>
			</div>