			


			<script>


			    $("document").ready(function() {


			        $(".admin_special").load("https://www.foodlips.com/blog/admin-special/");





			        /*$('.bxslider').bxSlider({


			        	//auto:true,


			        	video: true,


			        	useCSS: false


			        });*/


			       var username = $("#youtubeusername").val();


			       if(typeof username !== "undefined") {


			       		$("#frame").ytv({


			       			user: username,


				       		accent: "#d51c18"


				       	});


			       	}


			       	else {


			       		$("#frame").hide();


		       		}


			    });


			</script>


			


            <input type="hidden" id="username" name="username" value="<?=$this->db_session->userdata("user_name");?>" />


			


			<div id="container" class="center_bg">


    			<div class="container_self_1">


        			<div class="center">


        				<!-- <div class="row">


        					<div class="span12">


        						<div id="frame" style="margin-bottom: 10px;"></div>


    						</div>


        				</div> -->


            			<div class="left_span_3">


                			<div class="recipe_left">


                    			<div class="category_txt">CATEGORIES</div>


                				<?php if(isset($categories) && count($categories)) { ?>


                    				<ul>


										<?php foreach($categories as $category) { ?>


                    						<li>


                    							<a <?php if(isset($categoryid)) { if($category->id == $categoryid) { echo "class='active_menu'"; } } ?> href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">


                    								<?=$category->name; ?>


                    							</a>


                							</li>


                    					<?php } ?>


                        			</ul>


                    			<?php } ?>


                			</div>


            				<div class="submit_recipes">


                				<span class="submit_recipes_logo">


               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">


               	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">


           	    					</a>


                    			</span>


                    			<span class="submit_recipes_txt">


               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">


               	    					Submit Recipes


           	    					</a>


                  				</span>


                			</div>


                			


                			<div class="admin_special">


                			</div>


                			


                			<?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>


		                    <?php if(isset($featuredmember)) { ?>


		                    	<?php //echo "data: "; print_r($featuredmember); ?>


		                    	<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>


			                    <div class="featured_member">


			                    	<span class="admin_special_txt">Featured Member</span>


			                    	<?php


			                    		$userimg = "defaultuser.jpg";


										if($featuredmemberuser != "") {


											if($featuredmemberuser->image != "") {


												$userimg = $featuredmemberuser->image;


											}


										}


			                    	?>


			                        <span class="admin_special_img">


			                        	<a href="https://www.foodlips.com/community/profile/<?=$featuredmemberuser->user_name;?>">


			                           		<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" title="<?=$featuredmemberuser->name;?>" width="75" height="75" />


		                           		</a>


			                            <span class="featured_member_txt2"><?=$featuredmemberuser->name;?></span>


										<span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>


										<?php $date = explode(" ", $featuredmemberuser->created); ?>


			                            <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>


			                        </span>


			                    </div>


		                    <?php } ?>


                			<? /* <div class="featured_member">


                				<span class="admin_special_txt">Featured Member</span>


                    			<span class="admin_special_img">


                    				<a href="<?=base_url();?>">


                       					<img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="featured_member">


                   					</a>


                    				<span class="featured_member_txt2">Monique</span>


									<span class="featured_member_txt3">Recipe Submitted: 99</span>


                    				<span class="featured_member_txt3">Member Since: 14 Feb 2013</span>


                    			</span>


                			</div> */ ?>


                			<? /* 


                			<div class="advertisement">


                				<span class="admin_special_txt">Advertisement</span>


                			</div> */ ?>


            			</div>


                		<div class="selft_span7">


                			<!--Video slider-->


                			<? /*<div class="recipe_box_slider">


                				 <ul class="bxslider">


                					<?php if(isset($recipes) && count($recipes)) { ?>


                						<?php foreach($recipes as $recipe){ ?>


                							<?php if($recipe->video != "") { ?>


                								<li><?=$recipe->video?></li>


                							<?php }?>


                						<?php }?>


                					<?php }?>


                				</ul>


                			</div> */ ?>


                			<?php if(isset($recipes) && count($recipes)) { ?>


                				<?php foreach($recipes as $recipe) { ?>


                					<?php if($recipe->isyoutube == "1" && $recipe->youtubeusername != "") { ?>


                						<input type="hidden" value="<?=$recipe->youtubeusername;?>" id="youtubeusername"/>


                						<?php //$recipe->video?>


                						<?php break;?>


                					<?php }?>


                				<?php }?>


                			<?php }?>


                			<div id="frame" style="margin-bottom: 10px; height: 515px;"></div>


                			<? /*<?php if(isset($top5recipes) && count($top5recipes)) { ?>


                				<div class="recipe_box_slider">


	                				<div class="banner_img">


										<div id="this-carousel-id" class="carousel slide">


											<!-- class of slide for animation -->


											<div class="carousel-inner">


												<?php $i = 0; $imagefolder = "650x350/";


													foreach ($top5recipes as $recipe) {


														if($recipe->images != "") {


														 	$images = explode(",", $recipe->images);


															if(count($images)) { ?>


																<div <?=$i == 0 ? "class='active item'" : "class='item'"; ?>>


																	<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0]; ?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" style="width: 650px; height: 350px;" />


																	<? // <div class="carousel-caption recipe_b_contain">  ?>


																	<div class="carousel-caption">


																		<?php $user = $this->crudmodel->getuserbyid($recipe->uid); ?>


																		<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>">


																			<div class="recipe_b_img">


																				<?php


																					$userimg = "defaultuser.jpg";


																					if($user != "") {


																						if($user->image != "") {


																							$userimg = $user->image;


																						}


																					}


																				?>


											                					<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />


											            					</div>


										            					</a>


										                    			<div class="recipe_b_txt">


										                    				<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>


										                    				<span class="recipe_b_txt_1">


										                    					<? // <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"><?=$recipe->title;?></a>  ?>


										                    					<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>"><?=$recipe->title;?></a>


										                					</span><br />


										                        			<span class="recipe_b_txt_2">


										                        				<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>


										                    				</span><br>


										                    				<span class="recipe_b_txt_3">


									                    						<?php $ratings = $this->crudmodel->takerating($recipe->id);


																					$myrating = "";


					              													if($ratings != "") {


																						$ratings = trim($ratings);


																						$ratings = explode(',', $ratings);


																						$sum = "0"; $i = "0";


																						foreach($ratings as $rating) { $i++;


																							$sum += $rating;


																						}


																						$avgrating = $sum / $i;


																						$myrating = round($avgrating);


								  													}


																					$greystarts = 5 - $myrating;


																					$i = 0; $globalcount = 1;


																					while($i < $myrating) { ?>


																						<span class="ratingsmall">


																							<img <?=($this->db_session->userdata("id")!='') ? " class='' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star">


																						</span>


																						<?php $i++; $globalcount++;


																					}


																					$i = 0;


																					while($i < $greystarts) { ?>


																						<span class="ratingsmall">


																							<img <?=($this->db_session->userdata("id")!='') ? " class='' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star">


																						</span>


																					<?php $i++; $globalcount++; } ?>


										                					</span><br />


										                    			</div>


																	</div>


																</div>


															<?php } ?>


														<?php } else { ?>


															<div class="active item">


																<img src="<?=base_url();?>public/frontend/images/defaultrecipe.png" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" style="width: 650px; height: 350px;" />


															</div>


														<?php } ?>


													<?php $i++; } ?>


												</div>


												<!--  Next and Previous controls below


												href values must reference the id for this carousel -->


												<a class="carousel-control left" href="#this-carousel-id" data-slide="prev">&lsaquo;</a>


												<a class="carousel-control right" href="#this-carousel-id" data-slide="next">&rsaquo;</a>


											</div><!-- /.carousel -->


										</div>


	                    			</div>


                    		<?php } ?> */ ?>


                    		<div class="dropdown_category">


                    			<div class="sorting btn-group">


    								<button class="btn login">


                    					Sort by > Top 10 Recipes


                    				</button>


    								<button class="btn login dropdown-toggle" data-toggle="dropdown">


    									<span class="caret"></span>


    								</button>


    								<ul class="dropdown-menu action_my pull-left">


				                    	<?/* <li>


			                    			<a href="/">Item 1</a>


		                    			</li>


				                        <li>


				                        	<a href="/">Item 3</a>


			                        	</li>


				                        <li>


				                        	<a href="/">Item 3</a>


			                        	</li> */ ?>


    								</ul>


    							</div>


                				<div class="showingall btn-group" style="margin-left: 20px;">


    								<button class="btn login">


    									<?php $isselected = false; ?>


    									<?php if(isset($categories)) { ?>


    										<?php foreach($categories as $category) { ?>


    											<?php if($category->name == $this->uri->segment(3)) { ?>


    												<?=$category->name;?>


    												<?php $isselected = true; ?>


												<?php } ?> 


											<?php } ?>


										<?php } ?>


										<?php if(!$isselected) { ?>


                							Showing > All


            							<?php } ?>


                    				</button>


									<button class="btn login dropdown-toggle" data-toggle="dropdown">


    									<span class="caret"></span>


    								</button>


    								<?php if(isset($categories) && count($categories)) { ?>


    									<ul class="dropdown-menu action_my pull-left">


											<?php foreach($categories as $category) { ?>


                        						<li>


                        							<a class="<?=($category->name == $this->uri->segment(3)) ? 'active_menu' : '' ?>" href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">


                        								<?=$category->name; ?>


                    								</a>


                								</li>


                        					<?php } ?>


                        					<li>


                        						<a href="<?=base_url()?>recipe/category/All">All</a>


                    						</li>


										</ul>


									<?php } ?>


    							</div>


                    		</div>


                    		


                    		<?php if(isset($pagination_links)) { ?>


                    			<div class="custom-pagination">


                    				<?=$pagination_links;?>


                    			</div>


                			<?php } ?>


                			


                    		<?php if($this->input->post("search")) { ?>


                    			<div class="search_for_box">


                                	<span class="search_head_txt">Search result for: </span>


                        			<span class="search_head_txt2"><?=$this->input->post("search");?></span>


                				</div>


                			<?php } else if(isset($advancesearchfor)) { ?>


            					<div class="search_for_box">


                                	<span class="search_head_txt">Search result for :</span>


                        			<span class="search_head_txt2"><?=$advancesearchfor;?></span>


                				</div>


            				<?php } ?>


                    		<?php if(isset($recipes) && count($recipes)) { ?>


                    			<table width="100%" cellpadding="0" cellspacing="0" class="table" style="margin-bottom: 0px;">


									<?php foreach($recipes as $recipe) { ?>


										<?php if($recipe->video != "") { ?>


											<tr class="border_none">


                    							<td width="5">&nbsp;</td>


                								<td>


                        							<div class="selft_span6 reciepe_video span_leftmargin tr_bg">


                        								<div style="width: 560px; min-height: 50px; margin: 0 auto;">


                        									<?=$recipe->video;?>


                        								</div>


                            							


                        							</div>


                        							<?php $user = $this->crudmodel->getuserbyid($recipe->uid);


														$userimg = "defaultuser.jpg";


														if($user != "") {


															if($user->image != "") {


																$userimg = $user->image;


															}


													} ?>


                        							<div id=<?="notificationloading_".$recipe->id;?> class="selft_span6 span_leftmargin4 tr_bg">


                            							<div class="span1 span_leftmargin3_new">


                       	    								<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>">


	                        									<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />


	                    									</a> 


                            							</div>


                            							<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>


                            							<div class="span5 span_leftmargin3 padding-left10">


                            								<span class="recipe_txt_head2">


                                								<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">


                                									<?=$recipe->title;?>


                            									</a>


                            								</span><br />


                            								<span class="recipe_txt_1" style="min-height: 40px;"> by


                            									<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>"><?=$user != "" ? $user->name : "user";?></a> in 


                       											<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>


                        									</span>


                            								<? /* <span class="comment_vid">


                           	  									<a href="#">Comment 1</a>


                       	  									</span> */ ?>


                            								<span class="ranking2">


                                								<span class="ranking-video">


				                    								<?//=$rating;?>


				                        							<?php $userrating = round($this->crudmodel->takerating($recipe->id));


																	$greystarts = 5 - $userrating;


																	$i = 0; $globalcount = 1;


																	while($i < $userrating) { ?>


																		<span class="small_star">


																			<img id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="giverating" src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star" style="cursor:pointer" />


																		</span>


																	<?php $i++; $globalcount++; }


																	$i = 0;


																	while($i < $greystarts) { ?>


																		<span class="small_star">


																			<img id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="giverating" src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star" style="cursor:pointer" />


																		</span>


																	<?php $i++; $globalcount++; } ?>


                        										</span>


                            								</span>


                            								</div>


                            								<div class="selft_span5 span_leftmargin2">


                            									<?php /*<span id="<?="favorites_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="isloggedin(this)">*/?>


                            									<span id="<?="favorites_video_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="addtofavorites(this)">


			                                						<span class="btn btn-mini btn-primary btn-group btn_bg">


											                            <span class="iconlike">


											                                <img src="<?=base_url()?>public/frontend/images/add_to_fab.png" alt="add">


											                            </span>


			                           


											                            <?php /*<span class="btn_chek dropdown-toggle btn_bg" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>


											                           	 	Add to favorite


			                                                            </span>*/?>


			                                                            <span class="btn_chek dropdown-toggle btn_bg">


											                           	 	Add to favorite


			                                                            </span>


			


			                            								<ul class="dropdown-menu">


			                            									<li>


												                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>


											                        		</li>


											                        		<li class="divider"></li>


											                                <?php if(isset($books) && count($books) > 0) { ?>


				                    											<?php foreach($books as $book) { ?>


													                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">


												                    					<a><span style="color: #000;"><?=$book->name;?></span></a>


											                    					</li>


										                    					<?php } ?>


											                        		<?php } ?>


			                           	 								</ul>


			                    									</span>


                        										</span>


				                        						<span id="<?="made_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="made(this)">


				                            						<span class="iconlike">


				                                						<img src="<?=base_url()?>public/frontend/images/i_made.png" alt="like_thumbs" />


				                        							</span>


				                    								I made this


				                    								<span class="add_like_no">(<span id=<?="madecount_".$recipe->id;?>><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>)</span>


				                        						</span>


				                        						<span id="<?="like_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="like(this)">


				                        							<span class="iconlike">


				                            							<img src="<?=base_url()?>public/frontend/images/like_thumbsup.png" alt="like_thumbs" />


				                        							</span>


				                        							Like


				                        							<span class="add_like_no">(<span id=<?="likecount_".$recipe->id;?>><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>)</span>


				                        						</span>


				                        						<span class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="window.location = '<?=base_url()."recipe/details/".$recipe->seo;?>';">


				                        							View recipe


				                        						</span>


                        										<span class="video_txt" id=<?="notification_".$recipe->id;?>></span>


																<span class="video_txt" id=<?="ratingnotification_".$recipe->id;?>></span>


                                								<? /* <span class="btn btn-mini btn-primary btn_floteleft1">


                                    								<span class="iconlike">


                                        								<img src="images/add_to_fab.png" alt="like_thumbs" />


                                    								</span>Add to favorite<!--<span class="add_like_no">20</span>-->


                                								</span>


                                								<span class="btn btn-mini btn-primary btn_floteleft1">


                                    								<span class="iconlike">


                                        								<img src="images/i_made.png" alt="like_thumbs" />


                                									</span>I made this<span class="add_like_no">20</span>


                                								</span>


                            									<span class="btn btn-mini btn-primary btn_floteleft1">


                                									<span class="iconlike">


                                    									<img src="images/like_thumbsup.png" alt="like_thumbs" />


                            										</span>Like<span class="add_like_no">20</span>


                                								</span> */ ?>


                                							</div>


                          								<!-- </div> -->


                        							</div>


                    							</td>


                    							<td width="5">&nbsp;</td>


                							</tr>


											<tr class="height_tr">&nbsp;</tr>


            							<?php } ?>


            						<?php } ?>


            						</table>


								<?php } else if($this->input->post("search") || isset($advancesearchfor)) { ?>


									<p class="notfound">No recipes found for your selection.</p>


								<?php } else { ?>


									<p class="notfound">No recipes present for selected category.</p>


								<?php } ?>


								


								<?php if(isset($pagination_links)) { ?>


									<div class="custom-pagination">


										<?=$pagination_links;?>


									</div>


								<?php } ?>


            				</div>


        				</div>


    				</div>


				</div>


