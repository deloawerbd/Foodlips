
<form action = "<?=base_url()?>recipe/updaterecipe" method = "post" id = "recipeupdateform" enctype="multipart/form-data">
	
	<?php if(isset($recipeid)){ ?>
<label><a href = "<?=base_url();?>recipe/addrecipe/<?=$recipeid;?>">Back</a></lable>	

	<input type = "text" name= "recipeid" value = "<?=$recipeid;?>">
	
	<?php } ?>
	<?php if(isset($errmsg)){ ?>
	<span class="errmsg"><?=$errmsg; ?></span>
	<?php } ?><br>

	<lable>Add Image</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type = "file" name = "userfile" id = "userfile" onchange="return uploadimg(this.id)" value ="<?php if($this->input->post("userfile")) { echo $this->input->post("userfile"); } else { if(isset($recipe)) { echo $recipe->userfile; } } ?>" multiple ="true" /><br>
	<?php if(isset($images) && $images != "") {
		                        					$folder = "";
	                								if(isset($posttype)) {
	                									if($posttype == "sharepost") {
	                										$folder = "sharepost/thumbs/";
	                									}
														else if($posttype == "hirepost") {
															$folder = "hirepost/thumbs/";
														}
	                								}
											
	                								$images = explode(",", $images);
													if(count($images) > 0) { ?>
 	               		  								<ul id="image-list">
 	               		  									<?php foreach($images as $image) {
 	               		  											$id = explode(".", $image); ?>
	                          									<li id=<?=$id[0]."imageli";?>>
	                          										<span class="selectimg_inner">
						                                                <img src="<?=base_url();?>images/<?=$folder.$image;?>" width="50" height="50" alt="image" />
						                                            </span>
						                                            <span class="selectimg_innertxt">
						                                              <span id = "<?=$id[0].$id[1];?>" class='btn btn_remove' onclick="deleteImageNFile(this)"><i class="fa fa-trash"></i></span>
						                                            </span>
	                  											</li>
                  											<?php } ?>
	                   	  								</ul>
                   	  								<?php } ?> 
	                        				<?php } else { ?>
			                        			<ul id="image-list">
			                        			</ul>
		                        			<?php } ?>
		                        			
	<span class="errmsg"><?php echo form_error("userfile"); ?></span>
	<span id="userfileerr" class="errmsg hideerr marginbottom5">Add Image field is required.</span>
	<br><br><br><br>
	
	<lable>Video</lable>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
	<input type = "text" name = "video" value= "<?php if($this->input->post("video")) { echo $this->input->post("video"); } else { if(isset($recipe)) { echo $recipe->video; } } ?>">
	
	<span class="errmsg"><?php echo form_error("video"); ?></span><br><br><br><br>
	
	
	<lable>Ingredients details</lable>
	<textarea name="ingredientsdetails" rows="8" cols="40"><?php if($this->input->post("ingredientsdetails")) { echo $this->input->post("ingredientsdetails"); } else { if(isset($recipe)) { echo $recipe->ingredientsdetails; } } ?></textarea>
	<span class="errmsg"><?php echo form_error("ingredientsdetails"); ?></span><br><br><br><br>
	<lable>Description and Preparation Details</lable>
	<textarea name="preparationdetails" rows="8" cols="40"><?php if($this->input->post("preparationdetails")) { echo $this->input->post("preparationdetails"); } else { if(isset($recipe)) { echo $recipe->preparationdetails; } } ?></textarea>
	<span class="errmsg"><?php echo form_error("preparationdetails"); ?></span><br><br>
	
	<table>
	 <tr class="subtitle"> 
            <td>&nbsp;<strong><font color="#FF0000">* </font></strong>Ingredients 
              for search :</td>
          </tr>
         <?php if(isset($ingredients)) { ?>
    <?php $i = 0;foreach($ingredients as $ingredient): $ingredientsingle = $ingredient->id; ?>

<tr>
        	<td> 
        		<input class=""  type="checkbox"   name="ingredient[<?php echo $i ?>]" value="<?=$ingredientsingle;?>" id = "ingredient"  ><?=$ingredient->name;?>
        		<span id="ingredienterr" class="errmsg hideerr marginbottom5">Select atleast one ingredient</span>
        		
        	</td>

        </tr>
 <?php $i++; endforeach; } ?>                 
                 
                <tr > 
                  <td  colspan="4" align="center"><font class="smalltext">Above 
                    checked ingredients will be used as search fields to list 
                    your recipe in search result.</font></td>
                </tr></table>
                
      <a href="" onclick="message()">         
	 <input type="submit" name="sbt_updatesubmit" value="Upload" id ="update_submit" onclick="return validateRecipe()"></a>
	 <input class="sbbutton" type="submit" name="sbt_cancel" value="Cancel">
</form>
