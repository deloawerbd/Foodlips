			<div class="container">
    			<div class="row">
        			<div class="center">
            			<div class="span3 left_span_3">
                			<div class="recipe_left">
                    			<!--<div class="profile_detail">
                        		</div>-->
                        		<div class="profile_box_left">
                        			<span class="profile_left_image">
                        				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
											$userimg = "defaultuser.jpg";
											if($user != "") {
												if($user->image != "") {
													$userimg = $user->image;
												} 
											} ?>
                        				<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user->name;?>" title="<?=$user->name;?>" /><br />
                    					<p><?=$user->name;?></p>
                        			</span>
       								<ul class="nav border_none">
		                            	<li class="active">
		                            		<a href="<?=base_url();?>recipe/profile/" class="text_link_poem">
		                            			My recipes
	                            			</a>
	                            		</li>
		       							<li>
		       								<a href="<?=base_url();?>recipe/books/" class="text_link_poem">
		       									My books
	       									</a>
	       								</li>
	       								<li>
		       								<a href="<?=base_url();?>recipe/shoppinglist/" class="text_link_poem">
		       									My shopping list
	       									</a>
	       								</li>
       					  			</ul>
                       			</div>
                    		</div>
                		</div>
                		
                		<div class="span7">
	                		<div class="profile_books1 tab-pane" id="tab2">
								<? /* <span class="recipe_btn_profile">
									<a href="<?=base_url();?>recipe/addbook/">
	                    				<span class="btn btn-primary">
	                    					Create book
	                					</span>
	            					</a>
	                			</span> */ ?>
	                			<span class="recipe_btn_profile" style="min-height:10px;">
									<a class="btn btn-primary" href="<?=base_url();?>recipe/books/">
                    					Back
	            					</a>
	                			</span><br />
	                			<span class="bookname">
	                				<?php if(isset($bookname)) {
                						echo $bookname;
                					} ?>
	                			</span>
	                			<?php if(isset($recipes) && count($recipes) > 0) { ?>
	                				<ul>
                						<?php foreach($recipes as $recipe) { ?>
            								<li>
        										<?php $imagefolder = "275x198/"; ?>
												<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
												<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
                								<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
                									<?php if($recipe->images != "") {
														$images = explode(",", $recipe->images); ?>
														<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" style="width: 130px; height: 100px;" />
        											<?php } else { ?>
														<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" style="width: 130px; height: 100px;" />
    												<?php } ?>
    												<span class="profile_text1">
														<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
	                    								<? /* <a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>"> */ ?>
    														<?=$recipe->title;?>
														</a>
													</span>
												</a>
											</li>
										<?php } ?>
									</ul>
								<?php } else { ?>
									<p>
										No recipes present.
									</p>
								<?php } ?>
							</div>
						</div>
                		
                		<? /* <div class="span7">
                			<p>
        						<span class="submit_recipes_logo">
	           	    				<a href="<?=base_url();?>recipe/addbook/mybooks">
	           	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe" />
	       	    					</a>
                				</span>
        						<span class="submit_recipes_txt">
           	    					<a href="<?=base_url();?>recipe/addbook/">
           	    						Create book
       	    						</a>
              					</span>
        					</p>
                			<?php if(isset($recipes) && count($recipes) > 0) { ?>
            					<?php foreach($recipes as $recipe) { ?>
        							<?php $imagefolder = "275x198/";
        								if($recipe->images != "") {
        									$images = explode(",", $recipe->images); ?>
											<a href="<?=base_url();?>recipe/details/<?=$recipe->id;?>">
												<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$recipe->title?>" title="<?=$recipe->title;?>" width="200" height="200" />
											</a>
										<?php } else { ?>
											<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.'defaultrecipe.png';?>" alt="<?=$recipe->title;?>" title="<?=$recipe->title;?>" width="200" height="200" />
										<?php } ?>
            							<br /><span style="font-size: 16px;"><?=$recipe->title;?></span>
            					<?php } ?>
							<?php } ?>
						</div> */ ?>
    				</div>
    			</div>
			</div>