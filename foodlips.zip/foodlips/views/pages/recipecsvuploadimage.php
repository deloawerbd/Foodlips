<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Upload Image</title>
	</head>
	<body>
		<form action="<?= base_url()?>/admin/importcsv/uploadimage" enctype="multipart/form-data" method="post" style = "padding: 100px">
			<table border="1" width="40%" align="center">
				<tr >
					<td colspan="2" align="center"><strong>Upload Image</strong></td>
				</tr>
				<tr>
					<td align="center">Image:</td><td><input type="file" name="userfile[]" multiple></td></tr>
					<tr >
						<td colspan="2" align="center"><input type="submit" name="submitimage" value="Submit Image"></td>
					</tr>
			</table>
		</form>
	</body>
</html>