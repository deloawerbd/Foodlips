				<div class="page_wrapper">
    				<div class="container-fluid margin_top_10">
        				<div class="row">
        					<div class="col-sm-4 col-md-3 left_span_3">
	                			<div class="recipe_left">
	                    			<div class="category_txt">CATEGORIES</div>
	                				<?php if(isset($categories) && count($categories)) { ?>
	                    				<ul>
											<?php foreach($categories as $category) { ?>
	                    						<li>
	                    							<a <?php if(isset($categoryid)) { if($category->id == $categoryid) { echo "class='active_menu'"; } } ?> href="<?=base_url()?>recipe/category/<?=$category->name;?>" id="<?=$category->id;?>">
	                    								<?=$category->name; ?>
	                    							</a>
	                							</li>
	                    					<?php } ?>
	                        			</ul>
	                    			<?php } ?>
	                			</div>
	            				<div class="submit_recipes">
	                				<span class="submit_recipes_logo">
	               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
	               	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">
	           	    					</a>
	                    			</span>
	                    			<span class="submit_recipes_txt">
	               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
	               	    					Submit Recipes
	           	    					</a>
	                  				</span>
	                			</div>
	                			<div class="admin_special">
	                				<span class="admin_special_txt">Admin Special</span>
	                    			<span class="admin_special_img">
	                    				<a href="<?=base_url();?>">
	                        				<img src="<?=base_url();?>public/frontend/images/special_img_1.jpg" alt="special_img">
	                        			</a>
	                        			<span class="admin_special_txt2">Southwest chiken </span>
										<span class="admin_special_txt2">chopped salad</span>
	                    			</span>
	                			</div>
	                			<div class="featured_member">
	                				<span class="admin_special_txt">Featured Member</span>
	                    			<span class="admin_special_img">
	                    				<a href="<?=base_url();?>">
	                       					<img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="featured_member">
	                   					</a>
	                    				<span class="featured_member_txt2">Monique</span>
										<span class="featured_member_txt3">Recipe Submitted: 99</span>
	                    				<span class="featured_member_txt3">Member Since: 14 Feb 2013</span>
	                    			</span>
	                			</div>
	                			<div class="advertisement">
	                				<span class="admin_special_txt">Advertisement</span>
	                			</div>
	            			</div>
	            			
	            			<div class="col-sm-8 col-md-9">
	        					<div class="thumbnail emailbox">
		        					<?=form_open("recipe/emailtofriend");?>
										<?php if(isset($recipeid)) { ?>
											<input type="hidden" name="recipeid" value="<?=$recipeid;?>">
										<?php } ?>
										
										<?php if(isset($successmsg)) { ?>
											<div class="successmsg"><?=$successmsg;?></div>
										<?php } else if(isset($failmsg)) { ?>
											<div class="errmsg"><?=$failmsg;?></div>
										<?php } ?>
										
										<span>Mail to</span><br />
										<input type="text" id="toTxtFld" name="to" value="<?=isset($successmsg) ? "" : $this->input->post("to");?>"/><br />
										<div id="toEmailErr" class="errmsg hideerr">Email field is required.</div>
		            					<div id="invalidToEmailErr" class="errmsg hideerr">The Email field must contain a valid email address.</div>
										<script type="text/javascript">
		                   					$(function() {
		                   						$("#toTxtFld").focus();
		                   					});
		                   				</script>
										<span>Your email</span><br />
										<input type="text" id="fromTxtFld" name="from" value="<?=$this->input->post("from");?>"/><br />
										<div id="fromEmailErr" class="errmsg hideerr">Email field is required.</div>
		            					<div id="invalidFromEmailErr" class="errmsg hideerr">The Email field must contain a valid email address.</div>
										
										<span>Message</span><br />
										<textarea id="messageTxtArea" name="message" placeholder="Type your message"><?=$this->input->post("message");?></textarea><br />
										<div id="messageErr" class="errmsg hideerr">Message field is required.</div>
										<input type="submit" class="btn btn-primary" name="sbt_send" value="Send" onclick="return validateMessage()" />
									<?=form_close();?>
								</div>
							</div>
						</div>
					</div>
				</div>