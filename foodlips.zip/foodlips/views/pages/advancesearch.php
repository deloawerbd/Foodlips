			<script type="text/javascript">
				$("document").ready(function() {
	        		$(".admin_special").load("https://www.foodlips.com/blog/admin-special/");
	    		});
			</script>

			<div class="page_wrapper">
    			<div class="container-fluid">
    				<div class="row">
        				<div class="center">
            				<div class="col-md-3 col-sm-4">
                    			<div class="submit_recipes">
                    				<span class="submit_recipes_logo">
                   	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
                   	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="Submit recipe" title="Submit recipe" />
               	    					</a>
                        			</span>
                        			<span class="submit_recipes_txt">
                   	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
                   	    					Submit Recipes
           	    						</a>
                      				</span>
                    			</div>
                    			
                    			<div class="admin_special"></div>
                    			
                    			<?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>
		                    	<?php if(isset($featuredmember)) { ?>
		                    		<?php //echo "data: "; print_r($featuredmember); ?>
		                    		<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>
                					<div class="featured_member">
			                    		<div class="category_title">Featured Member</div>
			                    		<?php
			                    			$userimg = "defaultuser.jpg";
											if($featuredmemberuser != "") {
												if($featuredmemberuser->image != "") {
													$userimg = $featuredmemberuser->image;
												}
											}
			                    		?>
			                        	<div class="admin_special_img featured_member_cont">
			                        		<a class="featured_member_img" href="https://www.foodlips.com/community/profile/<?=$featuredmemberuser->user_name;?>">
			                           			<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" title="<?=$featuredmemberuser->name;?>" width="75" height="75" />
		                           			</a>
                                            <div class="featured_member_txt">
                                                <span class="featured_member_txt2"><?=$featuredmemberuser->name;?></span>
                                                <span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>
                                                <?php $date = explode(" ", $featuredmemberuser->created); ?>
                                                <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>
                                             </div>
			                        	</div>
			                    	</div>
                				<?php } ?>
                    			<? /* <div class="advertisement">
                    				<span class="admin_special_txt">Advertisement</span>
                    			</div> */ ?>
                			</div>
                			<div class="col-md-9 col-sm-8">
                    			<div class="recipe_detail_box_main">
                    				<h4 class="recipe_detail_head_2">Advance search</h4>
                        			<?php $attributes = array("class" => "form-horizontal form_box_control margintop5"); ?>
                        			<?=form_open("recipe/advancesearch", $attributes);?>
                        				<div class="fromtodate">
                        					<span>
                        						From <input class="input-small" type="text" id="from" name="from" title="From date" value="<?=$this->input->post("from");?>" readonly />
                        					</span>
                        					<span>
    											To <input class="input-small" type="text" id="to" name="to" title="To date" value="<?=$this->input->post("to");?>" readonly />
											</span>
                            			</div>
                            			<div class="span7 control-group">
                            				<label class="advancese_s_txtbox2">Name</label>
                            				<div class="control_input_box_adv">
                            					<input type="text" class="span5" name="name" title="Name of recipe to search" placeholder="Recipe name to search" />
                            				</div>
                            			</div>
                            			<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Category</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="categories" id="categories" title="Category of recipe to search">
                                 					<option value="0">Select Category</option>
			                  						<?php if(isset($recipe)) { ?>
							 							<?php foreach ($categories as $category) { ?>
							 								<?php if($recipe->categoryid == $category->id) { ?>
																<option value="<?=$category->id;?>" selected="true"><?=$category->name;?></option>
															<?php } else { ?>
																<option value="<?=$category->id;?>"><?=$category->name;?></option>
															<?php } ?>
														<?php } ?>
													<?php } else { ?>
							 							<?php foreach ($categories as $category) { ?>
															<option value="<?=$category->id;?>"><?=$category->name;?></option>
														<?php } ?>
													<?php } ?>
												</select>
                            				</div>
                            			</div>
                        				<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Course</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="courses" id="courses" title="Course of recipe to search">
                     		 						<option value="0">Select Course</option>
                      								<?php if(isset($recipe)) { ?>
					         							<?php foreach ($courses as $course) { ?>
					         								<?php if($recipe->courseid == $course->id) { ?>
																<option value="<?=$course->id;?>" selected="true"><?=$course->name;?></option>
															<?php } else { ?>
																<option value="<?=$course->id;?>"><?=$course->name;?></option>
															<?php } ?>
														<?php } ?>
					     							<?php } else { ?>
					         							<?php foreach ($courses as $course) { ?>
															<option value="<?=$course->id;?>"><?=$course->name;?></option>
														<?php } ?>
													<?php } ?>
	         									</select>
                            				</div>
                            			</div>
                            			<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Type</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="types" id="types" title="Type of recipe to search">
				                      				<option value="0">Select Type</option>
				                      				<?php if(isset($recipe)) {  echo "welcome";?>
				         								<?php foreach ($types as $type) { ?>
							         						<?php if($recipe->typeid == $type->id) { ?>
																<option value="<?=$type->id;?>" selected="true"><?=$type->name;?></option>
															<?php } else { ?>
																<option value="<?=$type->id;?>"><?=$type->name;?></option>
															<?php } ?>
														<?php } ?>
							     					<?php } else { ?>
							         					<?php foreach ($types as $type) { ?>
															<option value="<?=$type->id;?>"><?=$type->name;?></option>
														<?php } ?>
													<?php } ?>
					     						</select>
                            				</div>
                            			</div>
                         				<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Cuisine</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="cuisines" id="cuisines" title="Cuisine of recipe to search">
								                     <option value="0">Select Cuisine</option>
								                      <?php if(isset($recipe)) {  echo "welcome";?>
								         					<?php foreach ($cuisines as $cuisine) { ?>
								         						<?php if($recipe->cuisineid == $cuisine->id) { ?>
																	<option value="<?=$cuisine->id;?>" selected="true"><?=$cuisine->name;?></option>
																<?php } else { ?>
																	<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
																<?php } ?>
															<?php } ?>
								     					<?php } else { ?>
								         					<?php foreach ($cuisines as $cuisine) { ?>
																<option value="<?=$cuisine->id;?>"><?=$cuisine->name;?></option>
															<?php } ?>
														<?php } ?>
							         			</select>
                            				</div>
                            			</div>
                        				<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Season/Occasion</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="seasons" id="season" title="Season/Occasion of recipe to search">
						                      		<option value="0">Select Season</option>
							                      	<?php if(isset($recipe)) {  echo "welcome";?>
						         						<?php foreach ($seasons as $season) { ?>
						         							<?php if($recipe->seasonid == $season->id) { ?>
																<option value="<?=$season->id;?>" selected="true"><?=$season->name;?></option>
															<?php } else { ?>
																<option value="<?=$season->id;?>"><?=$season->name;?></option>
															<?php } ?>
														<?php } ?>
							     					<?php } else { ?>
							         					<?php foreach ($seasons as $season) { ?>
															<option value="<?=$season->id;?>"><?=$season->name;?></option>
														<?php } ?>
													<?php } ?>
							         			</select>
                            				</div>
                            			</div>
                            			<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Preparation Method</label>
                            				<div class="control_input_box_adv">
                            					<select class="span2" name="methods" id="methods" title="Preparation method of recipe to search">
				                      				<option value="0">Select Method</option>
							                      	<?php if(isset($recipe)) { ?>
							     						<?php foreach ($methods as $method) { ?>
						     								<?php if($recipe->methodid == $method->id) { ?>
																<option value="<?=$method->id;?>" selected="true"><?=$method->name;?></option>
															<?php } else { ?>
																<option value="<?=$method->id;?>"><?=$method->name;?></option>
															<?php }?>
														<?php } ?>
							 						<?php } else {?>
							     						<?php foreach ($methods as $method) { ?>
															<option value="<?=$method->id;?>"><?=$method->name;?></option>
														<?php } ?>
													<?php } ?>
								         		</select>
                            				</div>
                            			</div>
                        				<div class="span3 control-group margin_left_span">
			                            	<label class="advancese_s_txtbox">Preparation Time</label>
			                            	<div class="control_input_box_adv">
			                            		<input type="text" class="span2" name="preparationtime" title="Time require to make recipe (in minutes)" placeholder="Time in minutes" />
			                            	</div>
                            			</div>
                             			<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Calories</label>
                            				<div class="control_input_box_adv">
                            					<input type="text" class="span2" name="calories" title="Calories of recipe to search" placeholder="Calories" />
                            				</div>
                            			</div>
                            			<div class="span3 control-group margin_left_span">
                            				<label class="advancese_s_txtbox">Serves</label>
                            				<div class="control_input_box_adv">
                            					<input type="text" class="span2" name="serves" title="Number of people to be serve" placeholder="Serve" />
                            				</div>
                            			</div>
                            			
                            			<div class="clearboth"></div>
                        				
                         				<?php /*  if(isset($ingredients)) { ?>
                        					<div class="adv_search_head_2">Ingredients for search</div>
                            				<div class="adv_search_check_box"> 
                            					<ul>
                            						<?php foreach($ingredients as $ingredient) {
   							 							$ingredientsingle = $ingredient->id; ?>
                                						<li>
                                							<label class="checkbox">
                            									<input type="checkbox" name="ingredient[]" value="<?=$ingredientsingle;?>" />
                        										<?=$ingredient->name;?>
                    										</label>
                                    					</li>
                                					<?php } ?>
                                				</ul>
                            				</div>
                        				<?php } */?>          
                        				<div class="span3 control-group margin_left_span">
                        					<div class="adv_search_btn">
                        						<input type="submit" class="btn btn-success" name="sbt_search" value="Search" />
                        					</div>
                        				</div>
                   					<?=form_close();?>
                				</div>    
            				</div>
        				</div>
    				</div>
				</div>
			</div>