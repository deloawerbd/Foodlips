			<div class="container-fluid">
    			<div class="row">
        			<div class="center">
            			<div class="span3 left_span_3">
                			<div class="recipe_left">
                    			<!--<div class="profile_detail">
                        		</div>-->
                        		<div class="profile_box_left">
                        			<span class="profile_left_image">
                        				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
											$userimg = "defaultuser.jpg";
											if($user != "") {
												if($user->image != "") {
													$userimg = $user->image;
												} 
											} ?>
                        				<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user->name;?>" title="<?=$user->name;?>" /><br />
                    					<p><?=$user->name;?></p>
                        			</span>
       								<ul class="nav border_none">
		                            	<li class="active">
		                            		<a href="<?=base_url();?>recipe/profile/" class="text_link_poem">
		                            			My recipes
	                            			</a>
	                            		</li>
		       							<li>
		       								<a href="<?=base_url();?>recipe/profile/mybooks" class="text_link_poem">
		       									My books
	       									</a>
	       								</li>
		       						  	<? /* <li>
		       						  		<a href="<?=base_url();?>recipe/profile/changepassword" data-toggle="tab" class="text_link_poem">
		       						  			Change password
	       						  			</a>
	       						  		</li>
		                                <li>
		                                	<a href="" data-toggle="tab" class="text_link_poem">Change profile image</a>
	                                	</li> */ ?>
       					  			</ul>
                       			</div>
                    		</div>
                		</div>
                		<div class="span7">
                			<div class="profile_books1 tab-pane" id="tab2">
                				<span class="recipe_btn_profile" style="min-height:10px;">
									<a href="<?=base_url();?>recipe/books/">
                    					Back
	            					</a>
	                			</span>
	                			<?php if(isset($err)) { ?>
	                				<span class="errmsg"><?=$err;?></span><br />
	                			<?php } ?>
	                			<ul>
	                				<li>
	                					<?=form_open("recipe/addbook");?>
	                						<input type="text" name="name" value="" placeholder="Book name" /><br />
	                						<input type="submit" class="btn primary-btn" name="sbt_addbook" value="Create" />
	                					<?=form_close();?>
	                				</li>
                				</ul>
                			</div>
                		</div>
            		</div>
        		</div>
    		</div>