		<script src="<?=base_url()?>public/frontend/amazing_slider_engine/jquery.js"></script>
    	<script src="<?=base_url()?>public/frontend/amazing_slider_engine/amazingslider.js"></script>
    	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/frontend/amazing_slider_engine/amazingslider-1.css">
    	<script src="<?=base_url()?>public/frontend/amazing_slider_engine/initslider-1.js"></script>
    	
    	<script>
    		$(document).ready(function() {
			    $("#amazingslider-1").width("");
			});
    	</script>
    		
		<input type="hidden" id="username" name="username" value="<?=$this->db_session->userdata("user_name");?>" />
			<div id="container" class="center_bg">
    			<div class="container_self_1">
        			<div class="center">
            			<div class="left_span_3">
                			<div class="recipe_left">
                    			<div class="category_txt">CATEGORIES</div>
                				<?php if(isset($categories) && count($categories)) { ?>
                    				<ul>
										<?php foreach($categories as $category) { ?>
                    						<li>
                    							<a <?php if(isset($categoryid)) { if($category->id == $categoryid) { echo "class='active_menu'"; } } ?> href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">
                    								<?=$category->name; ?>
                    							</a>
                							</li>
                    					<?php } ?>
                        			</ul>
                    			<?php } ?>
                			</div>
            				<div class="submit_recipes">
                				<span class="submit_recipes_logo">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">
           	    					</a>
                    			</span>
                    			<span class="submit_recipes_txt">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					Submit Recipes
           	    					</a>
                  				</span>
                			</div>
                			
                			<div class="admin_special">
                			</div>
                			
                			<?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>
		                    <?php if(isset($featuredmember)) { ?>
		                    	<?php //echo "data: "; print_r($featuredmember); ?>
		                    	<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>
			                    <div class="featured_member">
			                    	<span class="admin_special_txt">Featured Member</span>
			                    	<?php
			                    		$userimg = "defaultuser.jpg";
										if($featuredmemberuser != "") {
											if($featuredmemberuser->image != "") {
												$userimg = $featuredmemberuser->image;
											}
										}
			                    	?>
			                        <span class="admin_special_img">
			                        	<a href="https://www.foodlips.com/community/profile/<?=$featuredmemberuser->user_name;?>">
			                           		<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" title="<?=$featuredmemberuser->name;?>" width="75" height="75" />
		                           		</a>
			                            <span class="featured_member_txt2"><?=$featuredmemberuser->name;?></span>
										<span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>
										<?php $date = explode(" ", $featuredmemberuser->created); ?>
			                            <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>
			                        </span>
			                    </div>
		                    <?php } ?>
            			</div>
            			
            			
                		<div class="right_recipe_home">
                			<!--Video slider-->
                			<div class="recipe_box_slider" style="margin-bottom: 20px">
                				<div id="sliderFrame">

        					<?php // echo "<pre>"; ?>
    						<?php //print_r($top5recipes);exit; ?>	
                			<div id="frame" style="margin-bottom: 10px; height: 515px;"></div>
                			<?php if(isset($top5recipes) && count($top5recipes)) { ?>
                				<div class="recipe_box_slider">
                						<div id="slider1_container" style="position: relative; top: 0px; left: 0px; width: 560px;height: 315px;">
												<div u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 560px; height: 315px;overflow: hidden;">
													
												    <!-- Slides Container -->
												    <?php foreach($top5recipes as $top5recipe){ ?>
												    	<?php if(!empty($top5recipe->video)){ ?>
												    	<div>
														    <div u="player" style="position: relative; top: 0px; left: 0px; width: 560px; height: 315px; overflow: hidden;">
														        <?= $top5recipe->video?>
														    </div>
													    </div>
													<?php } ?>
													<?php } ?>
											   </div>
												 <!--#region Bullet Navigator Skin Begin -->
												 <!-- Help: http://www.jssor.com/development/slider-with-bullet-navigator-jquery.html -->
						       
										        <!-- bullet navigator container -->
										        <div u="navigator" class="jssorb03" style="bottom: 6px; right: 6px;">
										            <!-- bullet navigator item prototype -->
										            <div u="prototype"><div u="numbertemplate"></div></div>
										        </div>
										        <!--#endregion Bullet Navigator Skin End -->
										</div>
                    			</div>
                    		<?php } ?>
							

							
								<div id="amazingslider-wrapper-1" style="width:100%; margin:0px auto 108px;">
							        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
						            	<?php
						            		foreach($top5recipes as $top5recipe) {
						            			$content = $top5recipe->video;
												if(!empty($content)) {
								            		$content = str_replace('<iframe width="560" height="315" src="//', '', $content);
													$content = str_replace('" frameborder="0" allowfullscreen></iframe>', '', $content);
													$arr = explode('/',$content);
													$fname = trim(end($arr)); 
								            		$image_url = "http://img.youtube.com/vi/" . $fname . "/0.jpg";
													$thumbnail_url = "http://i1.ytimg.com/vi/" . $fname . "/default.jpg";
													$video_url = "http://www.youtube.com/embed/" . $fname . "?v=" . $fname;
						            	?>
		
							            <ul class="amazingslider-slides" style="width=100%; display:none;">
							                <li><img src="<?=$image_url?>" />
							                <video preload="none" src="<?=$video_url;?>"></video>
							                </li>
							            </ul>
							            <ul class="amazingslider-thumbnails" style="display:none;">
							                <li><img src="<?=$thumbnail_url;?>" /></li>
							            </ul>
		   					           	<?php
		   					           			}
											}
										?>
							        </div>
						    	</div>

                    		</div>
                			</div>
                    		<div class="dropdown_category">
                    			<div class="sorting btn-group">
    								<button class="btn login">
                    					Sort by > Top 10 Recipes
                    				</button>
    								<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<ul class="dropdown-menu action_my pull-left">
				                    	<?/* <li>
			                    			<a href="/">Item 1</a>
		                    			</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li> */ ?>
    								</ul>
    							</div>
                				<div class="showingall btn-group">
    								<button class="btn login">
    									<?php $isselected = false; ?>
    									<?php if(isset($categories)) { ?>
    										<?php foreach($categories as $category) { ?>
    											<?php if($category->name == $this->uri->segment(3)) { ?>
    												<?=$category->name;?>
    												<?php $isselected = true; ?>
												<?php } ?> 
											<?php } ?>
										<?php } ?>
										<?php if(!$isselected) { ?>
                							Showing > All
            							<?php } ?>
                    				</button>
									<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<?php if(isset($categories) && count($categories)) { ?>
    									<ul class="dropdown-menu action_my pull-left">
											<?php foreach($categories as $category) { ?>
                        						<li>
                        							<a class="<?=($category->name == $this->uri->segment(3)) ? 'active_menu' : '' ?>" href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">
                        								<?=$category->name; ?>
                    								</a>
                								</li>
                        					<?php } ?>
                        					<li>
                        						<a href="<?=base_url()?>recipe/category/All">All</a>
                    						</li>
										</ul>
									<?php } ?>
    							</div>
                    		</div>
                    		
                    		<?php if(isset($pagination_links)) { ?>
                    			<div class="custom-pagination">
                    				<?=$pagination_links;?>
                    			</div>
                			<?php } ?>
                			
                    		<?php if($this->input->post("search")) { ?>
                    			<div class="search_for_box">
                                	<span class="search_head_txt">Search result for: </span>
                        			<span class="search_head_txt2"><?=$this->input->post("search");?></span>
                				</div>
                			<?php } else if(isset($advancesearchfor)) { ?>
            					<div class="search_for_box">
                                	<span class="search_head_txt">Search result for :</span>
                        			<span class="search_head_txt2"><?=$advancesearchfor;?></span>
                				</div>
            				<?php } ?>
                    		<?php if(isset($recipes) && count($recipes)) { ?>
                    			<table width="100%" cellpadding="0" cellspacing="0" class="table" style="margin-bottom: 0px;">
									<?php foreach($recipes as $recipe) { ?>
										<?php if($recipe->video != "") { ?>
											<tr class="border_none">
                    							<td width="5">&nbsp;</td>
                								<td>
                        							<div class="selft_span6 reciepe_video span_leftmargin tr_bg">
                        								<div style="width: 560px; min-height: 50px; margin: 0 auto;">
                        									<?=$recipe->video;?>
                        								</div>
                            							
                        							</div>
                        							<?php $user = $this->crudmodel->getuserbyid($recipe->uid);
														$userimg = "defaultuser.jpg";
														if($user != "") {
															if($user->image != "") {
																$userimg = $user->image;
															}
													} ?>
                        							<div id=<?="notificationloading_".$recipe->id;?> class="selft_span6 span_leftmargin4 tr_bg">
                            							<div class="span1 span_leftmargin3_new">
                       	    								<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>">
	                        									<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />
	                    									</a> 
                            							</div>
                            							<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
                            							<div class="span5 span_leftmargin3 padding-left10">
                            								<span class="recipe_txt_head2">
                                								<a href="<?=base_url();?>recipe/details/<?=$categoryname;?>/<?=$recipe->title;?>">
                                									<?=$recipe->title;?>
                            									</a>
                            								</span><br />
                            								<span class="recipe_txt_1" style="min-height: 40px;"> by
                            									<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>"><?=$user != "" ? $user->name : "user";?></a> in 
                       											<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>
                        									</span>
                            								<? /* <span class="comment_vid">
                           	  									<a href="#">Comment 1</a>
                       	  									</span> */ ?>
                            								<span class="ranking2">
                                								<span class="ranking-video">
				                    								<?//=$rating;?>
				                        							<?php $userrating = round($this->crudmodel->takerating($recipe->id));
																	$greystarts = 5 - $userrating;
																	$i = 0; $globalcount = 1;
																	while($i < $userrating) { ?>
																		<span class="small_star">
																			<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star green-rating giverating"></i>
																		</span>
																	<?php $i++; $globalcount++; }
																	$i = 0;
																	while($i < $greystarts) { ?>
																		<span class="small_star">
																			<i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star grey-rating giverating"></i>
																		</span>
																	<?php $i++; $globalcount++; } ?>
                        										</span>
                            								</span>
                            								</div>
                            								<div class="selft_span5 span_leftmargin2">
                            									<?php /*<span id="<?="favorites_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="isloggedin(this)">*/?>
                            									<span id="<?="favorites_video_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="addtofavorites(this)">
			                                						<span class="btn btn-mini btn-primary btn-group btn_bg">
											                            <span class="iconlike">
											                                <i class="fa fa-plus"></i>
											                            </span>
			                           
											                            <?php /*<span class="btn_chek dropdown-toggle btn_bg" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>
											                           	 	Add to favorite
			                                                            </span>*/?>
			                                                            <span class="btn_chek dropdown-toggle btn_bg">
											                           	 	Add to favorite
			                                                            </span>
			
			                            								<ul class="dropdown-menu">
			                            									<li>
												                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>
											                        		</li>
											                        		<li class="divider"></li>
											                                <?php if(isset($books) && count($books) > 0) { ?>
				                    											<?php foreach($books as $book) { ?>
													                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">
												                    					<a><span style="color: #000;"><?=$book->name;?></span></a>
											                    					</li>
										                    					<?php } ?>
											                        		<?php } ?>
			                           	 								</ul>
			                    									</span>
                        										</span>
				                        						<span id="<?="made_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="made(this)">
				                            						<span class="iconlike">
				                                						<i class="fa fa-coffee"></i>
				                        							</span>
				                    								I made this
				                    								<span class="add_like_no">(<span id=<?="madecount_".$recipe->id;?>><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>)</span>
				                        						</span>
				                        						<span id="<?="like_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="like(this)">
				                        							<span class="iconlike">
				                            							<i class="fa fa-thumbs-up"></i>
				                        							</span>
				                        							Like
				                        							<span class="add_like_no">(<span id=<?="likecount_".$recipe->id;?>><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>)</span>
				                        						</span>
				                        						<span class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="window.location = '<?=base_url()."recipe/details/".$recipe->seo;?>';">
				                        							View recipe
				                        						</span>
                        										<span class="video_txt" id=<?="notification_".$recipe->id;?>></span>
																<span class="video_txt" id=<?="ratingnotification_".$recipe->id;?>></span>
                                								<? /* <span class="btn btn-mini btn-primary btn_floteleft1">
                                    								<span class="iconlike">
                                        								<img src="images/add_to_fab.png" alt="like_thumbs" />
                                    								</span>Add to favorite<!--<span class="add_like_no">20</span>-->
                                								</span>
                                								<span class="btn btn-mini btn-primary btn_floteleft1">
                                    								<span class="iconlike">
                                        								<img src="images/i_made.png" alt="like_thumbs" />
                                									</span>I made this<span class="add_like_no">20</span>
                                								</span>
                            									<span class="btn btn-mini btn-primary btn_floteleft1">
                                									<span class="iconlike">
                                    									<img src="images/like_thumbsup.png" alt="like_thumbs" />
                            										</span>Like<span class="add_like_no">20</span>
                                								</span> */ ?>
                                							</div>
                          								<!-- </div> -->
                        							</div>
                    							</td>
                    							<td width="5">&nbsp;</td>
                							</tr>
											<tr class="height_tr">&nbsp;</tr>
            							<?php } ?>
            						<?php } ?>
            						</table>
								<?php } else if($this->input->post("search") || isset($advancesearchfor)) { ?>
									<p class="notfound">No recipes found for your selection.</p>
								<?php } else { ?>
									<p class="notfound">No recipes present for selected category.</p>
								<?php } ?>
								
								<?php if(isset($pagination_links)) { ?>
									<div class="custom-pagination" style="margin-bottom: 10px">
										<?=$pagination_links;?>
									</div>
								<?php } ?>
            				</div>
        				</div>
    				</div>
    				<script>
				        jssor_slider1_starter('slider1_container');
				    </script>
				</div>
			</div>