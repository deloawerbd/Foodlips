<script> var siteurl = "https://www.foodlips.com/"; </script>
<?php $recipe_base_url = "https://www.foodlips.com/shared/"; ?>
<?php if($this->db_session->userdata("id") != "") { ?>

	<!-- <div class="signup_login_header">
		<a class="signup_link" href="<?=base_url();?>auth/logout">Logout</a>
	</div> -->

	<?php } else { ?>

		<div class="signup_login_header">
			<a class="signup_link italic_txt" href="<?php echo $recipe_base_url; ?>auth/login">Sign Up</a>
			<span class="separator_slash"></span>
			<button type="button" class="btn green_btn" data-toggle="modal" data-target="#login-modal">Login</button>
		</div>

		<div class="modal fade bs-example-modal-sm" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
					  <div class="modal-dialog modal-sm">
					    <div class="modal-content">
						    <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title" id="myModalLabel">Login</h4>
							</div>
							<div class="modal-body">

								<div id="loginContainer" class="search_box_2">
									<div class="search_box_in"> <!-- write here display nonw -->
										<? /*<?=form_open("auth/login", array('id' => 'login_form'));?> */?>
										<?=form_open("recipe/login", array('id' => 'recipe_loginform'));?>
										<?php $loginflag = $this->input->post("login"); //form_open("auth/login");?>
										<?php if($loginflag) echo isset($this->fal_validation->login_error_message) ? $this->fal_validation->login_error_message : '';?>
											<?php if($loginflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'password'.'_error'} : '')?>
												<div class="community_email">
													<label for="user_name">
														<!-- <div class="community_email_txt">
															<?=$this->lang->line('FAL_user_name_label')?>User Name <? /* <!-- Username --> */?>
														</div> -->
														<div class="community_email_input">
															<input id="userName" name="user_name" type="text" placeholder="Username" value ="<?php if($loginflag) echo $this->input->post('user_name'); ?>"/>
															<?php //if($loginflag) echo (isset($this->fal_validation) ? $this->fal_validation->{'user_name'.'_error'} : '')?>
														</div>
													</label>
												</div>
												<div class="community_email">
													<label>
														<!-- <div class="community_email_txt">
															<?=$this->lang->line('FAL_user_password_label')?>Password <? /* <!-- Password --> */ ?>
														</div> -->
														<div class="community_email_input">
															<input id="loginPassword" name="password" type="password" placeholder="Password" />
														</div>
														<div class="community_email_input">
															<span class="community_chk_txt">
																<? /*anchor($this->config->item('FAL_forgottenPassword_uri'), $this->lang->line('FAL_forgotten_password_label').' ?',array('class'=>'text_h1')) */?>
																 <a href="<?=base_url();?>auth/forgotten_password">Forgotten Password ?</a>
															</span>
															<span class="community_email_input">&nbsp;or <a href="<?=base_url();?>auth/login" class="reg_txt">New Member</a></span>
														</div>
													</label>
												</div>
												<div class="community_login_btn_box">
													<!-- <input id="login" type="submit" name="login" class="community_btn" value="Login" /> -->
													<input id="loginBtn" type="submit" name="login" class="community_btn" value="Login" />
													<!-- loginlogout.php -->
												</div>
												<div class="both_clear"></div>
												<div id="userErr" class="hideerr errmsg"></div>
												
										<?=form_close();?>
									</div>
								</div>

							</div>
					    </div>
					  </div>
					</div>


	<?php } ?>
                
			<? /*	<?php $recipe = base64_encode("recipe"); ?>
				
				 <?php $offset1 = "offset1";
				if($this->db_session->userdata("id") != "") {
					$offset1 = "";
				} ?>
				<?php $attribute = array("class" => "searchform"); ?>
				<?=form_open("recipe", $attribute);?>
					<div class="span4 <?=$offset1?> margin_search_top" style="margin-right: 0px;">
						<span class="search_input">
							<input type="text" name="search" value="<?=$this->input->post("search");?>" title="Recipe to search" placeholder="Enter recipe keyword" />
						</span>
						<span>
							<input type="submit" class="btn login_link2" name="sbt_search" value="Search" />
						</span>
						<br />
						<span class="advance_txt">
							<a href="<?=base_url();?>recipe/advancesearch">Advance search</a>
						</span>
					</div>
				<?=form_close();?> 
				
				<?php if($this->db_session->userdata("id") == "") { ?>
        			<div class="span1 offset5 login_header_box">
						<!-- <a href="https://www.foodlips.com/community?<?=$recipe."=".$recipe;?>" class="btn login_link"> -->
							<a href="https://www.foodlips.com/recipes/auth/login" class="btn login_link">
							Login
						</a>
      				</div>
          		<?php } else { ?>
      				<?php $user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));
					$userimg = "defaultuser.jpg";
					if($user != "") {
						if($user->image != "") {
							$userimg = $user->image;
						} 
					} ?>
								
					<div class="span1 btn-group login_header_box">
						<a href="<?=base_url();?>recipe/profile" class="btn login_link">
							<span class="login_img">
								<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />
							</span>
	            			Profile
	    				</a>
					</div>
					<div class="span1 btn-group login_header_box" style="margin-left: 7px;">
						<a href="<?=base_url();?>recipe/logout" class="btn login_link">
                			Logout
            			</a>
					</div>
				<?php } ?> */ ?>
