<form action=<?=base_url();?>recipe/signup method="post" enctype="multipart/form-data" id="loginForm">
	<br><br>
	<?if(isset($success)){
	echo $success;
} else if(isset($unsuccess)) echo $unsuccess; ?><br><br><br>
User Name :	
<input type = "text" name ="user_name" placeholder="Enter your name"><br>
Email id :
<input type = "text" name ="email" placeholder="Enter your email"><br>
Password :
<input type = "text" name ="password" placeholder="Enter password" id="password"><br>
Confirm Password :
<input type = "text" name ="cpassword" placeholder="Confirm password" id="confirmpassword" ><br>
Add Image :
<input type = "file" name = "userfile" id = "userfile" onchange="return uploadimg(this.id)" value ="<?php if($this->input->post("userfile")) { echo $this->input->post("userfile"); } else { if(isset($recipe)) { echo $recipe->userfile; } } ?>" multiple ="true" />
<br><br>
<input type="submit" value="Register" name ="sbt_register">
<br><br><br>
<?if(isset($success)){
	echo $success;
}else if(isset($unsuccess)) echo $unsuccess;?>

</form>	
