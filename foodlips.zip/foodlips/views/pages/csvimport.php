<?php
if(isset($_POST["Import"]))
{
	$host="localhost"; // Host name.
	$db_user="foodlips_admin";
	$db_password="EDu#~V;9BPTd";
	$db='foodlips_restaurant'; // Database name.
	$conn = mysql_connect($host,$db_user,$db_password) or die (mysql_error());
	mysql_select_db($db) or die (mysql_error());
	
	echo $filename=$_FILES["file"]["tmp_name"];
	//echo $ext=substr($filename,strrpos($filename,"."),(strlen($filename)-strrpos($filename,".")));
	
	if($_FILES["file"]["size"] > 0)
	{
		$file = fopen($filename, "r");
		
		$firstrow = fgetcsv($file, 10000, ",");
		while (($excelrow = fgetcsv($file, 10000, ",")) !== FALSE)
		{
			$date = date("Y-m-d H:i:s");
			echo $excelrow[2];exit;
			$patterns = array (
								'/\W+/', // match any non-alpha-numeric character sequence, except underscores
								'/\s+/'  // match any number of white spaces
							);
			$replaces = array ('-', '-' );
			
			$post_name = trim(preg_replace($patterns, $replaces,strtolower($excelrow[2])));
			if(isset($excelrow[21]) && !empty($excelrow[21])){
				
				$sql = "INSERT into wp_posts(post_author,post_date,post_date_gmt,post_content,post_title,post_name,post_type) values('$excelrow[0]','$date','$date','$excelrow[1]','$excelrow[2]','$post_name','$excelrow[3]')";
				//$sql = "INSERT into wp_posts(post_author,post_date,post_content,post_title,post_name,post_type) values('$excelrow[0]','$date','$excelrow[1]','$excelrow[2]','$post_name','$excelrow[3]')";
				if(mysql_query($sql)){
					if(mysql_insert_id() > 0){
							
						//insert record into wp_postcodes table	
						$postid = mysql_insert_id();
						$sqlinsertpostcodes = "INSERT into wp_postcodes(post_id,post_type,latitude,longitude) values('$postid','$excelrow[3]','$excelrow[4]','$excelrow[5]')";
						mysql_query($sqlinsertpostcodes);
						
						//insert record into wp_term_relationships table for display categories by default is set to (restaurants = 12)	
						$insertpostcategory = "INSERT into wp_term_relationships(object_id,term_taxonomy_id) values('$postid','12')";
						mysql_query($insertpostcategory);
						
						//insert record into wp_postmeta table
						$pointer = 6;
						for($i=1;$i<=15;$i++){
							$metakey = $firstrow[$pointer];
							$metavalue = $excelrow[$pointer];
							//echo "<br />Meta_key:".$metakey."<br />";
							$sqlinsertpostmeta = "INSERT into wp_postmeta(post_id,meta_key,meta_value) values('$postid','$metakey','$metavalue')";
							//echo $sqlinsertpostmeta."<br />";
							mysql_query($sqlinsertpostmeta);
							$pointer++;
						}
						
						//insert new post if images found
						
						$images = explode(",", $excelrow[21]);
						//echo "comma seaprated img:".print_r($images);
						foreach($images as $image){
							$guid = "https://www.foodlips.com/shared/restaurants/wp-content/uploads/2013/11/".$image;
							//$guid = "/home/ssunrise1/dev.foodlips_backup/docs/img/".$image;
							$attachedfile = "2013/11/".$image; //actual image foldername
							
							$image = explode(".", $image);
							
							$imgpost_title = trim(preg_replace($patterns, $replaces,strtolower($image[0]))); 
							//echo"<br />".$image[0]."and".$image[1];
							
							$imagepost = "INSERT into wp_posts(post_author,post_date,post_date_gmt,post_title,post_status,post_name,post_parent,guid,post_type,post_mime_type) values('$excelrow[0]','$date','$date','$imgpost_title','attachment','$imgpost_title','$postid','$guid','attachment','image/jpeg')";
							mysql_query($imagepost);
							
							if(mysql_insert_id() > 0){
								$imgpost_id = mysql_insert_id();
								$insertImgpostmeta = "INSERT into wp_postmeta(post_id,meta_key,meta_value) values('$imgpost_id','_wp_attached_file','$attachedfile')";
								mysql_query($insertImgpostmeta);
							}
						}
					}
				}
			}else{
				$sql = "INSERT into wp_posts(post_author,post_date,post_date_gmt,post_content,post_title,post_name,post_type) values('$excelrow[0]','$date','$date','$excelrow[1]','$excelrow[2]','$post_name','$excelrow[3]')";
				//$sql = "INSERT into wp_posts(post_author,post_date,post_content,post_title,post_name,post_type) values('$excelrow[0]','$date','$excelrow[1]','$excelrow[2]','$post_name','$excelrow[3]')";
				if(mysql_query($sql)){
					if(mysql_insert_id() > 0){
						//insert record into wp_postcodes table	
						$postid = mysql_insert_id();
						$sqlinsertpostcodes = "INSERT into wp_postcodes(post_id,post_type,latitude,longitude) values('$postid','$excelrow[3]','$excelrow[4]','$excelrow[5]')";
						mysql_query($sqlinsertpostcodes);
						
						//insert record into wp_term_relationships table for display categories by default is set to (restaurants = 12)	
						$insertpostcategory = "INSERT into wp_term_relationships(object_id,term_taxonomy_id) values('$postid','12')";
						mysql_query($insertpostcategory);
						
						//insert record into wp_postmeta table
						$pointer = 6;
						for($i=1;$i<=15;$i++){
							$metakey = $firstrow[$pointer];
							$metavalue = $excelrow[$pointer];
							//echo "<br />Meta_key:".$metakey."<br />";
							$sqlinsertpostmeta = "INSERT into wp_postmeta(post_id,meta_key,meta_value) values('$postid','$metakey','$metavalue')";
							//echo $sqlinsertpostmeta."<br />";
							mysql_query($sqlinsertpostmeta);
							$pointer++;
						}
					}
				}
			}
		}
		fclose($file);
		echo "CSV File has been successfully Imported";
	}
	else
		echo "Invalid File:Please Upload CSV File";
}

	/*for event entry
 	//insert record into wp_postmeta table
						$pointer = 6;
						for($i=1;$i<=17;$i++){
							$metakey = $firstrow[$pointer];
							$metavalue = $excelrow[$pointer];
							//echo "<br />Meta_key:".$metakey."<br />";
							$sqlinsertpostmeta = "INSERT into wp_postmeta(post_id,meta_key,meta_value) values('$postid','$metakey','$metavalue')";
							//echo $sqlinsertpostmeta."<br />";
							mysql_query($sqlinsertpostmeta);
							$pointer++;
						}*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Import CSV/Excel file</title>
	</head>
	<body>
		<form enctype="multipart/form-data" method="post">
			<table border="1" width="40%" align="center">
				<tr >
					<td colspan="2" align="center"><strong>Import CSV/Excel file</strong></td>
				</tr>
				<tr>
					<td align="center">CSV/Excel File:</td><td><input type="file" name="file" id="file"></td></tr>
					<tr >
						<td colspan="2" align="center"><input type="submit" name="Import" value="Import"></td>
					</tr>
			</table>
		</form>
	</body>
</html>