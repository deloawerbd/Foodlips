 			<div class="page_wrapper">	
         <div class="container-fluid margin_top_10">
    				<div class="row">
                <div class="col-md-2"></div>
        				<div class="col-md-8">
            				<div class="well_custom submit_recipe_box">
                			<div class="community_head2 margin_bottom_none sub_recipe_head">New Recipe</div>
                				<?php $attributes = array("id" => "recipeupdateform", "class" => "form-horizontal form_box_control"); ?>
                				<?=form_open_multipart("recipe/submitrecipe", $attributes);?>
                					<?php if(isset($recipeid)) { ?>
										<label>
											<a class="btn btn-primary" href="<?=base_url();?>recipe/submitrecipe/<?=isset($recipeid) ? $recipeid : "";?>">Back</a>
										</label>
										<?php if(isset($recipeid)) { ?>
											<input type="hidden" id="recipeid" name="recipeid" value="<?=$recipeid;?>" />
										<?php } ?>
									<?php } ?>
									<?php if(isset($errmsg)) { ?>
										<span class="errmsg"><?=$errmsg;?></span><br />
									<?php } ?>
                    	 			<div id="recipemedialoading" class="control-group recipe_images_box">
                         				<div class="recipe_images">
                    						<span class="recipe_images_txt">Add images file</span>
                    						<input type="file" id="userfile" name="userfile"  title="Add recipe images, you can add multiple images for recipe" placeholder="Select recipe images" size="40" multiple ="true" /><br />
                    						<span><small>Note:<span style="color: #005DBD;"> You can add multiple images.</span></small></span>
                       						<ul id="image-list">
                       							<?php if(isset($recipe)) { ?>
                       								<?php if($recipe->images != "") { ?>
                   										<?php $imagefolder = "50x50/"; ?>
                       									<?php $images = explode(",", $recipe->images); ?>
                       									<?php foreach($images as $image) { ?>
                       										<?php $id = explode(".", $image); ?>
                       										<li id="<?=$id[0].'li'?>">
                                            <span class="selectimg_inner">
                                                <img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$image;?>" width="50" height="50" />
                                            </span>
                                            <span class="selectimg_innertxt">
                                              <span id = "<?=$id[0].$id[1];?>" class='btn btn_remove' onclick="deleteImage(this)"><i class="fa fa-trash"></i></span>
                                            </span>
            															</li>
            														<?php } ?>
                       								<?php } ?>
                   								<?php } ?>
											</ul>
											<span class="errmsg"><?=form_error("userfile");?></span>
											<div id="userfileerr" class="errmsg hideerr marginleft55 marginbottom5">Image field is required.</div>
                        				</div>
                        				<div class="clearboth"></div>
                    				</div>
                        			<div class="control-group">
                           				<div class="sub_recipe_head_2">Video</div>
                           				<div class="sub_recipe_head_2">
                           					<label class="radio">
                           						<input type="radio" name="youtuberadio" onchange="showEmbeded();" value="0" checked>
                           						Embeded code
                           					</label>
                           					<label class="radio">
                           						<input type="radio" name="youtuberadio" onchange="showYoutube();" value="1">
                           						Youtube Link
                           					</label>
                           				</div>
                           				<div id="youtube" class="control_textarea">
                            				<input type="text" name="youtubeuser" class="span3" title="Youtube Username" placeholder="Enter Youtube user Name" />
                            				<input type="text" name="youtubeurl" class="span5" placeholder="https://www.youtube.com/watch?v=Y84_wZgPE78" title="Enter Youtube URL"/>
                            			</div>
                            			<div id="embeded" class="control_textarea">
                            				<textarea id="video" class="span5" name="video" rows="5" title='Embeded code of your recipe video. For eg <iframe width="560" height="315" src="http://www.youtube.com/embed/PTUxCvCz8Bc" frameborder="0" allowfullscreen></iframe>' placeholder='Embeded code here. For eg <iframe width="560" height="315" src="http://www.youtube.com/embed/PTUxCvCz8Bc" frameborder="0" allowfullscreen></iframe>'><?php if($this->input->post("video")) { echo $this->input->post("video"); } else { if(isset($recipe)) { echo $recipe->video; } } ?></textarea>
                            				<? /* <input type="text" name="video" class="span3" placeholder="Video URL" value="<?php if($this->input->post("video")) { echo $this->input->post("video"); } else { if(isset($recipe)) { echo $recipe->video; } } ?>"> */ ?>
                            			</div>
                            			<span class="errmsg marginleft100"><?=form_error("video");?></span>
                            			<div id="videoeerr" class="errmsg hideerr marginleft100 marginbottom5">Video field is required.</div>
                            		</div>
                           			<div class="control-group">
                           				<div class="sub_recipe_head_2">Ingredients</div>
                    					<div class="control_textarea">
                    						<div id="itemDetails">
                    							<? /* <?php if(isset($ingredientdetails)) { ?>
                    								<?php $ingredientdetails = explode("|", $ingredientdetails); ?>
                    								<?php foreach($ingredientdetails as $ingredientdetail) { ?>
                										<input type="text" class="numeric unitValue required" name="itemGaylords[]" value="<?=$ingredientdetail;?>" tabindex="8" recname="itemGaylords" placeholder="Ingredient" style="width: 460px; margin-top: 5px; margin-bottom: 5px;" /><br />
                									<?php } ?>
                								<?php } ?> */ ?>
									      		<input type="text" tabindex="8" recname="itemGaylords" class="numeric unitValue required" id="itemGaylords" name="itemGaylords[]" title="Add recipe ingredients, you can add multiple ingredients by clicking on 'Add more'" placeholder="Ingredient" /><br />
								    		</div>
                    					</div>
                        			</div>
                            		<div class="control-group">
                           				<div class="sub_recipe_head_2">Preparation details</div>
                        				<div class="control_textarea">
                            				<textarea id="preparationdetails" class="span5" name="preparationdetails" rows="5" title="Recipe preparation details" placeholder="Preparation Details"><?php if($this->input->post("preparationdetails")) { echo $this->input->post("preparationdetails"); } else { if(isset($recipe)) { echo $recipe->preparationdetails; } } ?></textarea>
                            			</div>
                            			<span class="errmsg marginleft100"><?=form_error("preparationdetails");?></span>
                            			<div id="preparationdetailserr" class="errmsg hideerr marginleft100 marginbottom5">Preparation details field is required.</div>
                            		</div>
                            		
                            		<?php //if(isset($ingredients)) { ?>
                            			<!-- <div class="sub_recipe_head_2">Ingredients for search</div>
                    					<div class="sub_check_box">
                         					<ul>
   							 					<?php //foreach($ingredients as $ingredient) {
   							 						//$ingredientsingle = $ingredient->id; ?>
                                						<li>
                                            	<label>
                                                  <input type="checkbox" name="ingredient[]" value="<?=$ingredientsingle;?>" />
                                                  <?//=$ingredient->name;?>
                                              </label>
                                  					</li>
                                				<?php //} ?>
                            				</ul>
                    					</div> -->
                					<?php //} ?>
                        			<div class="control-group">
                        				<div class="recipe_submit_btn_1">
                        					<input type="submit" id="update_submit" class="btn btn-success" name="sbt_recipemedia" value="Submit" onclick="return validateRecieMedia()" />
                        					<input type="submit" class="btn btn-danger" name="sbt_cancel" value="Cancel" />
                        				</div>
                        			</div>
                   				<?=form_close();?>
            				</div>
            			</div>
                  <div class="col-md-2"></div>
        			</div>
    			</div>
           </div>