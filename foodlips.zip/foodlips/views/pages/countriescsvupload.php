<?php 

function makeslugs($string, $maxlen = 0) {
  		$newStringTab = array();
      	$string = strtolower(nodiacritics($string));
      	//$string = $this->_nodiacritics($string);
      	if(function_exists("str_split")) {
     		$stringTab=str_split($string);
		}
      	else {
     		$stringTab = mystrsplit($string);
		}

      	$numbers=array("0","1","2","3","4","5","6","7","8","9","-");
      	//$numbers=array("0","1","2","3","4","5","6","7","8","9");

      	foreach($stringTab as $letter) {
     		if(in_array($letter, range("a", "z")) || in_array($letter, $numbers)) {
        		$newStringTab[]=$letter;
            	//print($letter);
         	}
         	elseif($letter == " ") {
        		$newStringTab[] = "-";
			}
      	}

      	if(count($newStringTab)) {
     		$newString = implode($newStringTab);
         	if($maxlen > 0) {
            	$newString = substr($newString, 0, $maxlen);
			}
         
 			$newString = removeduplicates('--', '-', $newString);
		}
      	else {
     		$newString='';
		}
  		$newString = str_replace("-", " ", $newString);
		$newString = ucwords($newString);
		
  		return $newString;
		
	}
   	
	function nodiacritics($string) {
		//cyrylic transcription
      	$cyrylicFrom = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я');
      	$cyrylicTo = array('A', 'B', 'W', 'G', 'D', 'Ie', 'Io', 'Z', 'Z', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'Ch', 'C', 'Tch', 'Sh', 'Shtch', '', 'Y', '', 'E', 'Iu', 'Ia', 'a', 'b', 'w', 'g', 'd', 'ie', 'io', 'z', 'z', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'ch', 'c', 'tch', 'sh', 'shtch', '', 'y', '', 'e', 'iu', 'ia'); 
      
		$from = array("Á", "À", "Â", "Ä", "Ă", "Ā", "Ã", "Å", "Ą", "Æ", "Ć", "Ċ", "Ĉ", "Č", "Ç", "Ď", "Đ", "Ð", "É", "È", "Ė", "Ê", "Ë", "Ě", "Ē", "Ę", "Ə", "Ġ", "Ĝ", "Ğ", "Ģ", "á", "à", "â", "ä", "ă", "ā", "ã", "å", "ą", "æ", "ć", "ċ", "ĉ", "č", "ç", "ď", "đ", "ð", "é", "è", "ė", "ê", "ë", "ě", "ē", "ę", "ə", "ġ", "ĝ", "ğ", "ģ", "Ĥ", "Ħ", "I", "Í", "Ì", "İ", "Î", "Ï", "Ī", "Į", "Ĳ", "Ĵ", "Ķ", "Ļ", "Ł", "Ń", "Ň", "Ñ", "Ņ", "Ó", "Ò", "Ô", "Ö", "Õ", "Ő", "Ø", "Ơ", "Œ", "ĥ", "ħ", "ı", "í", "ì", "i", "î", "ï", "ī", "į", "ĳ", "ĵ", "ķ", "ļ", "ł", "ń", "ň", "ñ", "ņ", "ó", "ò", "ô", "ö", "õ", "ő", "ø", "ơ", "œ", "Ŕ", "Ř", "Ś", "Ŝ", "Š", "Ş", "Ť", "Ţ", "Þ", "Ú", "Ù", "Û", "Ü", "Ŭ", "Ū", "Ů", "Ų", "Ű", "Ư", "Ŵ", "Ý", "Ŷ", "Ÿ", "Ź", "Ż", "Ž", "ŕ", "ř", "ś", "ŝ", "š", "ş", "ß", "ť", "ţ", "þ", "ú", "ù", "û", "ü", "ŭ", "ū", "ů", "ų", "ű", "ư", "ŵ", "ý", "ŷ", "ÿ", "ź", "ż", "ž");
      	$to = array("A", "A", "A", "A", "A", "A", "A", "A", "A", "AE", "C", "C", "C", "C", "C", "D", "D", "D", "E", "E", "E", "E", "E", "E", "E", "E", "G", "G", "G", "G", "G", "a", "a", "a", "a", "a", "a", "a", "a", "a", "ae", "c", "c", "c", "c", "c", "d", "d", "d", "e", "e", "e", "e", "e", "e", "e", "e", "g", "g", "g", "g", "g", "H", "H", "I", "I", "I", "I", "I", "I", "I", "I", "IJ", "J", "K", "L", "L", "N", "N", "N", "N", "O", "O", "O", "O", "O", "O", "O", "O", "CE", "h", "h", "i", "i", "i", "i", "i", "i", "i", "i", "ij", "j", "k", "l", "l", "n", "n", "n", "n", "o", "o", "o", "o", "o", "o", "o", "o", "o", "R", "R", "S", "S", "S", "S", "T", "T", "T", "U", "U", "U", "U", "U", "U", "U", "U", "U", "U", "W", "Y", "Y", "Y", "Z", "Z", "Z", "r", "r", "s", "s", "s", "s", "B", "t", "t", "b", "u", "u", "u", "u", "u", "u", "u", "u", "u", "u", "w", "y", "y", "y", "z", "z", "z");
      
      	$from = array_merge($from, $cyrylicFrom);
		$to = array_merge($to, $cyrylicTo);

      $newstring = str_replace($from, $to, $string);
      return $newstring;
   	}
	
	function mystrsplit($string) {
  		$slen = strlen($string);
  		for($i = 0; $i < $slen; $i++) {
     		$sArray[$i] = $string{$i};
		}
      	return $sArray;
	}
	
	function removeduplicates($sSearch, $sReplace, $sSubject) {
		$i = 0;
      	do {
     		$sSubject = str_replace($sSearch, $sReplace, $sSubject);
			$pos = strpos($sSubject, $sSearch);
			$i++;
			if($i > 100) {
            	die('removeduplicates() loop error');
			}
      	}
      	while($pos !== false);
		return $sSubject;
	}


if(isset($_POST["Import"])){
	$filename = $_FILES["file"]["tmp_name"];
	if($_FILES["file"]["size"]>0){
		$file = fopen($filename,"r");
		while (($excelrow = fgetcsv($file,1000,",","'")) !== FALSE){
			$where = array("name"=>$excelrow[0]);
			if($this->restmodel->iscountryexists($where)){
				$countryid = $this->restmodel->getcountryidbyname($where);
			}else{
				$data = array("name"=>$excelrow[0]);
				$countryid = $this->restmodel->addcountry($data);
				//print_r($data);
			}
			 $excelrow[1] = makeslugs($excelrow[1]);
			$where = array("state_name"=>$excelrow[1]);
			if($this->restmodel->isstateexists($where)){
				$stateid = $this->restmodel->getstateidbyname($where);
			}else{
				$data = array("state_name"=>$excelrow[1],
							  "country_id"=>$countryid,
							  "substate"=>$excelrow[2]);
				$stateid = $this->restmodel->addstate($data);
				//print_r($data);
			}
			 $excelrow[3] = makeslugs($excelrow[3]);
			$data = array("stateid"=>$stateid,
						  "countryid"=>$countryid,
						  
						  "name"=>$excelrow[3],
						  "incaps"=>$excelrow[4],
						  "latitude"=>$excelrow[5],
						  "longitude"=>$excelrow[6]);
		  $insertid = $this->restmodel->addcity($data);
		  //print_r($data);exit;
		}
		fclose($file);
		echo "CSV File has been successfully Imported";
	}else{
		echo "Invalid file : Please upload csv file";
	}
	
	
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Import CSV/Excel file</title>
	</head>
	<body>
		<form enctype="multipart/form-data" method="post">
			<table border="1" width="40%" align="center">
				<tr >
					<td colspan="2" align="center"><strong>Import CSV/Excel file</strong></td>
				</tr>
				<tr>
					<td align="center">CSV/Excel File:</td><td><input type="file" name="file" id="file"></td></tr>
					<tr >
						<td colspan="2" align="center"><input type="submit" name="Import" value="Import"></td>
					</tr>
			</table>
		</form>
	</body>
</html>