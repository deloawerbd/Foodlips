			<script type="text/javascript">
				$("document").ready(function() {
			        $(".admin_special").load("https://www.foodlips.com/blog/admin-special/");
			    })
			</script>
	   		<div id="sendToCommunity" style="display:none;">
        		this div is just to send notification on community
        	</div>
        	<input type="hidden" id="username" name="username" value="<?=$this->db_session->userdata("user_name");?>" />

			<div class="page_wrapper">
		    	<div class="container-fluid">
		        	<div class="row">
		            	<div class="col-sm-4 col-md-3 left_recipe_home">
		                	<!--<div class="blog_sidebar">
		                    	<div class="category_title">CATEGORIES</div>
		                    	<ul>
		                    		<?php if(isset($categories) && count($categories)) { ?>
										<?php foreach($categories as $category) { ?>
		                        			<li>
		                        				<a href="<?=base_url()?>recipe/category/<?=$category->name;?>" id="<?=$category->id;?>">
		                        					<?=$category->name;?>
		                        				</a>
		                    				</li>
		                        		<?php } ?>
									<?php } ?>
		                        </ul>
		                    </div>-->
		                    <!--<div class="submit_recipes">
		                    	<span class="submit_recipes_logo">
		                    		<a href="<?=base_url();?>recipe/submitrecipe/recipe">
		                    			<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">
	                    			</a>
		                        </span>
		                        <span class="submit_recipes_txt">
		                   	    	<a href="<?=base_url();?>recipe/submitrecipe/recipe">
		                   	    		Submit Recipes
	                   	    		</a>
		                      </span>
		                    </div>-->

		                    <!--<div class="admin_special">
		                    </div>-->

		                    <?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>
		                    <?php if(isset($featuredmember)) { ?>
		                    	<?php //echo "data: "; print_r($featuredmember); ?>
		                    	<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>
			                    <!--<div class="featured_member">
			                    	<div class="category_title">Featured Member</div>
			                    	<?php
			                    		$userimg = "defaultuser.jpg";
										if($featuredmemberuser != "") {
											if($featuredmemberuser->image != "") {
												$userimg = $featuredmemberuser->image;
											}
										}
			                    	?>
			                        <div class="admin_special_img featured_member_cont">
			                        	<a class="featured_member_img" href="<?=base_url();?>community/profile/<?=$featuredmemberuser->user_name;?>">
			                           		<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" title="<?=$featuredmemberuser->name;?>" width="75" height="75" />
		                           		</a>
                                        <div class="featured_member_txt">
                                            <span class="featured_member_txt2">
                                                <a href="<?=base_url();?>community/profile/<?=$featuredmemberuser->user_name;?>"><?=$featuredmemberuser->name;?></a>
                                            </span>
                                            <span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>
                                            <?php $date = explode(" ", $featuredmemberuser->created); ?>
                                            <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>
                                        </div>
			                        </div>
			                    </div>-->
		                    <?php } ?>
		                </div>

		                <div class="col-sm-8 col-md-9">
                        	<div class="row">
	                    		<div class="col-md-9 recipe_detail_box_main">
	                    			<div class="category_title"><?=$recipe->title;?></div>
	                    			<h1><?=$recipe->title;?> Recipe</h1>
									<br></br>
									<h2> Thank you for visiting Foodlips Social Network. Try out this tasty <?=$recipe->title;?> recipe today and let us know what you think!</h2>
	                    				<div class="recipe_detail_userbox">
		                        			<ul class="well_custom">
		                            			<li>
	                                				<span class="recipe_detail_icon_new">
	                                    				<i class="fa fa-envelope-o" title="Email to friend"></i>
	                                					<a href="mailto:your friend email address here?subject=<?=$this->config->item("FAL_website_name").": ".$recipe->title;?>&body=Type your message here%0D%0D<?=base_url()."recipe/details/".$recipe->id;?>" title="Email to friend">
	                                					</a>
	                                    			</span>
	                                    			<span class="recipe_detail_link_new">
	                                    				<a href="mailto:your friend email address here?subject=<?=$this->config->item("FAL_website_name").": ".$recipe->title;?>&body=Type your message here%0D%0D<?=base_url()."recipe/details/".$recipe->id;?>" title="Email to friend">
	                                    				<?/* <a href="<?=base_url();?>recipe/emailtofriend/<?=$recipe->id;?>" title="Email to friend"> */ ?>
	                                    					<span style="text-decoration: none;">
	                                    						Email
	                                						</span>
	                                					</a>
	                                				</span>
		                                		</li>
		                            			<li>
		                            				<?php /*<span id="<?="favorites_".$recipe->id;?>" onclick="isloggedin(this)" style="cursor: pointer;">*/?>
		                            				<span id="<?="favorites_".$recipe->id;?>" onclick="addtofavorites(this)" style="cursor: pointer;">
		                        						<span class="recipe_detail_icon_new">
		                        							<span style="text-decoration: none;">
		                        								<i class="fa fa-heart-o"></i>
	                        								</span>
		                                    				<span class="btn-group" style="position: absolute; z-index: 1000; width: 100px;">
	                                    						<ul class="dropdown-menu">
	                            									<li style="width: 120px; min-height: 10px;">
										                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>
									                        		</li>
									                        		<li class="divider" style="width: 100px; min-height: 10px; margin: 0px; padding: 0px; background: none;"></li>
									                                <?php if(isset($books) && count($books) > 0) { ?>
		                    											<?php foreach($books as $book) { ?>
											                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" style="width: 120px;" onclick="addtobook(this)">
										                    					<a><span><?=$book->name;?></span></a>
									                    					</li>
								                    					<?php } ?>
									                        		<?php } ?>
	                           	 								</ul>
	                                    					</span>
	                                    				</span>
	                                    				<span class="btn-group">
	                                    					<span class="dropdown-toggle">
	                                    					<?php /*<span class="dropdown-toggle" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>*/?>
		                                    					<span class="recipe_detail_link_new" title="Add to favorites" style="cursor: pointer;">
					                           	 					Favorites
	                                            				</span>
	                                        				</span>
	                                        				<ul class="dropdown-menu">
	                        									<li>
									                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>
								                        		</li>
								                        		<li class="divider"></li>
								                                <?php if(isset($books) && count($books) > 0) { ?>
	                    											<?php foreach($books as $book) { ?>
										                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">
									                    					<a><span><?=$book->name;?></span></a>
								                    					</li>
							                    					<?php } ?>
								                        		<?php } ?>
	                       	 								</ul>
	                                        			</span>
	                                        		</span>
		                                		</li>
		                            			<li>
		                                			<span class="recipe_detail_icon_new">
		                                    			<a href="#comment" onclick="comment()">
		                                    				<? /* <img src="<?=base_url();?>public/frontend/images/comment_1.png" alt="comment" title="Comment" /> */ ?>
		                                    				<span style="text-decoration: none;">
		                                    					<i class="fa fa-comment-o"></i>
	                                						</span>
		                                        		</a>
		                                    		</span>
		                                			<span class="recipe_detail_link_new">
		                                    			<span class="recipe_detail_link_txt">
		                                    				<a href="#comment" onclick="comment()" title="Comment">
		                                    					<span style="text-decoration: none;">
		                                    						Comment <span id="commentcount"><?=isset($commentscount) ? $commentscount : 0;?></span>
	                                    						</span>
															</a>
		                                				</span>
		                                    			<? /* <span class="u1"><?=isset($commentscount) ? $commentscount : 0;?></span> */ ?>
		                                    		</span>
		                                		</li>
		                                		<li>
		                                			<span class="recipe_detail_icon_new">
		                                    			<span onclick="print()" style="cursor: pointer;">
		                                    				<i class="fa fa-print"></i>
		                                    				<? /* <img src="<?=base_url();?>public/frontend/images/print_1.png" alt="print" title="Print" /> */ ?>
	                                    				</span>
		                                    		</span>
		                                    		<span class="recipe_detail_link_new">
		                                    			<span onclick="print()" title="Print" style="cursor: pointer;">
		                                    				Print
		                                				</span>
		                                			</span>
		                                		</li>
		                                		<li>
		                                			<div style="width:89px; height:60px; padding:2px; margin-right:12px;">
			                                			<span class="recipe_detail_icon_new">
			                                    			<span id="<?="like_".$recipe->id;?>" onclick="recipelike(this)" style="cursor: pointer;">
			                                    				<? /* <img src="<?=base_url();?>public/frontend/images/like_1.png" alt="like" title="Like" /> */ ?>
			                                    				<i class="fa fa-thumbs-o-up"></i>
			                                        		</span>
			                                    		</span>
			                                    		<div style="margin: 0 auto;">
				                                			<span class="recipe_detail_link_new">
				                                    			<div class="recipe_detail_link_txt">
				                                    				<span id="<?="like_".$recipe->id;?>" onclick="recipelike(this)" title="Like" style="cursor: pointer;">
				                                    					Like <span id="likecount"><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>
			                                    					</span>
				                                				</div>
				                                    			<? /* <span class="u1"><span id="likecount"><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span></span> */ ?>
				                                    		</span>
			                                    		</div>
		                                    		</div>
		                                		</li>
		                                 		<li>
		                            				<span class="recipe_detail_icon_new">
		                                    			<span id="<?="made_".$recipe->id;?>" onclick="made(this)" style="cursor: pointer;">
		                                    				<? /* <img src="<?=base_url();?>public/frontend/images/made_1.png" alt="made" title="Made" /> */ ?>
		                                    				<i class="fa fa-cutlery"></i>
		                                        		</span>
		                                    		</span>
		                                    		<span class="recipe_detail_link_new">
		                                    			<span class="recipe_detail_link_txt">
		                                    				<span id="<?="made_".$recipe->id;?>" onclick="made(this)" title="Made" style="cursor: pointer;">
		                                    					Made <span id="madecount"><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>
	                                    					</span>
		                                				</span>
		                                    			<? /*  <span class="u1"><span id="madecount"><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span></span> */ ?>
		                                    		</span>
		                                		</li>
		                            		</ul>
		                            		<div class="both_clear"></div>
		                            		<p id=<?="notification_".$recipe->id;?>></p>
		                            	</div>

			                        	<div class="recipe_detail_userbox_2">
			                        		<ul class="well_custom">
			                            		<li>
			                                		<span class="recipe_detail_userbox_2_txt">Course</span>
			                                		<span class="recipe_detail_userbox_3_txt"><?=$coursename;?></span>
			                                	</li>
			                                	<li>
			                                		<span class="recipe_detail_userbox_2_txt">Method</span>
			                                		<span class="recipe_detail_userbox_3_txt"><?=$methodname;?></span>
			                                	</li>
			                                	<li>
			                                		<span class="recipe_detail_userbox_2_txt">Serves</span>
			                                    	<span class="recipe_detail_userbox_3_txt"><?=$recipe->serves;?></span>
			                                	</li>
			                                	<li>
			                                		<span class="recipe_detail_userbox_2_txt">Dish Type</span>
			                                    	<span class="recipe_detail_userbox_3_txt"><?=$typename;?></span>
			                                	</li>
			                                	<li>
			                                		<span class="recipe_detail_userbox_2_txt">Time</span>
			                                    	<span class="recipe_detail_userbox_3_txt"><?=$recipe->preparationtime;?></span>
			                                	</li>
			                                	<li>
			                                		<span class="recipe_detail_userbox_2_txt">Calories</span>
			                                		<span class="recipe_detail_userbox_3_txt"><?=$recipe->calories;?></span>
			                                	</li>
			                    			</ul>
			                        	</div>

			                        	<div class="recipe_box_slider">
			                        		<? /* <img src="<?=base_url();?>public/frontend/images/banner.jpg" alt="recipe-img"> */ ?>
			                        		<div id="myCarousel" class="carousel slide" style="margin: 0 auto;">
												<!-- Carousel slides -->
												<div class="carousel-inner">
													<?php $ismultipleimages = false; $images = ""; $imagefolder = "1004x400/"; //$imagefolder = "650x350/"; //$imagefolder = "275x198/"; ?>
													<?php if(isset($recipe)) { ?>
														<?php if($recipe->images != "") {
															$images = explode(",", $recipe->images);
															if(count($images)) { $i = 0;
																foreach ($images as $image) { ?>
																	<div <?=$i == 0 ? "class='active item'" : "class='item'"; ?>>
																		<a href="<?=base_url();?>public/frontend/images/recipe/<?=$image;?>" data-lightbox="roadtrip">
																			<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$image;?>" />
																		</a>
																	</div>
																<?php $i++; } ?>
															<?php } ?>
														<?php } else { ?>
															<div class="active item">
																<img src="<?=base_url();?>public/frontend/images/defaultrecipe.png" />
															</div>
														<?php } ?>
														<?php if(count($images) > 1) { $ismultipleimages = true; } ?>
													<?php } ?>
												</div>
												<?php if($ismultipleimages) { ?>
													<!-- Carousel nav -->
													<a class="carousel-control left" href="#myCarousel" data-slide="prev" style="margin-top: 5px;">‹</a>
													<a class="carousel-control right" href="#myCarousel" data-slide="next" style="margin-top: 5px;">›</a>
												<?php } ?>
											</div>
			                    		</div>

			                    		<?php $user = $this->crudmodel->getuserbyid($recipe->uid);
											$userimg = "defaultuser.jpg";
												if($user != "") {
													if($user->image != "") {
														$userimg = $user->image;
													}
												}
										?>

			                    		<div class="recipe_detail_user_detail">
			                        		<span class="recipe_detail_user_img">
			                        			<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>">
			                        				<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />
			                    				</a>
			                        		</span>
			                        		<span class="recipe_detail_user_txt">
			                        			<span class="recipe_detail_user_headtxt"><?=$recipe->title;?></span>
												<span class="recipe_txt_1">by
													<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>"><?=$user != "" ? $user->name : "user";?></a> in
			       										<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
			       									<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>
			                        			</span>
			                        		</span>
			                    		</div>

			                    		<?php if($recipe->video != "") { ?>
											<div class="recipe_detail_box">
				                    			<div class="recipe_detail_head">Video</div>
				                    			<div class="recipe_detail_video_box">
				                        			<? /* <a href="#">
				                            			<img src="<?=base_url();?>public/frontend/images/video_img.jpg" alt="video_img">
				                            		</a> */ ?>
				                            		<?=$recipe->video;?>
				                        		</div>
				                    		</div>
			                    		<?php } ?>

			                    		<?php if($recipe->ingredientdetails != "") { ?>
				                    		<div id="shopplingListLoading" class="recipe_detail_box">
				                    			<div class="recipe_detail_head">Ingredients</div>
				                        		<div class="recipe_detail_ingredients_box">
				                        			<input type="hidden" id="recipeid" name="recipeid" value="<?=$recipe->id;?>" />
				                        			<ul>
			                						 	<?php $ingredients = explode('|',$recipe->ingredientdetails); ?>
									 					<?php foreach($ingredients as $ingredient) { ?>
									 						<li>
									 							<span class="ingredients_chkbox">
			                        								<input type="checkbox" name="ingredientdetails[]" value="<?=$ingredient;?>" class="checkbox1" />
			                    								</span>
			                    								<span class="ingredients_chkbox_txt">
			                    									<?=$ingredient;?>
			                									</span>
			                    							</li>
			                            				<?php } ?>
				                            		</ul>
				                            		<span class="cart_sbt">
					                        			<input type="button" id="<?=$recipe->id;?>" class="btn btn-success btn_bg" name="addtocart" value="Add to shopping list" onclick="addToShoppingList(this.id)">
					                        			<input type="button" id="addMeal_btn" class="btn btn-success btn_bg" name="addtomeal" value="Add to Meal Planner"  data-toggle="modal" data-target="#addMeal">
					                        		</span>
					                        		<span id="shoppingNotfication"></span>
				                        		</div>
				                    		</div>

			                                <!-- Modal -->
			                                <div id="addMeal" class="modal fade" role="dialog">
			                                  <div class="modal-dialog">

			                                    <!-- Modal content-->
			                                    <div class="modal-content">
			                                     <form id="mealForm">
			                                      <div class="modal-header">
			                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
			                                        <h4 class="modal-title">Add To My Meal Planner</h4>
			                                      </div>
			                                      <div class="modal-body">
			                                            <div class="common_box">
									                    	<label class="common_height">Select Date:</label>
									                    	<input type="text" id="mealdate" name="date" class="input-small" />
									                    	<div id="mealRecipeErr" class="errmsg hideerr"></div>
									                    </div>
									                    <div class="common_box">
									                    	<label class="common_height">Price:</label>
									                    	<input type="text" id="price" class="marginbottom5" name="price" title="Approx. price ($)" placeholder="Approx. price ($)" />
									                    </div>

									                    <div class="common_box">
									                    	<input type="hidden" name="somekey" value="somekey" />
									                    	<input type="hidden" name="recipeid" value="<?=$recipe->id;?>" />
									                    	<input type="hidden" name="type" value="<?=$typename;?>" />
									                    	<? /*<input type="hidden" name="title" value="<?=$recipe->title;?>" />
									                    	<input type="hidden" name="isowner" value="" />*/ ?>
									                    	<div id="mealPriceErr" class="errmsg hideerr"></div>
									                    </div>
			                                      </div>
			                                      <div class="modal-footer">
			                                      	<input type="button" id="saveBtn" class="btn" value="Save" />
										        	<input type="button" id="cancelBtn" class="btn margin_left_15" value="Cancel" />
			                                      </div>
			                                      </form>
			                                    </div>

			                                  </div>
			                                </div>

			                    		<?php } ?>

			                    		<?php //echo "data: "; print_r($recipe); ?>

			                    		<?php if($recipe->preparationdetails != "") { ?>
			                    			<div class="recipe_detail_box">
			                    				<div class="recipe_detail_head">Description and How to Prepare</div>
			                        			<div class="recipe_detail_prepare_box">
				                    				<ol>
				                    					<?php if(strpos($recipe->preparationdetails, "\n") !== FALSE) { ?>
				                    						<?php $preparationdetails = explode("\n", $recipe->preparationdetails); ?>
				                    						<?php foreach($preparationdetails as $preparationdetail) { ?>
				                    							<?php if($preparationdetail != "") { ?>
				                    								<li><?=$preparationdetail;?></li>
			                    								<?php } ?>
			                    							<?php } ?>
			                    						<?php } else { ?>
			                    						<li><?=$recipe->preparationdetails;?></li>
			                    							<meta name="description" content="<?=$recipe->preparationdetails;?>">
			                							<?php } ?>
				                    				</ol>
			                					</div>
			                    			</div>
			                			<?php } ?>

			                    		<div class="recipe_detail_box">
			                    			<div class="recipe_detail_head">Rating</div>
			                        		<div id=<?="notificationloading_".$recipe->id;?> class="recipe_detail_prepare_box">
			                        			<span class="recipe_rating_txt">Rate this recipe</span>
			                            		<span class="recipe_rating_img_box">
			                            			<span class="ranking">
							            	 			<?=$rating;?>
							                			<?php $myrating = round($this->crudmodel->takerating($recipe->id));
														$graystars = 5-$myrating;
														$i = 0;
														$globalcount = 1;
														while($i < $myrating) { ?>
															<span>
																<? /* <img <?=($this->db_session->userdata("id")!='')? " style='cursor:pointer'' class='giverating' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' src="<?=base_url();?>public/frontend/images/green_star.png" alt="green_star"> */ ?>
																<i id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' class='fa fa-star green-rating giverating'></i>
															</span>
														<?php $i++; $globalcount++; }
														$i = 0;
														while($i < $graystars) { ?>
															<span>
																<? /* <img <?=($this->db_session->userdata("id")!='')? " style='cursor:pointer' class='giverating' ":''?> id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star"> */ ?>
																<i id='rt_<?=$globalcount;?>_<?=$recipe->id;?>' class='fa fa-star grey-rating giverating'></i>
															</span>
															<?php $i++; $globalcount++;
														} ?>
						            				</span>
							            			<span id=<?="ratingnotification_".$recipe->id;?>></span>
			                            		</span>
			                        		</div>
			                    		</div>

			                    		<div id="commentLoading" class="recipe_detail_box">
							            	<div class="recipe_detail_head">Comments & Reviews (<?=isset($commentscount) ? $commentscount : 0;?>)</div>
							                <div class="recipe_detail_prepare_box">
							                	<div id="comments">
								                	<?php if(isset($comments) && count($comments)) { ?>
							                			<?php foreach($comments as $comment) { ?>
							                				<?php $user = $this->crudmodel->getuserbycommentid($comment->id);
																$userimg = "defaultuser.jpg";
																if($user != "") {
																	if($user->image != "") {
																		$userimg = $user->image;
																	}
															} ?>
							                				<p class="comment2">
							                					<a href="<?=base_url();?>community/profile/<?=$user->user_name;?>">
																	<span class="user">
									                					<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" width="50" height="50" />
									            					</span>
								            					</a>
							                					<?=urldecode($comment->comment);?>
							                				</p>
							                			<?php } ?>
								                	<?php } ?>
							                	</div>
							                	<div id="comment">
						                			<textarea id="commentTxtArea" class="width600" name="comment" rows="2" placeholder="Type your comment"></textarea><br />
						                			<div id="commentErr" class="errmsg hideerr">Comment field is required.</div>
						                			<span class="errmsg"><?=form_error("comment");?><?php if(isset($commenterr)) { echo $commenterr; } ?></span>
						                			<span id="commentNotification"></span>
						                			<?php if(isset($recipe)) { ?>
						                				<input type="hidden" id="recipeid" name="recipeid" value="<?=$recipe->id;?>" />
					                				<?php } ?>
						                			<input type="button" class="btn btn-primary btn_bg" name="sbt_comment" value="Post" onclick="comment()" />
						                			<input type="reset" class="btn btn-primary btn_bg" name="clear" value="Clear" />
							                	</div>
							                </div>
							            </div>
			                		</div>

		                		<div class="col-md-3 recipe_detail_box_main">
		                			<div class="category_title">
		                				You may also like...
		                			</div>
		                			<div class="recipe_may_like">
		                				<?php //print_r($mayalsolike);?>
		                				<?php $imagefolder = "275x198/"; $ptr=0;?>
		                				<ul>
			                				<?php foreach($mayalsolike as $alsolikerecipe) { ?>
			                					<?php if($recipe->id == $alsolikerecipe->id || $ptr == 4) {
			                						//break;
			                					}else{?>
									        		<a target="_blank" href="<?=base_url();?>recipe/details/<?=$alsolikerecipe->seo;?>">
								        				<li title="<?=$alsolikerecipe->title;?>">
										            		<?php if($alsolikerecipe->images != "") {
																$images = explode(",", $alsolikerecipe->images); ?>
																<img src="<?=base_url();?>public/frontend/images/recipe/<?=$imagefolder.$images[0];?>" alt="<?=$alsolikerecipe->title;?>" />
															<?php } else { ?>
																<img src="<?=base_url();?>public/frontend/images/defaultrecipe.png" alt="<?=$alsolikerecipe->title;?>" />
															<?php } ?>
															<div>
																<?=$alsolikerecipe->title;?>
															</div>
														</li>
								         			</a>
							             			<?php $ptr++;
												} // end if
											} //end for ?>
							            </ul>
		                			</div>
		            			</div>

		            		</div>
	            		</div>

                    </div>
	            </div>
	   		</div>