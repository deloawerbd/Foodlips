<script>
	
	$("document").ready(function(){
		$(".giverating").click(function(){
			var myrating=$(this).attr("id");
			//alert(myrating);
			arr = myrating.split("_");
			var myrating2='';
			var recipeid='';
			//alert(arr);
			
	  		myrating2=arr["1"];	
	  	
	  		recipeid=arr["2"];	
			  	
			alert(myrating2);
			alert(recipeid);			
			 $.post('recipe/rate', {rating : myrating2,recipeid:recipeid}, function(data) {
			 				//alert(data);
						 	
						 		alert("Your rating saved successfully, Thank you !");
						 	
						 	
						}) 
			
		})
	})
</script>



 <?php 
 
	$this->db_session->userdata("name");
 
 ?>
    <div class="container">
    	<div class="row">
        	<div class="center">
            	<div class="span3 left_span_3">
                	<div class="recipe_left">
                    	<div class="category_txt">CATEGORIES</div>
                    	<ul>
                    		<?php if($catname==NULL) {
							?>
							<div>Catagory not found</div>
							<?php } else { ?>
							<?php foreach($catnames as $row) {
							?>
                        	<li><a class="<?=($row -> id == $this -> uri -> segment(3)) ? 'active_menu' : '' ?>" href="<?=base_url()?>recipe/categoryselected/<?=$row -> id; ?>" id="<?=$row -> id; ?>" onclick="<?=base_url()?>recipe/categoryselected"><?=$row -> name; ?></a></li>
                        	<?php } ?>
							<?php } ?>
                        </ul>
                    </div>
                    <div class="submit_recipes">
                    	<span class="submit_recipes_logo">
                   	    	<a href="#"><img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe"></a>
                        </span>
                        <span class="submit_recipes_txt">
                   	    	<a href="<?=base_url();?>recipe/submitrecipefirstpage">Submit Recipes</a>
                      </span>
                    </div>
                    <div class="admin_special">
                    	<span class="admin_special_txt">Admin Special</span>
                        <span class="admin_special_img">
                        	<a href="#">
                            	<img src="<?=base_url();?>public/frontend/images/special_img_1.jpg" alt="special_img">
                            </a>
                            <span class="admin_special_txt2">Southwest chiken </span>
							<span class="admin_special_txt2">chopped salad</span>
                        </span>
                    </div>
                    <div class="featured_member">
                    	<span class="admin_special_txt">Featured Member</span>
                        <span class="admin_special_img">
                        	<a href="#">
                           	<img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="featured_member"> </a>
                            <span class="featured_member_txt2">Monique</span>
							<span class="featured_member_txt3">Recipe Submitted: 99</span>
                            <span class="featured_member_txt3">Member Since: 14 Feb 2013</span>
                        </span>
                    </div>
                    <div class="advertisement">
                    	<span class="admin_special_txt">Advertisement</span>
                        
                    </div>
                </div>
                <div class="span7">
                
                	<div class="recipe_box_slider"><img src="<?=base_url();?>public/frontend/images/banner.jpg" alt="recipe-img">
                    
                    <div class="recipe_b_contain">
                	<div class="recipe_b_img"><img src="<?=base_url();?>public/frontend/images/banner_in_img.jpg" alt="cook"></div>
                    <div class="recipe_b_txt">
                    	<span class="recipe_b_txt_1"><a href="#">Pasta with Sun dried tomatos</a></span><br>
                        <span class="recipe_b_txt_2"><a href="#">Category Pizza/Pasta</a></span><br>
                        <span class="recipe_b_txt_3"><a href="#">Visitor Rating (4)</a> </span><br>
                    </div>
              </div>
                    
                    
                    </div>
                    <div class="dropdown_category">
                    	<div class="sorting btn-group">
    				<button class="btn login">
                    	
                    	Sort by > Top 10 Recipes
                    </button>
    				<button class="btn login dropdown-toggle" data-toggle="dropdown">
    				<span class="caret"></span>
    				</button>
    				<ul class="dropdown-menu action_my pull-left">
                    	<li><a href="#">Profile</a></li>
                        <li><a href="#">Setting</a></li>
                        <li><a href="#">Logout</a></li>
    				</ul>
    			</div>
                
                <div class="showingall btn-group">
    				<button class="btn login">
                    	
                    	Showing ><?php if(isset($catname)) echo $catname;?>
                    </button>
    				<button class="btn login dropdown-toggle" data-toggle="dropdown">
    				<span class="caret"></span>
    				</button>
    				<ul class="dropdown-menu action_my pull-left">
                    	<?php if($catname==NULL) {
							?>
							<div>Catagory not found</div>
							<?php } else { ?>
							<?php foreach($catnames as $row) {
							?>
                        	<li><a class="<?=($row -> id == $this -> uri -> segment(3)) ? 'active' : '' ?>" href="<?=base_url()?>recipe/categoryselected/<?=$row -> id; ?>" id="<?=$row -> id; ?>" ><?=$row -> name; ?></a></li>
                        	<?php } ?>
							<?php } ?>
                            <li><a href="#">Soups</a></li>
    				</ul>
    			</div>
                    </div>
                	<table width="100%" cellpadding="0" cellspacing="0" class="table table-hover" id="recipesdetails">
     				
     					<?php if($categories==NULL) {
						?>
						<div>
							Recipes not found
						</div>
						<tr class="border_none">
						<?php } else { ?>
						<?php foreach($categories as $row) { ?>
							
						<tr class="height_tr">
                        <td width="5">&nbsp;</td>
                        <td width="297" height="198"><a href="<?=base_url(); ?>recipe/details"> <img src="<?= base_url(); ?>public/frontend/images/<?=$row->images;?>"  width="297" height="198"/> </a></td>
                        <td width="5"></td>  
                        <td>
                        <span class="recipe_contain">
                        	<span class="recipe_img"><img src="<?=base_url();?>public/frontend/images/<?php if(isset($userimage)) echo $userimage; ?>" alt="recipe-img"></span>
                            <span class="recipe_txt_head">
                        		<a href="#"><?=$row -> title; ?></a>
                            </span><br>
							<span class="recipe_txt_1"> by <a href="#">Monique</a> in 
                           	<a href="#">Drinks,</a> 
                           	<a href="#">Smoothies</a>
                            </span>
                        <p class="post_detail_txt"><span class="seemore"><a href="#">See more</a></span></p>
                        <p class="post_detail_txt"><span class="seemore"><a href="#">Comment</a></span></p>
                        </span>
                        <span class="ranking"><?=$rating; ?>
                        	<?	
                        		$myrating=round($this->crudmodel->takerating($row->id));
                        		echo $myrating;
                        		
								$greystarts=5-$myrating;
                        		
								
								$i=0;
								$globalcount=1;
								while($i < $myrating){
									?>
										<span id= "1"><i  <?=($this->db_session->userdata("id")!='')? " ' class='fa fa-star green-rating giverating' ":''?> id='rt_<?=$globalcount;?>_<?=$row->id;?>'></i></span>
									
									<?
									$i++;
									$globalcount++;
								}
								
								$i=0;
								while($i < $greystarts){
									?>
										<span id= "1"><img  <?=($this->db_session->userdata("id")!='')? " style='cursor:pointer' class='giverating' ":''?> id='rt_<?=$globalcount;?>_<?=$row->id;?>' src="<?=base_url();?>public/frontend/images/gray_star.png" alt="green_star"></span>
									
									<?
									$i++;
									$globalcount++;
								}
								
                        	?>
                        	
                        	
                       
                        </span>
						<!--<span><a href="#" class="btn btn-success rpl_btnlink">Reply</a></span> -->
                        </td>
                         <td width="5">&nbsp;</td> 
                  		</tr>
                        <?php } ?>
						<?php } ?>
                
                       
                 
                      
            </table>
                </div>
               
            	
            </div>
        </div>
    </div>
    
     <!--       center end      -->   