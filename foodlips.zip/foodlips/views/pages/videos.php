		<script src="<?=base_url()?>public/frontend/anotherslider/js/jssor.js"></script>
		<script src="<?=base_url()?>public/frontend/anotherslider/js/jssor.slider.js"></script>
		<script src="<?=base_url()?>public/frontend/anotherslider/js/jssor.player.ytiframe.js"></script>
		
		<script>
        jssor_slider1_starter = function (containerId) {
            var options = {
                $AutoPlay: true,                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $DragOrientation: 3,                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)
                $AutoPlayInterval: 4000,            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $PauseOnHover: 3,                   //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, 4 freeze for desktop, 8 freeze for touch device, 12 freeze for desktop and touch device, default value is 1
                $ArrowKeyNavigation: true,   		//[Optional] Allows keyboard (arrow key) navigation or not, default value is false

                $BulletNavigatorOptions: {                //[Optional] Options to specify and enable navigator or not
                    $Class: $JssorBulletNavigator$,       //[Required] Class to create navigator instance
                    $ChanceToShow: 2,               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $ActionMode: 1,                 //[Optional] 0 None, 1 act by click, 2 act by mouse hover, 3 both, default value is 1
                    $AutoCenter: 1,                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1,                      //[Optional] Steps to go for each navigation request, default value is 1
                    $Lanes: 1,                      //[Optional] Specify lanes to arrange items, default value is 1
                    $SpacingX: 10,                   //[Optional] Horizontal space between each item in pixel, default value is 0
                    $SpacingY: 0,                   //[Optional] Vertical space between each item in pixel, default value is 0
                    $Orientation: 1                 //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
                }
            };

            var jssor_slider1 = new $JssorSlider$(containerId, options);

            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizes
            function ScaleSlider() {
                var parentWidth = jssor_slider1.$Elmt.parentNode.clientWidth;
                if (parentWidth)
                    jssor_slider1.$ScaleWidth(Math.min(parentWidth, 640));
                else
                    $Jssor$.$Delay(ScaleSlider, 30);
            }

            //Scale slider immediately
            ScaleSlider();
            //Scale slider after window load
            $Jssor$.$AddEvent(window, "load", ScaleSlider);

            $Jssor$.$AddEvent(window, "resize", $Jssor$.$WindowResizeFilter(window, ScaleSlider));
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            //responsive code end

            //fetch and initialize youtube players
            $JssorPlayer$.$FetchPlayers(document.body);
        };
   	 </script>

	<script>
	    $("document").ready(function() {
	        $(".admin_special").load("https://www.foodlips.com/blog/admin-special/");

	        /*$('.bxslider').bxSlider({
	        	//auto:true,
	        	video: true,
	        	useCSS: false
	        });*/
	       var username = $("#youtubeusername").val();
	       if(typeof username !== "undefined") {
	       		$("#frame").ytv({
	       			user: username,
		       		accent: "#d51c18"
		       	});
	       	}
	       	else {
	       		$("#frame").hide();
       		}
	    });
	</script>
	<style>
        /* jssor slider bullet navigator skin 03 css */
        /*
        .jssorb03 div           (normal)
        .jssorb03 div:hover     (normal mouseover)
        .jssorb03 .av           (active)
        .jssorb03 .av:hover     (active mouseover)
        .jssorb03 .dn           (mousedown)
        */
        .jssorb03 {
            position: absolute;
        }
        .jssorb03 div, .jssorb03 div:hover, .jssorb03 .av {
            position: absolute;
            /* size of bullet elment */
            width: 21px;
            height: 21px;
            text-align: center;
            line-height: 21px;
            color: white;
            font-size: 12px;
            background: url(<?=base_url()?>public/frontend/anotherslider/img/b03.png) no-repeat;
            overflow: hidden;
            cursor: pointer;
        }
        .jssorb03 div { background-position: -5px -4px; }
        .jssorb03 div:hover, .jssorb03 .av:hover { background-position: -35px -4px; }
        .jssorb03 .av { background-position: -65px -4px; }
        .jssorb03 .dn, .jssorb03 .dn:hover { background-position: -95px -4px; }
    </style>
            <input type="hidden" id="username" name="username" value="<?=$this->db_session->userdata("user_name");?>" />
			
			<div id="container" class="page_wrapper">
    			<div class="container-fluid">
        			<div class="row">
        				<!-- <div class="row">
        					<div class="span12">
        						<div id="frame" style="margin-bottom: 10px;"></div>
    						</div>
        				</div> -->
            			<div class="col-sm-4 col-md-3 left_recipe_home sidebar_left">
                			<div class="blog_sidebar">
                    			<div class="category_title">CATEGORIES</div>
                				<?php if(isset($categories) && count($categories)) { ?>
                    				<ul class="archives_link">
										<?php foreach($categories as $category) { ?>
                    						<li>
                    							<a <?php if(isset($categoryid)) { if($category->id == $categoryid) { echo "class='active_menu'"; } } ?> href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">
                    								<?=$category->name; ?>
                    							</a>
                							</li>
                    					<?php } ?>
                        			</ul>
                    			<?php } ?>
                			</div>
            				<div class="submit_recipes">
                				<span class="submit_recipes_logo">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					<img src="<?=base_url();?>public/frontend/images/logosubmit.png" alt="submit_recipe">
           	    					</a>
                    			</span>
                    			<span class="submit_recipes_txt">
               	    				<a href="<?=base_url();?>recipe/submitrecipe/recipe">
               	    					Submit Recipes
           	    					</a>
                  				</span>
                			</div>
                			
                			<div class="admin_special">
                			</div>
                			
                			<?php $featuredmember = $this->crudmodel->getfeaturedmember(); ?>
		                    <?php if(isset($featuredmember)) { ?>
		                    	<?php //echo "data: "; print_r($featuredmember); ?>
		                    	<?php $featuredmemberuser = $this->crudmodel->getuserbyid($featuredmember->uid); ?>
			                    <div class="featured_member">
			                    	<div class="category_title">Featured Member</div>
			                    	<?php
			                    		$userimg = "defaultuser.jpg";
										if($featuredmemberuser != "") {
											if($featuredmemberuser->image != "") {
												$userimg = $featuredmemberuser->image;
											}
										}
			                    	?>
			                        <div class="admin_special_img featured_member_cont">
			                        	<a class="featured_member_img" href="https://www.foodlips.com/community/profile/<?=$featuredmemberuser->user_name;?>">
			                           		<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$featuredmemberuser->name;?>" title="<?=$featuredmemberuser->name;?>" width="75" height="75" />
		                           		</a>
                                        <div class="featured_member_txt">
                                            <span class="featured_member_txt2"><?=$featuredmemberuser->name;?></span>
                                            <span class="featured_member_txt3">Recipe Submitted: <?=$this->crudmodel->getrecipecountbyuid($featuredmemberuser->id);?></span>
                                            <?php $date = explode(" ", $featuredmemberuser->created); ?>
                                            <span class="featured_member_txt3">Member Since: <?=$date[0];?></span>
                                        </div>
			                        </div>
			                    </div>
		                    <?php } ?>
            			</div>
            			
            			
                		<div class="col-sm-8 col-md-9">
                			<!--Video slider-->
                			<div class="recipe_box_slider">
                				<div id="sliderFrame">
        					<?php // echo "<pre>"; ?>
    						<?php //print_r($top5recipes);exit; ?>	
                			<div id="frame" style="margin-bottom: 10px; height: 415px;"></div>
                			<?php if(isset($top5recipes) && count($top5recipes)) { ?>
                				<div class="recipe_box_slider">
                						<div id="slider1_container" style="position: relative;width: 640px;height: 315px;">
												<div u="slides" id="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 640px; height: 315px;overflow: hidden;">
													
												    <!-- Slides Container -->
												    <?php foreach($top5recipes as $top5recipe){ ?>
												    	<?php if(!empty($top5recipe->video)){ ?>
												    	<div>
														    <div u="player" style="position: relative; top: 0px; left: 0px; width: 640px; height: 315px; overflow: hidden;">
														        <?= $top5recipe->video?>
														    </div>
													    </div>
													<?php } ?>
													<?php } ?>
											   </div>
												 <!--#region Bullet Navigator Skin Begin -->
												 <!-- Help: http://www.jssor.com/development/slider-with-bullet-navigator-jquery.html -->
						       
										        <!-- bullet navigator container -->
										        <div u="navigator" class="jssorb03" style="bottom: 6px; right: 6px;">
										            <!-- bullet navigator item prototype -->
										            <div u="prototype"><div u="numbertemplate"></div></div>
										        </div>
										        <!--#endregion Bullet Navigator Skin End -->
										</div>
                    			</div>
                    		<?php } ?>
                    		</div>
                			</div>
                    		<div class="dropdown_category">
                    			<div class="sorting btn-group">
    								<button class="btn login">
                    					Sort by > Top 10 Recipes
                    				</button>
    								<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<ul class="dropdown-menu action_my pull-left">
				                    	<?/* <li>
			                    			<a href="/">Item 1</a>
		                    			</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li>
				                        <li>
				                        	<a href="/">Item 3</a>
			                        	</li> */ ?>
    								</ul>
    							</div>
                				<div class="showingall btn-group">
    								<button class="btn login">
    									<?php $isselected = false; ?>
    									<?php if(isset($categories)) { ?>
    										<?php foreach($categories as $category) { ?>
    											<?php if($category->name == $this->uri->segment(3)) { ?>
    												<?=$category->name;?>
    												<?php $isselected = true; ?>
												<?php } ?> 
											<?php } ?>
										<?php } ?>
										<?php if(!$isselected) { ?>
                							Showing > All
            							<?php } ?>
                    				</button>
									<button class="btn login dropdown-toggle" data-toggle="dropdown">
    									<span class="caret"></span>
    								</button>
    								<?php if(isset($categories) && count($categories)) { ?>
    									<ul class="dropdown-menu action_my pull-left">
											<?php foreach($categories as $category) { ?>
                        						<li>
                        							<a class="<?=($category->name == $this->uri->segment(3)) ? 'active_menu' : '' ?>" href="<?=base_url()?>videos/category/<?=$category->name;?>" id="<?=$category->id;?>">
                        								<?=$category->name; ?>
                    								</a>
                								</li>
                        					<?php } ?>
                        					<li>
                        						<a href="<?=base_url()?>recipe/category/All">All</a>
                    						</li>
										</ul>
									<?php } ?>
    							</div>
                    		</div>
                    		
                    		<?php if(isset($pagination_links)) { ?>
                    			<div class="custom-pagination">
                    				<?=$pagination_links;?>
                    			</div>
                			<?php } ?>
                			
                    		<?php if($this->input->post("search")) { ?>
                    			<div class="search_for_box">
                                	<span class="search_head_txt">Search result for: </span>
                        			<span class="search_head_txt2"><?=$this->input->post("search");?></span>
                				</div>
                			<?php } else if(isset($advancesearchfor)) { ?>
            					<div class="search_for_box">
                                	<span class="search_head_txt">Search result for :</span>
                        			<span class="search_head_txt2"><?=$advancesearchfor;?></span>
                				</div>
            				<?php } ?>
                    		<?php if(isset($recipes) && count($recipes)) { ?>
                    			<div class="table video_post_table">
									<?php foreach($recipes as $recipe) { ?>
										<?php if($recipe->video != "") { ?>
                								<div class="video_post_table_row">
                        							<div class="video_post_left_cell">
                        								<div>
                        									<?=$recipe->video;?>
                        								</div>
                        							</div>
                        							<?php $user = $this->crudmodel->getuserbyid($recipe->uid);
														$userimg = "defaultuser.jpg";
														if($user != "") {
															if($user->image != "") {
																$userimg = $user->image;
															}
													} ?>
                        							<div id=<?="notificationloading_".$recipe->id;?> class="video_post_right_cell">
                            							<div class="video_post_avatar">
                       	    								<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>">
	                        									<img src="<?=base_url();?>public/frontend/images/user/<?=$userimg;?>" alt="<?=$user != '' ? $user->name : '';?>" title="<?=$user != '' ? $user->name : '';?>" />
	                    									</a> 
                            							</div>
                            							<?php $categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid); ?>
                            							<div class="video_post_text">
                            								<span class="recipe_txt_head2">
                                								<a href="<?=base_url();?>recipe/details/<?=$recipe->seo;?>">
                                									<?=$recipe->title;?>
                            									</a>
                            								</span><br />
                            								<span class="recipe_txt_1" style="min-height: 40px;"> by
                            									<a href="https://www.foodlips.com/community/profile/<?=$user->user_name;?>"><?=$user != "" ? $user->name : "user";?></a> in 
                       											<a href="<?=base_url()?>recipe/category/<?=$categoryname;?>"><?=$categoryname;?></a>
                        									</span>
                            								<? /* <span class="comment_vid">
                           	  									<a href="#">Comment 1</a>
                       	  									</span> */ ?>
                            								
                            								<div class="video_post_bottom_cont">
                                                            	<span class="ranking2">
                                                                    <span class="ranking-video">
                                                                        <?//=$rating;?>
                                                                        <?php $userrating = round($this->crudmodel->takerating($recipe->id));
                                                                        $greystarts = 5 - $userrating;
                                                                        $i = 0; $globalcount = 1;
                                                                        while($i < $userrating) { ?>
                                                                            <span class="small_star">
                                                                                <i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star green-rating giverating"></i>
                                                                            </span>
                                                                        <?php $i++; $globalcount++; }
                                                                        $i = 0;
                                                                        while($i < $greystarts) { ?>
                                                                            <span class="small_star">
                                                                                <i id="rt_<?=$globalcount;?>_<?=$recipe->id;?>" class="fa fa-star grey-rating giverating"></i>
                                                                            </span>
                                                                        <?php $i++; $globalcount++; } ?>
                                                                    </span>
                                                                </span>
                            									<?php /*<span id="<?="favorites_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="isloggedin(this)">*/?>
                            									<span id="<?="favorites_video_".$recipe->id;?>" class="btn_floteleft btn-group btn_floteleft1" onclick="addtofavorites(this)">
			                                						<span class="btn btn-mini btn-primary btn-group btn_bg">
											                            <span class="iconlike">
											                                <i class="fa fa-plus"></i>
											                            </span>
			                           
											                            <?php /*<span class="btn_chek dropdown-toggle btn_bg" <?=$this->db_session->userdata("id") != "" ? "data-toggle='dropdown'" : "";?>>
											                           	 	Add to favorite
			                                                            </span>*/?>
			                                                            <span class="btn_chek dropdown-toggle btn_bg">
											                           	 	Add to favorite
			                                                            </span>
			
			                            								<ul class="dropdown-menu">
			                            									<li>
												                        		<a href="<?=base_url();?>recipe/addbook">Create book</a>
											                        		</li>
											                        		<li class="divider"></li>
											                                <?php if(isset($books) && count($books) > 0) { ?>
				                    											<?php foreach($books as $book) { ?>
													                    			<li id="<?="book_".$book->id."_".$recipe->id;?>" onclick="addtobook(this)">
												                    					<a><span style="color: #000;"><?=$book->name;?></span></a>
											                    					</li>
										                    					<?php } ?>
											                        		<?php } ?>
			                           	 								</ul>
			                    									</span>
                        										</span>
				                        						<span id="<?="made_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="made(this)">
				                            						<span class="iconlike">
				                                						<i class="fa fa-coffee"></i>
				                        							</span>
				                    								I made this
				                    								<span class="add_like_no">(<span id=<?="madecount_".$recipe->id;?>><?=$this->crudmodel->getmadecountbyrecipeid($recipe->id);?></span>)</span>
				                        						</span>
				                        						<span id="<?="like_".$recipe->id;?>" class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="recipelike(this)">
				                        							<span class="iconlike">
				                            							<i class="fa fa-thumbs-up"></i>
				                        							</span>
				                        							Like
				                        							<span class="add_like_no">(<span id=<?="likecount_".$recipe->id;?>><?=$this->crudmodel->getlikecountbyrecipeid($recipe->id);?></span>)</span>
				                        						</span>
				                        						<span class="btn btn-mini btn-primary btn_floteleft1 btn_bg" onclick="window.location = '<?=base_url()."recipe/details/".$recipe->seo;?>';">
				                        							View recipe
				                        						</span>
                        										<span class="video_txt" id=<?="notification_".$recipe->id;?>></span>
																<span class="video_txt" id=<?="ratingnotification_".$recipe->id;?>></span>
                                								<? /* <span class="btn btn-mini btn-primary btn_floteleft1">
                                    								<span class="iconlike">
                                        								<img src="images/add_to_fab.png" alt="like_thumbs" />
                                    								</span>Add to favorite<!--<span class="add_like_no">20</span>-->
                                								</span>
                                								<span class="btn btn-mini btn-primary btn_floteleft1">
                                    								<span class="iconlike">
                                        								<img src="images/i_made.png" alt="like_thumbs" />
                                									</span>I made this<span class="add_like_no">20</span>
                                								</span>
                            									<span class="btn btn-mini btn-primary btn_floteleft1">
                                									<span class="iconlike">
                                    									<img src="images/like_thumbsup.png" alt="like_thumbs" />
                            										</span>Like<span class="add_like_no">20</span>
                                								</span> */ ?>
                                							</div>
                          								</div>
                        							</div>
                    							</div>
            							<?php } ?>
            						<?php } ?>
            						</div>
								<?php } else if($this->input->post("search") || isset($advancesearchfor)) { ?>
									<p class="notfound">No recipes found for your selection.</p>
								<?php } else { ?>
									<p class="notfound">No recipes present for selected category.</p>
								<?php } ?>
								
								<?php if(isset($pagination_links)) { ?>
									<div class="custom-pagination" style="margin-bottom: 10px">
										<?=$pagination_links;?>
									</div>
								<?php } ?>
            				</div>
        				</div>
    				</div>
    				<script>
				        jssor_slider1_starter('slider1_container');
				    </script>
				</div>
			</div>