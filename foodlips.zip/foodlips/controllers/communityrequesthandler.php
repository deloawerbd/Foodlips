<?php

	class Communityrequesthandler extends Controller {

		/**
		 * Just an constructor to initialize controller
		 */
		function Communityrequesthandler() {
			parent::Controller();
			$this->load->helper("url");
			$this->load->model("communitymodel");
		}

		/**
		 * This function is used to get user name.
		 */
		function getusername() {
			if($this->input->post("somekey") && $this->input->post("login") && $this->input->post("user_name")) {
				$response = array();

				$user_name = $this->input->post("user_name");

				if (strpos($user_name, "@") !== false) {
					$this->load->model("crudmodel");
					$user = $this->crudmodel->getuserbyemail($user_name);
					if(isset($user) && !empty($user)) {
						$temparr["msg"] = "success";
						$temparr["user_name"] = $user->user_name;
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "success";
					$temparr["user_name"] = $user->user_name;
				}

				array_push($response, $temparr);
				echo json_encode(array("user" => $response));
			}
		}

		/**
		 * This function is used to validate login.
		 */
		function isvalidlogin() {
			if($this->input->post("user_name") && $this->input->post("password") && $this->input->post("login")) {
				$response = array();

				$user_name = $this->input->post("user_name");
				$password = $this->_encode($this->input->post("password"));

				$where = array(
								"user_name" => $user_name,
								"password" => $password
							);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && !empty($user)) {
					$temparr["msg"] = "success";
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("login" => $response));
			}
		}

		/**
	 	* This function is used to do login for Recipe, Community, Restaurant, Wineries and Blog.
	 	*/
		function login() {
			if($this->input->post("somekey") && $this->input->post("login")) { ?>

			    <script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.7.2.min.js"></script>

				<?php $user_name = "";
				$password = $this->input->post("password");
				$siteurl = "https://www.foodlips.com/";

				if (strpos($this->input->post("user_name"), '@') !== false) {
					$this->load->model("crudmodel");
					$user = $this->crudmodel->getuserbyemail($this->input->post("user_name"));
					$user_name = $user->user_name;
				}
				else {
					$user_name = $this->input->post("user_name");
				} ?>


	        	<?php
					/**
				 	* COMMUNITY AND RECIPE LOGIN
				 	*/
				?>
		        <form id="recipe_loginform" method="post" action="<?=base_url();?>/auth/login" style="display: none;">
					<input type="text" name="user_name" value="<?=$user_name;?>" id="user_name" maxlength="30" size="30" />
					<input type="password" name="password" value="<?=$password;?>" id="password" maxlength="30" size="30" />
					<input type="submit" name="login" value="Login" id="login" class="submit" />
				</form>

				<?php
					/**
					 * BLOG LOGIN
					 */
				?>
		        <form id="blog_loginform" method="post" action="<?=$siteurl;?>blog/wp-login.php" name="loginform" style="display: none;">
					<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
					<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
					<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
					<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
					<input type="hidden" name="testcookie" value="1" />
				</form>

				<?php
				 	/**
					 * RESTAURANT LOGIN
					 */
				?>
				<form id="restaurant_loginform" method="post" action="<?=$siteurl;?>restaurants/wp-login.php" name="loginform" style="display: none;">
					<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
					<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
					<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
					<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
					<input type="hidden" name="testcookie" value="1" />
				</form>

				<?php
				 	/**
					 * WINERY LOGIN
					 */
				?>
				<form id="winery_loginform" method="post" action="<?=$siteurl;?>wineries/wp-login.php" name="loginform" style="display: none;">
					<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
					<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
					<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
					<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
					<input type="hidden" name="testcookie" value="1" />
				</form>


				<? /* <form name="loginwidgetform" id="loginwidgetform" action="#login_widget" method="post">
	       	 		<input name="widgetptype" value="login" type="hidden">
	       			<input name="log" id="widget_user_login" type="text">
	            	<input name="pwd" id="widget_user_pass" type="password">
	           		<input name="redirect_to" value="https://www.foodlips.com/recipes/" type="hidden">
					<input name="testcookie" value="1" type="hidden">
					<div class="form_row clearfix">
	        			<input name="submit" value="Sign In" class="b_signin" type="submit">
					</div>
				</form> */ ?>


		        <script type="text/javascript">
		            $("document").ready(function() {

	            		$.post("<?=base_url();?>auth/login", $("#recipe_loginform").serialize(),
							function(data) {
								//alert(data);
							})
							.error(function(err) { /*alert("Recipe Error occurred: " + err.responseText);*/ })
							.complete(function() {
								$.post("<?=$siteurl;?>blog/wp-login.php", $("#blog_loginform").serialize(),
								function(data) {
									//alert(data);
								})
								.error(function(err) { /*alert("Blog Error occurred: " + err.responseText);*/ })
								.complete(function() {
									$.post("<?=$siteurl;?>restaurants/wp-login.php", $("#restaurant_loginform").serialize(),
									function(data) {
										//alert(data);
									})
									.error(function(err) { /*alert("Restaurant Error occurred: "  + err.responseText);*/ })
									.complete(function() {
										$.post("<?=$siteurl;?>wineries/wp-login.php", $("#winery_loginform").serialize(),
										function(data) {
											//alert(data);
										})
										.error(function(err) { /*alert("Winery Error occurred: " + err.responseText);*/ })
										.complete(function() { });
									});
								});
							});
					});
		        </script>
    		<?php
			}
		}

		function isduplicateregistration() {
			if($this->input->post("user_name") && $this->input->post("email")) {

				$response = array();

				$user_name = $this->input->post("user_name");
				$email = $this->input->post("email");

				$where = array(
								"user_name" => $user_name
							);

				$user = $this->communitymodel->getuser($where);

				$temparr["isusernameexists"] = "false";
				$temparr["isemailexists"] = "false";
				$temparr["user"] = "new";

				if(isset($user) && !empty($user)) {
					$temparr["isusernameexists"] = "true";
					if($user->email == $email) {
						$temparr["isemailexists"] = "true";
					}

					$temparr["user"] = "exists";
				}

				if($temparr["isemailexists"] = "false") {
					$where = array(
								"email" => $email
							);

					$user = $this->communitymodel->getuser($where);
					if(isset($user) && !empty($user)) {
						$temparr["isemailexists"] = "true";
						$temparr["user"] = "exists";
					}
				}

				array_push($response, $temparr);
				echo json_encode(array("register" => $response));
			}
		}

		/**
		 * This function is used to share link on community.
		 */
		function share() {
			if($this->input->post("link")) {
				$response = array();

				$uid = $this->db_session->userdata("id");

				if(!empty($uid) && $uid > 0) {
					$link = $this->input->post("link");

					if(strpos($link, "://") == false || strpos($link, "http") == false || strpos($link, "https") == false) {
						$link = "http://".$link;
					}

					$where = array(
									"id" => $uid
								);
					$user = $this->communitymodel->getuser($where);

					if(!empty($user)) {

						$share = array(
										"uid" => $uid,
										"link" => $link,
										"date" => date("Y-m-d H:i:s")
									);

						if($this->communitymodel->addshare($share) > 0) {
							$info = array(
									"link" => $link
								);

							$activity = array(
												"uid" => $uid,
												"content" => $this->config->item("share_link"),
												"info" => serialize($info),
												"date" => date("Y-m-d H:i:s")
											);

							if($this->communitymodel->addactivity($activity) > 0) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "invalidaccount";
					}
				}
				else {
					$temparr["msg"] = "notloggedin";
				}

				array_push($response, $temparr);
				echo json_encode(array("share" => $response));
			}
		}

		/**
		 * This function is used to share link on community when user is already login.
		 */
		function sharesecond() {

            $response = array();

		    /* if (isset($_SERVER["HTTP_ORIGIN"])) {
                header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
            } */

            //"632277805f56af26ede8edc1b5cc2f63";
            $isorigin = false;
            if (isset($_SERVER["HTTP_ORIGIN"])) {
                $url = parse_url($_SERVER["REQUEST_URI"]);
                parse_str($url["query"], $query);

                if(isset($query) && is_array($query) && !empty($query)) {
                    if(isset($query["token"])) {
                        //$temparr["token"] = $query["token"];
                        if($query["token"] == "632277805f56af26ede8edc1b5cc2f63") {
                            $isorigin = true;
                            header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
                        }
                    }
                }
            }
            else {
               $isorigin = true;
            }

            if($isorigin) {
    			$uid = $this->db_session->userdata("id");

                if(empty($uid)) {
                    $this->load->model("communitymodel");
                    $where = array(
                                    "ip_address" => $_SERVER["REMOTE_ADDR"],
                                    "user_agent" => substr($_SERVER["HTTP_USER_AGENT"], 0, 50)
                                );

                    $wherenotin = array();
                    $wherenotin[] = "a:0:{}";
                    $wherenotin[] = "NULL";

                    $cisession = $this->communitymodel->getcisession($where, $wherenotin);
                    if(!empty($cisession)) {
                        if(!empty($cisession->session_data)) {
                            $userdata = unserialize($cisession->session_data);
                            if(is_array($userdata) && !empty($userdata)) {
                                if(isset($userdata["id"]) && $userdata["id"] > 0) {
                                    $uid = $userdata["id"];
                                }
                            }
                        }
                    }
                }

    			if(!empty($uid) && $uid > 0) {
    				if($this->uri->segment("2") == "share©") {
    				    $url = parse_url($_SERVER["REQUEST_URI"]);
                        parse_str($url["query"], $query);

    					//$link = explode("?",$_SERVER["REQUEST_URI"]);
    					if(isset($query) && is_array($query) && !empty($query)) {
    					    if(isset($query["u"])) {
        						//$link = preg_replace("/u=/", "", rawurldecode($link[1]), 1);
        						$link = $query["u"];

								if(strpos($link, "://") == false || strpos($link, "http") == false || strpos($link, "https") == false) {
									$link = "http://".$link;
								}

        						$where = array(
        										"id" => $uid
        									);
        						$user = $this->communitymodel->getuser($where);

        						if(!empty($user)) {

        							$share = array(
        											"uid" => $uid,
        											"link" => $link,
        											"date" => date("Y-m-d H:i:s")
        										);

        							if($this->communitymodel->addshare($share) > 0) {
        								$info = array(
                										"link" => $link
                									);

        								$activity = array(
        													"uid" => $uid,
        													"content" => $this->config->item("share_link"),
        													"info" => serialize($info),
        													"date" => date("Y-m-d H:i:s")
        												);

        								if($this->communitymodel->addactivity($activity) > 0) {
        									$temparr["msg"] = "success";
        								}
        								else {
        									$temparr["msg"] = "fail";
        								}
        							}
        							else {
        								$temparr["msg"] = "fail";
        							}
    							}
                                else {
                                    $temparr["msg"] = "fail";
                                }
    						}
    						else {
    							$temparr["msg"] = "invalidaccount";
    						}
    					}
    					else {
    						$temparr["msg"] = "fail";
    					}
    				}
    				else {
    					$temparr["msg"] = "fail";
    				}
    			}
    			else {
    			    $temparr["msg"] = "notloggedin";
    			}
			}
            else {
                $temparr["msg"] = "notauthorised";
            }

			array_push($response, $temparr);
			echo json_encode(array("sharesecond" => $response));
		}

		function _encode($password) {
			$this->CI=& get_instance();
			$majorsalt = null;
			// if you set your encryption key let's use it
	  		if ($this->CI->config->item("encryption_key") != "") {
				// conctenates the encryption key and the password
				$_password = $this->CI->config->item("encryption_key").$password;
			}
			else {
				$_password = $password;
			}

			// if PHP5
			if (function_exists("str_split")) {
			    $_pass = str_split($_password);
			}
			// if PHP4
			else {
				$_pass = array();
		    	if (is_string($_password)) {
		    		for ($i = 0; $i < strlen($_password); $i++) {
		        		array_push($_pass, $_password[$i]);
		        	}
		     	}
			}

			// encrypts every single letter of the password
			foreach ($_pass as $_hashpass) {
				$majorsalt .= md5($_hashpass);
			}

	        // encrypts the string combinations of every single encrypted letter
	        // and finally returns the encrypted password
			return $password = md5($majorsalt);
	  	}

		/**
		 * This function is used to enable or disable profile wall
		 */
		function enabledisableprofilewall() {
			if($this->input->post("somekey") && $this->input->post("somekey") != "" && $this->input->post("personalmessagesvalue")) {
				$response = array();

				$personalmessagesvalue = $this->input->post("personalmessagesvalue");
				$uid = $this->db_session->userdata("id");

				$where = array(
								"id" => $uid
							);
				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {
					$where = array(
								"uid" => $uid
							);

					$settings = $this->communitymodel->getsettings($where);

					$personalmessages = "1";

					if($personalmessagesvalue == "false") {
						$personalmessages = "0";
					}

					if(isset($settings) && $settings != "") {
						// update setting

						$setting = array(
										"personalmessages" => $personalmessages
									);

						if($this->communitymodel->updatesettings($setting, $where)) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						// insert setting

						$setting = array(
										"uid" => $uid,
										"personalmessages" => $personalmessages
									);

						if($this->communitymodel->addsettings($setting) > 0) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}

					array_push($response, $temparr);
				}
				else {
					$temparr["msg"] = "usernotfound";
					array_push($response, $temparr);
				}

				echo json_encode(array("profilewall" => $response));
			}
		}

		/**
		 * This function is used to get latest news feeds.
		 */
		/* function newsfeed() {
			if($this->input->post("somekey") && $this->input->post("somekey") != "") {

				$response = array();
				//$wherein = array();
				$uid = $this->db_session->userdata("id");

				$followers = $this->communitymodel->getalluserfollowers($uid);
				if(isset($followers) && $followers != "") {
					$followers = unserialize($followers->followers);
				}

				$followings = $this->communitymodel->getalluserfollowings($uid);
				if(isset($followings) && $followings != ""){
					$followings = unserialize($followings->following);
				}

				$where = array("uid"=>$uid);
				$contacts = $this->communitymodel->getcontact($where);
				if(isset($contacts) && $contacts != ""){
					$contacts = unserialize($contacts->friends);
				}

				$result = array_merge($followers,$followings,$contacts);

				$newsfeeds = $this->communitymodel->getunnotifiedactivities($result);

				if(isset($newsfeeds) && $newsfeeds != "") {
					foreach($newsfeeds as $newsfeed) {
						$temparr["id"] = $newsfeed->id;
						$temparr["uid"] = $newsfeed->uid;

						$userimg = "noavatar.png";
						$temparr["name"] = "";
						$temparr["user_name"] = "";

						$where = array(
							"id" => $newsfeed->uid
						);
						$user = $this->communitymodel->getuser($where);
						if(isset($user) && $user != "") {
							$temparr["name"] = $user->user_name;
                            if(!empty($user->name)) {
                               $temparr["name"] = $user->name;
                            }
							$temparr["user_name"] = $user->user_name;

							if($user->image != "") {
								$userimg = $user->image;
							}
						}
						$temparr["image"] = $userimg;
						$temparr["hide"] = $newsfeed->hide;
						//$temparr["content"] = $newsfeed->content;
						$temparr["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
						$temparr["timeago"] = $this->_timeago($newsfeed->date);
						$temparr["msg"] = "success";

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nonews";
					array_push($response, $temparr);
				}

				echo json_encode(array("newsfeeds" => $response, "friendrequests" => $this->_getfriendrequests(), "messages" => $this->_getmessages(), "notifications" => $this->_getnotifications()));
			}
		} */

		/**
		 * This function is used to get latest news feeds.
		 * created on 3 aug 2013
		 */
		function newsfeed() {
			if($this->input->post("somekey") && $this->input->post("somekey") != "") {

					$response = array();
					//$wherein = array();
					$uid = $this->db_session->userdata("id");

					$followers = $this->communitymodel->getalluserfollowers($uid);
					if(!empty($followers)) {
						$followers = unserialize($followers->followers);
					}

					$followings = $this->communitymodel->getalluserfollowings($uid);
					if(!empty($followings)) {
						$followings = unserialize($followings->following);
					}

					$where = array("uid"=>$uid);
					$contacts = $this->communitymodel->getcontact($where);
					if(!empty($contacts)) {
						$contacts = unserialize($contacts->friends);
					}

					if(!empty($followers) && !empty($followings) && !empty($contacts)) {
						$result = array_merge($followers, $followings, $contacts);
						$newsfeeds = $this->communitymodel->getunnotifiedactivities($result);
					}

					if(isset($newsfeeds) && $newsfeeds != "") {
						foreach($newsfeeds as $newsfeed) {
							$temparr["id"] = $newsfeed->id;
							$temparr["uid"] = $newsfeed->uid;

							$userimg = "noavatar.png";
							$temparr["name"] = "";
							$temparr["user_name"] = "";

							$where = array(
								"id" => $newsfeed->uid
							);
							$user = $this->communitymodel->getuser($where);
							if(isset($user) && $user != "") {
								$temparr["userid"] = $user->id;
								$temparr["name"] = $user->user_name;
	                            if(!empty($user->name)) {
	                               $temparr["name"] = $user->name;
	                            }
								$temparr["user_name"] = $user->user_name;

								if($user->image != "") {
									$userimg = $user->image;
								}
							}
							$temparr["image"] = $userimg;
							$temparr["hide"] = $newsfeed->hide;
							//$temparr["content"] = $newsfeed->content;
							$temparr["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
							$temparr["timeago"] = $this->_timeago($newsfeed->date);

							$temparr["likecount"] = $this->communitymodel->getlikecountsbyaid($newsfeed->id);

							$where = array(
											"aid" => $newsfeed->id
										);
							$communitycomments = $this->communitymodel->getcommunitycomments($where);
							if(isset($communitycomments) && $communitycomments != "") {
								foreach ($communitycomments as $communitycomment) {

									$where = array(
										"id" => $communitycomment->uid
									);
									$commentuser = $this->communitymodel->getuser($where);
									$cmtuserimg = "noavatar.png";
									if(!empty($commentuser)) {
									    $temparr["commentuname"] = $commentuser->user_name;
	                                    if(!empty($commentuser->name)) {
	                                        $temparr["commentuname"] = $commentuser->name;
	                                    }
										$temparr["commentuser_name"] = $commentuser->user_name;

										if($commentuser->image != "") {
											$cmtuserimg = $commentuser->image;
										}
									}

									$temparr["commentuimage"] = $cmtuserimg;
									$temparr["commentcontent"] = urldecode($communitycomment->comment);
									$temparr["commenttimeago"] = $this->_timeago($communitycomment->date);
								}
							}

							$temparr["msg"] = "success";

							array_push($response, $temparr);

							//$wherein[] = $newsfeed->id;

							/* $activity = array(
											"isnotified" => "1"
										);
							$where = array(
											"id" => $newsfeed->id
										);
							$this->communitymodel->updateactivity($activity, $where); */
						}

						/* if(isset($wherein) && $wherein != "") {
							$activity = array(
											"isnotified" => "1"
										);
							$this->communitymodel->updateactivities($activity, $wherein);
						} */
					}
					else {
						$temparr["msg"] = "nonews";
						array_push($response, $temparr);
					}
					echo json_encode(array("newsfeeds" => $response, "friendrequests" => $this->_getfriendrequests(), "messages" => $this->_getmessages(), "notifications" => $this->_getnotifications()));
			}
		}

		/**
		 * function is used to get updates without newsfeeds activities
		 */
		function notifications() {
			if($this->input->post("somekey") && $this->input->post("somekey") != "") {
				$response = array();
				echo json_encode(array("friendrequests" => $this->_getfriendrequests(), "messages" => $this->_getmessages(), "notifications" => $this->_getnotifications()));
			}
		}

		/**
		 * function is used to get newsfeeds 10 records each time click on viewmore likn
		 */
		 function viewmorenewsfeed() {
		 	if($this->input->post("offset") && $this->input->post("offset") != "") {
		 		$response = array();

				//$wherein = array();
				$uid = $this->db_session->userdata("id");

				$followers = $this->communitymodel->getalluserfollowers($uid);
				if(isset($followers) && $followers != "") {
					$followers = unserialize($followers->followers);
				}

				$followings = $this->communitymodel->getalluserfollowings($uid);
				if(isset($followings) && $followings != ""){
					$followings = unserialize($followings->following);
				}
				$where = array("uid"=>$uid);

				$contacts = $this->communitymodel->getcontact($where);
				if(isset($contacts) && $contacts != ""){
					$contacts = unserialize($contacts->friends);
				}

				$result = array();
				if(is_array($contacts))
				{
					$result = $contacts;
				}else if(is_array($followings)){
					$result = array_merge($result,$followings);
				}else if(is_array($followers)){
					$result = array_merge($result,$followers);
				}
				//$result = array_unique($result);
				$start = $this->input->post("offset");

				$newsfeeds = $this->communitymodel->getlatestactivitiesbyuserwherein($result,$start);
				//$newnewsfeeds = array();

				//$newsfeeds = $this->communitymodel->getunnotifiedactivities($result);

				if(isset($newsfeeds) && $newsfeeds != "") {
					foreach($newsfeeds as $newsfeed) {
						$temparr["id"] = $newsfeed->id;
						$temparr["uid"] = $newsfeed->uid;

						$userimg = "noavatar.png";
						$temparr["name"] = "";
						$temparr["user_name"] = "";

						$where = array(
							"id" => $newsfeed->uid
						);
						$user = $this->communitymodel->getuser($where);
						if(isset($user) && $user != "") {
							$temparr["userid"] = $user->id;
							$temparr["name"] = $user->user_name;
                            if(!empty($user->name)) {
                               $temparr["name"] = $user->name;
                            }
							$temparr["user_name"] = $user->user_name;

							if($user->image != "") {
								$userimg = $user->image;
							}
						}
						$temparr["image"] = $userimg;
						$temparr["hide"] = $newsfeed->hide;
						//$temparr["content"] = $newsfeed->content;
						$temparr["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
						$temparr["timeago"] = $this->_timeago($newsfeed->date);

						$temparr["likecount"] = $this->communitymodel->getlikecountsbyaid($newsfeed->id);

						$where = array(
										"aid" => $newsfeed->id
									);
						$communitycomments = $this->communitymodel->getcommunitycomments($where);
						if(isset($communitycomments) && $communitycomments != "") {
							foreach ($communitycomments as $communitycomment) {

								$where = array(
									"id" => $communitycomment->uid
								);
								$commentuser = $this->communitymodel->getuser($where);
								$cmtuserimg = "noavatar.png";
								if(isset($commentuser) && $commentuser != "") {

									$temparr["commentuname"] = $commentuser->name;
									$temparr["commentuser_name"] = $commentuser->user_name;

									if($commentuser->image != "") {
										$cmtuserimg = $commentuser->image;
									}
								}

								$temparr["commentuimage"] = $cmtuserimg;
								$temparr["commentcontent"] = urldecode($communitycomment->comment);
								$temparr["commenttimeago"] = $this->_timeago($communitycomment->date);
							}
						}

						$temparr["msg"] = "success";

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nonews";
					array_push($response, $temparr);
				}
				echo json_encode(array("newsfeeds" => $response));
			}
		 }

		/**
		 * This function is used to get friend requests.
		 */
		function _getfriendrequests() {

			if($this->input->post("somekey") && $this->input->post("somekey") != "") {

				$response = array();

				$where = array(
							"uid" => $this->db_session->userdata("id")
						);
				$friendrequest = $this->communitymodel->getfriendrequests($where);

				if(isset($friendrequest) && $friendrequest != "") {

					$temparr["id"] = $friendrequest->id;
					$temparr["uid"] = $friendrequest->uid;

					$requests = unserialize($friendrequest->requests);

					if($friendrequest->requests != "") {
						$requests = unserialize($friendrequest->requests);

						if(count($requests) > 0) {
							foreach($requests as $requestinguid) {
								$temparr["name"] = "";
								$temparr["user_name"] = "";
								$userimg = "noavatar.png";

								$where = array(
									"id" => $requestinguid
								);
								$user = $this->communitymodel->getuser($where);
								if(isset($user) && $user != "") {
								    $temparr["name"] = $user->user_name;
                                    if(!empty($user->name)) {
									   $temparr["name"] = $user->name;
                                    }

									$temparr["user_name"] = $user->user_name;

									if($user->image != "") {
										$userimg = $user->image;
									}
								}

								$temparr["image"] = $userimg;

								$temparr["msg"] = "success";

								array_push($response, $temparr);
							}
						}
						else {
							$temparr["msg"] = "nofriendrequests";
							array_push($response, $temparr);
						}
					}
					else {
						$temparr["msg"] = "nofriendrequests";
						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nofriendrequests";
					array_push($response, $temparr);
				}

				//echo json_encode(array("friendrequests" => $response));
				return $response;
			}
		}

		/**
		 * This function is used to get personal messages.
		 */
		function _getmessages() {

			if($this->input->post("somekey") && $this->input->post("somekey") != "") {

				$response = array();

				$where = array(
								"ownerid" => $this->db_session->userdata("id"),
								"isnotified" => "0"
							);

				$messages = $this->communitymodel->getmessages($where);

				if(isset($messages) && $messages != "") {

					$messagescnt = count($messages);
					$nomessagescnt = 0;

					foreach($messages as $message) {

						$messagetext = $message->message;

						if(!empty($messagetext)) {

							$temparr["id"] = $message->id;
							$temparr["ownerid"] = $message->ownerid;
							$temparr["uid"] = $message->uid;
							$temparr["message"] = substr($message->message, 0, 30);

							$temparr["name"] = "";
							$temparr["user_name"] = "";
							$userimg = "noavatar.png";

							$where = array(
								"id" => $message->uid
							);
							$user = $this->communitymodel->getuser($where);
							if(isset($user) && $user != "") {
								$temparr["name"] = $user->user_name;
                                if(!empty($user->name)) {
                                   $temparr["name"] = $user->name;
                                }
								$temparr["user_name"] = $user->user_name;

								if($user->image != "") {
									$userimg = $user->image;
								}
							}

							$temparr["image"] = $userimg;

							$temparr["msg"] = "success";

							array_push($response, $temparr);
						}
						else {
							$nomessagescnt++;
						}
					}
					if($messagescnt == $nomessagescnt) {
						$temparr["msg"] = "nomessages";
						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nomessages";
					array_push($response, $temparr);
				}

				return $response;
			}
		}

		/**
		 * This function is used to get notifications.
		 */
		function _getnotifications() {

			if($this->input->post("somekey") && $this->input->post("somekey") != "") {

				$response = array();
				$where = array(
							"uid" => $this->db_session->userdata("id"),
							"isnotified" => "0"
							);

				$notifications = $this->communitymodel->getnotification($where);

				if(isset($notifications) && $notifications != "") {

					foreach($notifications as $notification) {

						$temparr["id"] = $notification->id;
						$temparr["uid"] = $notification->uid;
						$temparr["content"] = $notification->content;

						$info = unserialize($notification->info);
						$temparr["gname"] = $info["gname"];
						$temparr["gid"] = $info["gid"];
						$temparr["gseo"] = $info["gseo"];
						$temparr["gmember"] = $info["gmember"];
						if($notification->content=="Meet Invitation")
						{
							$scr = base_url()."public/frontend/images/Groups-Meeting-Dark-icon.png";
							if($info["groupimage"]!='')
							{
								$scr = base_url()."public/frontend/images/meet/50x50/".$info["groupimage"];
							}
							$temparr["groupimage"] = $scr;
						}else {
							$temparr["groupimage"] = $info["groupimage"];
						}

						if($notification->content=="Joined group"){
							$user = $this->communitymodel->getuser(array("id" =>$info["gmember"]));
							$temparr["name"] = $user->name;
							$temparr["uname"] = $user->user_name;
							$temparr["uimg"] = $user->image;
						}
						$temparr["groupowner"] = $info["groupowner"];
						$temparr["user_name"] = $info["user_name"];

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nonotifications";
					array_push($response, $temparr);
				}

				return $response;
			}
        }

		/**
		 * function is used to seprate url for the given text and return url with anchor tag as well as remainning string as it is
		 * @param $text text string containing url
		 */
		function _separateurl($text) {
		  	$reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
			if(preg_match($reg_exUrl, $text, $url)) {
				return preg_replace($reg_exUrl, "<a href=".$url[0]." target='_blanck' class='livepreview' >$url[0]</a> ", $text);
			} else {
				return $text;
			}
		}
		function _seturlimage($link="") {
	        //return base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png";
	        if(strpos($link, "://") !== false || strpos($link, "http") !== false || strpos($link, "https") !== false) {
	            //echo "</br>1";
	            //echo "</br>link: ".$link;
	            if(strpos($link, "http") == 0) {
	                //echo "</br>2<pre>";
	                $contents = @file_get_contents($link);
	                //var_dump($http_response_header);
	                if(isset($http_response_header) && !empty($http_response_header)) {
	                    if(strpos($http_response_header[0], "404") == false || strpos($http_response_header[0], "302") == false) {
	                        //echo "</br>if";
	                        //exit();
	                        //echo "</br>3";
	                        //$file = fopen($link, "r");
	                        //$link = "https://www.foodlips.com/recipes/recipe/";
	                        $ch = curl_init();
	                        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	                        curl_setopt($ch, CURLOPT_URL, $link);
	                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	                        /* $result = curl_exec($ch);
	                        if ( $result==false ) {
	                        echo curl_errno($ch).' '.curl_error($ch);
	                        } */
	                        $file = curl_exec($ch);
	                        //$link = "https://www.foodlips.com/recipes/recipe/";
	                        //echo "</br>link: $link </br>file: ".$file; exit();
	                        //echo "link: ".$link; exit();
	                        curl_close($ch);
	                        //exit();
	                        if(!empty($file)) {
	                            //echo "</br>4"; exit();
	                            //while (!feof($file)) {
	                            foreach(preg_split("/((\r?\n)|(\r\n?))/", $file) as $line) {
	                                //echo "</br>line: ".$line;
	                                //$line = fgets ($file, 1024);
	                                if (preg_match ("/<img[^>]+>/i", $line, $out)) {
	                                    if(strpos($link, "recipe") !== false || strpos($link, "community") !== false || strpos($link, "recipes") !== false ) {
	                                        if(preg_match('@src="([^"]+)"@', $out[0], $match)) {
	                                            $imgsrc = substr($match[0], 5, -1);
	                                        }
	                                        elseif(preg_match("@src='([^']+)'@", $out[0], $match)) {
	                                            $imgsrc = substr($match[0], 5, -1);
	                                        }

	                                        if(strpos($imgsrc, "frontend/images/recipe/650x350/") !== false || strpos($imgsrc, "frontend/images/recipe/1004x400/") !== false ||
	                                            strpos($imgsrc, "frontend/images/group/200x200/") !== false || strpos($imgsrc, "frontend/images/user/250x250/") !== false) {
	                                            break;
	                                        }
	                                        else {
	                                            $imgsrc = "";
	                                        }
	                                    }
	                                    else {
	                                        if(preg_match('@src="([^"]+)"@', $out[0], $match)) {
	                                            $imgsrc = substr($match[0], 5, -1);
	                                        }
	                                        elseif(preg_match("@src='([^']+)'@", $out[0], $match)) {
	                                            $imgsrc = substr($match[0], 5, -1);
	                                        }
	                                        //echo "</br>src: ".$imgsrc;
	                                        //break;
	                                        //$file = fopen($imgsrc, "r");
	                                        if(!empty($imgsrc)) {
	                                            break;
	                                        }
	                                    }
	                                }
	                            }
	                            //fclose($file);
	                        }
	                        else {
	                            /* echo "</br>else";
	                            exit(); */
	                        }
	                    }
	                    else {
	                        //echo "</br>else";
	                        //exit();
	                    }
	                }
	                else {
	                    //echo "</br>else";
	                    //exit();
	                }
	            }
	        }
	        /* else {
	        $reg_exUrl = "/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
	        if(preg_match($reg_exUrl, $link, $url)) {
	        $file = fopen ("http://".$url[0], "r");
	        }
	        else {
	        return "";
	        }
	        } */

	        if(isset($imgsrc) && !empty($imgsrc)) {
	            return $imgsrc;
	        }

	        //return base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png";
	        return base_url()."public/frontend/images/recipe/275x198/preview-not-available.jpg";
	    }

		/**
		 * This function is used to get activity in format.
		 * @param $uid, the user of actitivity.
		 * @param $content, the content of actitivity to be formatted.
		 * @param $info, the information of actitivity done.
		 * @return $activity, formatted activity.
		 * Note : data-lightbox attribute are used in anchor tag for showing image in pop-up window
		 */
		function _getactivitycontent($uid, $content, $info) {
			$activity = "";

			if(isset($uid) && $uid != "" && isset($content) && $content != "" && isset($info) && $info != "") {
				$info = unserialize($info);
				$this->load->model("crudmodel");

				if($content == $this->config->item("new_group")) {
					$activity = "Created group <br /> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}
				else if($content == $this->config->item("group_join")) {
					$activity = "Joined group <br /> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}
				else if($content == $this->config->item("group_wall_post")) {
					$activity = "Posted on </br> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a> wall.";
				}
				else if($content == $this->config->item("new_question")) {
					$activity = "Asked new question </br> <a href='".base_url()."community/question/".$info["gseo"]."'>".$info["question"]."</a> </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}
				else if($content == $this->config->item("reply_on_question")) {
					$activity = "Replied on question </br> <a href='".base_url()."community/question/".$info["qseo"]."'>".$info["question"]."</a> </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}
				else if($content == $this->config->item("are_now_friends")) {
					//$activity = "<a href='".base_url()."community/profile/".$info["acceptinguser_username"]."'>".$info["acceptinguser_name"]."</a>".""." and <a href='".base_url()."community/profile/".$info["requestinguser_username"]."'>".$info["requestinguser_name"]."</a> are now friends.";
					$activity = " and <a href='".base_url()."community/profile/".$info["requestinguser_username"]."'>".$info["requestinguser_name"]."</a> are now friends.";
				}
				else if($content == $this->config->item("new_poll")) {
					$activity = "</br> Submitted poll under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}
				else if($content == $this->config->item("recipe_like")) {
					$recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
					//$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
					//$activity = " Like <a href='".base_url()."recipe/details/".$categoryname."/".$recipe->title."'>".$recipe->title."</a>";
					if(!empty($recipe)) {
	                    $activity = "Like recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
	                    if($recipe->images != "") {
	                        $images = explode(",", $recipe->images);
	                        if(count($images)) {
	                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {

	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                            else {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                        }
	                    }
	                    else {
	                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
	                        $activity .= "</a>";
	                    }
	                }
				}
				else if($content == $this->config->item("recipe_made")) {
	                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
	                if(!empty($recipe)) {
	                    $activity = "Made recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
	                    if($recipe->images != "") {
	                        $images = explode(",", $recipe->images);
	                        if(count($images)) {
	                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {

	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                            else {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                        }
	                    }
	                    else {
	                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
	                        $activity .= "</a>";
	                    }
	                }
	            }
	            else if($content == $this->config->item("recipe_favorite")) {
	                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
	                if(!empty($recipe)) {
	                    $activity = "Favorite recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
	                    if($recipe->images != "") {
	                        $images = explode(",", $recipe->images);
	                        if(count($images)) {
	                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
									$activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                            else {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                        }
	                    }
	                    else {
	                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
	                        $activity .= "</a>";
	                    }
	                }
	            }
				else if($content == $this->config->item("recipe_comment")) {
	                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
	                if(!empty($recipe)) {
	                    $activity = "Commented on </br> <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
	                    if($recipe->images != "") {
	                        $images = explode(",", $recipe->images);
	                        if(count($images)) {
	                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                            else {
	                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
									$activity .= "</a>";
	                            }
	                        }
	                    }
	                }
	            }
	            else if($content == $this->config->item("recipe_submitted")) {
	                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
	                if(!empty($recipe)) {
	                    if($recipe->approved == "1") {
	                        $activity = "Submitted recipe </br> <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
	                        if($recipe->images != "") {
	                            $images = explode(",", $recipe->images);
	                            if(count($images)) {
	                                if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
	                                	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
	                                    $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
										$activity .= "</a>";
	                                }
	                                else {
	                                	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
	                                    $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title' style='width: 250px; height: 250px;' </br>";
										$activity .= "</a>";
	                                }
	                            }
	                        }
	                    }
	                }
	            }
				else if($content == $this->config->item("comment_on_activity")) {
					if($uid == $info["uid"]) {
						/**
						 * TODO
						 * Check if user is male or female and accordingly use 'his' or 'her' word in notification
						 */
						$activity = "Commented on his activity.";
					}
					else {
						$activity = "Commented on <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["name"]."'s</a> activity.";
					}
				}
				else if($content == $this->config->item("share_link")) {
					if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
						$src = $this->_seturlimage($info["link"]);
						$activity = "Shared <a href='".$info["link"]."'>link</a> ";
						if(!empty($src)) {
							$activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50'></a></br>";
						}
					}
				}

				/*else if($content == $this->config->item("share_link")) {
					$activity = "Shared <a href='".$info["link"]."'>Link</a>";
				}*/

				// "profileowner_id" => $profileowner->id,
				// "profileowner_uname" => $profileowner->user_name,
				// "profileowner_name" => $profileowner->name,
				// "uid" => $uid,
				// "uname" => $user->user_name,
				// "name" => $user->name,
				// "aid" => $aid,
				// "comment" => $comment
				else if($content == $this->config->item("comment_on_groupwallpost")) {
					$activity = "Commented on </br>".$info["message"]." </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
				}

				else if($content == $this->config->item("profile_wall_post")) {
					if($uid == $info["uid"]) {
						//echo $this->_separateurl($info["status"]);
						if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
							//$exlink = preg_replace('/(https?|ssh|ftp):\/\/[^\s"]+/','<br /><a href="$0" target="_blank" style="color: #A90101;">$0</a>', $info["link"]);

							$activity = "Posted a <a href='".$info["link"]."' style='color: #A90101;'>Link</a>";
							//$activity = "Posted ".$exlink;
							$activity .= "<p>".$info["status"]."</p>";
							$activity .= "</br><div class='previewImagesPosted'>";
							$activity .= "<div class='previewImagePosted'>";
							$activity .= "<img src='".$info["linkimage"]."' class='imgIframe' style='width: 100%; height: auto;' />";
							if($info["isvideolink"] == "yes") {
								$activity .= "<span class='videoPostPlay'></span>";
							}
							$activity .= "</div>";
							$activity .= "</div>";
							$activity .= "<div class='previewContentPosted'>";
							$activity .= "<div class='previewTitlePosted'>";
							//$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
							$activity .= "<a target='_blank' href='".$info["link"]."'>";
							$activity .= "<span style='color: #A90101;'>".$info["linktitle"]."</span>";
							$activity .= "</a>";
							$activity .= "</div>";
							$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
							$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
							$activity .= "</div>";
							$activity .= "<div style='clear: both'></div>";
							if(!empty($info["image"])) {
								//$activity .= "</br>Image</br><a href='".$info["link"]."' target='_blank'><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' width='250' height='250' /></a></br> on self wall";
								$activity .= "</br>Image</br><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
								$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /></a>";
							}
						}
						else {
							$activity = "Posted </br>". $info["status"];
							if(!empty($info["image"])) {
								$activity .= "</br>Image</br><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
								$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> </a>";
							}
						}

						if(!empty($info["video"])) {
							$activity .= "</br>Video</br>".$info["video"];
						}
						$activity .= "</br> on self wall";
					}
					else{
						$where = array("id" => $uid);
						$user = $this->communitymodel->getuser($where);
						if(!empty($user)) {
							$name = $user->user_name;
							if(!empty($user->name)) {
								$name = $user->name;
							}
							if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
								//$exlink = preg_replace('/(https?|ssh|ftp):\/\/[^\s"]+/','<br /><a href="$0" target="_blank" style="color: #A90101;">$0</a>', $info["link"]);

								$activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
								$activity .= "</br>Posted a <a href='".$info["link"]."' style='color: #A90101;'>Link</a>";
								$activity .= "<p>".$info["status"]."</p>";

								$activity .= "</br><div class='previewImagesPosted'>";
								$activity .= "<div class='previewImagePosted'>";
								$activity .= "<img src='".$info["linkimage"]."' class='imgIframe' style='width: 130px; height: auto; float: left;' />";
								if($info["isvideolink"] == "yes") {
									$activity .= "<span class='videoPostPlay'></span>";
								}
								$activity .= "</div>";
								$activity .= "</div>";
								$activity .= "<div class='previewContentPosted'>";
								$activity .= "<div class='previewTitlePosted'>";
								//$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
								$activity .= "<a target='_blank' href='".$info["link"]."'>";
								$activity .= "<span>".$info["linktitle"]."</span>";
								$activity .= "</a>";
								$activity .= "</div>";
								$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
								$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
								$activity .= "</div>";
								$activity .= "<div style='clear: both'></div>";
								if(!empty($info["image"])) {
									$activity .= "</br>Image</br><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
									$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> </a>";
									//$activity .= "<br />on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall </br>";
								}
							}
							else {
								$activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a></br>Posted ".$info["status"];
								//$activity = "Posted </br>". $info["status"];
								if(!empty($info["image"])) {
									$activity .= "</br>Image</br><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
									$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /></a>";
								}
							}
							if(!empty($info["video"])) {
								$activity .= "</br>Video</br>".$info["video"];
							}
							$activity .= "<br />on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall </br>";
	                    }
					}
				}
				/*else if($content == $this->config->item("profile_wall_post")) {
					/*if($info["image"]==""){
						$activity = " ".$info["status"]." " ;

					}else {
						$activity = " ".$info["status"]."
					<br/>
					<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> " ;
					}*
					if($uid == $info['uid']){
						if($info["image"]=="") {
							$activity = " Posted ".$this->_separateurl($info["status"])." on self wall ";
						}else {
							$activity = " Posted ".$this->_separateurl($info["status"])."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' />  on self wall";
						}
					}else{
						$where =array("id"=>$uid);
						$user = $this->communitymodel->getuser($where);
						if($info["image"]=="") {
							$activity = " <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a> Posted ".$this->_separateurl($info["status"])." on <a href='".base_url()."community/profile/".$user->name."'>".$user->name."'s</a> wall";
							//$activity = $info["status"]." Posted on wall by <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
						}else {
							$activity = " <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a> Posted ".$this->_separateurl($info["status"])."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> "." on <a href='".base_url()."community/profile/".$user->name."'>".$user->name."'s</a> wall";
							//$activity = "Posted on ".$info["uname"]."profile wall".$info["status"]."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> ";
							//$activity = $info["status"]."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> "." Posted on wall by <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
						}
					}
				}*/
			}

			return $activity;
		}

		/**
		 * This function is used to get activity time ago in format.
		 * @param $date, the date actitivity to calculate.
		 * @param $info, the information of actitivity done.
		 * @return timeago, calculated time difference.
		 */
		function _timeago($date) {
			if(empty($date)) {
				// no date provided
				return "";
			}

			$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
			$lengths = array("60","60","24","7","4.35","12","10");

			$now = time();
			$unix_date = strtotime($date);

			// check validity of date
			if(empty($unix_date)) {
				// bad date
				return "";
			}

			// is it future date or past date
			if($now > $unix_date) {
				$difference = $now - $unix_date;
				$tense = "ago";
			}
			else {
				$difference = $unix_date - $now;
				$tense = "from now";
			}

			for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
				$difference /= $lengths[$j];
			}

			$difference = round($difference);

			if($difference != 1) {
				$periods[$j].= "s";
			}

			return "$difference $periods[$j] {$tense}";
		}

		/**
		 * This function is used to accept friend request.
		 */
		function acceptfriendrequest() {
			if($this->input->post("user_name") && $this->input->post("user_name") != "") {

				$response = array();
				$user_name = $this->input->post("user_name");

				$where = array(
							"user_name" => $user_name
						);
				$requestinguser = $this->communitymodel->getuser($where);

				$uid = $this->db_session->userdata("id");
				$where = array(
							"id" => $uid
						);
				$acceptinguser = $this->communitymodel->getuser($where);

				if(isset($requestinguser) && $requestinguser != "" && isset($acceptinguser) && $acceptinguser != "") {

					$requestinguser_name = $requestinguser->name;
					$requestinguser_username = $requestinguser->user_name;

					$acceptinguser_name = $acceptinguser->name;
					$acceptinguser_username = $acceptinguser->user_name;

					$where = array(
							"uid" => $acceptinguser->id
						);
					$contact = $this->communitymodel->getcontact($where);

					if(isset($contact) && $contact != "") {
						// update
						$friends = unserialize($contact->friends);
						if($friends != "" && in_array($requestinguser->id, $friends)) {
							$temparr["msg"] = "alreadyfriend";
						}
						else {
							$friends[] = $requestinguser->id;

							$friends = array_values($friends);
							$contact = array(
											"friends" => serialize($friends)
										);

							if($this->communitymodel->updatecontact($contact, $where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
					}
					else {
						// insert
						$friends[] = $requestinguser->id;

						$contact = array(
									"uid" => $acceptinguser->id,
									"friends" => serialize($friends)
								);

						if($this->communitymodel->addfriendcontact($contact) > 0) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}

					// this is for cross entry in contact table
					// means entry should be for both for eg. above code do like A is friend of B
					// and below code do entry like B is friend of A
					// this is required because we may need to get user friend list as per user
					$where = array(
							"uid" => $requestinguser->id
						);
					$contact = $this->communitymodel->getcontact($where);

					if(isset($contact) && $contact != "") {
						// update
						$requestinguserfriends = unserialize($contact->friends);
						if($requestinguserfriends != "" && in_array($acceptinguser->id, $requestinguserfriends)) {
							$temparr["msg"] = "alreadyfriend";
						}
						else {
							$requestinguserfriends[] = $acceptinguser->id;

							$requestinguserfriends = array_values($requestinguserfriends);
							$contact = array(
											"friends" => serialize($requestinguserfriends)
										);

							if($this->communitymodel->updatecontact($contact, $where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
					}
					else {
						// insert
						$requestinguserfriends[] = $acceptinguser->id;

						$contact = array(
									"uid" => $requestinguser->id,
									"friends" => serialize($requestinguserfriends)
								);

						if($this->communitymodel->addfriendcontact($contact) > 0) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}

					// here the request is accepted now we need to update friendrequest table
					// so that the same request should not appear in notification
					if($temparr["msg"] == "success") {
						$where = array(
										"uid" => $acceptinguser->id
									);

						$friendrequest = $this->communitymodel->getfriendrequest($where);
						if(isset($friendrequest) && $friendrequest != "") {
							// updating with new request
							$requests = array();

							$isrequested = false;
							if($friendrequest->requests != "") {
								$requests = unserialize($friendrequest->requests);
								if(in_array($requestinguser->id, $requests)) {
									$isrequested = true;
								}
								else {
									$temparr["msg"] = "notrequested";
								}
							}

							if($isrequested) {
								$requests = array_diff($requests, array($requestinguser->id));

								$requests = array_values($requests);
								$friendrequest = array(
													"requests" => serialize($requests)
												);

								if($this->communitymodel->updatefriendrequest($friendrequest, $where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
								$info = array(
											"requestinguser_username" => $requestinguser_username,
											"requestinguser_name" => $requestinguser_name,
											"acceptinguser_name" => $acceptinguser_name,
											"acceptinguser_username" => $acceptinguser_username
										);

								$activity = array(
												"uid" => $acceptinguser->id,
												"content" => $this->config->item("are_now_friends"),
												"info" => serialize($info),
												"date" => date("Y-m-d H:i:s")
											);

								$this->communitymodel->addactivity($activity);
							}
						}
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("friendrequests" => $response));
			}
		}

		/**
		 * This function is used to reject friend request.
		 */
		function rejectfriendrequest() {
			if($this->input->post("user_name") && $this->input->post("user_name") != "") {
				$response = array();

				$user_name = $this->input->post("user_name");
				$where = array(
							"user_name" => $user_name
						);
				$requestinguser = $this->communitymodel->getuser($where);

				$uid = $this->db_session->userdata("id");
				$where = array(
							"id" => $uid
						);
				$rejectinguser = $this->communitymodel->getuser($where);

				if(isset($requestinguser) && $requestinguser != "" && isset($rejectinguser) && $rejectinguser != "") {

					$requestinguser_name = $requestinguser->name;
					$requestinguser_username = $requestinguser->user_name;

					$rejectinguser_name = $rejectinguser->name;
					$rejectinguser_username = $rejectinguser->user_name;

					$where = array(
									"uid" => $rejectinguser->id
								);

					$friendrequest = $this->communitymodel->getfriendrequest($where);

					if(isset($friendrequest) && $friendrequest != "") {
						$requests = array();

						$isrequested = false;
						if($friendrequest->requests != "") {
							$requests = unserialize($friendrequest->requests);
							if(in_array($requestinguser->id, $requests)) {
								$isrequested = true;
							}
							else {
								$temparr["msg"] = "notrequested";
							}
						}

						if($isrequested) {

							$requests = array_diff($requests, array($requestinguser->id));

							$friendrequest = array(
												"requests" => serialize($requests)
											);

							if($this->communitymodel->updatefriendrequest($friendrequest, $where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("friendrequests" => $response));
			}
		}

		/**
		 * This function is used to update activity.
		 */
		function updateactivity() {
			if($this->input->post("somekey") && $this->input->post("somekey") != "" && $this->input->post("wherein") && $this->input->post("wherein") != "") {
				$response = array();

				$activity = array(
									"isnotified" => "1"
								);

				$wherein = $this->input->post("wherein");

				if($this->communitymodel->updateactivities($activity, $wherein)) {
					$temparr["msg"] = "success";
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("newsfeeds" => $response));
			}
		}

		/**
		 * This function is used to join group.
		 */
		function joingroup() {
			if($this->input->post("gid") != "") {

				$response = array();

				$gid = $this->input->post("gid");
				$where = array(
							"id" => $gid,
							"isdeleted" => "0"
						);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$uid = $this->db_session->userdata("id");
					$gname = $group->name;
					$gseo = $group->seo;
					$members = unserialize($group->members);
					$guid = $group->uid;
					$gimg = $group->image;

					if($members != "" && in_array($uid, $members)) {
						$temparr["msg"] = "alreadyjoined";
					}
					else {

						$members[] = $uid;

						$members = array_values($members);
						$group = array(
									"members" => serialize($members)
								);

						if($this->communitymodel->updategroup($group, $where)) {

							$this->_userjoinedgroups($uid, $gid); // user is memeber of how many groups
							$info = array(
									"gid" => $gid,
									"gname" => $gname,
									"gseo" => $gseo
								);

							$activity = array(
									"uid" => $uid,
									"content" => $this->config->item("group_join"),
									"info" => serialize($info),
									"date" => date("Y-m-d H:i:s")
								);

							$this->communitymodel->addactivity($activity);

							$noteinfo = array(
									"gid" => $gid,
									"gname" => $gname,
									"gseo" => $gseo,
									"gmember" => $uid,
									"groupowner" => $guid,
									"groupimage" => $gimg,
									"user_name" => $this->db_session->userdata("user_name")
								);

							$activity = array(
									"uid" => $guid,
									"content" => $this->config->item("group_join"),
									"info" => serialize($noteinfo),
									"date" => date("Y-m-d H:i:s")
								);
							// data for sending notiifcation to group admin
							$this->communitymodel->addnotification($activity);

							// seprate entry for groups activities
							$activity = array(
									"uid" => $uid,
									"gid" => $gid,
									"content" => $this->config->item("group_join"),
									"info" => serialize($info),
									"date" => date("Y-m-d H:i:s")
								);
							$this->communitymodel->addgroupactivity($activity);

							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("join" => $response));
			}
		}
	/**
	 * function to make entry for user is member of how many groups
	 **/
	function _userjoinedgroups($uid,$gid){
		$where = array("uid" => $uid);
		$usersgroup = $this->communitymodel->getuserjoinedgroups($where);

		if(isset($usersgroup) && $usersgroup != "") {
			$groups = array();

			if(!empty($usersgroup->groups)) {
				$groups = unserialize($usersgroup->groups);

				if(is_array($groups) && in_array($gid, $groups)) {

				}
				else{
					$groups[] = $gid;
					$groups = array_values($groups);

					$where = array("uid" => $uid);

					$updategroups = array(
									"groups" => serialize($groups)
								);
					$this->communitymodel->updateuserjoinedgroups($updategroups, $where);
				}
			}
			else{
				$groups[] = $gid;
				$groups = array("uid" => $uid,
							"groups" => serialize($groups)
						);
				$this->communitymodel->adduserjoinedgroups($groups);
			}
		}
		else{
			$groups[] = $gid;
			$groups = array("uid" => $uid,
							"groups" => serialize($groups)
						);
			$this->communitymodel->adduserjoinedgroups($groups);
		}
	}

		/**
		 * This function is used to unjoin group.
		 */
		function unjoingroup() {
			if($this->input->post("gid") != "") {

				$response = array();

				$where = array(
							"id" => $this->input->post("gid"),
							"isdeleted" => "0"
						);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$uid = $this->db_session->userdata("id");

					$members = unserialize($group->members);

					if($members != "" && in_array($uid, $members)) {

						$members = array_diff($members, array($uid));

						$members = serialize($members);

						$group = array(
									"members" => $members
								);

						if($this->communitymodel->updategroup($group, $where)) {
							$gid = $this->input->post("gid");

							$this->_unjoinusersjoinedgroups($uid, $gid); // function to maintain users joined groups records
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "success";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("join" => $response));
			}
		}
		/**
		 * function to remove entry from users joined groups array
		 */
		function _unjoinusersjoinedgroups($uid, $gid){

			$where = array("uid" => $uid);
			$usersgroup = $this->communitymodel->getuserjoinedgroups($where);

			if(isset($usersgroup) && $usersgroup != "") {
				$groups = array();
				if(!empty($usersgroup->groups)) {

					$groups = unserialize($usersgroup->groups);

					if(is_array($groups) && in_array($gid, $groups)) {

						$groups = array_diff($groups, array($gid));
						$groups = array_values($groups);
						$updategroups = array(
									"groups" => serialize($groups)
								);
						$this->communitymodel->updateuserjoinedgroups($updategroups, $where);
					}
				}
			}
		}

		/**
		 * This function is used to post on group wall.
		 */
		function groupwallpost() {
			if($this->input->post("gid") && $this->input->post("message")) {

				$response = array();

				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");

				$where = array(
							"id" => $gid,
							"isdeleted" => "0"
						);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}

					$isadmin = false;
					if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
					{
						$isadmin = true;
						$temparr["isadmin"] = "true";
					}

					$isgroupmember = false;
					if(!$isgroupowner && !$isadmin) {
						if($group->members != "") {
							if(in_array($uid, unserialize($group->members))) {
								$isgroupmember = true;
								$temparr["isgroupmember"] = "true";
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
						else {
							$temparr["isgroupmember"] = "false";
						}
					}

					if($isgroupowner || $isgroupmember || $isadmin) {

						$temparr["ispermitted"] = "true";

						$image = "";

						if(isset($_FILES["userfile"]["name"]) && $_FILES["userfile"]["name"] != "") {

							$groupwalluploadpath = $this->config->item("group_wall_post_original_upload_path");

							$config = array(
										"upload_path" => $groupwalluploadpath,
										"allowed_types" => "jpg|jpeg|gif|png"
									);

							$filename = $_FILES["userfile"]["name"];
							$filename = explode(".", $filename);
							$filename[0] = $filename[0].time().".".$filename[1];
							$_FILES["userfile"]["name"] = $filename[0];

							$this->load->library("upload", $config);

							if($this->upload->do_upload()) {

								$image_data = $this->upload->data();

								$imagestypes = array(
												"group_200x200_upload_path" => $this->config->item("group_wall_post_150x150_upload_path"),
												"group_50x50_upload_path" => $this->config->item("group_wall_post_50x50_upload_path")
											);

								$this->load->library("image_lib");

								foreach ($imagestypes as $imagetype) {

									$width = 200;
									$heigth = 200;

									if($imagetype == $this->config->item("group_wall_post_150x150_upload_path")) {
										$width = 150;
										$heigth = 150;
									}
									else if($imagetype == $this->config->item("group_wall_post_50x50_upload_path")) {
										$width = 50;
										$heigth = 50;
									}

									$config = array(
												"source_image" => $image_data["full_path"],
												"new_image" => $imagetype,
												"maintain_ration" => true,
												"width" => $width,
												"height" => $heigth
											);
$config['source_image'] = $image_data["full_path"];
$exif = exif_read_data($config['source_image']);
if($exif && isset($exif['Orientation']))
{
	$ort = $exif['Orientation'];

	if ($ort == 6 || $ort == 5)
		$config['rotation_angle'] = '270';
	if ($ort == 3 || $ort == 4)
		$config['rotation_angle'] = '180';
	if ($ort == 8 || $ort == 7)
		$config['rotation_angle'] = '90';
}


if ( ! $this->image_lib->rotate())
{
	// Error Message here
	//echo $this->image_lib->display_errors();
}

$this->image_lib->clear();
									$this->image_lib->initialize($config);
									$this->image_lib->resize();
								}

								$image = $image_data["file_name"];
							}
							else {
								$temparr["msg"] = "imageuploadingfail";
							}
							//$this->upload->display_errors();
						}

						$date = date("Y-m-d H:i:s");

						$info = array();
						$info["gid"] = $gid;
						$info["gname"] = $group->name;
						$info["gseo"] = $group->seo;

						$info["link"] = $this->input->post("link");
						$info["linktitle"] = $this->input->post("linktitle");
						$info["linkdescription"] = "";
						$linkdescription = $this->input->post("linkdescription");
						if($linkdescription != "Enter a description" ) {
							$info["linkdescription"] = $this->input->post("linkdescription");
						}
						$info["linkimage"] = $this->input->post("linkimage");
						$info["isvideolink"] = $this->input->post("isvideolink");
						$info["uid"] = $uid;
						$info["status"] = $this->input->post("message");
						$info["image"] = $image;
						$info["video"] = $this->input->post("video");

						$groupwallpost = array(
										"gid" => $gid,
										"uid" => $uid,
										"message" => urlencode($this->input->post("message")),
										"image" => $image,
										"info" => serialize($info),
										"date" => $date
									);

						if($this->communitymodel->addgroupwallpost($groupwallpost) > 0) {
							/*$info = array();
							$info["gid"] = $gid;
							$info["gname"] = $group->name;
							$info["gseo"] = $group->seo;

							$info["link"] = $this->input->post("link");
							$info["linktitle"] = $this->input->post("linktitle");
							$info["linkdescription"] = "";
							$linkdescription = $this->input->post("linkdescription");
							if($linkdescription != "Enter a description" ) {
								$info["linkdescription"] = $this->input->post("linkdescription");
							}
							$info["linkimage"] = $this->input->post("linkimage");
							$info["isvideolink"] = $this->input->post("isvideolink");
							$info["uid"] = $uid;
							$info["status"] = $this->input->post("message");
							$info["image"] = $image;
							$info["video"] = $this->input->post("video");*/

							$activity = array(
									"uid" => $uid,
									"content" => $this->config->item("group_wall_post"),
									"info" => serialize($info),
									"date" => $date
								);

							$this->communitymodel->addactivity($activity);

							//seprate entry for group activities
							$activity = array(
									"uid" => $uid,
									"gid" => $gid,
									"content" => $this->config->item("group_wall_post"),
									"info" => serialize($info),
									"date" => $date
								);
							if($this->communitymodel->addgroupactivity($activity) > 0){
								$temparr["msg"] = "success";
							}

						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["ispermitted"] = "false";
					}
				}
				else {
					$temparr["msg"] = "groupfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupwallpost" => $response));
			}
		}

		/**
		 * This function is used to delete group wall post.
		 */
		function deletegroupwallpost() {

			if($this->input->post("gid") && $this->input->post("pid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$pid = $this->input->post("pid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}

					$isadmin = false;
					if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
					{
						$isadmin = true;
						$temparr["isadmin"] = "true";
					}

					$isgroupmember = false;
					if(!$isgroupowner && !$isadmin) {
						if(isset($group) && $group != "") {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
					}

					$where = array(
								"id" => $pid
							);

					$groupwallpost = $this->communitymodel->getgroupwallpost($where);

					if(isset($groupwallpost) && $groupwallpost != "") {

						$ispostowner = false;
						if($isgroupmember) {
							if($groupwallpost->uid == $uid) {
								$ispostowner = true;
								$temparr["ispostowner"] = "true";
							}
							else {
								$temparr["ispostowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $ispostowner) || $isadmin ) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $pid,
								"gid" => $gid,
								"uid" => $uid
							);

							if($this->communitymodel->deletegroupwallpost($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "postnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupwallpost" => $response));
			}
		}

		/**
		 * This function is used to post on reply on question.
		 */
		 function questionreply() {
			if($this->input->post("gid") && $this->input->post("qid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$qid = $this->input->post("qid");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $qid > 0 && $uid > 0) {

					$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							);

					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {

							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $qid
							);

							$question = $this->communitymodel->getquestion($where);

							if(isset($question) && $question != "") {
								$date = date("Y-m-d H:i:s");

								$reply = array(
											"gid" => $gid,
											"qid" => $qid,
											"uid" => $uid,
											"answer" => $this->input->post("message"),
											"date" => $date
										);

								$replyid = $this->communitymodel->addreply($reply);

								if($replyid > 0) {
									$info = array(
												"gid" => $gid,
												"gseo" => $group->seo,
												"gname" => $group->name,
												"qid" => $qid,
												"question" => $question->question,
												"qseo" => $question->seo,
												"rid" => $replyid
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("reply_on_question"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									//seprate entry for groups activities
									$activity = array(
													"uid" => $uid,
													"gid" => $gid,
													"content" => $this->config->item("reply_on_question"),
													"info" => serialize($info),
													"date" => $date
												);
									$this->communitymodel->addgroupactivity($activity);

									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["msg"] = "questionnotfound";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
		}

	/*	function reply() {
			if($this->input->post("gid") && $this->input->post("qid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$qid = $this->input->post("qid");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $qid > 0 && $uid > 0) {

					$where = array(
								"id" => $gid
							);

					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {

							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $qid
							);

							$question = $this->communitymodel->getquestion($where);

							if(isset($question) && $question != "") {
								$date = date("Y-m-d H:i:s");

								$reply = array(
											"gid" => $gid,
											"qid" => $qid,
											"uid" => $uid,
											"message" => $this->input->post("message"),
											"date" => $date
										);

								$replyid = $this->communitymodel->addreply($reply);

								if($replyid > 0) {
									$info = array(
												"gid" => $gid,
												"gseo" => $group->seo,
												"gname" => $group->name,
												"qid" => $qid,
												"question" => $question->question,
												"qseo" => $question->seo,
												"rid" => $replyid
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("reply_on_question"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["msg"] = "questionnotfound";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
		}*/


		/**
		 * This function is used to delete answers from question.
		 */
		function deletereply() {

			if($this->input->post("gid") && $this->input->post("qid") && $this->input->post("rid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$qid = $this->input->post("qid");
				$rid = $this->input->post("rid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}

					$isgroupmember = false;
					if(!$isgroupowner) {
						if($group->members != "") {
							if(in_array($uid, unserialize($group->members))) {
								$isgroupmember = true;
								$temparr["isgroupmember"] = "true";
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
						else {
							$temparr["isgroupmember"] = "false";
						}
					}

					$where = array(
								"id" => $rid
							);

					$reply = $this->communitymodel->getreply($where);

					if(isset($reply) && $reply != "") {

						$isreplyowner = false;
						if($isgroupmember) {

							if($reply->uid == $uid) {
								$isreplyowner = true;
								$temparr["isreplyowner"] = "true";
							}
							else {
								$temparr["isreplyowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $isreplyowner)) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $rid,
								"gid" => $gid,
								"qid" => $qid,
								"uid" => $uid
							);

							if($this->communitymodel->deletereply($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "replynotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
		}


		 /*Function to delete asked question by the owner of the question */
		function deletequestion() {

			if($this->input->post("gid") && $this->input->post("qid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$qid = $this->input->post("qid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}


					$isgroupmember = false;
					if(!$isgroupowner) {
						if(isset($group) && $group != "") {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
					}

					$where = array(
								"id" => $qid
							);

					$question = $this->communitymodel->getquestion($where);

					if(isset($question) && $question != "") {

						$ispostowner = false;
						if($isgroupmember) {
							if($question->uid == $uid) {
								$ispostowner = true;
								$temparr["ispostowner"] = "true";
							}
							else {
								$temparr["ispostowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $ispostowner)) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $qid,
								"gid" => $gid,
								"uid" => $uid
							);

							if($this->communitymodel->deletequestion($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "questionnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("question" => $response));
			}
		}

		/**
		 * This function is used to send friend request.
		 */
		function addasfriend() {
			if($this->input->post("user_name")) {
				$response = array();

				$user_name = $this->input->post("user_name");
				$requestinguid = $this->db_session->userdata("id");

				// here getting the user to whom request is to be send
				$where = array(
							"user_name" => $user_name
						);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {

					// here getting the user who is requesting
					$where = array(
							"id" => $requestinguid
						);

					$requestinguser = $this->communitymodel->getuser($where);

					if(isset($requestinguser) && $requestinguser != "") {

						// here just checking if the user have requests,
						// if yes then update with new request or insert new request
						$where = array(
										"uid" => $user->id
									);

						$friendrequest = $this->communitymodel->getfriendrequest($where);

						if(isset($friendrequest) && $friendrequest != "") {
							// updating with new request
							$requests = array();

							$isalreadyrequested = false;
							if($friendrequest->requests != "") {
								$requests = unserialize($friendrequest->requests);
								if(in_array($requestinguid, $requests)) {
									$temparr["msg"] = "alreadyrequested";
									$isalreadyrequested = true;
								}
							}

							if(!$isalreadyrequested) {
								$requests[] = $requestinguid;

								$friendrequest = array(
													"requests" => serialize($requests)
												);

								if($this->communitymodel->updatefriendrequest($friendrequest, $where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						else {
							// inserting new request
							$requests[] = $requestinguid;

							$friendrequest = array(
												"uid" => $user->id,
												"requests" => serialize($requests)
											);

							if($this->communitymodel->addfriendrequest($friendrequest) > 0) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
					}
					else {
						$temparr["msg"] = "accountnotfound";
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("friendRequest" => $response));
			}
		}

		/**
		 * This function is used to cancel friend request.
		 */
		function cancelfriendrequest() {
			if($this->input->post("user_name")) {
				$response = array();

				$user_name = $this->input->post("user_name");
				$requestinguid = $this->db_session->userdata("id");

				// here getting the user to whom request is to be send
				$where = array(
							"user_name" => $user_name
						);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {

					// here getting the user who is requesting
					$where = array(
							"id" => $requestinguid
						);

					$requestinguser = $this->communitymodel->getuser($where);

					if(isset($requestinguser) && $requestinguser != "") {

						// here just checking if the user have requests,
						// if yes then update with new request or insert new request
						$where = array(
										"uid" => $user->id
									);

						$friendrequest = $this->communitymodel->getfriendrequest($where);

						if(isset($friendrequest) && $friendrequest != "") {
							// updating with new request
							$requests = array();

							$isrequested = false;
							if($friendrequest->requests != "") {
								$requests = unserialize($friendrequest->requests);
								if(in_array($requestinguid, $requests)) {
									$isrequested = true;
								}
								else {
									$temparr["msg"] = "notrequested";
								}
							}

							if($isrequested) {

								$requests = array_diff($requests, array($requestinguid));
								$requests = array_values($requests);
								$friendrequest = array(
													"requests" => serialize($requests)
												);

								if($this->communitymodel->updatefriendrequest($friendrequest, $where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						/* else {
							// inserting new request
							$requests[] = $requestinguid;

							$friendrequest = array(
												"uid" => $user->id,
												"requests" => serialize($requests)
											);

							if($this->communitymodel->addfriendrequest($friendrequest) > 0) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						} */
					}
					else {
						$temparr["msg"] = "accountnotfound";
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("friendRequest" => $response));
			}
		}

		/**
		 * This function is used to remove friend from contact of this user.
		 */
		function unfriend() {
			if($this->input->post("user_name")) {
				$response = array();

				$user_name = $this->input->post("user_name");
				$requestinguid = $this->db_session->userdata("id");

				// here getting the user who is to be remove from friend list
				$where = array(
							"user_name" => $user_name
						);
				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {

				//here getting the user who want to remove friend from his friend list i.e $requestinguser//
					$where = array(
							"id" => $requestinguid
						);

					$requestinguser = $this->communitymodel->getuser($where);

					if(isset($requestinguser) && $requestinguser != "") {

						// here just checking if the user is friend or not,
						// if yes then update with contact list
						$where = array(
										"uid" => $requestinguser->id
									);

						$contact = $this->communitymodel->getcontact($where);

						if(isset($contact) && $contact != "") {
							$friends = array();

							$isfriend = false;
							if($contact->friends != "") {
								$friends = unserialize($contact->friends);
								if(in_array($user->id, $friends)) {
									$isfriend = true;
								}
								else {
									$temparr["msg"] = "notanfriend";
								}
							}

							if($isfriend) {

								$friends = array_diff($friends, array($user->id));

								$friends = array_values($friends);
								$contact = array(
													"friends" => serialize($friends)
												);

								if($this->communitymodel->updatecontact($contact, $where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["msg"] = "notanfriend";
							}
						}
						else {
							$temparr["msg"] = "nocontacts";
						}

					$where = array(
								"uid" => $user->id
								);
					$profilecontacts = $this->communitymodel->getcontact($where);
					if(isset($profilecontacts) && $profilecontacts != "") {
						$profilefriends = array();
						$isprofilfriend = false;
						if($profilecontacts->friends != "") {
							$profilefriends = unserialize($profilecontacts->friends);
							if(in_array($requestinguser->id, $profilefriends)) {
								$profilefriends = true;
							}
							else {
								$temparr["msg"] = "notanfriend";
							}
						}


						if($profilefriends) {
							$profilefriends = unserialize($profilecontacts->friends);
							$profilefriends = array_diff($profilefriends, array($requestinguser->id));
							$profilefriends = array_values($profilefriends);
							$contact = array(
											"friends" => serialize($friends)
										);
							if($this->communitymodel->updatecontact($contact, $where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
						else {
							$temparr["msg"] = "notanfriend";
						}
					}
					else {
						$temparr["msg"] = "nocontacts";
					}
					}
					else {
						$temparr["msg"] = "accountnotfound";
					}

				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("friendRequest" => $response));
			}
		}

		/**
		 * This function is used to comment on activity.
		 */
		function commentonactivity() {
			if($this->input->post("profileownerid") && $this->input->post("aid") && $this->input->post("comment") && $this->input->post("somekey") == "somekey") {

				$response = array();

				$profileownerid = $this->input->post("profileownerid");
				$aid = $this->input->post("aid");
				$comment = $this->input->post("comment");
				$uid = $this->db_session->userdata("id");

				if($aid > 0 && $uid > 0) {

					$where = array(
								"id" => $aid
							);

					$activity = $this->communitymodel->getactivity($where);

					if(isset($activity) && $activity != "") {

						$where = array(
								"id" => $profileownerid
							);

						$profileowner = $this->communitymodel->getuser($where);

						if(isset($profileowner) && $profileowner != "") {
							$isactivityowner = false;
							if($activity->uid == $profileowner->id) {
								$isactivityowner = true;
								$temparr["isactivityowner"] = "true";
							}

							$isfriend = false;
							if(!$isactivityowner) {

								$where = array(
									"uid" => $profileowner->id
								);
								$contact = $this->communitymodel->getcontact($where);

								if(isset($contact) && $contact != "") {
									if($contact->friends != "") {
										$friends = unserialize($contact->friends);
										if(in_array($uid, $friends)) {
											$isfriend = true;
										}
										else {
											$temparr["msg"] = "notanfriend";
										}
									}
								}
								else {
									$temparr["msg"] = "nocontacts";
								}
							}
							if($isactivityowner || $isfriend) {

								$temparr["ispermitted"] = "true";

								$date = date("Y-m-d H:i:s");

								$communitycomment = array(
														"aid" => $aid,
														"uid" => $uid,
														"comment" => $comment,
														"date" => $date
													);

								if($this->communitymodel->addcommunitycomment($communitycomment) > 0) {

									$where = array(
												"id" => $uid
											);
									$user = $this->communitymodel->getuser($where);

									$info = array(
												"profileowner_id" => $profileowner->id,
												"profileowner_uname" => $profileowner->user_name,
												"profileowner_name" => $profileowner->name,
												"uid" => $uid,
												"uname" => $user->user_name,
												"name" => $user->name,
												"aid" => $aid,
												"comment" => $comment
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("comment_on_activity"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									// here just creating an array to pass to javascript
									// so that we can show or add new comment to comment container
									$userimg = "noavatar.png";

									$temparr["profileowner_id"] = $profileowner->id;
									$temparr["profileowner_uname"] = $profileowner->user_name;
									$temparr["profileowner_name"] = $profileowner->name;
									$temparr["uid"] = $user->id;

									$temparr["name"] = $user->user_name;
                                    if(!empty($user->name)) {
                                       $temparr["name"] = $user->name;
                                    }

									$temparr["user_name"] = $user->user_name;

									if($user->image != "") {
										$userimg = $user->image;
									}
									$temparr["image"] = $userimg;
									$temparr["comment"] = $comment;
									$temparr["timeago"] = $this->_timeago($date);;

									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["ispermitted"] = "false";
							}
						}
						else {
							$temparr["msg"] = "usernotfound";
						}
					}
					else {
						$temparr["msg"] = "activitynotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("comments" => $response));
			}
		}

		/**
		 * This function is used to comment on activity.
		 */
		function commentonpublicwallactivity() {
			if($this->input->post("profileownerid") && $this->input->post("aid") && $this->input->post("comment") && $this->input->post("somekey") == "somekey") {

				$response = array();

				$profileownerid = $this->input->post("profileownerid");
				$aid = $this->input->post("aid");
				$comment = $this->input->post("comment");
				$uid = $this->db_session->userdata("id");

				$temparr["ispermitted"] = "true";

				if($aid > 0 && $uid > 0) {

					$where = array(
									"user_name" => base64_encode($this->db_session->userdata("user_name"))
								);

					$membership = $this->communitymodel->getmembership($where);
					if(!empty($membership)) {

						$haveposts = false;
						//$temparr["haveposts"] = false;
						$temparr["isexpired"] = false;
						/*if($membership->type == "1") {
							if($membership->posts > 0 && $membership->posts <= 10) {
								$haveposts = true;
								$temparr["haveposts"] = true;
							}
						}
						else if($membership->type == "2") {
							$haveposts = true;
							$temparr["haveposts"] = true;
						}*/

						//if($haveposts) {
							$today = date("Y-m-d H:i:s");
							if($today <= $membership->enddate) {
								$where = array(
												"id" => $aid
											);
								$activity = $this->communitymodel->getpublicwallactivity($where);

								if(!empty($activity)) {

									$where = array(
												"id" => $profileownerid
											);
									$profileowner = $this->communitymodel->getuser($where);

									if(!empty($profileowner)) {
										/* $isactivityowner = false;
										if($activity->uid == $profileowner->id) {
											$isactivityowner = true;
											$temparr["isactivityowner"] = "true";
										}

										$isfriend = false;
										if(!$isactivityowner) {

										}

										if($isactivityowner || $isfriend) { */

											$temparr["ispermitted"] = "true";

											$date = date("Y-m-d H:i:s");

											$communitycomment = array(
																	"aid" => $aid,
																	"uid" => $uid,
																	"comment" => $comment,
																	"date" => $date
																);

											if($this->communitymodel->addpublicwallcomment($communitycomment) > 0) {

												$where = array(
															"id" => $uid
														);
												$user = $this->communitymodel->getuser($where);

												$info = array(
															"profileowner_id" => $profileowner->id,
															"profileowner_uname" => $profileowner->user_name,
															"profileowner_name" => $profileowner->name,
															"uid" => $uid,
															"uname" => $user->user_name,
															"name" => $user->name,
															"aid" => $aid,
															"comment" => $comment
														);

												$activity = array(
																"uid" => $uid,
																"content" => $this->config->item("comment_on_public_wall_activity"),
																"info" => serialize($info),
																"date" => $date
															);

												if($this->communitymodel->addpublicwallactivity($activity) > 0) {
													// here just creating an array to pass to javascript
													// so that we can show or add new comment to comment container
													$userimg = "noavatar.png";

													$temparr["profileowner_id"] = $profileowner->id;
													$temparr["profileowner_uname"] = $profileowner->user_name;
													$temparr["profileowner_name"] = $profileowner->name;
													$temparr["uid"] = $user->id;

													$temparr["name"] = $user->user_name;
                                                    if(!empty($user->name)) {
                                                        $temparr["name"] = $user->name;
                                                    }

													$temparr["user_name"] = $user->user_name;

													if($user->image != "") {
														$userimg = $user->image;
													}
													$temparr["image"] = $userimg;
													$temparr["comment"] = $comment;
													$temparr["timeago"] = $this->_timeago($date);;

													$temparr["msg"] = "success";
												}
												else {
													$temparr["msg"] = "fail";
												}
											}
											else {
												$temparr["msg"] = "fail";
											}
										/* }
										else {
											$temparr["ispermitted"] = "false";
										} */
									}
									else {
										$temparr["msg"] = "usernotfound";
									}
								}
								else {
									$temparr["msg"] = "activitynotfound";
								}
							}
							else {
								$temparr["isexpired"] = true;
							}
						//}
					}
					else {
						$temparr["msg"] = "notmember";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("comments" => $response));
			}
		}

		/**
	 	* This function is used to add likes of public wall activity
	 	*/
		function likepublicwall() {
			if($this->input->post("profileownerid") && $this->input->post("aid") && $this->input->post("somekey") == "somekey") {

				$response = array();

				$profileownerid = $this->input->post("profileownerid");
				$aid = $this->input->post("aid");

				$uid = $this->db_session->userdata("id");

				if($aid > 0 && $uid > 0) {
					$where = array(
									"id" => $aid
								);
					$activity = $this->communitymodel->getpublicwallactivity($where);

					if(!empty($activity)) {
						$where = array(
										"id" => $profileownerid
									);
						$profileowner = $this->communitymodel->getuser($where);

						if(!empty($profileowner)) {

							$temparr["ispermitted"] = "true";

							$where = array(
											"aid" => $aid,
											"uid" => $uid
										);
							if($this->communitymodel->ispublicawallactivityliked($where)) {
								$temparr["msg"] = "alreadyliked";
							}
							else {
								$date = date("Y-m-d H:i:s");
								$communitylike = array(
														"aid" => $aid,
														"uid" => $uid,
														"date" => $date
													);
								if($this->communitymodel->addpublicwalllikes($communitylike) > 0) {
									$where = array(
													"aid" => $aid
												);
									$temparr["likecounts"] = $this->communitymodel->getpublicwalllikecounts($where);
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						else {
							$temparr["msg"] = "usernotfound";
						}
					}
					else {
						$temparr["msg"] = "activitynotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("likes" => $response));
			}
		}

		/**
		 * This function is used to accept group invitation.
		 */
		function accectgroupinvitation() {

			if($this->input->post("gid") != "" && $this->input->post("notificationid") != "" ) {

				$response = array();

				$gid = $this->input->post("gid");
				$notificationid =  $this->input->post("notificationid");

				$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							  );
				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$uid = $this->db_session->userdata("id");
					$gname = $group->name;
					$gseo = $group->seo;
					$members = unserialize($group->members);

					$members[] = $uid;

					$group = array(
									"members" => serialize($members)
								);

					if($this->communitymodel->updategroup($group, $where)) {
						$where = array(
								"id" => $notificationid
							);
						$updatenotification = array(
													"isnotified" => "1"
											);
						if($this->communitymodel->updatenotification($updatenotification, $where)) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("notification" => $response));
			}
		}

		/**
		 * This function is used to accept meet invitation.
		 */
		function meetinvitation(){

			if($this->input->post("gid") != "" && $this->input->post("notificationid") != "" ) {

				$response = array();

				$meetid = $this->input->post("gid");
				$notificationid =  $this->input->post("notificationid");

				$where = array(
                            "id" => $meetid,
                            "isdeleted" => "0"
                        );
            	$groupmeetArr = $this->communitymodel->getallmeets($where);
				$groupmeet = $groupmeetArr[0];

				if(isset($groupmeet) && $groupmeet != "") {
					$uid = $this->db_session->userdata("id");
					$meetname = $groupmeet->name;
					$meetseo = $groupmeet->seo;

					$where = array("id" => $notificationid);
					$updatenotification = array("isnotified" => "1");
					if($this->communitymodel->updatenotification($updatenotification, $where))
					{
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("notification" => $response));
			}
		}

		/**
		 * This function is used to remove new member joining notification.
		 */
		function newgroupmember() {

			if($this->input->post("gid") != "" && $this->input->post("notificationid") != "" ) {

				$response = array();

				$gid = $this->input->post("gid");
				$notificationid =  $this->input->post("notificationid");
				if(isset($notificationid) && $notificationid != ""){

					$where = array("id" => $notificationid);

					$updatenotification = array("isnotified" => "1");
					if($this->communitymodel->updatenotification($updatenotification, $where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "fail";
					}
				}else {
					$temparr["msg"] = "notfound";
				}
				array_push($response, $temparr);
				echo json_encode(array("notification" => $response));
			}
		}

		/**
		 * This function is used to reject group invitation.
		 */
		function rejectgroupinvitation() {

			if($this->input->post("notificationid") != "") {

				$response = array();

				$notificationid =  $this->input->post("notificationid");

				$where = array(
								"id" => $notificationid
							);
				$updatenotification = array(
											"isnotified" => "1"
										);

				if($this->communitymodel->updatenotification($updatenotification, $where)) {
					$temparr["msg"] = "success";
				}
				else {
					$temparr["msg"] = "fail";
				}
			}
			array_push($response, $temparr);
			echo json_encode(array("notification" => $response));
		}

	    function getfriends() {

			if($this->input->post("gid") != "") {

				$response = array();
				$temparr = array();

				$id = $this->input->post("gid");

				$where = array(
							"id" => $id,
							"isdeleted" => "0"
							);
				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$data["group"] = $group;

					$where = array(
								"uid" => $this->db_session->userdata("id")
								);
					$friendids = $this->communitymodel->getallfriends($where);
					$friends = array();
					if(isset($friendids) && $friendids != "") {
						foreach($friendids as $id) {
			                    $members = unserialize($group->members);
		                   		if(isset($members) && $members !=""){
									if($members != "" && !in_array($id, $members)) {
										$where = array(
														"id" => $id
													);
										$user = $this->communitymodel->getuser($where);
											if(isset($user) && $user != "") {
												$friends[] = $user;
											}
									}

						  		}
							   	else {
									$where = array(
												"id" => $id
												);
									$user = $this->communitymodel->getuser($where);
									if(isset($user) && $user != "") {
										$friends[] = $user;


									}
								}
						}
					}
				}
				if(isset($friends) && $friends != "") {
					foreach($friends as $friend) {

						if($friend->image != "") {
							$userimg = $friend->image;
						}else{
							$userimg = "noavatar.png";
						}

						$temparr["name"] = $friend->name;
						$temparr["id"] = $friend->id;
						$temparr["image"] = $userimg;
						$temparr["msg"] = "success";
						array_push($response, $temparr);
					}
				}

				echo json_encode(array("friends" => $response));

			}
		}
	/*function to get all questions*/
	/*function getallquestions() {
		if($this->input->post("gid") != "") {

				$response = array();
				$temparr = array();

				$id = $this->input->post("gid");

				$where = array(
							"id" => $id,
							"isdeleted" => "0"
							);
				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$data["group"] = $group;

					$where = array(
								"uid" => $this->db_session->userdata("id")
								);
					$questions = $this->communitymodel->getallquestions($where);
				}
				if(isset($questions) && $questions != "") {
					foreach($questions as $question) {
						$temparr["question"] = $question->question;
						$temparr["seo"] = $question->seo;
						$temparr["date"] = $question->date;
						$temparr["msg"] = "success";
						array_push($response, $temparr);
					}
				}

				echo json_encode(array("questions" => $response));

			}
	}*/

	function submitpoll_bk() {
		//echo $this->input->post("question");

		if($this->input->post("gid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $uid > 0) {
					$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							);
					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {

							$temparr["ispermitted"] = "true";
							$date = date("Y-m-d H:i:s");

							$poll = array(
								"uid" => $uid,
								"gid" => $gid,
								"question" => $this->input->post("question"),
								"date" => $date
								);

							$pollsubmit = $this->communitymodel->addpoll($poll);

							if(isset($pollsubmit) && $pollsubmit != "") {

								$options = array(
											"qid" => $pollsubmit,
											"value" => $this->input->post("option1")
											);

								$optionsubmit = $this->communitymodel->addpolloptions($options);

								if(isset($optionsubmit) && $optionsubmit != ""){
									$options = array(
											"qid" => $pollsubmit,
											"value" => $this->input->post("option2")
											);
									$optionsubmit = $this->communitymodel->addpolloptions($options);

									$info = array(
												"gid" => $gid,
												"gseo" => $group->seo,
												"gname" => $group->name,
												"qid" => $pollsubmit,
												"question" => $this->input->post("question")
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("new_poll"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["msg"] = "fail to submit poll";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
	}

	function submitpoll() {
		//echo $this->input->post("question");

		if($this->input->post("gid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");
				$opinion_nos = $this->input->post("opinin_nos");

				if($gid > 0 && $uid > 0) {
					$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							);
					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {

							$temparr["ispermitted"] = "true";
							$date = date("Y-m-d H:i:s");

							$poll = array(
								"uid" => $uid,
								"gid" => $gid,
								"question" => $this->input->post("pollquestion"),
								"date" => $date
								);

							$pollsubmit = $this->communitymodel->addpoll($poll);

							if(isset($pollsubmit) && $pollsubmit != "") {
								$optionsubmit = array();

								for($i=1;$i<=$opinion_nos;$i++)
								{
									if($this->input->post("option".$i)!='')
									{
										$options = array(
												"qid" => $pollsubmit,
												"value" => $this->input->post("option".$i)
												);

										$optionsubmit[] = $this->communitymodel->addpolloptions($options);
									}
								}

								if(isset($optionsubmit) && count($optionsubmit)>0){
									$info = array(
												"gid" => $gid,
												"gseo" => $group->seo,
												"gname" => $group->name,
												"qid" => $pollsubmit,
												"question" => $this->input->post("question")
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("new_poll"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									$activity = array(
													"uid" => $uid,
													"gid" => $gid,
													"content" => $this->config->item("new_poll"),
													"info" => serialize($info),
													"date" => $date
												);
									$this->communitymodel->addgroupactivity($activity);

									//print_r($_POST);exit;
									redirect("community/poll/".$this->input->post("seo"));
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$temparr["msg"] = "fail to submit poll";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
	}

	/*Function to vote on submitted poll*/
	function voteonpoll(){
		if($this->input->post("optionid") && $this->input->post("gid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $uid > 0) {
					$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							);
					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {

							$temparr["ispermitted"] = "true";
							$date = date("Y-m-d H:i:s");

							/*$vote = array(
								"optionid"=>$this->input->post("optionid"),
								"uid" => $uid
								);
							$voteresult = $this->communitymodel->getvotes($vote);

							if(!$voteresult > 0){ */

								$vote = array(
								"optionid"=>$this->input->post("optionid"),
								"uid" => $uid,
								"date" => $date
								);

								$voted = $this->communitymodel->addpollvotes($vote);

								if(isset($voted) && $voted != "") {
									$info = array(
												"gid" => $gid,
												"gseo" => $group->seo,
												"gname" => $group->name,
												//"qid" => $this->input->post("qid"),
												"option" => $this->input->post("optionid")
											);

									$activity = array(
													"uid" => $uid,
													"content" => $this->config->item("vote_on_poll"),
													"info" => serialize($info),
													"date" => $date
												);

									$this->communitymodel->addactivity($activity);

									$activity = array(
													"uid" => $uid,
													"gid" => $gid,
													"content" => $this->config->item("vote_on_poll"),
													"info" => serialize($info),
													"date" => $date
												);
									$this->communitymodel->addgroupactivity($activity);
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail to vote poll";
								}
							/*}
							else{
								$temparr["msg"] = "alreadyvoted";
							}	*/
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
	}

	/**
		 * This function is used to delete group poll.
		 */
		function removegrouppoll() {

			if($this->input->post("gid") && $this->input->post("pid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$pid = $this->input->post("pid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}


					$isgroupmember = false;
					if(!$isgroupowner) {
						if(isset($group) && $group != "") {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
					}

					$where = array(
								"id" => $pid
							);

					$groupwallpoll = $this->communitymodel->getgroupwallpoll($where);

					if(isset($groupwallpoll) && $groupwallpoll != "") {

						$ispostowner = false;
						if($isgroupmember) {
							if($groupwallpoll->uid == $uid) {
								$ispostowner = true;
								$temparr["ispostowner"] = "true";
							}
							else {
								$temparr["ispostowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $ispostowner)) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $pid,
								"gid" => $gid,
								"uid" => $uid
							);

							if($this->communitymodel->deletegroupwallpoll($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "pollnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupwallpoll" => $response));
			}
		}

	/**
		 * This function is used to delete group meet.
		 */
		function removegroupmeet() {

			if($this->input->post("gid") && $this->input->post("pid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$pid = $this->input->post("pid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
						$temparr["seo"] = $group->seo;
					}


					$isgroupmember = false;
					if(!$isgroupowner) {
						if(isset($group) && $group != "") {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
					}

					$where = array(
								"id" => $pid
							);

					$groupwallmeet = $this->communitymodel->getgroupmeet($where);

					if(isset($groupwallmeet) && $groupwallmeet != "") {

						$ispostowner = false;
						if($isgroupmember) {
							if($groupwallmeet->uid == $uid) {
								$ispostowner = true;
								$temparr["ispostowner"] = "true";
							}
							else {
								$temparr["ispostowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $ispostowner)) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $pid,
								"gid" => $gid,
								"uid" => $uid
							);

							if($this->communitymodel->deletegroupmeet($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "pollnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupmeet" => $response));
			}
		}

		function removegroupmeetcomments() {
			if($this->input->post("gid") && $this->input->post("pid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$mid = $this->input->post("mid");
				$pid = $this->input->post("pid");
				$uid = $this->db_session->userdata("id");

				$where = array("id" => $gid,"isdeleted" => "0");

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {
					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
						$temparr["seo"] = $group->seo;
					}


					$isgroupmember = false;
					if(!$isgroupowner) {
						if(isset($group) && $group != "") {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
					}

					$where = array("id" => $pid);
					$groupwallmeet = $this->communitymodel->getgroupmeetquestions($where);

					if(isset($groupwallmeet) && $groupwallmeet != "") {

						$ispostowner = false;
						if($isgroupmember) {
							if($groupwallmeet->uid == $uid) {
								$ispostowner = true;
								$temparr["ispostowner"] = "true";
							}
							else {
								$temparr["ispostowner"] = "false";
							}
						}

						if($isgroupowner || ($isgroupmember && $ispostowner)) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $pid,
								"gid" => $gid,
								"uid" => $uid
							);

							if($this->communitymodel->deletegroupmeetcomments($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "pollnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupmeet" => $response));
			}
		}

	function askquestion() {

		if($this->input->post("gid") && $this->input->post("question")) {

				$response = array();

				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $uid > 0) {
					$where = array(
								"id" => $gid,
								"isdeleted" => "0"
							);
					$group = $this->communitymodel->getgroup($where);

					if(isset($group) && $group != "") {

						$isgroupowner = false;
						if($uid != "") {
							if($group->uid == $uid) {
								$isgroupowner = true;
								$temparr["isgroupowner"] = "true";
							}
						}

						$isgroupmember = false;
						if(!$isgroupowner) {
							if($group->members != "") {
								if(in_array($uid, unserialize($group->members))) {
									$isgroupmember = true;
									$temparr["isgroupmember"] = "true";
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}

						if($isgroupowner || $isgroupmember) {
							$temparr["ispermitted"] = "true";

							$seo = strtolower(strtok($this->input->post("question")," ")."-".md5(time()));
							$date = date("Y-m-d H:i:s");
							$question = array(
											"gid" => $gid,
											"uid" => $uid,
											"question" => $this->input->post("question"),
											"seo" => $seo,
											"date" => $date
										);

							$questionid = $this->communitymodel->addquestion($question);
							if($questionid > 0) {

								$info = array(
										"gid" => $gid,
										"gname" => $group->name,
										"gseo" => $group->seo,
										"qid" => $questionid,
										"question" => $this->input->post("question"),
										"qseo" => $seo
									);

								$activity = array(
										"uid" => $uid,
										"content" => $this->config->item("new_question"),
										"info" => serialize($info),
										"date" => $date,
										"isnotified" => "0"
									);

								$this->communitymodel->addactivity($activity);

								$activity = array(
										"uid" => $uid,
										"gid" => $gid,
										"content" => $this->config->item("new_question"),
										"info" => serialize($info),
										"date" => $date,
										"isnotified" => "0"
									);
								$this->communitymodel->addgroupactivity($activity);

								$temparr["msg"] = "success";

							}
							else {
									$temparr["msg"] = "fail";
								}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "groupnotfound";
					}
				}
				else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("replies" => $response));
			}
	}


		/**
 		 * This function is used to post on profile wall.
		 */
		function profilewallpost() {
			if($this->db_session->userdata("id") != "" && $this->input->post("status") && $this->input->post("user") && $this->input->post("sendpersonalmessage")) {
				$response = array();

				$uid = $this->db_session->userdata("id");
				$username = $this->input->post("user");

				$where = array("id" => $uid);
				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {
					$profileuser = "";

					$isadmin = false;
					if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
					{
						$isadmin = true;
						$temparr["isadmin"] = "true";
					}

					if($this->db_session->userdata("user_name") != $username) {
						$where = array("user_name" => $username);
						$profileuser = $this->communitymodel->getuser($where);
						$temparr["isowner"] = "false";

						$where = array("uid" => $profileuser->id);
						$profileusercontacts = $this->communitymodel->getcontact($where);

						if(!empty($profileusercontacts))
						{
							$friendlist = unserialize($profileusercontacts->friends);
							if(in_array($uid, $friendlist) || $isadmin)
							{
								$temparr["isfriend"] = $isfriend = "true";
							}
							else{
								$temparr["isfriend"] = $isfriend = "false";
							}
						}
						elseif($isadmin)
						{
							$temparr["isfriend"] = $isfriend = "true";
						}
						else
						{
							$temparr["isfriend"] = $isfriend = "false";
						}
					}
					else {
						$profileuser = $user;
						$temparr["isowner"] = "true";
						$temparr["isfriend"] = $isfriend = "true";
					}

					if($isfriend == "true"){
						if(!empty($profileuser)) {

							$date = date("Y-m-d H:i:s");

							$sendpersonalmessage = $this->input->post("sendpersonalmessage");
							if($sendpersonalmessage == "no") {
								$image = "";

								if(isset($_FILES["userfile"]["name"]) && $_FILES["userfile"]["name"] != "") {
									$profilewalluploadpath = $this->config->item("profile_wall_post_original_upload_path");

									$config = array(
													"upload_path" => $profilewalluploadpath,
													"allowed_types" => "jpg|jpeg|gif|png"
												);

									$filename = $_FILES["userfile"]["name"];
									$filename = explode(".", $filename);
									$filename[0] = $filename[0].time().".".$filename[1];
									//$_FILES["userfile"]["name"] = $filename[0];

									$this->load->library("upload", $config);

									if($this->upload->do_upload()) {

										$image_data = $this->upload->data();

										$imagestypes = array(
															"profile_200x200_upload_path" => $this->config->item("profile_wall_post_150x150_upload_path"),
															"profile_50x50_upload_path" => $this->config->item("profile_wall_post_50x50_upload_path")
														);

										$this->load->library("image_lib");

										foreach ($imagestypes as $imagetype) {
											$width = 200;
											$heigth = 200;
											if($imagetype == $this->config->item("profile_wall_post_150x150_upload_path")) {
												$width = 250;
												$heigth = 250;
											}
											else if($imagetype == $this->config->item("profile_wall_post_50x50_upload_path")) {
												$width = 50;
												$heigth = 50;
											}

											$config = array(
															"source_image" => $image_data["full_path"],
															"new_image" => $imagetype,
															"maintain_ration" => true,
															"width" => $width,
															"height" => $heigth
															);
$config['source_image'] = $image_data["full_path"];
$exif = exif_read_data($config['source_image']);
if($exif && isset($exif['Orientation']))
{
	$ort = $exif['Orientation'];

	if ($ort == 6 || $ort == 5)
		$config['rotation_angle'] = '270';
	if ($ort == 3 || $ort == 4)
		$config['rotation_angle'] = '180';
	if ($ort == 8 || $ort == 7)
		$config['rotation_angle'] = '90';
}


if ( ! $this->image_lib->rotate())
{
	// Error Message here
	//echo $this->image_lib->display_errors();
}

$this->image_lib->clear();
$this->image_lib->initialize($config);

											$this->image_lib->resize();
										}
										$image = $image_data["file_name"];

									}
									else {
										$temparr["msg"] = "imageuploadingfail";
									}
									//$this->upload->display_errors();
								}

								$profilewallpost = array(
													"uid" => $uid,
													"status" => urlencode($this->input->post("status")),
													"link" => $this->input->post("link"),
													"image" => $image,
													"video" => $this->input->post("video"),
													"date" => $date
												);

								if($this->communitymodel->addprofilewallpost($profilewallpost) > 0) {
									$walluid = $this->input->post("walluserid");

									$info["link"] = $this->input->post("link");
									$info["linktitle"] = $this->input->post("linktitle");
									$info["linkdescription"] = "";
									$linkdescription = $this->input->post("linkdescription");
									if($linkdescription != "Enter a description" ) {
										$info["linkdescription"] = $this->input->post("linkdescription");
									}
									$info["linkimage"] = $this->input->post("linkimage");
									$info["isvideolink"] = $this->input->post("isvideolink");


									$info["uid"] = $uid;
									$info["status"] = urlencode($this->input->post("status"));
									$info["uname"] = $user->name;
									$info["image"] = $image;
									$info["video"] = $this->input->post("video");

									/*$info = array(
													"uid" => $uid,
													"status" => $this->input->post("status"),
													"uname" => $user->name,
													"image" => $image
											);*/

									$activity = array(
													"uid" => $profileuser->id,
													"content" => $this->config->item("profile_wall_post"),
													"info" => serialize($info),
													"date" => $date
												);
									$aid = $this->communitymodel->addactivity($activity);
									if($aid > 0) {
										if(!empty($image)) {
											$imagegallery = array(
																	"uid" => $profileuser->id,
																	"aid" => $aid,
																	"image" => $image,
																	"date" => $date
																);
											$this->communitymodel->addimagegallery($imagegallery);
										}

										$temparr["user"] = $profileuser->user_name;
										$temparr["msg"] = "success";
									}
									else {
										$temparr["msg"] = "fail";
									}
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
							else {
								$where = array("user_name" => $this->input->post("user"));

								$owner = $this->communitymodel->getuser($where);

								if(isset($owner) && !empty($owner)) {

									$message = array(
												"ownerid" => $owner->id,
												"uid" => $this->db_session->userdata("id"),
												"message" => urlencode($this->input->post("status")),
												"date" => date("Y-m-d H:i:s")
											);

									if($this->communitymodel->addmessage($message) > 0) {
										$temparr["user"] = $profileuser->user_name;
										$temparr["msg"] = "success";
									}
									else {
										$temparr["msg"] = "msgsendingfail";
									}
								}
								else {
									$temparr["msg"] = "invaliduser";
								}
							}
						}
						else {
							$temparr["msg"] = "invaliduser";
						}
					}else{
						$temparr["msg"] = "unkownfriend";
					}

				}
				else {
					$temparr["msg"] = "invalidaccount";
				}

				array_push($response, $temparr);
				echo json_encode(array("profilewallpost" => $response));
			}
		}

		/**
		 * This function is used to follow friend.
		 */
		function followfriend() {

			if($this->input->post("user_name")) {

				$response = array();
				$temparr = array();

				$username = $this->input->post("user_name");
				$followid = $this->db_session->userdata("id");

				$where = array(
								"user_name" => $username
							);
				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {

					$where = array(
									"id" => $followid
								);
					$followersuser = $this->communitymodel->getuser($where);

					if(isset($followersuser) && $followersuser != "") {
						$where = array(
										"uid" => $user->id
									);

						$friendsfollowers = $this->communitymodel->getfollowers($where);

						if(isset($friendsfollowers) && $friendsfollowers != "") {

							$followers = array();
							$isalreadyfollow = false;

							if($friendsfollowers->followers != "") {
								$followers = unserialize($friendsfollowers->followers);
								if(in_array($followid, $followers)) {
									$temparr["msg"] = "alreadyfollowed";
									$isalreadyfollow = true;
								}
							}

							if(!$isalreadyfollow) {
								$where = array(
												"uid" => $user->id
											);
								$followers[] = $followid;
								$followers = array_values($followers);
								$newfollower = array(
													"followers" => serialize($followers)
												);

								if($this->communitymodel->updatefollowers($newfollower,$where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						else {
							/********  add followers ************/
							$followersid[] = $followid;

							$followers = array(
												"uid" => $user->id,
												"followers" => serialize($followersid)
											);
							if($this->communitymodel->addfollowers($followers) > 0) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}

						$where = array(
										"uid" => $followid
									   );
						$friendsfollowings = $this->communitymodel->getfollowing($where);

						if(isset($friendsfollowings) && $friendsfollowings != "") {

							$newfollowing = array();
							$isalreadyfollowings = false;

							if($friendsfollowings->following != "") {
								$following = unserialize($friendsfollowings->following);
								if(in_array($user->id, $following)) {
									$temparr["msg"] = "alreadyfollowings";
									$isalreadyfollowings = true;
								}
							}

							if(!$isalreadyfollowings) {
								/** update following **/
								$newfollowing = unserialize($friendsfollowings->following);
								$newfollowing[] = $user->id;
								$newfollowing = array_values($newfollowing);
								$newfollowings = array(
														"following" => serialize($newfollowing)
													);

								if($this->communitymodel->updatefollowing($newfollowings, $where)) {
									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						else {
							/********  add followings ************/
							$followingsid[] = $user->id;

							$followings = array(
												"uid" => $followid,
												"following" => serialize($followingsid)
											);
							if($this->communitymodel->addfollowings($followings) > 0) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "fail";
							}
						}
					}
					else {
						$temparr["msg"] = "usernotfound";
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

			array_push($response, $temparr);
			echo json_encode(array("follow" => $response));
		}
	}

	/*** This function is used to unfollow friend from his followers. */
		function unfollow() {

			if($this->input->post("user_name")) {
				$response = array();

				$username = $this->input->post("user_name");
				$followid = $this->db_session->userdata("id");

				$where = array(
							"user_name" => $username
						);
				$user = $this->communitymodel->getuser($where);

				if(isset($user) && $user != "") {

					$where = array(
							"id" => $followid
						);
					$followuser = $this->communitymodel->getuser($where);
					if(isset($followuser) && $followuser != "") {

						$where = array(
								"uid" => $user->id
								);
						$followersuser = $this->communitymodel->getfollowers($where);
						if(isset($followersuser) && $followersuser != "") {
								$follow = array();
								$isfollow = false;
								if($followersuser->followers != "") {
									$follow = unserialize($followersuser->followers);
									if(in_array($followuser->id, $follow)) {
										$isfollow = true;
									}
									else {
										$temparr["msg"] = "notanfollow";
									}
								}

								if($isfollow) {

									$follow = array_diff($follow, array($followuser->id));

									$newfollower = array(
														"followers" => serialize($follow)
													);
									if($this->communitymodel->updatefollowers($newfollower, $where)) {
										$temparr["msg"] = "success";
									}
									else {
										$temparr["msg"] = "fail";
									}
								}
								else {
									$temparr["msg"] = "notfollow";
								}
							}
							else {
								$temparr["msg"] = "nofollowers";
							}
						$where = array(
								"uid" => $followid
								);
						$followinguser = $this->communitymodel->getfollowing($where);
						if(isset($followinguser) && $followinguser != "") {
								$followings = array();
								$isfollowing = false;
								if($followinguser->following != "") {
									$followings = unserialize($followinguser->following);
									if(in_array($user->id, $followings)) {
										$isfollowing = true;
									}
									else {
										$temparr["msg"] = "notanfollowing";
									}
								}

								if($isfollowing) {

									$followings = array_diff($followings, array($user->id));

									$newfollowings = array(
														"following" => serialize($followings)
													);

									if($this->communitymodel->updatefollowing($newfollowings, $where)) {
										$temparr["msg"] = "success";
									}
									else {
										$temparr["msg"] = "fail";
									}
								}
								else {
									$temparr["msg"] = "notfollow";
								}
							}
							else {
								$temparr["msg"] = "nofollowers";
							}
					}
				}
				else {
					$temparr["msg"] = "usernotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("follow" => $response));
			}
		}

	/**********  This function is used for comment on group wall post  **********/

		function commentongroupwall() {
			if($this->input->post("groupwallpostid") && $this->input->post("profileownerid")&& $this->input->post("gid") && $this->input->post("comment")){

				$response = array();

				$groupwallpostid = $this->input->post("groupwallpostid");
				$gid = $this->input->post("gid");
				$profileownerid = $this->input->post("profileownerid");
				$comment = $this->input->post("comment");
				$uid = $this->db_session->userdata("id");

				if($gid > 0 && $groupwallpostid > 0 && $uid > 0) {
					$where = array(
									"id" => $gid,
									"isdeleted" => "0"
								);

					$group = $this->communitymodel->getgroup($where);
					if(isset($group) && $group != "") {

							$isgroupowner = false;
							if($uid != "") {
								if($group->uid == $uid) {
									$isgroupowner = true;
									$temparr["isgroupowner"] = "true";
								}
							}

							$isadmin = false;
							if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
							{
								$isadmin = true;
								$temparr["isadmin"] = "true";
							}

							$isgroupmember = false;
							if(!$isgroupowner && !$isadmin) {
								if($group->members != "") {

									if(in_array($uid, unserialize($group->members))) {
										$isgroupmember = true;
										$temparr["isgroupmember"] = "true";
									}
									else {
										$temparr["isgroupmember"] = "false";
									}
								}
								else {
									$temparr["isgroupmember"] = "false";
								}
							}

							if($isgroupowner || $isgroupmember || $isadmin) {

								$temparr["ispermitted"] = "true";

								$where = array(
											"id" => $groupwallpostid
											);
								$groupwallpost = $this->communitymodel->getgroupwallpost($where);

								if(isset($groupwallpost) && $groupwallpost != "") {
									$date = date("Y-m-d H:i:s");

									$groupwallcomment = array(
															"gid" => $gid,
															"uid" => $uid,
															"comment" => $this->input->post("comment"),
															"groupwallpostid" => $groupwallpostid,
															"date" => $date
														);

									$commentid = $this->communitymodel->addgroupcomment($groupwallcomment);

									if($commentid > 0) {
										$info = array(
													"gid" => $gid,
													"gseo" => $group->seo,
													"gname" => $group->name,
													"message" => $groupwallpost->message,
													"comment" => $comment,
													"cid" => $commentid
												);

										$activity = array(
														"uid" => $uid,
														"content" => $this->config->item("comment_on_groupwallpost"),
														"info" => serialize($info),
														"date" => $date
													);

										$this->communitymodel->addactivity($activity);

										$activity = array(
														"uid" => $uid,
														"gid" => $gid,
														"content" => $this->config->item("comment_on_groupwallpost"),
														"info" => serialize($info),
														"date" => $date
													);
										$this->communitymodel->addgroupactivity($activity);

										$temparr["msg"] = "success";
									}
									else {
										$temparr["msg"] = "fail";
									}

								}
								else {
									$temparr["msg"] = "groupwallpostnotfound";
								}

							}
							else {
								$temparr["ispermitted"] = "false";
							}

						}
						else {
							$temparr["msg"] = "groupnotfound";
						}

				}else {
					$temparr["msg"] = "fail";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupwallpostcomments" => $response));

			}

		}


		/****   delete group wall post comment *********/

		function deletegroupwallpostcomment() {

			if($this->input->post("gid") && $this->input->post("groupwallpostid") && $this->input->post("cid")) {

				$response = array();

				$gid = $this->input->post("gid");
				$groupwallpostid = $this->input->post("groupwallpostid");
				$cid = $this->input->post("cid");
				$uid = $this->db_session->userdata("id");

				$where = array(
							"id" => $gid,
							"isdeleted" => "0"
						);

				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}

					$isadmin = false;
					if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
					{
						$isadmin = true;
						$temparr["isadmin"] = "true";
					}

					$isgroupmember = false;
					if(!$isgroupowner && !$isadmin) {
						if($group->members != "") {
							if(in_array($uid, unserialize($group->members))) {
								$isgroupmember = true;
								$temparr["isgroupmember"] = "true";
							}
							else {
								$temparr["isgroupmember"] = "false";
							}
						}
						else {
							$temparr["isgroupmember"] = "false";
						}
					}

					$where = array(
								"id" => $cid
							);

					$groupcomment = $this->communitymodel->getgroupcomment($where);

					if(isset($groupcomment) && $groupcomment != "") {

						$iscommentowner = false;
						if($isgroupmember) {

							if($reply->uid == $uid) {
								$isreplyowner = true;
								$temparr["iscommentowner"] = "true";
							}
							else {
								$temparr["iscommentowner"] = "false";
							}
						}

						$role = $this->db_session->userdata("role");
						if($role == "superadmin" || $role == "admin") {
							$isgroupowner = $isgroupmember = $iscommentowner = true;
						}

						if($isgroupowner || ($isgroupmember && $iscommentowner) || $isadmin) {
							$temparr["ispermitted"] = "true";

							$where = array(
								"id" => $cid,
								"gid" => $gid,
								"groupwallpostid" => $groupwallpostid,
								"uid" => $uid
							);

							if($this->communitymodel->deletegroupwallpostcomment($where)) {
								$temparr["msg"] = "success";
							}
							else {
								$temparr["msg"] = "failtodelete";
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "commentnotfound";
					}
				}
				else {
					$temparr["msg"] = "groupnotfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("groupwallpostcomments" => $response));
			}
		}

		/*******This function is used for delete group or update,set isdeleted =1     **********/
		function deleteGroup(){
			if($this->input->post("gid")){
				$response = array();
				$gid = $this->input->post("gid");
				$uid = $this->db_session->userdata("id");

				$where = array(
						"id" => $gid,
						"isdeleted" => "0"
					);
				$group = $this->communitymodel->getgroup($where);

				if(isset($group) && $group != "") {

					$isgroupowner = false;
					if($group->uid == $uid) {
						$isgroupowner = true;
						$temparr["isgroupowner"] = "true";
					}else{
						$temparr["isgroupowner"] = "false";
					}
					if($isgroupowner){
						$where = array(
										"id" => $gid,
										"uid" => $uid
									);
						$updategroup = array(
												"isdeleted" => "1"
												);
					 	$this->communitymodel->updateisdeletedgroup($updategroup, $where);

					}

				}else{
					$temparr["msg"]="groupnotfound";
				}
				array_push($response, $temparr);
				echo json_encode(array("deletegroup" => $response));

			}
		}

		/**
		 * Function is used to upload profile pictures **/
		function uploadprofileimage() {
			//if($this->input->post("somekey") == "somekey") {
				$userid = $this->db_session->userdata("id");
        		$count = $this->input->post('count');

				$response = array();

				if($userid > 0 && $count < 5) {
					//$count = $count+1;

	        		$this->load->model("communitymodel");

					$userimguploadpath = $this->config->item("user_upload_path");

					$config = array(
								"upload_path" => $userimguploadpath,
								"allowed_types" => "jpg|jpeg|gif|png",
								"maintain_ratio" => true,
							);
					$filename = $_FILES["userfile"]["name"];
					$filename = explode(".", $filename);
					$filename[0] = $filename[0].time().".".$filename[1];
					$_FILES["userfile"]["name"] = $filename[0];

					$this->load->library("upload", $config);

					if($this->upload->do_upload()) {

						$image_data = $this->upload->data();

						$imagestypes = array(
											"index_upload_path" => $this->config->item("user_upload_path"),
											"user_250x250_upload_path" => $this->config->item("user_250x250_upload_path"),
											"user_640x640_upload_path" => $this->config->item("user_640x640_upload_path"),
											"user_40x40_upload_path" => $this->config->item("user_40x40_upload_path"),
											"user_25x25_upload_path" => $this->config->item("user_25x25_upload_path")
										);

						$this->load->library("image_lib");

						foreach ($imagestypes as $imagetype) {

							$width = 640;
							$heigth = 640;

							if($imagetype == $this->config->item("user_upload_path")) {
								$width = 2050;
								$heigth = 2050;
							}
							else if($imagetype == $this->config->item("user_250x250_upload_path")) {
								$width = 250;
								$heigth = 250;
							}
							else if($imagetype == $this->config->item("user_640x640_upload_path")) {
								$width = 500;
								$heigth = 500;
							}
							else if($imagetype == $this->config->item("user_40x40_upload_path")) {
								$width = 40;
								$heigth = 40;
							}
							else if($imagetype == $this->config->item("user_25x25_upload_path")) {
								$width = 25;
								$heigth = 25;
							}

							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
$config['source_image'] = $image_data["full_path"];

//silencing error reporting for unsupported image (png)
$exif = @exif_read_data($config['source_image']);
if($exif && isset($exif['Orientation']))
{
	$ort = $exif['Orientation'];

	if ($ort == 6 || $ort == 5)
		$config['rotation_angle'] = '270';
	if ($ort == 3 || $ort == 4)
		$config['rotation_angle'] = '180';
	if ($ort == 8 || $ort == 7)
		$config['rotation_angle'] = '90';
}


if ( ! $this->image_lib->rotate())
{
	// Error Message here
	//echo $this->image_lib->display_errors();
}

$this->image_lib->clear();
$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
						//
						//$recipeimages = $this->crudmodel->getimagesbyid($recipeid);
						$userimages = $this->communitymodel->getimagesbyuserid($userid);

						if(isset($userimages)) {
							$userimages = $userimages.",".$image_data["file_name"];
							$userimg = array(
									"uid" => $userid,
									"images" => $userimages
								);

							$where = array(
											"uid" => $this->db_session->userdata("id")
										);
							if($this->communitymodel->updateuserimages($userimg,$where)) {
								$temparr["images"] = $image_data["file_name"];
								$temparr["msg"] = "success";
								array_push($response, $temparr);
								echo json_encode(array("images" => $response));
							}
							/*else{
								$userimages = $image_data["file_name"];
								$userimg = array(
										"uid" => $userid,
										"images" => $userimages
									);

								if($this->communitymodel->adduserimages($userimg)) {
									$temparr["images"] = $image_data["file_name"];
									$temparr["msg"] = "success";
									array_push($response, $temparr);
									echo json_encode(array("images" => $response));
								}
							}*/
						}
						/*if(empty($userimages)) {
							$userimages = $image_data["file_name"];
							$userimg = array(
									"uid" => $userid,
									"images" => $userimages
								);

							if($this->communitymodel->adduserimages($userimg)) {
								$temparr["images"] = $image_data["file_name"];
								$temparr["msg"] = "success";
								array_push($response, $temparr);
								echo json_encode(array("images" => $response));
							}
						}*/
					}
					else {
						$temparr["msg"] = "fail";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
				}
				else {
					$temparr["msg"] = "outoflimit";
					array_push($response, $temparr);
					echo json_encode(array("images" => $response));
				}
			//}
		//echo "fail";
		}

		function deleteprofileimage() {
			//$recipeid = $this->input->post("recipeid");
			$uid = $this->input->post("uid");
			$filename = $this->input->post("filename");
            log_message('error', $uid);
            log_message('error', $filename);
			$filename = trim($filename);

			if($uid && $filename) {
				//$this->load->model("crudmodel");

				$where = array(
						"id" => $this->db_session->userdata("id")
				);

				$result = $this->communitymodel->getuser($where);
				if($filename == $result->image){
					$image = array("image" => "noavatar.png");
					$this->communitymodel->updateuser($image,$where);
				}

				$userimages = $this->communitymodel->getimagesbyuserid($uid);
				if($userimages != "") {
					$issingleimg = false;
					$imagearr = explode(",", $userimages);
					$imagecnt = count($imagearr);
					if($imagecnt != 0) {
						if($imagecnt - 1 == 1) {
							$issingleimg = true;
						}
					}
					$image = $filename.",";
					$isfound = strpos($userimages, $image);
					if($isfound === FALSE) {
						$userimages = str_replace($filename, "", $userimages);
						if($issingleimg) {
							$userimages = str_replace(",", "", $userimages);
						}
					}
					else {
						$userimages = str_replace($image, "", $userimages);
					}
				}

				$usersnewimgs = array(
							"images" => $userimages
						);

				$response = array();

				$where = array(
								"uid" => $this->db_session->userdata("id")
							);

				if($this->communitymodel->updateuserimages($usersnewimgs,$where)) {

					$uploadpath = $this->config->item("user_40x40_upload_path");

					$temparr["path"] = $uploadpath;

					if(file_exists($uploadpath."/".$filename)) {
						unlink($uploadpath."/".$filename);

						$uploadpath = $this->config->item("user_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}

						$uploadpath = $this->config->item("user_250x250_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}

						$uploadpath = $this->config->item("user_640x640_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}

						$uploadpath = $this->config->item("user_25x25_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}

						/*$uploadpath = $this->config->item("recipe_home_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}*/

						$temparr["msg"] = "success";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
					else {
						$temparr["msg"] = "not found";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
				}
				else {
					$temparr["msg"] = "fail";
					array_push($response, $temparr);
					echo json_encode(array("images" => $response));
				}
			}
		}
	function changeprofileimage(){
		$uid = $this->input->post("uid");
		$filename = $this->input->post("filename");
			$filename = trim($filename);

			if($uid && $filename) {
				$usersnewimg = array(
							"image" => $filename
						);
				$response = array();
				$where = array(
								"id" => $this->db_session->userdata("id")
							);
				if($this->communitymodel->updateuser($usersnewimg,$where)) {

						$temparr["msg"] = "success";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
				}
				else {
						$temparr["msg"] = "fail";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
			}
	}

		/**
		 * This function is used to get recipes.
		 */
		function getrecipes() {
			//if($this->input->post("typeid")) {


				$response = array();

				$this->load->model("crudmodel");
				//print_r($this->input->post("typeid"));exit;
				$where = array(
							"courseid" => $this->input->post("courseid"),
							"approved" => "1",
						);
				//$or = array("categoryid"=>$this->input->post("typeid"));
				$or = "";
				//$recipes = $this->crudmodel->getrecipes($where);
				$recipes = $this->crudmodel->getrecipebytypeorcategory($where,$or);

				if(isset($recipes) && !empty($recipes)) {

					foreach($recipes as $recipe) {

						$temparr["id"] = $recipe->id;
						$temparr["title"] = $recipe->title;
						$recipeimage = explode(',', $recipe->images);

						if(isset($recipeimage[0]) && !empty($recipeimage[0])){
							$temparr["image"] = $recipeimage[0];
						}else{
							$temparr["image"] = "defaultrecipe.png";
						}

						$temparr["msg"] = "success";

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "norecipes";
					array_push($response, $temparr);
				}

				echo json_encode(array("recipes" => $response));
			}
		//}

		/**
		 * This function is used to add meal
		 */
		function addmeal() {
			//if($this->input->post("somekey")) {
				$response = array();

				$recipeid = $this->input->post("recipe");

				$this->load->model("crudmodel");
				$recipe = $this->crudmodel->getrecipebyid($recipeid);

				if(isset($recipe) && $recipe != "") {

					$image = "defaultrecipe.png";
					if($recipe->images != "") {
						$images = explode(",", $recipe->images);
						if(count($images)) {
							if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
								$image = $images[0];
							}
						}
					}

					$uid = $this->db_session->userdata("id");

					$shoppinglist = $this->crudmodel->getshoppinglistbyrecipeid($recipe->id);
					$shoppinlistcount = 0;
					if(isset($shoppinglist) && !empty($shoppinglist)) {
						$ingredients = $shoppinglist->ingredients;
						$ingredients = explode("|", $ingredients);
						$shoppinlistcount = count($ingredients);
					}

					$price = $this->input->post("price");
					if(empty($price)) {
						$price = 0;
					}

					$typeid = $this->input->post("type");
					$typename = $this->crudmodel->gettypenamebyid($typeid);

					$courseid = $this->input->post("course");
					$coursename = $this->crudmodel->getcoursenamebyid($courseid);

					if(!isset($coursename)||empty($coursename)){
						$coursename = "";
					}

					/* $url = base_url();
					$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
					if(!empty($categoryname)) {
						$url .= "recipe/details/".$categoryname."/".$recipe->title;
					} */
					$url = base_url()."recipe/details/".$recipe->seo;

					$date = date("Y-m-d H:i:s", strtotime($this->input->post("date")));
					$meal = array(
								"uid" => $uid,
								"recipeid" => $recipeid,
								"recipetitle" => $recipe->title,
								"shoppinlistcount" => $shoppinlistcount,
								"price" => $price,
								"image"	=> $image,
								"type" => $coursename,
								"url" => $url,
								"date" => $date
							);

					$mealid = $this->communitymodel->addmeal($meal);

					if($mealid > 0) {

						$where = array(
									"id" => $mealid,
									"uid" => $uid
								);

						$meal = $this->communitymodel->getmeal($where);

						if(isset($meal) && !empty($meal)) {
					 		$recipetitle = $this->crudmodel->getrecipetitlebyid($meal->recipeid);
							//$title = ucfirst($meal->type)."-".$recipetitle;
							$title = $meal->type."-".$recipetitle;

							$shoppinlistcount = $meal->shoppinlistcount;
							$description = "(Shoppinglist $shoppinlistcount)";

							$temparr["title"] = $title;
							$temparr["image"] = $image;
							$temparr["description"] = $description;
							$temparr["price"] = $price;
							$temparr["url"] = $url;
							$temparr["msg"] = "success";
						}
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("meal" => $response));
			}
		//}

		/**
		 * This function is used to update meal.
		 */
		function updatemeal() {
			if($this->input->post("mealid") && $this->input->post("days")) {
				$response = array();

				$mealid = $this->input->post("mealid");
				$uid = $this->db_session->userdata("id");

				$where = array(
								"id" => $mealid,
								"uid" => $uid
							);

				$meal = $this->communitymodel->getmeal($where);

				if(isset($meal) && $meal != "") {

					$days = $this->input->post("days");

					$date = $meal->date;
					$date = strtotime($date);
					$newdate = $date;
					if($days < 0) {
						$number = substr($days, 1);
						if($number == 1) {
							$newdate = strtotime("-24 hours", $date);
						}
						else {
							$newdate = strtotime("-$number days", $date);
						}
					}
					else {
						$number = substr($days, 1);
						if($number == 1) {
							$newdate = strtotime("+24 hours", $date);
						}
						else {
							$newdate = strtotime("+$days days", $date);
						}
					}

					$newmeal = array(
								"date" => date("Y-m-d H:i:s", $newdate)
							);

					if($this->communitymodel->updatemeal($newmeal, $where)) {
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("meal" => $response));
			}
		}

		/**
		 * This function is used to delete meal form mealplanner calender.
		 */
		function deletemeal() {
			if($this->input->post("mealid")) {
				$response = array();

				$mealid = $this->input->post("mealid");
				$uid = $this->db_session->userdata("id");

				$where = array(
								"id" => $mealid,
								"uid" => $uid
							);
				$meal = $this->communitymodel->deletemeal($where);

				if(isset($meal) && $meal != "") {

					if($this->communitymodel->deletemeal($where)){
						$temparr["msg"] = "success";
					}else{
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}
				array_push($response, $temparr);
				echo json_encode(array("meal" => $response));
			}
		}

		/**
		 * This function is used to add meal
		 */
		function getallmeals() {

			if($this->input->post("somekey") && $this->input->post("uname")) {

				$response = array();

				$uid = "";

				$isowner = $this->input->post("isowner");
				if($isowner) {
					$uid = $this->db_session->userdata("id");
				}
				else {
					$where = array(
							"user_name" => $this->input->post("uname")
						);

					$user = $this->communitymodel->getuser($where);
					$uid = $user->id;
				}

				$where = array(
							"uid" => $uid
						);

				$meals = $this->communitymodel->getallmeals($where);

				if(isset($meals) && !empty($meals)) {
					$this->load->model("crudmodel");
					foreach($meals as $meal) {

						$temparr["id"] = $meal->id;
						$temparr["uid"] = $meal->uid;
						$temparr["recipeid"] = $meal->recipeid;
						$temparr["recipetitle"] = $meal->recipetitle;
						$temparr["shoppinlistcount"] = $meal->shoppinlistcount;
						$temparr["price"] = $meal->price;
						$temparr["url"] = $meal->url;

						$temparr["image"] = "defaultrecipe.png";
						if(file_exists($this->config->item("recipe_detail_upload_path")."/".$meal->image)) {
							$temparr["image"] = $meal->image;
						}

						$temparr["type"] = $meal->type;
						$temparr["date"] = $meal->date;

						//$recipetitle = $this->crudmodel->getrecipetitlebyid($meal->recipeid);
						//$title = ucfirst($meal->type)."-".$meal->recipetitle;
						$title = $meal->type."-".$meal->recipetitle;

						$start = "";
						if(!empty($meal->date)) {
							$date = explode(" ", $meal->date);
							if(count($date)) {
								$start = $date[0];
							}
						}

						$shoppinlistcount = $meal->shoppinlistcount;
						$description = "(Shoppinglist $shoppinlistcount)";

						$temparr["title"] = $title;
						$temparr["start"] = $start;
						$temparr["description"] = $description;
						$temparr["msg"] = "success";

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nomeals";
					array_push($response, $temparr);
				}

				echo json_encode(array("meals" => $response));
			}
		}

		/**
		 * This metod is used to send personal messages.
		 */
		function sendpersonalmessage() {
			if($this->input->post("somekey") && $this->input->post("personalmessage")) {
				$response = array();

				$uid = $this->db_session->userdata("id");

				$where = array(
							"id" => $uid
						);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && !empty($user)) {

					$where = array(
							"user_name" => $this->input->post("user_name")
						);

					$owner = $this->communitymodel->getuser($where);

					if(isset($owner) && !empty($owner)) {

						$message = array(
									"ownerid" => $owner->id,
									"uid" => $uid,
									"message" => $this->input->post("personalmessage"),
									"date" => date("Y-m-d H:i:s")
								);

						$messageid = $this->communitymodel->addmessage($message);

						if($messageid > 0) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "notfound";
					}
				}
				else {
					$temparr["msg"] = "invalidaccount";
				}

				array_push($response, $temparr);
				echo json_encode(array("message" => $response));
			}
		}

		/**
		 * This function is used to get personal messages by user.
		 */
		function getmessagesbyuser() {

			if($this->input->post("somekey") != "" && $this->input->post("user_name")) {


				$response = array();

				$ownerid = $this->db_session->userdata("id");
				$where = array(
						"id" => $ownerid
					);
				$owner = (array) $this->communitymodel->getuser($where);

				if(isset($owner) && !empty($owner)) {

					$user_name = $this->input->post("user_name");
					$where = array(
									"user_name" => $user_name
								);
					$user = $this->communitymodel->getuser($where);

					// to get data only which is usable from $owner and storing it in $filterowner
					$filterowner = array(
										"id" => $owner["id"],
										"user_name" => $owner["user_name"],
										"name" => $owner["name"],
										"image" => $owner["image"]
									);

					$temparr["owner"] = $filterowner;

					// to get data only which is usable from $user and storing it in $filteruser
					$filteruser = array(
										"id" => $user->id,
										"user_name" => $user->user_name,
										"name" => $user->name,
										"image" => $user->image
									);

					$temparr["user"] = $filteruser;

					$uid = $user->id;

					/** Code for updating messages from unread to read **/
					if($this->input->post("update") && $this->input->post("update")=='true')
					{
						$where = array("ownerid" => $ownerid,"uid" => $uid, "isread"=>'0');
						$this->communitymodel->updatemessages($where);
					}
					/** Code for updating messages from unread to read **/

					//$where = array("ownerid" => $ownerid, "uid" => $uid, "isread"=>'1');
					//$where1 = array("ownerid" => $uid, "uid" => $ownerid, "isread"=>'1');
					$where = "ownerid ='$ownerid' AND uid ='$uid' OR ownerid ='$uid' AND uid ='$ownerid' AND isread='1'";
					$orderby = array("field" => "date",	"order" => "asc",);

					$messages = $this->communitymodel->getmessages($where, "", $orderby);
					//print_r($messages); exit;
					if(isset($messages) && $messages != "") {

						$messagescnt = count($messages);
						$nomessagescnt = 0;

						foreach($messages as $message) {

							$messagetext = $message->message;

							if(!empty($messagetext)) {

								$temparr["id"] = $message->id;
								$temparr["ownerid"] = $message->ownerid;
								$temparr["uid"] = $message->uid;
								$temparr["message"] = $message->message;
								$temparr["date"] = $message->date;

								$messagedate = date("Y-m-d", strtotime($message->date));
								$todays = date("Y-m-d");
								if($messagedate == $todays) {
									$temparr["timeago"] = $this->_timeago($message->date);
								}
								else {
									$temparr["timeago"] = date("Y-m-d", strtotime($message->date));
								}

								$temparr["name"] = "";
								$temparr["user_name"] = "";
								$userimg = "noavatar.png";

								$where = array(
									"id" => $message->uid
								);
								$user = $this->communitymodel->getuser($where);
								if(isset($user) && $user != "") {
									$temparr["name"] = $user->user_name;
                                    if(!empty($user->name)) {
                                       $temparr["name"] = $user->name;
                                    }
									$temparr["user_name"] = $user->user_name;

									if($user->image != "") {
										$userimg = $user->image;
									}
								}

								$temparr["image"] = $userimg;

								$where = array(
												"messageid" => $message->id
											);

								/*$messagesreplies = $this->communitymodel->getmessagesreplies($where);
								if(isset($messagesreplies) && !empty($messagesreplies)) {
									$messagereplyarr = array();
									foreach($messagesreplies as $messagereply) {
										//$temparr["messagesreplies"][$message->id] = (array) $messagereply;
										//$temparr["messagesreplies"] = $messagereply;
										//$temparr["messagesreplies"][] = (array) $messagereply;
										$temparr["messagesreplies"][] = (array) $messagereply;
									}
									//$temparr["messagesreplies"][$message->id] = (array) $messagereplyarr;
									//$temparr["messagesreplies"][$message->id] = array_values($messagereplyarr);
								}*/

								$temparr["msg"] = "success";

								array_push($response, $temparr);
							}
							else {
								$nomessagescnt++;
							}
						}
						if($messagescnt == $nomessagescnt) {
							$temparr["msg"] = "nomessages";
							array_push($response, $temparr);
						}

					}
					else {
						$temparr["msg"] = "nomessages";
						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "notfound";
					array_push($response, $temparr);
				}

				echo json_encode(array("messages" => $response));
			}
		}

		/**
	 * This function is used to load messages view.
	 */
	function messages() {

		$uid = $this->db_session->userdata("id");

		$where = array("id" => $uid);
		$owner = $this->communitymodel->getuser($where);


		if(isset($owner) && !empty($owner)) {
			$where = array("ownerid" => $uid);
			$groupby = "";
			$orderby = "";

			$messages = $this->communitymodel->getmessages($where, $groupby, $orderby);

			if(isset($messages) && !empty($messages)) {

				$newmessages = array();
				//$newmessagesreply = array();
				$data["segment"] = "";
				foreach($messages as $message) {
					$array = (array) $message;

					$where = array("id" => $message->uid);
					$user = $this->communitymodel->getuser($where);
					$array["image"] = "noavatar.png";
					if(isset($user) && !empty($user)) {
						$array["name"] = $user->name;
						$array["user_name"] = $user->user_name;

						if(!empty($user->image)) {
							if(file_exists($this->config->item("user_40x40_upload_path")."/".$user->image)) {
								$array["image"] = $user->image;
							}
						}
					}

					$messagedate = date("Y-m-d", strtotime($message->date));
					$todays = date("Y-m-d");
					if($messagedate == $todays) {
						$array["timeago"] = $this->_timeago($message->date);
					}
					else {
						$array["timeago"] = date("Y-m-d", strtotime($message->date));
					}

					/* $where = array(
									"messageid" => $message->id
								);

					$array["messagesreplies"] = $this->communitymodel->getmessagesreplies($where); */

					$object = (object) $array;
					$newmessages[] = $object;

					if($data["segment"] == "") {
						$data["segment"] = $user->user_name;
					}

					if(!isset($data["userdisplayname"])) {
						$data["userdisplayname"] = $user->name;
					}
				}

				for($i = 0; $i < count($messages); $i++) {
					$messages[$i] = $newmessages[$i];
				}
			}

			//echo "</br>messages: "; print_r($messages);

			$data["owner"] = $owner;
			$data["messages"] = $messages;
			$data["ajaxrequest"] = TRUE;
		}
		//$data["page"] = "community/messages";
		$this->load->view("community/template/messagecontainerright", $data);
	}

		/**
		 * This method is used to get messages replies. NOT USED
		 */
		function getmessagesreplies() {
			if($this->input->post("somekey") != "" && $this->input->post("messageid")) {
				$where = array(
								"messageid" => $this->input->post("messageid")
							);

				$messagesreplies = $this->communitymodel->getmessagesreplies($where);
				if(isset($messagesreplies) && !empty($messagesreplies)) {
					foreach($messagesreplies as $messagereply) {
						$temparr = (array) $messagereply;
						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nomessagesreplies";
				}

				echo json_encode(array("messagesreplies" => $response));
			}
		}

		/**
		 * This function is used to add reply on message.
		 */
		function addmessagereply() {
			if($this->input->post("messageid") && $this->input->post("ownerid") && $this->input->post("reply")) {
				$response = array();

				$uid = $this->db_session->userdata("id");

				$where = array(
							"id" => $uid
						);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && !empty($user)) {

					$temparr["user"] = (array) $user;

					$ownerid = $this->input->post("ownerid");

					$where = array(
									"id" => $ownerid
								);

					$owner = $this->communitymodel->getuser($where);

					if(isset($owner) && !empty($owner)) {

						$reply = $this->input->post("reply");
						$date = date("Y-m-d H:i:s");

						$messagereply = array(
												"messageid" => $this->input->post("messageid"),
												"ownerid" => $owner->id,
												"uid" => $uid,
												"reply" => $reply,
												"date" => $date
											);

						if($this->communitymodel->addmessagesreply($messagereply) > 0) {

							// if one user reply on message it means we also need to say other user that u have incoming message i.e reply from user
							// so add in message table also, here the reply becomes message for user
							$message = array(
												"ownerid" => $owner->id,
												"uid" => $uid,
												"message" => $this->input->post("reply"),
												"date" => date("Y-m-d H:i:s")//,
												//"isreply" => "1"
											);

							if($this->communitymodel->addmessage($message) > 0) {
								$temparr["reply"] = $reply;
								$temparr["date"] = $date;
								$temparr["timeago"] = $this->_timeago($date);

								$temparr["msg"] = "success";
							}

							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "notfound";
					}
				}
				else {
					$temparr["msg"] = "invalidaccount";
				}

				array_push($response, $temparr);
				echo json_encode(array("messagereply" => $response));
			}
		}

		/**
		 * This function is used to update messages to notified i.e 0 to 1.
		 */
		function updateMessages() {
			if($this->input->post("somekey")) {
				$response = array();

				$uid = $this->db_session->userdata("id");

				$where = array(
							"id" => $uid
						);

				$user = $this->communitymodel->getuser($where);

				if(isset($user) && !empty($user)) {
					$where = array("ownerid" => $uid);
					$messages = array("isnotified" => "1","isread"=>"1");

					if($this->communitymodel->updatemessage($messages, $where)) {
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}

				array_push($response, $temparr);
				echo json_encode(array("message" => $response));
			}
		}

	/**
	 * function is used to show the user name list
	 */
	/**function getusernames() {
		if($this->input->post("name")) {

			$response = array();

			//$this->load->model("crudmodel");
			$where = array("user_name" => $this->input->post("name"));
			$names = $this->communitymodel->getusernames($where);

			if(isset($names) && !empty($names)) {

				foreach($names as $name) {

					$temparr["name"] = $name->user_name;
					$temparr["msg"] = "success";
					array_push($response, $temparr);
				}
			}
			else {
					$temparr["msg"] = "nousername";
					array_push($response, $temparr);
			}

			echo json_encode(array("names" => $response));
		}
	}**/

	/**
	 * This function is used to show the user name list.
	 */
	function autocomplete() {
		if($this->input->post("countryid") || $this->input->post("countryid") == "0" && $this->input->post("membername")) {
			$uid = $this->db_session->userdata("id");
			$countryid = $this->input->post("countryid");
			$uname = $this->input->post("membername");

			$members = $this->communitymodel->get_autocomplete($uname,$countryid);

			if(isset($members) && !empty($members)) {
				echo "<ul>";
					foreach($members as $row):
						$cntr_yname = "";

						$where = array("user_name" => $row->user_name);
						$user = $this->communitymodel->getuser($where);

						if(!empty($countryid))
							$cntryname = $this->communitymodel->getcountryname($countryid);
						else
							$cntryname = $this->communitymodel->getcountryname($user->country_id);

						if(!empty($cntryname))
							$cntr_yname = $cntryname->name;

						$isrequested="";
						$where = array("uid" => $uid);
						$isfriend = $this->communitymodel->isfriend($where, $uid, $user->id);
						if(!$isfriend){
							$where = array("uid" => $user->id);
							$isrequested = $this->communitymodel->isfriendrequested($where, $uid);
						}

						$addbtnstyle = "display: none;";
						$cancelbtnstyle = "display: none;";
						$unfriendbtnstyle = "display: none;";
						if(isset($isfriend) && !$isfriend && isset($isrequested) && !$isrequested) {
							$addbtnstyle = "";
						} else if(isset($isrequested) && $isrequested) {
							$cancelbtnstyle = "";
						} else if(isset($isfriend) && $isfriend) {
							$unfriendbtnstyle = "";
						}
						echo "<li id='$row->id.$row->user_name'>
								<div class='search_img'>
									<a href='".base_url()."community/profile/$row->user_name'>";
										if(isset($row->image) && $row->image != "" ) {
											echo "<img src ='".base_url()."public/frontend/images/user/250x250/$row->image' />";
										} else {
											echo "<img src ='".base_url()."public/frontend/images/user/250x250/noavatar.png'/>";
										}
									echo "<br></a>";
								echo "</div>".
								"<div class='member_detail_box'>".
									"<div class='member_detail_inner search_heading'>".
										"<a href='".base_url()."community/profile/$row->user_name'>";
											echo $row->name;
									echo "</a>".
									"</div>".
									"<div class='member_detail_inner'>"
										.$row->user_name.
									"</div>".
									"<div class='member_detail_inner'>".
										"<span title='".$cntr_yname."'>".
											"<img src='".base_url()."public/frontend/images/country/png/".strtolower($cntryname->iso).".png' alt='".$cntr_yname."' />".
										"</span>".
										"<span style='float: right;'>".
											"<input type='button' id='add_".$row->user_name."' class='add_as_frd' name='addasfriend_btn' value='Add as friend' onclick='addAsFriend(this.id)' style='".$addbtnstyle."'/>".
											"<input type='button' id='cancel_".$row->user_name."' class='cancel_req' name='cancelfriend_btn' value='Cancel request' onclick='cancelFriendRequest(this.id)' style='".$cancelbtnstyle."'/>".
											"<input type='button' id='unfriend_".$row->user_name."' class='remove_frd' name='unfriend_btn' value='Unfriend' onclick='unFriend(this.id)' style='".$unfriendbtnstyle."'/>".
										"</span>".
									"</div>".
								"</div>".
							"</li>";
					endforeach;
				echo "</ul>";
			}
			else {
				echo "<p style='margin: 5px 0px 10px 10px;'>No matching member found</p>";
			}
		}
	}

	/**
	 * function is used to add likes into the activitylikes table
	 */
	function like() {
		if($this->input->post("profileownerid") && $this->input->post("aid") && $this->input->post("somekey") == "somekey") {

			$response = array();

			$profileownerid = $this->input->post("profileownerid");
			$aid = $this->input->post("aid");

			$uid = $this->db_session->userdata("id");

			if($aid > 0 && $uid > 0) {
				$where = array(
								"id" => $aid
							);
				$activity = $this->communitymodel->getactivity($where);

				if(isset($activity) && $activity != "") {
					$where = array(
									"id" => $profileownerid
								);
					$profileowner = $this->communitymodel->getuser($where);

					if(isset($profileowner) && $profileowner != "") {
						$isactivityowner = false;

						if($activity->uid == $profileowner->id) {
							$isactivityowner = true;
							$temparr["isactivityowner"] = "true";
						}

						$isfriend = false;

						if(!$isactivityowner) {
							$where = array(
											"uid" => $profileowner->id
										);
							$contact = $this->communitymodel->getcontact($where);

							if(isset($contact) && $contact != "") {
								if($contact->friends != "") {
									$friends = unserialize($contact->friends);
									if(in_array($uid, $friends)) {
										$isfriend = true;
									}
									else {
										$temparr["msg"] = "notanfriend";
									}
								}
							}
							else {
								$temparr["msg"] = "nocontacts";
							}
						}
						if($isactivityowner || $isfriend) {
							$temparr["ispermitted"] = "true";

							$where = array(
											"aid" => $aid,
											"uid" => $uid
										);
							if($this->communitymodel->isactivityliked($where)) {
								$temparr["msg"] = "alreadyliked";
							}
							else {
								$date = date("Y-m-d H:i:s");
								$communitylike = array(
														"aid" => $aid,
														"uid" => $uid,
														"date" => $date
													);
								if($this->communitymodel->addcommunitylikes($communitylike) > 0) {
									//$where = array( "aid" => $aid);
									$temparr["likecounts"] = $this->communitymodel->getlikecountsbyaid($aid);

									$temparr["msg"] = "success";
								}
								else {
									$temparr["msg"] = "fail";
								}
							}
						}
						else {
							$temparr["ispermitted"] = "false";
						}
					}
					else {
						$temparr["msg"] = "usernotfound";
					}
				}
				else {
					$temparr["msg"] = "activitynotfound";
				}
			}
			else {
				$temparr["msg"] = "fail";
			}
			array_push($response, $temparr);
			echo json_encode(array("likes" => $response));
		}
	}

	/**
	 * function to show the online users
	 */
	function getonlineusers() {

		$response = array();

		$query = $this->communitymodel->get_all_session_data();

		$user = array();

		foreach ($query->result() as $row)
		{
			$udata = unserialize($row->session_data);
			//$online[]= $udata['id'];
			if(isset($udata['id'])){
				$temparr[] = $udata["id"];
			}

		}
		//return $online;
		//array_push($response, $online);
		echo json_encode(array("members" => $temparr));
	}

	/**
	 * function is used to get activity 10 records each time click on viewmore link
	 */
	 function viewmoreactivities() {
	 	if($this->input->post("offset") && $this->input->post("offset") != "") {
	 		$response = array();

	 		$uid = $this->input->post("uid");
	 		$offset = $this->input->post("offset");
	 		$where = array("uid" => $uid);

	 		$newsfeeds = $this->communitymodel->getlatest10activitiesbyuser($where,$offset);
	 		if(isset($newsfeeds) && $newsfeeds != "") {
					foreach($newsfeeds as $newsfeed) {
						$temparr["id"] = $newsfeed->id;
						$temparr["uid"] = $newsfeed->uid;

						$userimg = "noavatar.png";
						$temparr["name"] = "";
						$temparr["user_name"] = "";

						$where = array(
							"id" => $newsfeed->uid
						);
						$user = $this->communitymodel->getuser($where);
						if(isset($user) && $user != "") {
							$temparr["userid"] = $user->id;
							$temparr["name"] = $user->user_name;
                            if(!empty($user->name)) {
                               $temparr["name"] = $user->name;
                            }
							$temparr["user_name"] = $user->user_name;

							if($user->image != "") {
								$userimg = $user->image;
							}
						}
						$temparr["image"] = $userimg;
						$temparr["hide"] = $newsfeed->hide;
						//$temparr["content"] = $newsfeed->content;
						$temparr["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
						$temparr["timeago"] = $this->_timeago($newsfeed->date);

						$temparr["likecount"] = $this->communitymodel->getlikecountsbyaid($newsfeed->id);

						$where = array(
										"aid" => $newsfeed->id
									);
						$communitycomments = $this->communitymodel->getcommunitycomments($where);
						if(isset($communitycomments) && $communitycomments != "") {
							foreach ($communitycomments as $communitycomment) {

								$where = array(
									"id" => $communitycomment->uid
								);
								$commentuser = $this->communitymodel->getuser($where);
								$cmtuserimg = "noavatar.png";
								if(isset($commentuser) && $commentuser != "") {

									$temparr["commentuname"] = $commentuser->name;
									$temparr["commentuser_name"] = $commentuser->user_name;

									if($commentuser->image != "") {
										$cmtuserimg = $commentuser->image;
									}
								}

								$temparr["commentuimage"] = $cmtuserimg;
								$temparr["commentcontent"] = urldecode($communitycomment->comment);
								$temparr["commenttimeago"] = $this->_timeago($communitycomment->date);
							}
						}

						$temparr["msg"] = "success";

						array_push($response, $temparr);
					}
				}
				else {
					$temparr["msg"] = "nonews";
					array_push($response, $temparr);
				}
				echo json_encode(array("newsfeeds" => $response));
			}
		 }
	/**
	 * function is used to update shoppinglist
	 */
	function updateshoppinglist() {
		//print_r($_POST);exit;
		if($this->input->post("recipeid")){
			$response = array();
			$this->load->model("crudmodel");
			$uid = $this->db_session->userdata("id");
			$recipe = $this->crudmodel->getshoppinglistbyrecipeid($this->input->post("recipeid"));

			if($uid == $recipe->uid){
				$where = array("recipeid" => $this->input->post("recipeid"));
				$ingredients = array();

				$totalingredients = array_merge($this->input->post("ingredientdetails"),$this->input->post("extraingredients"));

				//$ingredients = implode("|", $this->input->post("ingredientdetails")); // ingredients
				$ingredients = implode("|", $totalingredients);

				$data = array("ingredients" =>$ingredients);

				if($this->crudmodel->updateshoppinglist($data,$where)) {
					$temparr["msg"] = "success";
				}
				else{
					$temparr["msg"] = "fail";
				}
			}else{
				$temparr["msg"] = "isnotowener";
			}

			array_push($response, $temparr);
			echo json_encode(array("shopping" => $response));
		}
	}

	/**
	 * This function is used to delete recipe from shopping list
	 */
	function deleteshoppinglist() {
		if($this->input->post("uid") && $this->input->post("recipeid")){

			$response = array();
			$where = array(
						"uid" => $this->input->post("uid"),
						"recipeid" => $this->input->post("recipeid")
					);
			$this->load->model("crudmodel");
			if($this->crudmodel->deleteshoppedrecipe($where)){
				$temparr["msg"] = "success";
			}
			else {
				$temparr["msg"] = "failtodelete";
			}

			array_push($response, $temparr);
			echo json_encode(array("shopresult" => $response));
		}
	}

	/**
	 * This function is used to delete favourite blog.
	 */
	function removefavouriteblog() {
		if($this->input->post("id")) {
			$temparr = array();
			$response = array();
			$blogid = $this->input->post("id");

			$uid = $this->db_session->userdata("id");
			$where = array("id" => $blogid);

			$blog = $this->communitymodel->getfavoriteblogsbyid($where);
			//print_r($blog); exit;
			$temparr["msg"] = $blog;
			if(isset($blog) && $blog != "") {
				$ispostowner = false;

				if($blog->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}


				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}

				//if($ispostowner || $isadmin){
					if($this->communitymodel->deletefavoriteblogbyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
			//	}
			}else {
				$temparr["msg"] = "blognotfound";
				$temparr["blogid"] = $blogid;
				$temparr["blog"] = $blog;
				$temparr["uid"] = $uid;
			}
			array_push($response, $temparr);
			echo json_encode(array("blogresult" => $response));
		}
	}

	/**
	 * This function is used to delete outside Recipes.
	 */
	function removeoutsiderecipe() {
		if($this->input->post("id")) {

			$response = array();
			$recipeid = $this->input->post("id");

			$uid = $this->db_session->userdata("id");

			$where = array("id" => $recipeid);

			$recipe = $this->communitymodel->getoutsiderecipesbyid($where);
			//print_r($blog); exit;
			if(isset($recipe) && $recipe != "") {
				$ispostowner = false;

				if($recipe->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}
				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}
//			if($ispostowner || $isadmin){
					if($this->communitymodel->deleteoutsiderecipesbyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
//				}
			}else {
				$temparr["msg"] = "recipenotfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("reciperesult" => $response));
		}
	}

	/**
	 * This function is used to delete online videos.
	 */
	function removeonlinevideo() {
		if($this->input->post("id")) {

			$response = array();
			$videoid = $this->input->post("id");

			$uid = $this->db_session->userdata("id");

			$where = array("id" => $videoid);

			$video = $this->communitymodel->getonlinevideobyid($where);
			if(isset($video) && $video != "") {
				$ispostowner = false;

				if($video->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}
				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}
				if($ispostowner || $isadmin){
					if($this->communitymodel->deleteonlinevideobyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
				}
			}else {
				$temparr["msg"] = "recipenotfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("videoresult" => $response));
		}
	}

	/**
	 * This function is used to delete winebeer collection.
	 */
	function removewinebeer() {
		if($this->input->post("id")) {

			$response = array();
			$wineid = $this->input->post("id");

			$uid = $this->db_session->userdata("id");

			$where = array("id" => $wineid);

			$winenbeer = $this->communitymodel->getwinenbeerbyid($where);

			if(isset($winenbeer) && $winenbeer != "") {
				$ispostowner = false;

				if($winenbeer->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}
				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}
				if($ispostowner || $isadmin){
					if($this->communitymodel->deletewinenbeerbyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
				}
			}else {
				$temparr["msg"] = "winenotfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("wineresult" => $response));
		}
	}

	/**
	 * This function is used to delete liqure collection.
	 */
	function removeliqurespirit() {
		if($this->input->post("id")) {

			$response = array();
			$liqureid = $this->input->post("id");
			$uid = $this->db_session->userdata("id");

			$where = array("id" => $liqureid);
			$liqurespirit = $this->communitymodel->getliqurespiritbyid($where);

			if(isset($liqurespirit) && $liqurespirit != "") {
				$ispostowner = false;

				if($liqurespirit->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}
				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}
				if($ispostowner || $isadmin){
					if($this->communitymodel->deleteliqurespiritbyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
				}
			}else {
				$temparr["msg"] = "liqurenotfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("liqureresult" => $response));
		}
	}

	/**
	 * This function is used to delete drink collection.
	 */
	function removedrinkrecipes() {
		if($this->input->post("id")) {

			$response = array();
			$drinkid = $this->input->post("id");
			$uid = $this->db_session->userdata("id");

			$where = array("id" => $drinkid);

			$drinkrecipe = $this->communitymodel->getdrinkrecipebyid($where);

			if(isset($drinkrecipe) && $drinkrecipe != "") {
				$ispostowner = false;

				if($drinkrecipe->uid == $uid) {
					$ispostowner = true;
					$temparr["ispostowner"] = "true";
				}
				$isadmin = false;
				if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin")
				{
					$isadmin = true;
					$temparr["isadmin"] = "true";
				}
				if($ispostowner || $isadmin){
					if($this->communitymodel->deletedrinkrecipebyid($where)) {
						$temparr["msg"] = "success";
					}else {
						$temparr["msg"] = "failtodelete";
					}
				}
			}else {
				$temparr["msg"] = "drinknotfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("drinkresult" => $response));
		}
	}
}
?>