<?php
//This controller is used for other functionalities of restaurants

class Restaurant extends Controller {
	
	function Restaurant() {
		parent :: Controller();
		
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->library("form_validation");
		
		$this->load->model("crudmodel");
		$this->load->model("communitymodel");
		$this->load->model("country");
		$this->load->model("restaurants/restaurantmodel","restmodel");
	}
	
	function index(){
		//print_r($this->restmodel->getallcountries($this->config->item("countryids")));exit;
		$base_url = base_url();
		redirect($base_url."restaurants/Australia");
	}
	
	// add new restaurant 
	function add() {
		$this->freakauth_light->check();
		
		$data["countries"] = $this->restmodel->getallcountries($this->config->item("countryids"));
		//$data["cities"] = $this->restmodel->getallcities();
		$data["cuisines"] = $this->restmodel->getcuisines(NULL);
		$data["features"] = $this->restmodel->getfeatures();
		$data["prices"] = $this->restmodel->getprices(NULL);
		$data["categories"] = $this->restmodel->getcategories();		
		if($this->input->post("sbt_add")){
			//print_r($_POST);exit;
			$this->form_validation->set_rules("country", "Country", "required");
			$this->form_validation->set_rules("title", "Title", "required");
			$this->form_validation->set_rules("geo_address", "Address", "required");
			$this->form_validation->set_rules("description", "Description", "required");
			$this->form_validation->set_rules("contact", "Phone", "required");
			$this->form_validation->set_rules("txtemail", "Email", "required|valid_email");
			
			if ($this->form_validation->run() == FALSE) {
				$data['page'] = "restaurants/addrestaurant";
				$this->load->view("template/templaterestaurant",$data);
			}else {
				//print_r($_POST);exit;
				$restaurant = array(
								"uid" => $this->db_session->userdata("id"),
								"cuisineid" => $this->input->post("selcuisine"),
								"categoryid" => $this->input->post("selcategory"),
								"title" => $this->input->post("title"),
								"seo" => $this->_createseo($this->input->post("title")),
								"content" => $this->input->post("description"),
								"latitude" => $this->input->post("geo_latitude"),
								"longitude" => $this->input->post("geo_longitude"),
								"geo_address" => $this->input->post("geo_address"),
								"timing" => $this->input->post("timing"),
								"contact" => $this->input->post("contact"),
								"email" => $this->input->post("txtemail"),
								"website" => $this->input->post("website"),
								"twitter" => $this->input->post("twitter"),
								"facebook" =>$this->input->post("facebook"),
								"video" => $this->input->post("video"),
								"images" => is_array($this->input->post("imagearray")) ? serialize($this->input->post("imagearray")) : "",
								"price" => $this->input->post("selprice"),
								"special_offers" => $this->input->post("specialoffer"),
								"featureid" => serialize($this->input->post("selfeature")),
								"countryid" => $this->input->post("country"),
								"stateid" => $this->input->post("state"),
								"cityid" => $this->input->post("city"),
								"date" => date("Y-m-d h:m:i")
							);
				if($this->restmodel->addrestaurant($restaurant)){
					//redirect("restaurant/add", "refresh");
					$countryname = $this->getCountryById($this->input->post("country"));
					redirect("restaurants/".$countryname,"refresh");
				}
			}
		}else{
			$data['page'] = "restaurants/addrestaurant";
			$this->load->view("template/templaterestaurant",$data);
		}
	}

	function getCountryById($id)
    {	
        	//SELECT id, name FROM country
            $this->db->select('name');
            $this->db->where('id', $id);
            $query = $this->db->get('countries');
            
            foreach ($query->result() as $row)
            {
            	
                return $row->{'name'};
                
            }
        
        	return null;
    }

	// function to cerate seo link
	function _createseo($postval) {
        $specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
        return $seo = strtolower(str_replace($specialchars, "-", $postval)."-".md5(time()));
    }

	// function to show detail view of restaurant
	function details() {
		$data["allfeatures"] = $this->restmodel->getfeatures();
		$data["segment3"] = $this->uri->segment("3");
		if($this->uri->segment("3") != "" && $this->uri->segment("3") != "venue"){
			// data are comming from our database
			$seo = $this->uri->segment("3");
			$restaurant = $this->restmodel->getrestaurantsdetails(array("seo" => $seo));
			
			if(!empty($restaurant)) {
				$data["restaurants"] = $restaurant;
				
				$data["cuisine"] = $this->restmodel->getcuisines(array("id" => $restaurant->cuisineid));
				
				if($this->is_serial($restaurant->featureid)) {
					$features = unserialize($restaurant->featureid);
					$data["features"] = $this->restmodel->getfeaturebyid($features);
				}else{
					$data["features"] = $this->restmodel->getfeaturebyid($restaurant->featureid);
				}
							
				$data["price"] = $this->restmodel->getprices(array("id" => $restaurant->price));
				$data["country"] = $this->restmodel->getcountry(array("id" => $restaurant->countryid));
				
				if(isset($restaurant->latitude) && isset($restaurant->longitude)){
					$latlng = $restaurant->latitude.",".$restaurant->longitude;
					$data["topmap"] = $this->_getmap($latlng);
				}else{
					$data["topmap"] = $this->_getmap($restaurant->geo_address);
				}
				
				if($this->is_serial($restaurant->images)){
					$data["images"] = unserialize($restaurant->images);
				}
				//for menu images
				
				$breakfast_imgs = array();
				$lunch_imgs = array();
				$dinner_imgs = array();
				$extrainfo_rows = $this->restmodel->getImages($restaurant->id);
				//print_r($breakfast_images);exit;
				if($extrainfo_rows){
				foreach($extrainfo_rows as $extrainfo_row){
					if($this->is_serial($extrainfo_row->breakfast)){
					$breakfastarray = unserialize($extrainfo_row->breakfast);
					foreach($breakfastarray as $breakfastarr){
						$breakfast_imgs[] = $breakfastarr; 
					}
					}
					if($this->is_serial($extrainfo_row->lunch)){
					$luncharray = unserialize($extrainfo_row->lunch);
					foreach($luncharray as $luncharr){
						$lunch_imgs[] = $luncharr; 
					}
					}
					if($this->is_serial($extrainfo_row->dinner)){
					$dinnerarray = unserialize($extrainfo_row->dinner);
					foreach($dinnerarray as $dinnerarr){
						$dinner_imgs[] = $dinnerarr; 
					}
					}
					
					
				}
				
				//echo"<pre>";
				//print_r($breakfast_imgs);
				//exit();
				$data['breakfast_imgs'] = $breakfast_imgs;	
				$data['lunch_imgs'] = $lunch_imgs;	
				$data['dinner_imgs'] = $dinner_imgs;	
				}
				//for likes
				if($this->db_session->userdata("id")){
					$where = array(
								'rid'=>$restaurant->id,
								'uid'=>$this->db_session->userdata("id")
							   );
					$data["liked"] = $this->restmodel->getlikebyuser($where);
				}
				$where = array("rid"=>$restaurant->id,
								"liked"=>"1"
								);
				$like =  $this->restmodel->countlike($where);
				$where = array("rid" => $restaurant->id);
				$total_like = $this->restmodel->countlike($where);
				if($like && $total_like){
					$data["calculated_likes"] = ($like*10)/$total_like;
				}else{
					$data["calculated_likes"] = 0;
				}
				$data["comments"] = $this->restmodel->getcomments($where);
				$data["neighbors"] = $this->restmodel->getneighborsrestaurants($restaurant->latitude,$restaurant->longitude);
				$data["hours"] = $this->restmodel->gethours(null);
				$data["page"] = "restaurants/details";
				$this->load->view("template/templaterestaurant",$data);
			}
		}else if($this->uri->segment("3") == "venue" && $this->uri->segment("4") != ""){
			
			//data will come from Foursquare API
			$segment_4 = $this->uri->segment("4");
			//print_r($segment_4);exit;
			$segment_4 = explode("-", $segment_4);
			if(isset($segment_4[2])){
				if($segment_4[2]=="ve"){
					$data["priceappend"] = "Very Expensive";
				}elseif($segment_4[2] == "e"){
					$data["priceappend"] = "Expensive";
				}elseif($segment_4[2] == "m"){
					$data["priceappend"] = "Moderate";
				}elseif($segment_4[2] == "c"){
					$data["priceappend"] = "Cheap";
				}elseif($segment_4[2] == ""){
					$data["priceappend"] = "";
				}
			}else{
				$data["priceappend"] = "";
			}
			if(isset($segment_4[1])){
				$venueid = $segment_4[1];	
			}else{
				$venueid = $this->uri->segment("4");
			}
			$where = array("rid"=>$venueid);
			if($this->restmodel->getrestextrainfoapi($where)>0){
				$restaurant = $this->restmodel->getrestextrainfoapi($where);
				//print_r($restaurant);exit;
				if($this->is_serial($restaurant[0]->restaurant_img)){
						$data["images"] = unserialize($restaurant[0]->restaurant_img);
				}
				if($this->is_serial($restaurant[0]->featureid)) {
					$features = unserialize($restaurant[0]->featureid);
					$data["features"] = $this->restmodel->getfeaturebyid($features);
				}else{
					$data["features"] = $this->restmodel->getfeaturebyid($restaurant[0]->featureid);
				}
			}
			//for menu images
			$breakfast_imgs = array();
			$lunch_imgs = array();
			$dinner_imgs = array();
			$extrainfo_rows = $this->restmodel->getImages($venueid);
			//print_r($breakfast_images);exit;
			if($extrainfo_rows){
			foreach($extrainfo_rows as $extrainfo_row){
				if($this->is_serial($extrainfo_row->breakfast)){
				$breakfastarray = unserialize($extrainfo_row->breakfast);
				foreach($breakfastarray as $breakfastarr){
					$breakfast_imgs[] = $breakfastarr; 
				}
				}
				if($this->is_serial($extrainfo_row->lunch)){
				$luncharray = unserialize($extrainfo_row->lunch);
				foreach($luncharray as $luncharr){
					$lunch_imgs[] = $luncharr; 
				}
				}
				if($this->is_serial($extrainfo_row->dinner)){
				$dinnerarray = unserialize($extrainfo_row->dinner);
				foreach($dinnerarray as $dinnerarr){
					$dinner_imgs[] = $dinnerarr; 
				}
				}
			}
			//echo"<pre>";
			//print_r($breakfast_imgs);
			//exit();
			$data['breakfast_imgs'] = $breakfast_imgs;	
			$data['lunch_imgs'] = $lunch_imgs;	
			$data['dinner_imgs'] = $dinner_imgs;	
			}
			$venue = $this->_getfoursquarevenue($venueid);
			if(isset($venue) && !empty($venue)) {
				//to  get the likes
				if($this->db_session->userdata("id")){
					$where = array(
								'rid'=>$venueid,
								'uid'=>$this->db_session->userdata("id")
							   );
					$data["liked"] = $this->restmodel->getlikebyuser($where);
				}
				$where = array("rid"=>$venueid,
								"liked"=>"1"
								);
				$like =  $this->restmodel->countlike($where);
				$where = array("rid" => $venueid);
				$total_like = $this->restmodel->countlike($where);
				if($like && $total_like){
					$data["calculated_likes"] = ($like *10)/$total_like;
				}else{
					$data["calculated_likes"] = 0;
				}
				//echo"<pre>";
				//print_r($venue);exit;
				$data["venue"] = $venue;
				$data["neighborvenues"] = $this->_getneighborhoodvenues($venue->location->lat, $venue->location->lng);
				$latlng = $venue->location->lat.",".$venue->location->lng;
				$data["topmap"] = $this->_getmap($latlng);
				$data["hours"] = $this->restmodel->gethours(null);
				$where = array("rid" => $venueid);
				$data["comments"] = $this->restmodel->getcomments($where);
				$data["page"] = "restaurants/venuedetails";
				$this->load->view("template/templaterestaurant",$data);	
			}
		}
		 //$data["page"] = "restaurants/details";
		//$this->load->view("template/templaterestaurant",$data);
	}
	
	
	 // Function to show map address with marker
	 function _getmap($address) {
	 	$this->load->library('googlemaps');
		$config['center'] = $address;
		$config['zoom'] = '15';
		//$config['map_name'] = 'state_map';
		//$config['map_div_id'] = 'map_canvas_state';
		$config['map_height'] = '320px';
		$config['map_width'] = '100%';
		
		$marker["position"] = $address;
		$marker["icon"] = "https://chart.apis.google.com/chart?cht=mm&chs=24x32&chco=FFFFFF,008CFF,000000&ext=.png";
		//$marker['infowindow_content'] = $this->_markerpopup($mark);
		$marker["animation"] = "DROP";
		$this->googlemaps->add_marker($marker);
		$this->googlemaps->initialize($config);
		
		return $statemap = $this->googlemaps->create_map();
	 }
	 
	 //function to check is srting serialize return result
	function is_serial($data) {
		return (@unserialize($data) !== false);
	} 
	
	
	//Function to get venue data from Foursqure API
	function _getfoursquarevenue($venueid) {
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
		
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/".$venueid);
		$venues = json_decode($response);
		//echo "<pre>";
		//print_r($response);exit;
		//print_r($venues->response->venue);exit;
		return $venues->response->venue;
	  }
	 
	//Function to get Neighborhood restaurants
	function _getneighborhoodvenues($lat,$lng){
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
		$params = array(
						"ll" => "$lat,$lng",
						"llAcc" => "100",
						"radius"=>"1000",
						"categoryId"=>"4d4b7105d754a06374d81259",
						"venuePhotos" => 1,
						"sortByDistance" => 1,
						"limit" => 4
					);
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/explore",$params);
		$venues = json_decode($response);
		// echo "<pre>";
		// print_r($venues);exit;
		return $venues->response->groups[0]->items;
	} 
}
?>