<?php

	class Requesthandler extends Controller {
		
		function Requesthandler() {
			parent::Controller();
			$this->load->helper("url");
		}
		
		function isloggedin() {

            $response = array();

            $temparr["msg"] = "false";
            if($this->db_session->userdata("id")) {
	 	        $temparr["msg"] = "true";
            }

			array_push($response, $temparr);
			echo json_encode(array("login" => $response));
		}
		
        function isshareloggedin() {

            $response = array();

            $isorigin = false;
            if (isset($_SERVER["HTTP_ORIGIN"])) {
                //"632277805f56af26ede8edc1b5cc2f63";
                $url = parse_url($_SERVER["REQUEST_URI"]);
                parse_str($url["query"], $query);

                if(isset($query) && is_array($query) && !empty($query)) {
                    if(isset($query["token"])) {
                        if($query["token"] == "632277805f56af26ede8edc1b5cc2f63") {
                            $isorigin = true;
                            header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
                        }
                    }
                }
                
                /* $token = explode("?",$_SERVER["REQUEST_URI"]);
                if(is_array($token) && !empty($token)) {
                    $token = preg_replace("/token=/", "", rawurldecode($token[1]), 1);
                    if($token == "632277805f56af26ede8edc1b5cc2f63") {
                        $isorigin = true;
                        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
                    }
                } */
            }
            else {
               $isorigin = true;
            }
            
            //$sessid = ""; $sessid11 = $ip = "";
            if($isorigin) {
                if($this->db_session->userdata("id")) {
                    $temparr["msg"] = "true";
                }
                else {
                    $temparr["msg"] = "false";

                    $this->load->model("communitymodel");
                    $where = array(
                                    "ip_address" => $_SERVER["REMOTE_ADDR"],
                                    "user_agent" => substr($_SERVER["HTTP_USER_AGENT"], 0, 50)
                                );

                    $wherenotin = array();
                    $wherenotin[] = "a:0:{}";
                    $wherenotin[] = "NULL";

                    $cisession = $this->communitymodel->getcisession($where, $wherenotin);
                    if(!empty($cisession)) {
                        if(!empty($cisession->session_data)) {
                            $userdata = unserialize($cisession->session_data);
                            if(is_array($userdata) && !empty($userdata)) {
                                if(isset($userdata["id"]) && $userdata["id"] > 0) {
                                    $temparr["msg"] = "true";
                                }
                            }
                        }
                    }
                }
            }
            else {
                $temparr["msg"] = "notauthorised";
            }
            
            //$temparr["data"] = "ip: ".$_SERVER["REMOTE_ADDR"]." agent: ".substr($_SERVER["HTTP_USER_AGENT"], 0, 50);

            array_push($response, $temparr);
            echo json_encode(array("login" => $response));
        }
        
		/**
		 * This function is used to get user name.
		 */
		function getusername() {
			if($this->input->post("somekey") && $this->input->post("user_name") && $this->input->post("password")) {
				$response = array();

				$user_name = $this->input->post("user_name");
				$password = $this->input->post("password");
				
				if (strpos($user_name, "@") !== false) {
					$this->load->model("crudmodel");
					$user = $this->crudmodel->getuserbyemail($user_name);
					if(isset($user) && !empty($user)) {
						if($user->user_name == $user_name && $password == $user->password) {
							$temparr["msg"] = "success";
							$temparr["user_name"] = $user->user_name;
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$this->load->model("communitymodel");
					
					$where = array(
									"user_name" => $user_name
								);
					$user = $this->communitymodel->getuser($where);
					if(isset($user) && !empty($user)) {
						if($user->user_name == $user_name && $password == $user->password) {
							$temparr["msg"] = "success";
							$temparr["user_name"] = $user->user_name;
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				
				array_push($response, $temparr);
				echo json_encode(array("user" => $response));
			}
		}
		
		function uploadimage() {
			if($this->input->post("recipeid")) {
				$recipeid = $this->input->post("recipeid");
        		
				$response = array();
				
				if($recipeid > 0) {
	        		$this->load->model("crudmodel");
					
					$recipeuploadpath = $this->config->item("recipe_upload_path");
					
					$config = array(
								"upload_path" => $recipeuploadpath,
								"allowed_types" => "jpg|jpeg|gif|png"
							);
			
					$filename = $_FILES["userfile"]["name"];
					$filename = explode(".", $filename);
					$filename[0] = $filename[0].time().".".$filename[1];
					$_FILES["userfile"]["name"] = $filename[0];
			
					$this->load->library("upload", $config);
					
					if($this->upload->do_upload()) {
						
						$image_data = $this->upload->data();
						
						$imagestypes = array(
											"index_upload_path" => $this->config->item("index_upload_path"),
											"recipe_home_upload_path" => $this->config->item("recipe_home_upload_path"),
											"recipe_detail_upload_path" => $this->config->item("recipe_detail_upload_path"),
											"recipe_media_upload_path" => $this->config->item("recipe_media_upload_path"),
											"recipe_25x25_upload_path" => $this->config->item("recipe_25x25_upload_path")
										);
						
						$this->load->library("image_lib");
						
						foreach ($imagestypes as $imagetype) {
								
							$width = 100;
							$heigth = 100;
							
							if($imagetype == $this->config->item("index_upload_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("recipe_home_upload_path")) {
								$width = 650;
								$heigth = 350;
							}
							else if($imagetype == $this->config->item("recipe_detail_upload_path")) {
								$width = 275;
								$heigth = 198;
							}
							else if($imagetype == $this->config->item("recipe_media_upload_path")) {
								$width = 50;
								$heigth = 50;
							}
							else if($imagetype == $this->config->item("recipe_25x25_upload_path")) {
								$width = 25;
								$heigth = 25;
							}
							
							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
								
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
						
						$recipeimages = $this->crudmodel->getimagesbyid($recipeid);
						
						if($recipeimages != "") {
							$recipeimages = $recipeimages.",".$image_data["file_name"];
						}
						else {
							$recipeimages = $image_data["file_name"];
						}
				
						$recipe = array(
									"images" => $recipeimages,
									"date" => date("Y-m-d H:i:s")
								);
								
						$where = array(
										"id" => $recipeid,
										"uid" => $this->db_session->userdata("id")
									);
										
						if($this->crudmodel->updaterecipe($recipe, $where)) {
							$temparr["images"] = $image_data["file_name"];
							$temparr["msg"] = "success";
							array_push($response, $temparr);
							echo json_encode(array("images" => $response));
						}
					}
					else {
						$temparr["msg"] = "fail";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
				}
				else {
					$temparr["msg"] = "notfound.";
					array_push($response, $temparr);
					echo json_encode(array("images" => $response));
				}
			}
		}

		function deleteimage() {
			$recipeid = $this->input->post("recipeid");
			$filename = $this->input->post("filename");
			
			$filename = trim($filename);
			
			if($recipeid && $filename) {
				$this->load->model("crudmodel");
				
				$where = array(
						"id" => $recipeid,
						"uid" => $this->db_session->userdata("id")
				);
				
				$recipeimages = $this->crudmodel->getrecipeimages($where);
				if($recipeimages != "") {
					$issingleimg = false;
					$imagearr = explode(",", $recipeimages);
					$imagecnt = count($imagearr);
					if($imagecnt != 0) {
						if($imagecnt - 1 == 1) {
							$issingleimg = true;
						}
					}
					$image = $filename.",";
					$isfound = strpos($recipeimages, $image);
					if($isfound === FALSE) {
						$recipeimages = str_replace($filename, "", $recipeimages);
						if($issingleimg) {
							$recipeimages = str_replace(",", "", $recipeimages);
						}
					}
					else {
						$recipeimages = str_replace($image, "", $recipeimages);
					}
				}
				
				$recipe = array(
							"images" => $recipeimages
						);
						
				$response = array();
				
				$where = array(
								"id" => $recipeid,
								"uid" => $this->db_session->userdata("id")
							);
							
				if($this->crudmodel->updaterecipe($recipe, $where)) {
					
					$uploadpath = $this->config->item("recipe_media_upload_path");
					
					$temparr["path"] = $uploadpath;
					
					if(file_exists($uploadpath."/".$filename)) {
						unlink($uploadpath."/".$filename);
						
						$uploadpath = $this->config->item("recipe_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}
						
						$uploadpath = $this->config->item("index_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}
						
						$uploadpath = $this->config->item("recipe_detail_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}
						
						$uploadpath = $this->config->item("recipe_home_upload_path");
						if(file_exists($uploadpath."/".$filename)) {
							unlink($uploadpath."/".$filename);
						}
						
						$temparr["msg"] = "success";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
					else {
						$temparr["msg"] = "not found";
						array_push($response, $temparr);
						echo json_encode(array("images" => $response));
					}
				}
				else {
					$temparr["msg"] = "fail";
					array_push($response, $temparr);
					echo json_encode(array("images" => $response));
				}
			}
		}
		
		function like() {
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				$this->load->model("crudmodel");
				
				$recipeid = $this->input->post("recipeid");
				$uid = $this->db_session->userdata("id");
				
				$where = array(
							"recipeid" => $recipeid,
							"uid" => $uid
						);
						
				if($this->crudmodel->isliked($where)) {
					$temparr["msg"] = "alreadyliked";
				}
				else {
					$like = array (
								"recipeid" => $recipeid,
								"uid" => $uid,
								"date" => date("y-m-d H:i:s")
							);
					
					if($this->crudmodel->addlike($like) > 0) {
							$info = array(
											"recipeid" => $recipeid,
											"uid" => $uid,
											"date" => date("y-m-d H:i:s")
										);
							$activity = array(
												"uid" => $uid,
												"content" => $this->config->item("recipe_like"),
												"info" => serialize($info),
												"date" => date("Y-m-d H:i:s")
											);
											
							$this->load->model("communitymodel");
							$this->communitymodel->addactivity($activity);
						//$this->_notify($recipeid, "like");
						
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
					
					$temparr["likecount"] = $this->crudmodel->getlikecountbyrecipeid($recipeid);
				}
				
				array_push($response, $temparr);
				echo json_encode(array("likes" => $response));
			}
			else {
				$temparr["msg"] = "notfound";
				array_push($response, $temparr);
				echo json_encode(array("likes" => $response));
			}
		}
		
		function made() {
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				$this->load->model("crudmodel");
				
				$recipeid = $this->input->post("recipeid");
				$uid = $this->db_session->userdata("id");
				
				$where = array(
							"recipeid" => $recipeid,
							"uid" => $uid
						);
						
				if($this->crudmodel->ismade($where)) {
					$temparr["msg"] = "alreadymade";
				}
				else {
					$made = array (
								"recipeid" => $recipeid,
								"uid" => $uid,
								"date" => date("y-m-d H:i:s")
							);
							
					if($this->crudmodel->addmade($made) > 0) {
						
						//$this->_notify($recipeid, "made");
						$info = array(
										"recipeid" => $recipeid,
										"uid" => $uid,
										"date" => date("y-m-d H:i:s")
									);
						$activity = array(
											"uid" => $uid,
											"content" => $this->config->item("recipe_made"),
											"info" => serialize($info),
											"date" => date("Y-m-d H:i:s")
										);
						
						$this->load->model("communitymodel");		
						$this->communitymodel->addactivity($activity);
						
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
					
					$temparr["madecount"] = $this->crudmodel->getmadecountbyrecipeid($recipeid);
				}
				
				array_push($response, $temparr);
				echo json_encode(array("made" => $response));
			}
			else {
				$temparr["msg"] = "notfound";
				array_push($response, $temparr);
				echo json_encode(array("made" => $response));
			}
		}

		function addtofavorites() {
				
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				$this->load->model("crudmodel");
				$this->load->model("communitymodel");
				
				$recipeid = $this->input->post("recipeid");
				
				$where = array(
							"recipeid" => $recipeid,
							"uid" => $this->db_session->userdata("id")
						);
				if($this->input->post("isvideo")){$where["isvideo"] = $this->input->post("isvideo");}
				else{$where["isvideo"] = "0";}
					
						
				if($this->crudmodel->isfavorite($where)) {
					$temparr["msg"] = "alreadyadded";
				}
				else {
					$favorite = array (
								"recipeid" => $recipeid,
								"uid" => $this->db_session->userdata("id"),
								"date" => date("y-m-d H:i:s")
							);
					if($this->input->post("isvideo"))
					{
						$favorite["isvideo"] = $this->input->post("isvideo");
					}
					
					if($this->crudmodel->addtofavorites($favorite) > 0) {
						$info = array(
										"recipeid" => $recipeid,
										"uid" => $this->db_session->userdata("id"),
										"date" => date("y-m-d H:i:s")
									);
						$activity = array(
											"uid" => $this->db_session->userdata("id"),
											"content" => $this->config->item("recipe_favorite"),
											"info" => serialize($info),
											"date" => date("Y-m-d H:i:s")
										);
						$this->load->model("communitymodel");
						$this->communitymodel->addactivity($activity);
						
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
					
					//$temparr["likecount"] = $this->crudmodel->getlikecountbyrecipeid($recipeid);
				}
				
				array_push($response, $temparr);
				echo json_encode(array("favorite" => $response));
			}
			else {
				$temparr["msg"] = "notfound";
				array_push($response, $temparr);
				echo json_encode(array("favorite" => $response));
			}
		}

		function rate() {
			if($this->input->post("rating") && $this->input->post("recipeid")) {
				
				$this->load->model("crudmodel");
				
				$recipeid = $this->input->post("recipeid");
				
				$where = array(
							"uid" => $this->db_session->userdata("id"),
							"recipeid" => $recipeid
						);
				
				$rating = array(
							"uid" => $this->db_session->userdata("id"),
							"recipeid" => $recipeid,
							"rating" => $this->input->post("rating")
						);
				
				$response = array();
				
				if($this->crudmodel->isratingexistsating($where)) {
					if($this->crudmodel->updaterating($where, $rating)) {
						$temparr["msg"] = "updated";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					if($this->crudmodel->addrating($rating) > 0) {
							
						//$this->_notify($recipeid, "rate");
						
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				
				array_push($response, $temparr);
				echo json_encode(array("rating" => $response));
			}
			else {
				redirect("recipe");
			}
    	}

		function addtobook() {
			$response = array();
			
			if($this->input->post("bookid") != "" && is_numeric($this->input->post("bookid")) && $this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
					
				$this->load->model("crudmodel");
				
				$bookid = $this->input->post("bookid");
				$recipeid = $this->input->post("recipeid");
				
				$where = array(
							"id" => $bookid,
							"uid" => $this->db_session->userdata("id")
						);
				
				$book = $this->crudmodel->getbookbyidnuid($where);
				
				if($this->crudmodel->isalreadyinbook($where, $recipeid)) {
					$temparr["msg"] = "alreadyinbook";
					$temparr["name"] = $book->name;
				}
				else if($this->crudmodel->isbookexsits($where)) {
					
					$recipeids = $book->recipeid;
					
					if($recipeids != "") {
						$recipeids = $recipeids.",".$recipeid;
						//$recipeids = trim($recipeids, ",");
					}
					else {
						$recipeids = $recipeid;
					}
					
					$data = array(
									"recipeid" => $recipeids,
									"date" => date("y-m-d H:i:s")
								);
					
					if($this->crudmodel->updatebook($where, $data)) {
						$temparr["msg"] = "success";
						$temparr["name"] = $book->name;
					}
					else {
						$temparr["msg"] = "fail";
						$temparr["name"] = $book->name;
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}
				
				array_push($response, $temparr);
				echo json_encode(array("book" => $response));
			}
			else {
				$temparr["msg"] = "fail";
				array_push($response, $temparr);
				echo json_encode(array("book" => $response));
			}
		}
		
		function comment() {
			
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				
				$recipeid = $this->input->post("recipeid");
				
				if($recipeid > 0) {
					
					$this->load->model("crudmodel");
					$this->load->model("communitymodel");
					
					$userid = $this->db_session->userdata("id");
					$commentcontent = $this->input->post("comment");
					
					$comment = array (
									"comment" => urlencode($commentcontent),
									"recipeid" => $recipeid,
									"uid" => $userid,
									"date" => date("y-m-d H:i:s"),
									"notified" => "1"
								);
						
					if($this->crudmodel->addcomment($comment) > 0) {
						$user = $this->crudmodel->getuserbyid($userid);
						
						$info = array(
										"recipeid" => $recipeid,
										"uid" => $this->db_session->userdata("id"),
										"date" => date("y-m-d H:i:s")
									);
						$activity = array(
											"uid" => $this->db_session->userdata("id"),
											"content" => $this->config->item("recipe_comment"),
											"info" => serialize($info),
											"date" => date("Y-m-d H:i:s")
										);
						$this->communitymodel->addactivity($activity);
						
						$temparr["msg"] = "success";
						$temparr["image"] = $user->image;
						$temparr["username"] = $user->user_name;
						$temparr["commentcontent"] = $commentcontent;
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notfound";
				}
				
				array_push($response, $temparr);
				echo json_encode(array("comment" => $response));
			}
			else {
				$temparr["msg"] = "fail";
				array_push($response, $temparr);
				echo json_encode(array("comment" => $response));
			}
		}
		
		function addtoshoppinglist() {
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid")) && $this->input->post("list") != "") {
				
				$ingredients = $this->input->post("list");
				$ingredients = rtrim($ingredients, "|");
				$recipeid = $this->input->post("recipeid");
				$uid = $this->db_session->userdata("id");
				
				$shoppinglist = array(
								"uid" => $uid,
								"recipeid" => $recipeid,
								"ingredients" => $ingredients
							);
			
				$this->load->model("crudmodel");
				
				$where = array(
							"uid" => $uid,
							"recipeid" => $recipeid
						);
				
				if($this->crudmodel->isshoppinglistexsist($where)) {
					
					$shoppinglist = array(
								"ingredients" => $ingredients
							);
					
					if($this->crudmodel->updateshoppinglist($shoppinglist, $where)) {
						$temparr["msg"] = "success";
						array_push($response, $temparr);
						echo json_encode(array('shoppinglist' => $response));
					}
					else {
						$temparr["msg"] = "fail";
						array_push($response, $temparr);
						echo json_encode(array("shoppinglist" => $response));
					}
				}
				else if($this->crudmodel->addshoppinglist($shoppinglist) > 0) {
					$temparr["msg"] = "success";
					array_push($response, $temparr);
					echo json_encode(array('shoppinglist' => $response));
				}
				else {
					$temparr["msg"] = "fail";
					array_push($response, $temparr);
					echo json_encode(array("shoppinglist" => $response));
				}
			}
			else {
				$temparr["msg"] = "fail";
				array_push($response, $temparr);
				echo json_encode(array("shoppinglist" => $response));
			}
		}
		
		/* function addtoshoppinglist() {	
		
			if($this->_isloggedin()) {
			
				$ingredients = $this->input->post('values');
				$recipeid = $_POST['recipeid'];
				$uid = $_POST['uid'];
				$ingredients = implode("|",$ingredients);
				
				$ingredientstolist = array(
							"uid" => $this->db_session->userdata("id"),
							"recipeid" => $recipeid,
							"ingredients" => $ingredients
				);
				
				$this->load->model("crudmodel");
				
				$response = array();
				
				if($this->crudmodel->addtoshoppinglist($ingredientstolist,$recipeid,$uid)) {
					array_push($response, $ingredients);
					echo json_encode(array('values' => $response));
				}
				else {
					$temparr["msg"] = "not found";
					array_push($response, $temparr);
					echo json_encode(array("values" => $response));
				}
			}
		} */
		
		function iscommentnotified() {
			$response = array();
			
			if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				$this->load->model("crudmodel");
				
				$recipeid = $this->input->post("recipeid");
				
				$where = array(
							"recipeid" => $recipeid,
							"uid" => $this->db_session->userdata("id"),
							"notified" => "1"
						);
						
				if($this->crudmodel->iscommentnotified($where)) {
					$temparr["msg"] = "alreadynotified";
				}
				else {
					
					$where = array(
							"recipeid" => $recipeid,
							"uid" => $this->db_session->userdata("id"),
							"notified" => "0"
						);
						
					$comment = array(
									"notified" => "1"
								);
					
					if($this->crudmodel->updatecomment($where, $comment)) {
						$temparr["msg"] = "success";
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				
				array_push($response, $temparr);
				echo json_encode(array("status" => $response));
			}
			else {
				$temparr["msg"] = "notfound";
				array_push($response, $temparr);
				echo json_encode(array("status" => $response));
			}
			
			/* $response = array();
			
			if($this->db_session->userdata("id")) {
				$temparr["msg"] = "true";
			}
			else {
				$temparr["msg"] = "false";
			}
			
			array_push($response, $temparr);
			echo json_encode(array("login" => $response)); */
		}
		
		//function notify($recipeid = "", $action = "") {
		function notify() {
		 	
		 	if($this->db_session->userdata("id") != "" && $this->input->post("recipeid") != "" && $this->input->post("action") != "") {
					
				$this->load->model("crudmodel");
 				
 				$recipeid = $this->input->post("recipeid");
	 			$action = $this->input->post("action");
		 		
		 		$msg = "";
				$username = $this->db_session->userdata("user_name");
				
				if($action == "like") {
					$msg = $username." likes ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				else if($action == "made") {
					$msg = $username." made ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				else if($action == "rate") {
					$msg = $username." rated ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				
				if($msg != "") {
					$msg .= " ".base_url()."recipe/details/$recipeid"; ?>
				
					<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.7.2.min.js"></script>
							
					<form id="notify" action="https://www.foodlips.com/community/export.php" method="post">
					    <input type="hidden" name="msg" value="<?=$msg;?>" />
					    <input type="submit" value="Submit" />
					</form>
		
					<script type="text/javascript">
						$(document).ready(function() {
							$("#notify").submit();
						});
					</script>
					 
				<?php }
			}
		}

		function _notify1($recipeid = "", $action = "") {
			//extract($_POST);
	
			//set POST variables
			/* $fields = array(
		            "username" => $_POST["username"],
		            "password" => $_POST["password"]
		        ); */
		 	
		 	if($this->db_session->userdata("id") != "" && $recipeid != "" && $action != "") {
		 		$msg = "";
				$username = $this->db_session->userdata("user_name");
				
				if($action == "like") {
					$msg = $username." likes ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				else if($action == "made") {
					$msg = $username." made ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				else if($action == "rate") {
					$msg = $username." rated ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
				}
				
				if($msg != "") {
					$msg .= " ".base_url()."recipe/details/$recipeid";
					
					$fields = array(
			            "msg" => $msg
			        );
					
			 		$fields_string = "msg=".$msg;
					
					//url-ify the data for the POST
					/* foreach($fields as $key => $value) {
						$fields_string .= $key.'='.$value.'&';
					} */
					
					//rtrim($fields_string, '&');
				
					//echo "data: ".$fields_string;
					//exit();
				
					//open connection
					$ch = curl_init();
					$url = "https://www.foodlips.com/community/export.php";
				
					//set the url, number of POST vars, POST data
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_POST, count($fields));
					curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
				
					//execute post
					$result = curl_exec($ch);
				
					//close connection
					curl_close($ch);
				}
			}
		}
	/**
	 * function to submit recipe reviews into reviews table
	 */
	 function reviews() {
	 	$response = array();
		
		if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
				
			$recipeid = $this->input->post("recipeid");
			
			if($recipeid > 0) {
				
				$this->load->model("crudmodel");
				$userid = $this->db_session->userdata("id");
				$reviewflag = false;
				$recipereviews = $this->crudmodel->getreviewsbyrecipeid($recipeid);
				
				if(isset($recipereviews) && !empty($recipereviews)) {
					foreach($recipereviews as $reviews) {
						if($reviews->uid == $userid) {
							$reviewflag = true;
							break;
						}
					}
				}
				if(!$reviewflag){
					$reviewcontent = $this->input->post("review");
					
					$review = array (
										"review" => $reviewcontent,
										"recipeid" => $recipeid,
										"uid" => $userid,
										"date" => date("y-m-d H:i:s")
									);
					if($this->crudmodel->addreview($review) > 0) {
						$user = $this->crudmodel->getuserbyid($userid);
						
						$temparr["msg"] = "success";
						$temparr["image"] = $user->image;
						$temparr["username"] = $user->user_name;
						$temparr["reviewcontent"] = $reviewcontent;
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else{
					$temparr["msg"] = "reviewfound";
				}
			}
			else {
				$temparr["msg"] = "notfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("review" => $response));
		}
		else {
			$temparr["msg"] = "fail";
			array_push($response, $temparr);
			echo json_encode(array("review" => $response));
		}
	}
/**
 * Function to update review allready submitted by the user
 */
	function updatereviews() {
		$response = array();
		
		if($this->input->post("recipeid") != "" && is_numeric($this->input->post("recipeid"))) {
							
			$recipeid = $this->input->post("recipeid");
			
			if($recipeid > 0) {
				
				$this->load->model("crudmodel");
				$userid = $this->db_session->userdata("id");
				
				$reviewcontent = $this->input->post("review");
				$where = array(
								"uid" => $userid,
								"recipeid" => $recipeid);
				$review = array (
									"review" => $reviewcontent,
									"date" => date("y-m-d H:i:s")
								);
				if($this->crudmodel->updatereview($where,$review)) {
					$user = $this->crudmodel->getuserbyid($userid);
					$temparr["msg"] = "success";
					$temparr["image"] = $user->image;
					$temparr["username"] = $user->user_name;
					$temparr["reviewcontent"] = $reviewcontent;
				}
				else {
					$temparr["msg"] = "fail";
				}
			}
			else {
				$temparr["msg"] = "notfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("review" => $response));
		}
		else {
			$temparr["msg"] = "fail";
			array_push($response, $temparr);
			echo json_encode(array("review" => $response));
		}
	}
	
	/**
	 * function to add extra information about restaurents
	 
	 function addrestaurentsinfo() {
	 	if($this->input->post("pid")) {
	 			
	 		$pid = $this->input->post("pid");
        		
				$response = array();
				
				if($pid > 0) {
					$this->load->model("crudmodel");
					
					$restaurentuploadpath = $this->config->item("restaurent_upload_path");
					
					$config = array(
								"upload_path" => $restaurentuploadpath,
								"allowed_types" => "jpg|jpeg|gif|png"
							);
			
					$filename = $_FILES["userfile"]["name"];
					$filename = explode(".", $filename);
					$filename[0] = $filename[0].time().".".$filename[1];
					$_FILES["userfile"]["name"] = $filename[0];
			
					$this->load->library("upload", $config);
					
					if($this->upload->do_upload()) {
						
						$image_data = $this->upload->data();
						
						$imagestypes = array(
											"restaurent_index_upload_path" => $this->config->item("restaurent_index_upload_path"),
											"restaurent_home_upload_path" => $this->config->item("restaurent_home_upload_path"),
											"restaurent_detail_upload_path" => $this->config->item("restaurent_detail_upload_path"),
										);
						
						$this->load->library("image_lib");
						
						foreach ($imagestypes as $imagetype) {
								
							$width = 100;
							$heigth = 100;
							
							if($imagetype == $this->config->item("restaurent_index_upload_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("restaurent_home_upload_path")) {
								$width = 650;
								$heigth = 350;
							}
							else if($imagetype == $this->config->item("restaurent_detail_upload_path")) {
								$width = 275;
								$heigth = 198;
							}
														
							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
								
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
						
						$restaurentimages = $image_data["file_name"];
						
				
						$restaurent = array(
									"pid" => $pid,
									"restaurent_img" => $restaurentimages,
									"menus" => $this->input->post("menu"),
									"date" => date("Y-m-d H:i:s"),
								);
						if($this->crudmodel->addrestaurantinfo($restaurent)) {
							//$temparr["images"] = $image_data["file_name"];
							$temparr["msg"] = "success";
							array_push($response, $temparr);
							echo json_encode(array("restaurents" => $response));
						}
					}
					else {
						$temparr["msg"] = "fail";
						array_push($response, $temparr);
						echo json_encode(array("restaurents" => $response));
					}
				}
				else {
					$temparr["msg"] = "notfound.";
					array_push($response, $temparr);
					echo json_encode(array("restaurents" => $response));
				}
			}
	 }*/
	 
	 function addmealfromrecipe() {
	 		
	 	if($this->input->post("somekey")) {
	 		$response = array();
			
			$recipeid = $this->input->post("recipeid");
			
			$this->load->model("crudmodel");
			
			$recipe = $this->crudmodel->getrecipebyid($recipeid);
			
			if(isset($recipe) && $recipe != "") {
				$image = "defaultrecipe.png";
				if($recipe->images != "") {
					$images = explode(",", $recipe->images);
					if(count($images)) {
						if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
							$image = $images[0];
						}
					}
				}
				
				$uid = $this->db_session->userdata("id");
				$shoppinglist = $this->crudmodel->getshoppinglistbyrecipeid($recipe->id);
				$shoppinlistcount = 0;
				if(isset($shoppinglist) && !empty($shoppinglist)) {
					$ingredients = $shoppinglist->ingredients;
					$ingredients = explode("|", $ingredients);
					$shoppinlistcount = count($ingredients);
				}
				
				$price = $this->input->post("price");
				if(empty($price)) {
					$price = 0;
				}
				
				$typename = $this->input->post("type");
				$url = base_url()."recipe/details/".$recipe->seo;
				
				$date = date("Y-m-d H:i:s", strtotime($this->input->post("date")));
				$meal = array(
							"uid" => $uid,
							"recipeid" => $recipeid,
							"recipetitle" => $recipe->title,
							"shoppinlistcount" => $shoppinlistcount,
							"price" => $price,
							"image"	=> $image,
							"type" => $typename,
							"url" => $url,
							"date" => $date
						);
				$this->load->model("communitymodel");
				//$mealid = $this->communitymodel->addmeal($meal);
				if($this->communitymodel->addmeal($meal) > 0) {
					$temparr["msg"] = "success";
				}
				else {
					$temparr["msg"] = "fail";
				}
			}
			else {
				$temparr["msg"] = "notfound";
			}
			array_push($response, $temparr);
			echo json_encode(array("meal" => $response));
		}
	 }
}
?>