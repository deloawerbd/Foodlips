<?php

	class Videos extends Controller {
		function Videos() {
			parent::Controller();

			$this->load->helper("url");
			$this->load->helper("form");
			$this->load->model("communitymodel");
			$this->load->model("crudmodel");
		}
		
		function index() {
			$this->load->library("pagination");
			$config["base_url"] = base_url()."videos/index/";
			$config["uri_segment"] = 3;
			$config["per_page"] = 5;
			$config["full_tag_open"] = "<p>";
			$config["full_tag_close"] = "</p>";
			$config["cur_tag_open"] = "<b class='current'>";
			$config["cur_tag_close"] = "</b>";
			$config["next_link"] = "&gt";
			$config["prev_link"] = "&lt";

			$where = array(
					"approved" => "1"
				);

			$query = $this->crudmodel->getallrecipes($where);

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();

			$page = $this->uri->segment(3, 0);
	    	$page = explode("=", $page);
			if(is_array($page) && count($page) > 1) {
				$page = $page[1];
			}
			
			// check if $page is still array if yes then make it as non array variable
			// it is necessary to avoid db err as we cannot use array in place of start or end limit 
			if(is_array($page)) {
				$page = "";
			}
			
	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);

			if($this->input->post("sbt_search")) {
				
				$search = array(
						"title" => $this->input->post("search")
					);

				$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);
				
				//$query = $this->crudmodel->getallrecipes($limit);
			}
			else {
				$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
	
				//if(count($data["recipes"])) {
					//$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
				//}
				//$data["userimage"] = $this->crudmodel->getuserdetailsbyid();
			}
			
			$data["categories"] = $this->crudmodel->getallcategories();
			$data["top5recipes"] = $this->crudmodel->gettop5recipes();

			if($this->db_session->userdata("id") != "") {
				$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
			}			
			$data["pagination_links"] = $this->pagination->create_links();
			$data["page"] = "pages/videos";
			$this->load->view("template/template", $data);
		}
		
		function category() {
			$this->load->model("crudmodel");

			$selectedcategory = "";
			$categoryid = "";

	    	if($this->uri->segment(3) != "" && !is_numeric($this->uri->segment(3))) {
	    		$selectedcategory = $this->uri->segment(3);

				if($selectedcategory != "All") {
					if (strpos($this->uri->segment(3),"_") !== false) {
						$selectedcategory = str_replace("_", " ", $this->uri->segment(3));
					}
					$categoryid = $this->crudmodel->getcategoryidbycategoryname($selectedcategory);
				}
			}
			/* else if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {
				$categoryid = $this->uri->segment(3);
			} */
				
			//$selectedcategory = $this->uri->segment(3);
			
			$this->load->library("pagination");

			$config["base_url"] = base_url()."videos/category/".$selectedcategory;
			$config["uri_segment"] = 4;
			$config["per_page"] = 5;
			$config["full_tag_open"] = "<p>";
			$config["full_tag_close"] = "</p>";
			$config["cur_tag_open"] = "<b>";
			$config["cur_tag_close"] = "</b>";
			$config["next_link"] = "&gt";
			$config["prev_link"] = "&lt";

			$page = $this->uri->segment(4, 0);
	    	$page = explode("=", $page);
			if(is_array($page) && count($page) > 1) {
				$page = $page[1];
			}
			
			// check if $page is still array if yes then make it as non array variable
			// it is necessary to avoid db err as we cannot use array in place of start or end limit 
			if(is_array($page)) {
				$page = "";
			}
		
	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);
			
			if($categoryid != "") {
				$data["recipes"] = $this->crudmodel->getallrecipesbycategoryid($categoryid, $limit);
				$data["categoryid"] = $categoryid;
			}
				
			if($selectedcategory == "All") {
				
				$page = $this->uri->segment(4, 0);
	    		$page = explode("=", $page);
				if(is_array($page) && count($page) > 1) {
					$page = $page[1];
				}
				
				// check if $page is still array if yes then make it as non array variable
				// it is necessary to avoid db err as we cannot use array in place of start or end limit 
				if(is_array($page)) {
					$page = "";
				}
		
	    		$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);
				$config["uri_segment"] = 4;
				
				$where = array(
								"approved" => "1"
							);

				$query = $this->crudmodel->getallrecipes($where);
				$config["total_rows"] = $query->num_rows();
				$this->pagination->initialize($config);

				$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
			}
			else {
				$config["total_rows"] = count($this->crudmodel->getallrecipesbycategoryid($categoryid));
				$this->pagination->initialize($config);
			}
				
			//$data["top5recipes"] = $this->crudmodel->gettop5recipes();
			$data["categories"] = $this->crudmodel->getallcategories();

		 	if(count($data["recipes"])) {
				$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
		 	}
			
			$data["pagination_links"] = $this->pagination->create_links();
			
			$data["page"] = "pages/videos";
			$this -> load -> view("template/template", $data);
    	}
	
	}

?>