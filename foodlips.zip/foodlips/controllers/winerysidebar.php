<?php

class Winerysidebar extends Controller{
	
	function Winerysidebar(){
		parent::Controller();
		$this->load->model("winemodel");
	}
	
	function index(){
		$this->load->view("wineries/sidebar");
	}
	
	function ourpicks(){
		 $ourpicks = $this->winemodel->getourpicks();
		 print_r($ourpicks);exit;
		$this->load->view("wineries/sidebar");
	}
	function test(){
			echo "hello check";
	}
}
