<?php

class Paypal extends Controller {
	
	function index()
	{
		$this->load->view('paypal');
	}
	
	
}