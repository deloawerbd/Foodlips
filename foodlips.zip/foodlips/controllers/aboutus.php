<?php 

class Aboutus extends Controller {

		function Aboutus() {
			parent::Controller();

			$this->load->helper("url");
			$this->load->helper("form");
			$this->load->model("communitymodel");
		}
		function index(){
			$data["page"] = "pages/aboutus";
			$this->load->view("template/template", $data);
		}
}