<?php

class Home extends Controller {

    function Home() {
        parent::Controller();
        $this->load->model('home_model', 'home');
    }

    function index() {
        $data['slides'] = $this->home->get_slides();
        $this->load->view('home_view.php', $data);
    }

}

?>