<?php

/* ======This controller is only used for Restaurants Site ====== */

class Restaurants extends Controller {

    function Restaurants() {
        parent::Controller();

        $this->load->helper("url");
        //$this->load->helper("form");
        //$this->load->library("form_validation");

        $this->load->model("crudmodel");
        $this->load->model("communitymodel");
        $this->load->model("restaurants/restaurantmodel", "restmodel");
    }

    function index(){
        $this->load->view('restaurants/restaurants_view.php');
    }

    /**
     * Here we are checking country name and and display restaurants as per country
     */
    function country() {
        $countryarray = array("United-States", "Canada", "Argentina", "Brazil", "Australia", "New-Zealand",
            "Czech-Republic", "Denmark", "Germany", "United-Kingdom", "Ireland", "Italy", "Poland",
            "Portugal", "Austria", "Belgium", "Finland", "France", "Hungary", "Iceland", "Netherlands",
            "Norway", "Spain", "Sweden", "Switzerland", "South-Africa", "Japan", "Singapore", "Hong-Kong",
            "India", "China");

        $this->load->library("pagination");

        $rec_per_page = 0;
        $rec_per_page = 10;
        $next_page_no_of_recs_for_api = 0;
        $next_page_no_of_recs_for_api = 1;

        $config["uri_segment"] = 3;
        $config['num_links'] = 1;
        $config["per_page"] = $rec_per_page;
        $config["full_tag_open"] = "<p>";
        $config["full_tag_close"] = "</p>";
        $config["cur_tag_open"] = "<b class='current'>";
        $config["cur_tag_close"] = "</b>";
        $config["next_link"] = "&gt";
        $config["prev_link"] = "&lt";

        $fields = "id,categoryid,title,seo,images,price,content";

        if ($this->uri->segment('2') != "" && in_array($this->uri->segment('2'), $countryarray)) {
            $segment2 = $this->uri->segment('2');
        } else {
            $segment2 = "Australia";
        }
        $parameter = array();
        if (strpos($segment2, '-') !== false) {

            $country = explode('-', $segment2);
            $data["countryname"] = $country[0] . " " . $country[1];
        } else {
            $data["countryname"] = $segment2;
        }

        if (isset($data["countryname"]) && !empty($data["countryname"])) {
            $countryrow = $this->restmodel->getcountry(array("name" => $data["countryname"]));
            $parameter["countryid"] = $countryrow->id;
        }
        $where = array("countryid" => $parameter["countryid"], "iscapitalcity" => "1");
        $cities = $this->restmodel->getcitieswhere($where);
        //echo "<pre>";print_r($cities);echo "</pre><br>";
        //if(!empty($cities) && empty($_SERVER['REQUEST_URI'])){
        if (!empty($cities) && count($_SERVER['REQUEST_URI']) == 1) {
            $capitalcity = $cities[0]->name;
            $capitalstate = $this->restmodel->getstatesbycountryid(array("id" => $cities[0]->stateid));
            $address = $capitalcity . "," . $capitalstate[0]->state_name . "," . $data["countryname"];

            $data["searchstate"] = $capitalstate[0]->state_name;
            $where = array("stateid" => $capitalstate[0]->id);
            $data['cities'] = $this->restmodel->getcitieswhere($where);
            $data["searchcity"] = $capitalcity;
        }

        //echo $data["searchstate"] . '<br>';
        //echo $data["searchcity"] . '<br>';

        $radius = "100000";
        $keyword = "";
        $url = parse_url($_SERVER['REQUEST_URI']);
        $searchfeature = "";
        if (isset($url["query"]) && !empty($url["query"])) {
            $data["hideslider"] = "1";
            parse_str($url["query"], $query);
            if (isset($query["keyword"]) && !empty($query["keyword"])) {
                $keyword = $query["keyword"];
                $data["searchkeyword"] = $query["keyword"];
            }
            if (isset($query["state"]) && !empty($query["state"])) {
                $address = $query["state"] . "," . $data["countryname"];
                $stateid = $this->restmodel->getstateidbyname(array("state_name" => $query["state"]));
                $parameter["stateid"] = $stateid;
                $data["searchstate"] = $query["state"];
                $searchstate = $query["state"];
            }

            if (isset($query["city"]) && !empty($query["city"])) {
                $address = $query["city"] . "," . @$address;
                $cityrow = $this->restmodel->getcitieswhere(array("name" => $query["city"]));
                $parameter["cityid"] = $cityrow[0]->id;
                $data["searchcity"] = $query["city"];
            }

            if (isset($query["cuisine"]) && !empty($query["cuisine"])) {
                $parameter["cuisineid"] = $query["cuisine"];
                $data["searchcuisine"] = $query["cuisine"];
            }


            if (isset($query["feature"]) && !empty($query["feature"])) {
                //$parameter["featureid"] = $query["feature"];
                $searchfeature = '"' . $query["feature"] . '"';
                $data["searchfeature"] = $query["feature"];
            }


            if (isset($query["price"]) && !empty($query["price"])) {
                $parameter["price"] = $query["price"];
                $data["searchprice"] = $query["price"];
            }
        }

        //print_r(parse_url($_SERVER['REQUEST_URI']));
        //echo "<pre>";
        //print_r($data["venues"] = $this->_getfoursquarevenus($data["countryname"],NULL,NULL));exit;



        $data["country"] = $this->restmodel->getcountry(array("name" => $data["countryname"]));



        $config["base_url"] = base_url() . '/restaurants/' . str_replace(' ', '-', $data["countryname"]) . '/';

        $page = $this->uri->segment(3, 0);
        $page = explode("=", $page);
        if (is_array($page) && count($page) > 1) {
            $page = $page[1];

            if (empty($page)) {
                $page = 0;
            }
        }

        if (is_array($page)) {
            $page = 0;
        }
        //echo "<br>page".$page;
        $pagesfordb = 0;
        $total_rows = 0;
        $limitforapi = 0;
        $offset = 0;

        $where = array();
        $where = array("countryid" => $data["country"]->id);

//			$total_rows = $this->restmodel->getrestaurantsdetailcountforpagination($fields,$where);
        $total_rows = count($this->_getrestaurantsformdbpagination($fields, $parameter, $keyword, $searchfeature, "", "", null));

        $pagesfordb = $total_rows;

        if ($total_rows <= ($page + $rec_per_page)) {
            if (($total_rows < ($page + $rec_per_page)) && ($pagesfordb > 0)) {
                $total_rows = $total_rows + (($page + $rec_per_page) - $total_rows);
            } else {
                $total_rows = $page + $rec_per_page;
            }
            //$total_rows = $total_rows + ($rec_per_page * 2);
            $total_rows = $total_rows + $next_page_no_of_recs_for_api;
        }
//			$config["total_rows"] = $total_rows;
//			$this->pagination->initialize($config);

        $limit = array('start' => $config['per_page'], 'end' => $page);

        $order_by = "";
        $order = "";

//			echo $total_rows . '<br>';

        $restaurantsfromdb = array();
        $restaurantsfromapi = array();

        if ($page <= $pagesfordb) {
            $restaurantsfromdb = $this->_getrestaurantsformdbpagination($fields, $parameter, $keyword, $searchfeature, $order_by, $order, $limit);
        }

        if ($pagesfordb > 0) {
//				echo ($page + $rec_per_page) . '<br>';
//				echo ($pagesfordb); exit(0);

            if (($page + $rec_per_page) >= $pagesfordb) {
//					echo ($page + $rec_per_page); exit(0);

                if (($page + $rec_per_page - $pagesfordb) < $rec_per_page) {
                    $limitforapi = ($rec_per_page - ($pagesfordb - $page));
                    $offset = 0;
                } else {
                    $offset = ($page - $pagesfordb);
                    $limitforapi = $rec_per_page;
                }

                $restaurantsfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $limitforapi, $offset);

                $total_rows = $total_rows - ($limitforapi - count($restaurantsfromapi));

                $restaurantsfromapicount = count($this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $next_page_no_of_recs_for_api, (count($restaurantsfromapi) + $offset)));

                if ($restaurantsfromapicount == 0) {
                    $total_rows = $total_rows - 1;
                }

//					print_r($address); exit(0);
            }
        } else {
            $offset = $page;
            $limitforapi = $rec_per_page;

            $restaurantsfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $limitforapi, $offset);

            $total_rows = $total_rows - ($limitforapi - count($restaurantsfromapi));

            $restaurantsfromapicount = count($this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $next_page_no_of_recs_for_api, (count($restaurantsfromapi) + $offset)));

            if ($restaurantsfromapicount == 0) {
                $total_rows = $total_rows - 1;
            }
        }

        /* 			echo count($restaurantsfromapi);exit;
          echo $total_rows . '<br>';
          echo $limitforapi . '<br>';
          exit(0);
         */

        $config["total_rows"] = $total_rows;

        $this->pagination->initialize($config);

        $restaurants = array();
        $restaurantarray = array();
        if (!empty($restaurantsfromdb)) {

            foreach ($restaurantsfromdb as $restaurant) {

                $restaurantarray["from"] = "db";

                $restaurantarray["title"] = $restaurant->title;
                $restaurantarray["res_link"] = $restaurant->seo;
                $restaurantarray["content"] = $restaurant->content;

                $images = unserialize($restaurant->images);
                $restaurantarray["image"] = "Restaurantdefault.jpg";
                if (!empty($images)) {
                    $restaurantarray["image"] = $images[0];
                }


                $restaurantarray["price"] = "";
                $restaurantarray["category"] = "";

                $where = array("id" => $restaurant->price);
                $res = $this->restmodel->getprices($where);
                if (!empty($res)) {
                    $restaurantarray["price"] = $res->name;
                }
                $where = array("id" => $restaurant->categoryid);
                $res = $this->restmodel->getcategorybyid($where);
                if (!empty($res)) {
                    $restaurantarray["category"] = $res->name;
                }
                //to get the likes
                $where = array("rid" => $restaurant->id,
                    "liked" => "1"
                );
                $like = $this->restmodel->countlike($where);
                $where = array("rid" => $restaurant->id);
                $total_like = $this->restmodel->countlike($where);
                if ($like && $total_like) {
                    $restaurantarray["calculated_likes"] = ($like * 10) / $total_like;
                } else {
                    $restaurantarray["calculated_likes"] = 0;
                }
                $restaurants[] = (object) $restaurantarray;
            }
        }
        $markers = array();
        $markersarray = array();
        if (!empty($restaurantsfromapi)) {
            foreach ($restaurantsfromapi as $venue) {
                //echo "<pre>";
                //print_r($venue->venue->price);exit;
                //$image = $venue->venue->photos->groups[0]->items[0]->prefix."original".$venue->venue->photos->groups[0]->items[0]->suffix;
                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    if (property_exists($venue->location, "lat")) {
                        $markers["position"] = $venue->location->lat . "," . $venue->location->lng;
                    }
                } else {
                    if (property_exists($venue->venue->location, "lat")) {
                        $markers["position"] = $venue->venue->location->lat . "," . $venue->venue->location->lng;
                    }
                }

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    $markers["id"] = isset($venue->id) ? $venue->id : "";
                    $markers["name"] = isset($venue->name) ? $venue->name : "No Name";
                } else {
                    $markers["id"] = isset($venue->venue->id) ? $venue->venue->id : "";
                    $markers["name"] = isset($venue->venue->name) ? $venue->venue->name : "No Name";
                }

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    if (isset($venue->categories->icon) && !empty($venue->categories->icon)) {
                        $markers["image"] = $venue->categories->icon->prefix . $venue->categories->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/home/100x100/Restaurantdefault.jpg";
                    }
                    if (!empty($venue->respnse->venues->categories)) {
                        if (property_exists($venue->response->venues->categories['0'], "name")) {
                            $markers["type"] = $venue->response->venues->categories['0']->name;
                        }
                    }
                } else {
                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $markers["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/home/100x100/Restaurantdefault.jpg";
                    }
                    if (!empty($venue->venue->price) && property_exists($venue->venue, "price")) {
                        $markers["price"] = $venue->venue->price->message;
                    }
                    if (!empty($venue->venue->categories)) {
                        if (property_exists($venue->venue->categories['0'], "name")) {
                            $markers["type"] = $venue->venue->categories['0']->name;
                        }
                    }
                }

                //push markers details into array
                $markersarray[] = (object) $markers;

                $restaurantarray["from"] = "api";
                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    $restaurantarray["title"] = !empty($venue->name) ? $venue->name : "No Name";
                    $restaurantarray["res_link"] = ("venue/" . $venue->id);
                    $restaurantarray["content"] = "";
                } else {
                    $restaurantarray["title"] = !empty($venue->venue->name) ? $venue->venue->name : "No Name";
                    if (!empty($venue->venue->name)) {
                        $specialchars = array("'", "|", "%", ",", "!", "@", "$", "^", "*", "&", "-", "#", "?", "/", "-");
                        $titleforurl = str_replace($specialchars, "", $venue->venue->name);
                        $titleforurl = preg_replace('/\s+/', '_', $titleforurl);
                    } else {
                        $titleforurl = "v";
                    }
                    //print_r($titleforurl);
                    //echo"<br>";
                    $titleforurl = filter_var($titleforurl, FILTER_SANITIZE_URL);
                    if (isset($venue->venue->price->message) && $venue->venue->price->message == "Very Expensive") {
                        $priceappend = "-ve";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Expensive") {
                        $priceappend = "-e";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Moderate") {
                        $priceappend = "-m";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Cheap") {
                        $priceappend = "-c";
                    } else {
                        $priceappend = "";
                    }
                    $restaurantarray["res_link"] = !empty($venue->venue->id) ? ("venue/" . $titleforurl . "-" . $venue->venue->id) . $priceappend : "";
                    $restaurantarray["content"] = "";
                }
                $restaurantarray["image"] = base_url() . "public/frontend/images/restaurents/home/100x100/Restaurantdefault.jpg";

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    //Fouresquare Api Integration
                    $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
                    $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
                    // Load the Foursquare API library
                    $config = array(
                        "client_id" => $client_key,
                        "client_secret" => $client_secret
                    );
                    $this->load->library("foursquareapi", $config);
                    $venueId = $venue->id;
                    $image_response = $this->foursquareapi->GetPublic("venues/$venueId/photos");
                    $venue_image = json_decode($image_response);
                    if (!empty($venue_image->response->photos->items[0]->suffix) && !empty($venue_image->response->photos->items[0]->prefix)) {
                        //echo"<pre>";
                        //print_r($venue_image);exit;
                        //print_r($venue_image->response->photos->items[0]->prefix.$venue_image->response->photos->items[0]->suffix);exit;
                        $restaurantarray["image"] = $venue_image->response->photos->items[0]->prefix . "100x100" . $venue_image->response->photos->items[0]->suffix;
                    }
                } else {
                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $restaurantarray["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    }
                }


                $restaurantarray["price"] = "";
                $restaurantarray["category"] = "";

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    if (!empty($venue->categories) && property_exists($venue->categories['0'], "name")) {
                        $restaurantarray["category"] = $venue->categories['0']->name;
                    }
                } else {
                    if (!empty($venue->venue->price) && property_exists($venue->venue, "price")) {
                        $restaurantarray["price"] = $venue->venue->price->message;
                    }
                    if (!empty($venue->venue->categories) && property_exists($venue->venue->categories['0'], "name")) {
                        $restaurantarray["category"] = $venue->venue->categories['0']->name;
                    }
                }
                //to get the likes
                $venueid = $venue->venue->id;
                if (isset($venueid) && !empty($venueid)) {
                    $where = array("rid" => $venueid,
                        "liked" => "1"
                    );
                    $like = $this->restmodel->countlike($where);
                    $where = array("rid" => $venueid);
                    $total_like = $this->restmodel->countlike($where);
                    if ($like && $total_like) {
                        $restaurantarray["calculated_likes"] = ($like * 10) / $total_like;
                    } else {
                        $restaurantarray["calculated_likes"] = 0;
                    }
                }

                $restaurants[] = (object) $restaurantarray;
            }
            // echo"<pre>";
            //print_r($restaurants);exit;
        }


        $data["restaurants"] = $restaurants;
        $data["pagination_links"] = $this->pagination->create_links();

        $where = array("country_id" => $data["country"]->id);
        //$states = $this->restmodel->getstatesbycountryid($where);
        $data['states'] = $this->restmodel->getstatesbycountryid($where);
        //$where = array("stateid"=>200);
        //$cities = $this->restmodel->getcitieswhere($where);
        //print_r($cities);exit;
        // not sorted by states insufficiant data


        $results = $this->restmodel->getallcities_of_country($data["country"]->id);
        //echo '<pre>';print_r($results);echo '</pre>'; exit;
        /* 			$city_state_names = array();
          foreach($results as $result) {
          $city_state_names[] = $result->city . ' in ' . $result->state;
          } */
        $data['city_state_names'] = json_encode($results); //$city_state_names;
        //echo '<pre>';print_r($data['city_state_names']);echo '</pre>'; exit;

        if (!empty($searchstate)) {
            $where = array("state_name" => $searchstate);
            $stateid = $this->restmodel->getstateidbyname($where);
            $where = array("stateid" => $stateid);
            $data['cities'] = $this->restmodel->getcitieswhere($where);
        }
        //we are passing the venues for the top sliders
        $data["venues"] = $this->_getfoursquarevenus(isset($address) ? $address : $data["countryname"], NULL, NULL);
        $data['cuisines'] = $this->restmodel->getcuisines(NULL);
        $data['features'] = $this->restmodel->getfeatures();
        // $prices = $this->restmodel->getprices(NULL);
        // print_r($prices);exit;
        $data['prices'] = $this->restmodel->getprices(NULL);
        $data['countrymap'] = $this->_getcoutrymap($data["countryname"], $markersarray);
        //$data['statemap'] = $this->_getstatesmap($data["countryname"]);

        $data["page"] = "restaurants/home";
        $this->load->view("template/templaterestaurant", $data);
    }

    /**
     * Function to generate Google maps countrywise
     * @country: name of the country
     * @markers : array of the marker with full address
     */
    function _getcoutrymap($country, $markers = array()) {
        if (isset($country) && $country !== "") {

            // load maps library
            $this->load->library('googlemaps');
            $config['center'] = $country;
            $config['zoom'] = '4';
            $config['map_name'] = 'map_country';
            $config['map_div_id'] = 'map_canvas_country';
            $config['cluster'] = TRUE;

            $this->googlemaps->initialize($config);
            //print_r($markers);exit;
            if (isset($markers) && !empty($markers)) {
                foreach ($markers as $mark) {
                    //echo $mark->pos;

                    $marker["position"] = $mark->position;
                    $marker["icon"] = "https://chart.apis.google.com/chart?cht=mm&chs=24x32&chco=FFFFFF,008CFF,000000&ext=.png";
                    $marker['infowindow_content'] = $this->_markerpopup($mark);
                    $marker["animation"] = "DROP";
                    $this->googlemaps->add_marker($marker);
                }
            }

            $map = $this->googlemaps->create_map();
            return $map;
        }
    }

    /**
     * Function to get the states map
     */
    function _getstatesmap($country) {
        $this->load->library('googlemaps');
        $config['center'] = $country;
        $config['zoom'] = '4';
        //$config['region'] = $country;
        $config['map_name'] = 'state_map';
        $config['map_div_id'] = 'map_canvas_state';
        $config['map_height'] = '320px';
        $config['map_width'] = '88%';

        //$config['disableDefaultUI'] = 'TRUE';
        //$config['disableNavigationControl'] = 'TRUE';
        //$config['disableMapTypeControl'] = 'TRUE';
        $config['onclick'] = 'alert(\'You just clicked at: \' + event.latLng.lat() + \', \' + event.latLng.lng());';
        $this->googlemaps->initialize($config);

        return $statemap = $this->googlemaps->create_map();
    }

    /**
     * function to create popup window for google maps marker
     */
    function _markerpopup($marker) {
        /* $window = "<div style='width:200px; min-height:30px;'>";
          $window = $window . "<img src='".$marker->image."' />";
          $window = $window ."<div><a target='_blank' href='".base_url()."restaurant/details/venue/".$marker->id."'><b>".$marker->name."</b></a></div>";
          $window = $window . "<div>".@$marker->price."</div>";
          $window = $window ."</div>"; */

        $window = "<div class='marker_outerbox'>";
        $window .= "<div class='marker_imgbox'><img src='" . $marker->image . "'/></div>";
        $window .= "<div class='marker_content'>";
        $window .= "<h4><a target='_blank' href='" . base_url() . "restaurant/details/venue/" . $marker->id . "'>" . $marker->name . "</a></h4>";
        $window .= "<p>Type : " . @$marker->type . "</p>";
        $window .= "<p>Price : " . @$marker->price . "</p>";
        $window .= "</div>";
        $window .= "</div>";

        return $window;
    }

    /**
     * Function to get data from Foursqure API
     */
    function _getfoursquarevenus($country, $search, $venueid) {

        //Fouresquare Api Integration
        $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
        $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";

        // Load the Foursquare API library
        $config = array(
            "client_id" => $client_key,
            "client_secret" => $client_secret
        );

        $this->load->library("foursquareapi", $config);
        $this->load->model("restaurants/restaurantmodel", "restmodel");
        $address = explode(",", $country);
        //print_r(count($address));exit;
        if (count($address) == 3) {
            $where = array("name" => $address[0]);
            $city = $this->restmodel->getlatlng($where, "cities");

            if ($city[0]->latitude != "" && $city[0]->longitude != "") {
                $lat = $city[0]->latitude;
                $lng = $city[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                // $data = array("latitude" => $lat, "longitude"=> $lng);
                // $where = array("name" =>$address[0]);
                // $this->restmodel->addlatlng($data,$where,"cities");
            }
        } elseif (count($address) == 2) {

            $where = array("state_name" => $address[0]);
            $state = $this->restmodel->getlatlng($where, "state");

            if ($state[0]->latitude != "" && $state[0]->longitude != "") {
                $lat = $state[0]->latitude;
                $lng = $state[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;

                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);
                $where = array("state_name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "state");
            }
        } elseif (count($address) == 1) {

            $where = array("name" => $address[0]);
            $countries = $this->restmodel->getlatlng($where, "countries");
            //print_r($countries);exit;

            if ($countries[0]->latitude != "" && $countries[0]->longitude != "") {
                $lat = $countries[0]->latitude;
                $lng = $countries[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);

                $data = array("latitude" => $lat, "longitude" => $lng);
                $where = array("name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "countries");
            }
        }

        // Prepare parameters

        $params = array(
            "ll" => "$lat,$lng",
            "llAcc" => "100",
            "radius" => "100000",
            "categoryId" => "4d4b7105d754a06374d81259",
            "venuePhotos" => 1,
            "sortByDistance" => 1,
            "limit" => 10
        );

        // Perform a request to a public resource
        $response = $this->foursquareapi->GetPublic("venues/explore", $params);
        $venues = json_decode($response);
        //print_r($venues);exit;
        return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
    }

    function _getfoursquarevenusForPagination($country, $search, $keyword, $searchfeature, $venueid, $limit, $offset) {
        //Fouresquare Api Integration
        //print_r($country);exit;
        $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
        $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
        $radius = "100000";
        // Load the Foursquare API library
        $config = array(
            "client_id" => $client_key,
            "client_secret" => $client_secret
        );

        $this->load->library("foursquareapi", $config);
        $this->load->model("restaurants/restaurantmodel", "restmodel");
        $address = explode(",", $country);
        if (count($address) == 3) {
            $countryrow = $this->restmodel->getcountry(array("name" => $address[2]));
            $staterow = $this->restmodel->getstatesbycountryid(array("state_name" => $address[1]));

            $where = array("name" => $address[0], "stateid" => $staterow[0]->id, "countryid" => $countryrow->id);
            $city = $this->restmodel->getlatlng($where, "cities");

            if ($city[0]->latitude != "" && $city[0]->longitude != "") {
                $lat = $city[0]->latitude;
                $lng = $city[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                //$data = array("latitude" => $lat, "longitude"=> $lng);
                //$where = array("name" =>$address[0]);
                //$this->restmodel->addlatlng($data,$where,"cities");
            }
        } elseif (count($address) == 2) {
            $countryrow = $this->restmodel->getcountry(array("name" => $address[1]));
            $where = array("state_name" => $address[0], "country_id" => $countryrow->id);
            $state = $this->restmodel->getlatlng($where, "state");

            if ($state[0]->latitude != "" && $state[0]->longitude != "") {
                $lat = $state[0]->latitude;
                $lng = $state[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;

                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);

                $where = array("state_name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "state");
            }
        } elseif (count($address) == 1) {

            $where = array("name" => $address[0]);
            $countries = $this->restmodel->getlatlng($where, "countries");
            //print_r($countries);exit;

            if ($countries[0]->latitude != "" && $countries[0]->longitude != "") {
                $lat = $countries[0]->latitude;
                $lng = $countries[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);

                $data = array("latitude" => $lat, "longitude" => $lng);
                $where = array("name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "countries");
            }
        }
        /*
          $price = "";
          $price = "1,2,3,4";
          if(!empty($search["price"]))
          {
          if($search["price"] != 0)
          {
          $price = $search["price"];
          }
          }
         */
        // Prepare parameters
        //$price=1;				//"price" => $price,
        //print_r($lat);
        //echo"<br>";
        //print_r($lng);exit;
        $params = array(
            "ll" => "$lat,$lng",
            "llAcc" => "100000", //"100";
            "categoryId" => "4d4b7105d754a06374d81259",
            "radius" => "100000", //100000
            //"radius"=>$radius,
            //"categoryId"=>"4d4b7105d754a06374d81259",
            //"categoryId"=>"4bf58dd8d48988d13b941735",
            "venuePhotos" => 1,
            //"price"=>1,
            "sortByDistance" => 1,
            "limit" => $limit,
            "offset" => $offset,
            "section" => "",
            "intent" => "browse"
        );
        if (isset($search["price"])) {
            //$params["price"]=$search["price"];
        }
        if (isset($search["cuisineid"])) {
            $where = array('id' => $search["cuisineid"]);
            $category_id = $this->restmodel->getCategoryIdForCuisine($where);
            $params["categoryId"] = $category_id;
        }
        if (!empty($keyword)) {
            //print_r($keyword);exit;
            $params["query"] = $keyword;
            $params["intent"] = 'browse';
            $params["categoryId"] = "";
        }
        if (!empty($searchfeature)) {
            //print_r($keyword);exit;
            $params["query"] = $searchfeature;
            $params["intent"] = 'browse';
            $params["categoryId"] = "";
        }
        if (count($address) == 3) {
            $params["radius"] = 5000;
        }
        // Perform a request to a public resource
        if (!empty($keyword) || !empty($searchfeature)) {
            $new_venue_array = "";
            $response = $this->foursquareapi->GetPublic("venues/explore", $params);
            $venues = json_decode($response);
            $venuesarray = $venues->response->groups[0]->items;
            //echo "<pre>";
            //print_r($venuesarray);exit;
            foreach ($venuesarray as $singlevenue) {
                //$new_venue_array[] = $singlevenue;
                //echo"<pre>";
                //print_r($singlevenue);exit;
                $categoryid = $singlevenue->venue->categories[0]->id;
                if ($this->restmodel->isCategoryPresent($categoryid)) {
                    if (isset($search["price"])) {
                        $priceid = $singlevenue->venue->price->tier;
                        if ($priceid == $search["price"]) {
                            $new_venue_array[] = $singlevenue;
                        }
                    } else {
                        $new_venue_array[] = $singlevenue;
                    }
                }
            }
            //echo "<pre>";
            //print_r($new_venue_array);exit;
            return $new_venue_array;
            //echo "<pre>";
            //print_r($venues->response->groups[0]->items);exit;
            //return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
            //print_r($venues->response->venues);exit;
            //return isset($venues->response->venues) ? $venues->response->venues : "";
        } else {
            $new_venue_array = "";
            $response = $this->foursquareapi->GetPublic("venues/explore", $params);
            $venues = json_decode($response);
            // $venuesarray = $venues->response->groups[0]->items;
            // echo "<pre>";
            // print_r($venuesarray);exit;
            if (isset($search["price"])) {
                $venuesarray = $venues->response->groups[0]->items;
                //echo "<pre>";
                //print_r($venuesarray);exit;
                foreach ($venuesarray as $singlevenue) {
                    if (isset($singlevenue->venue->price->tier)) {
                        $priceid = $singlevenue->venue->price->tier;
                    } else {
                        $priceid = "";
                    }
                    //print_r($priceid);
                    if ($priceid == $search["price"]) {
                        $new_venue_array[] = $singlevenue;
                    }
                }
                return $new_venue_array;
            } else {
                return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
            }
            //echo "<pre>";
            //print_r($new_venue_array);exit;
            //return $new_venue_array;
            //echo "<pre>";
            //print_r($venues->response->groups[0]->items);
            //exit;
            //echo "<pre>";
            //print_r($venues->response->groups[0]->items);exit;
        }

        //echo"<pre>";
        //print_r($venues);exit;
    }

    /**
     * Function to get restaurants for our site database
     */
    function _getrestaurantsformdb($country) {

        if (isset($country) && !empty($country)) {
            $countryrow = $this->restmodel->getcountry(array("name" => $country));
            $parameters["countryid"] = $countryrow->id;
        }
        $url = parse_url($_SERVER['REQUEST_URI']);
        if (isset($url["query"]) && !empty($url["query"])) {
            parse_str($url["query"], $query);

            if (isset($query["state"]) && !empty($query["state"])) {
                $staterow = $this->restmodel->getstatesbycountryid(array("state_name" => trim($query["state"])));
                $parameters["stateid"] = $staterow[0]->id;
            }
            if (isset($query["city"]) && !empty($query["city"])) {
                $cityrow = $this->restmodel->getcitieswhere(array("name" => trim($query["city"])));
                $parameters["cityid"] = $cityrow[0]->id;
            }
            if (isset($query["cuisine"]) && !empty($query["cuisine"])) {
                $parameters["cuisineid"] = $query["cuisine"];
            }
            if (isset($query["feature"]) && !empty($query["feature"])) {
                //$parameter["feature"] = $query["feature"];
            }
            if (isset($query["price"]) && !empty($query["price"])) {
                $parameters["price"] = $query["price"];
            }
        }
        return $this->restmodel->getrestaurants($parameters);
    }

    function _getrestaurantsformdbpagination($fields, $parameters, $keyword, $feature, $order_by, $order, $limit) {
        $searchprices = "";
        $searchfeatures = "";
        $searchcuisines = "";
        if (!empty($keyword)) {
            $table = "rest_price";
            $results = $this->restmodel->searchFreeKeyword($keyword, $table);
            if ($results) {
                foreach ($results as $result) {
                    $searchprices[] = $result->id;
                }
            }
            $table = "rest_features";
            $results = $this->restmodel->searchFreeKeyword($keyword, $table);
            //print_r($result);exit;
            if ($results) {
                foreach ($results as $result) {
                    $searchfeatures[] = $result->id;
                }
            }
            $table = "rest_cuisine";
            $results = $this->restmodel->searchFreeKeyword($keyword, $table);
            if ($results) {
                foreach ($results as $result) {
                    $searchcuisines[] = $result->id;
                }
            }
        }
        //print_r($parameters); exit(0);
        return $this->restmodel->getrestaurantsdetailforpagination($fields, $parameters, $keyword, $searchprices, $searchfeatures, $searchcuisines, $feature, $order_by, $order, $limit);
        //$return =  $this->restmodel->getrestaurantsdetailforpagination($fields, $parameters, $order_by, $order, $limit);
        //print_r($return);exit;
    }

}

?>