<?php

class Winery extends Controller {
	
	function Winery() {
		parent :: Controller();
		
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->library("form_validation");
		$this->load->model("wineries/winemodel");
		$this->load->model("crudmodel");
		$this->load->model("communitymodel");
		$this->load->model("restaurants/restaurantmodel","restmodel");
	}
	
	function index(){
		$base_url = base_url();
		redirect($base_url."wineries/Australia");
	}
	
	// add new winery
	function add() {
		$this->freakauth_light->check();
		
		$data["countries"] = $this->restmodel->getallcountries($this->config->item("winecountryids"));
		//$data["cities"] = $this->restmodel->getallcities();
		$data["cuisines"] = $this->restmodel->getcuisines(NULL);
		$data["categories"] = $this->restmodel->getcategories();
		$data["features"] = $this->restmodel->getfeatures();
		$data["prices"] = $this->restmodel->getprices(NULL);
		
		if($this->input->post("sbt_add")){
			//print_r($_POST);exit;
			$this->form_validation->set_rules("country", "Country", "required");
			$this->form_validation->set_rules("title", "Title", "required");
			$this->form_validation->set_rules("geo_address", "Address", "required");
			$this->form_validation->set_rules("description", "Description", "required");
			$this->form_validation->set_rules("contact", "Phone", "required|numeric");
			$this->form_validation->set_rules("txtemail", "Email", "required|valid_email");
			
			if ($this->form_validation->run() == FALSE) {
				$data['page'] = "wineries/addwinery";
				$this->load->view("template/templaterestaurant",$data);
			}else {
				
				$winery = array(
								"uid" => $this->db_session->userdata("id"),
								"cuisineid" => $this->input->post("selcuisine"),
								"categoryid" => $this->input->post("selcategory"),
								"title" => $this->input->post("title"),
								"seo" => $this->_createseo($this->input->post("title")),
								"content" => $this->input->post("description"),
								"latitude" => $this->input->post("geo_latitude"),
								"longitude" => $this->input->post("geo_longitude"),
								"geo_address" => $this->input->post("geo_address"),
								"timing" => $this->input->post("timing"),
								"contact" => $this->input->post("contact"),
								"email" => $this->input->post("txtemail"),
								"website" => $this->input->post("website"),
								"twitter" => $this->input->post("twitter"),
								"facebook" =>$this->input->post("facebook"),
								"video" => $this->input->post("video"),
								"images" => is_array($this->input->post("imagearray")) ? serialize($this->input->post("imagearray")) : "",
								"price" => $this->input->post("selprice"),
								"special_offers" => $this->input->post("specialoffer"),
								"featureid" => serialize($this->input->post("selfeature")),
								"countryid" => $this->input->post("country"),
								"stateid" => $this->input->post("state"),
								"cityid" => $this->input->post("city"),
								"date" => date("Y-m-d h:m:i")
							);
				//print_r($winery);exit;
				if($this->winemodel->addwinery($winery)){
					redirect("winery/add", "refresh");
				}
			}
		}else{
			$data['page'] = "wineries/addwinery";
			$this->load->view("template/templaterestaurant",$data);
		}
	}

	// function to cerate seo link
	function _createseo($postval) {
        $specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
        return $seo = strtolower(str_replace($specialchars, "-", $postval)."-".md5(time()));
    }
	
	// function to show detail view of winery
	function details() {
		$data["allfeatures"] = $this->winemodel->getfeatures();
		$data["segment3"] = $this->uri->segment("3");
		
		if($this->uri->segment("3") != "" && $this->uri->segment("3") != "venue"){
							
			// data are comming from our database
			$seo = $this->uri->segment("3");
			$winery = $this->winemodel->getwinerydetails(array("seo" => $seo));
			if(!empty($winery)) {
				$data["wineries"] = $winery;
				$data["cuisine"] = $this->winemodel->getcuisines(array("id" => $winery->cuisineid));
				if($this->is_serial($winery->featureid)) {
					$features = unserialize($winery->featureid);
					$data["features"] = $this->winemodel->getfeaturebyid($features);
				}else{
					$data["features"] = $this->winemodel->getfeaturebyid($winery->featureid);
				}
				$data["price"] = $this->winemodel->getprices(array("id" => $winery->price));
				$data["country"] = $this->winemodel->getcountry(array("id" => $winery->countryid));
				if(isset($winery->latitude) && isset($winery->longitude)){
					$latlng = $winery->latitude.",".$winery->longitude;
					$data["topmap"] = $this->_getmap($latlng);
				}else{
					$data["topmap"] = $this->_getmap($winery->geo_address);
				}
				if($this->is_serial($winery->images)){
					$data["images"] = unserialize($winery->images);
				}
				//for menu images
				
				$breakfast_imgs = array();
				$lunch_imgs = array();
				$dinner_imgs = array();
				$extrainfo_rows = $this->winemodel->getImages($winery->id);
				//print_r($breakfast_images);exit;
				if($extrainfo_rows){
				foreach($extrainfo_rows as $extrainfo_row){
					if($this->is_serial($extrainfo_row->breakfast)){
					$breakfastarray = unserialize($extrainfo_row->breakfast);
					foreach($breakfastarray as $breakfastarr){
						$breakfast_imgs[] = $breakfastarr; 
					}
					}
					if($this->is_serial($extrainfo_row->lunch)){
					$luncharray = unserialize($extrainfo_row->lunch);
					foreach($luncharray as $luncharr){
						$lunch_imgs[] = $luncharr; 
					}
					}
					if($this->is_serial($extrainfo_row->dinner)){
					$dinnerarray = unserialize($extrainfo_row->dinner);
					foreach($dinnerarray as $dinnerarr){
						$dinner_imgs[] = $dinnerarr; 
					}
					}
					
					
				}
				
				//echo"<pre>";
				//print_r($breakfast_imgs);
				//exit();
				$data['breakfast_imgs'] = $breakfast_imgs;	
				$data['lunch_imgs'] = $lunch_imgs;	
				$data['dinner_imgs'] = $dinner_imgs;	
				}
				//for likes
				if($this->db_session->userdata("id")){
					$where = array(
								'wid'=>$winery->id,
								'uid'=>$this->db_session->userdata("id")
							   );
					$data["liked"] = $this->winemodel->getlikebyuser($where);
				}
				$where = array("wid"=>$winery->id,
								"liked"=>"1"
								);
				$like =  $this->winemodel->countlike($where);
				$where = array("wid" => $winery->id);
				$total_like = $this->winemodel->countlike($where);
				if($like && $total_like){
					$data["calculated_likes"] = ($like*10)/$total_like;
				}else{
					$data["calculated_likes"] = 0;
				}
				$where = array("wid" => $winery->id);
				$data["comments"] = $this->winemodel->getcomments($where);
				$data["hours"] = $this->winemodel->gethours(null);
				$data["neighbors"] = $this->winemodel->getneighborswineries($winery->latitude,$winery->longitude);
			    $data["page"] = "wineries/details";
				$this->load->view("template/templaterestaurant",$data);
			}
		}else if($this->uri->segment("3") == "venue" && $this->uri->segment("4") != ""){
						
			//data will come from Foursquare API
			$segment_4 = $this->uri->segment("4");
			$segment_4 = explode("-", $segment_4);
			if(isset($segment_4[2])){
				if($segment_4[2]=="ve"){
					$data["priceappend"] = "Very Expensive";
				}elseif($segment_4[2] == "e"){
					$data["priceappend"] = "Expensive";
				}elseif($segment_4[2] == "m"){
					$data["priceappend"] = "Moderate";
				}elseif($segment_4[2] == "c"){
					$data["priceappend"] = "Cheap";
				}elseif($segment_4[2] == ""){
					$data["priceappend"] = "";
				}
			}else{
				$data["priceappend"] = "";
			}
			if(isset($segment_4[1])){
				$venueid = $segment_4[1];	
			}else{
				$venueid = $this->uri->segment("4");
			}
			//$venueid = $this->uri->segment("4");
			$where = array("wid"=>$venueid);
			if($this->winemodel->getwineextrainfoapi($where)>0){
				$restaurant = $this->winemodel->getwineextrainfoapi($where);
				//print_r($restaurant);exit;
				if($this->is_serial($restaurant[0]->winery_img)){
						$data["images"] = unserialize($restaurant[0]->winery_img);
				}
				if($this->is_serial($restaurant[0]->featureid)) {
					$features = unserialize($restaurant[0]->featureid);
					$data["features"] = $this->winemodel->getfeaturebyid($features);
				}else{
					$data["features"] = $this->winemodel->getfeaturebyid($restaurant[0]->featureid);
				}
			}
			//for menu images
			$breakfast_imgs = array();
			$lunch_imgs = array();
			$dinner_imgs = array();
			$extrainfo_rows = $this->winemodel->getImages($venueid);
			//print_r($breakfast_images);exit;
			if($extrainfo_rows){
			foreach($extrainfo_rows as $extrainfo_row){
				if($this->is_serial($extrainfo_row->breakfast)){
				$breakfastarray = unserialize($extrainfo_row->breakfast);
				foreach($breakfastarray as $breakfastarr){
					$breakfast_imgs[] = $breakfastarr; 
				}
				}
				if($this->is_serial($extrainfo_row->lunch)){
				$luncharray = unserialize($extrainfo_row->lunch);
				foreach($luncharray as $luncharr){
					$lunch_imgs[] = $luncharr; 
				}
				}
				if($this->is_serial($extrainfo_row->dinner)){
				$dinnerarray = unserialize($extrainfo_row->dinner);
				foreach($dinnerarray as $dinnerarr){
					$dinner_imgs[] = $dinnerarr; 
				}
				}
				
				
			}
			
			//echo"<pre>";
			//print_r($breakfast_imgs);
			//exit();
			$data['breakfast_imgs'] = $breakfast_imgs;	
			$data['lunch_imgs'] = $lunch_imgs;	
			$data['dinner_imgs'] = $dinner_imgs;	
			}
			$venue = $this->_getfoursquarevenue($venueid);
			if(isset($venue) && !empty($venue)) {
				//to  get the likes
				if($this->db_session->userdata("id")){
					$where = array(
								'wid'=>$venueid,
								'uid'=>$this->db_session->userdata("id")
							   );
					$data["liked"] = $this->winemodel->getlikebyuser($where);
				}
				$where = array("wid"=>$venueid,
								"liked"=>"1"
								);
				$like =  $this->winemodel->countlike($where);
				$where = array("wid" => $venueid);
				$total_like = $this->winemodel->countlike($where);
				if($like && $total_like){
					$data["calculated_likes"] = ($like *10)/$total_like;
				}else{
					$data["calculated_likes"] = 0;
				}
				$data["venue"] = $venue;
				$data["neighborvenues"] = $this->_getneighborhoodvenues($venue->location->lat, $venue->location->lng);
				$latlng = $venue->location->lat.",".$venue->location->lng;
				
				$data["topmap"] = $this->_getmap($latlng);
				$data["hours"] = $this->winemodel->gethours(null);
				$where = array("wid" => $venueid);
				$data["comments"] = $this->winemodel->getcomments($where);
				
				$data["page"] = "wineries/venuedetails";
				$this->load->view("template/templaterestaurant",$data);	
			}
		}
	}

			//function to check is srting serialize return result
			function is_serial($data) {
				return (@unserialize($data) !== false);
			} 
	
	//Function to get venue data from Foursqure API
	function _getfoursquarevenue($venueid) {
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
		
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/".$venueid);
		$venues = json_decode($response);
		//echo "<pre>";
		//print_r($venues->response->venue);exit;
		return $venues->response->venue;
	}
	
	//Function to get Neighborhood winery
	function _getneighborhoodvenues($lat,$lng){
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
/*
		$params = array(
						"ll" => "$lat,$lng",
						"llAcc" => "100",
						"radius"=>"1000",
						"categoryId"=>"4d4b7105d754a06374d81259",
						"venuePhotos" => 1,
						"sortByDistance" => 1,
						"limit" => 4
					);
 */
 
 		$params = array(
						"ll" => "$lat,$lng",
						"llAcc" => "100",
						"radius"=>"1000",
						"categoryId"=>"4bf58dd8d48988d14b941735",
						"venuePhotos" => 1,
						"sortByDistance" => 1,
						"limit" => 4
					);
					
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/explore",$params);
		$venues = json_decode($response);
		//echo "<pre>";
		//print_r($venues->response->groups[0]->items);exit;
		return $venues->response->groups[0]->items;
	}
	
	// Function to show map address with marker
	 function _getmap($address) {
	 	$this->load->library('googlemaps');
		$config['center'] = $address;
		$config['zoom'] = '15';
		//$config['map_name'] = 'state_map';
		//$config['map_div_id'] = 'map_canvas_state';
		$config['map_height'] = '320px';
		$config['map_width'] = '100%';
		
		$marker["position"] = $address;
		$marker["icon"] = "http://chart.apis.google.com/chart?cht=mm&chs=24x32&chco=FFFFFF,008CFF,000000&ext=.png";
		//$marker['infowindow_content'] = $this->_markerpopup($mark);
		$marker["animation"] = "DROP";
		$this->googlemaps->add_marker($marker);
		$this->googlemaps->initialize($config);
		
		return $statemap = $this->googlemaps->create_map();
	 }
	
}
?>