<?php

class wineries extends Controller{
	
	function wineries(){
		parent::controller();
		$this->load->model("wineries/winemodel");
		//$this->load->model("restaurants/restaurantmodel");
		$this->load->model("restaurants/restaurantmodel","restmodel");
		$this->_container = $this->config->item('FAL_template_dir').'template_admin/container';
		$this->load->library("form_validation");
		$this->freakauth_light->check("admin");
		//$this->output->enable_profiler(TRUE);
	}
	
	function index(){
		$mesg = null;
		$selected = "";
		$selected1 = ""; 
		if($this->input->post("submitpicks")){
			$checkedarray = $this->input->post("checkedarray");
			$checkedarray = explode("_", $checkedarray);
			//print_r($checkedarray);exit;
			$data = array("ourpicks"=>"0");
			$table = "wine_details";
			$where = "";
			$this->winemodel->updatepicks($where,$data,$table);
			foreach($checkedarray as $check) {
						//print_r($check);
						$data = array("ourpicks"=>"1");	
						$where = array("id"=>$check);
						$table = "wine_details";
						$mesg = $this->winemodel->updatepicks($where,$data,$table);
					}
					
					
			$checkedarray = $this->input->post("checkedarray1");
			$checkedarray = explode("_", $checkedarray);
			$data = array("mostpopular"=>"0");
			$table = "wine_details";
			$where = "";
			$this->winemodel->updatepicks($where,$data,$table);
			foreach($checkedarray as $check) {
						//print_r($check);
						$data = array("mostpopular"=>"1");	
						$where = array("id"=>$check);
						$table = "wine_details";
						$mesg = $this->winemodel->updatepicks($where,$data,$table);
					}
		}
		$this->load->library("pagination");
		$config["base_url"] = base_url().'/admin/wineries/index/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
		$config["total_rows"] = $this->winemodel->rowcount();
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		if(is_array($page)&& count($page)>0){
			$page  = explode("=", $page);
		}
		
		if(is_array($page)){
			$page = "";
		}
		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		$wineries = $this->winemodel->getallwineriesdetails($limit);
		// echo"<pre>";
		 // print_r($wineries);
		 $newwineryarray = array();
		 if(isset($wineries)&&!empty($wineries)){
		foreach($wineries as $winery){
			$wineryarray = (array)$winery;
			if(isset($winery->countryid)&&!empty($winery->countryid)){
			$where = array("id"=>$winery->countryid);
			$wineryarray["countryname"] = $this->winemodel->getcountry($where)->name;
			}
			if(isset($winery->stateid)&&!empty($winery->stateid)){
			$where = array("id"=>$winery->stateid);
			$wineryarray["statename"] = $this->winemodel->getstate($where)->state_name;
			}
			$wineryobject = (object)$wineryarray;
			$newwineryarray[] = $wineryobject;
		}
		 }
		for($i=0; $i<count($newwineryarray); $i++){
			$wineries[$i] = $newwineryarray[$i];
		}
		$checked = $this->winemodel->getcheckedids();
		foreach($checked as $check){
			//print_r($check->id);
			$selected .= $check->id."_";
		}
		$selected = substr($selected, 0, strlen($selected)-1);
		$data["selected"] = $selected;

		$checked = $this->winemodel->getcheckedmostpopularids();
		foreach($checked as $check){
			//print_r($check->id);
			$selected1 .= $check->id."_";
		}
		$selected1 = substr($selected1, 0, strlen($selected1)-1);
		$data["selected1"] = $selected1;
		
		$table = "wine_details";
		$pickscount = $this->winemodel->getpickscount($table);
 		$data["pickscount"] = $pickscount;
		$mostpopularcount = $this->winemodel->getmostpopularcount($table);
 		$data["mostpopularcount"] = $mostpopularcount;
		$data["mesg"] = $mesg;
		$data["wineries"] = $wineries;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/list';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function editwinery(){
		$id = $this->uri->segment(4);
		$where = array("id"=>$id);
		$data["winery"] = $this->winemodel->getwinerydetails($where);
		$data["countries"] = $this->restmodel->getallcountries($this->config->item("winecountryids"));
		//$data["cities"] = $this->restmodel->getallcities();
		$data["cuisines"] = $this->restmodel->getcuisines(NULL);
		$data["categories"] = $this->winemodel->getcategories();
		$data["features"] = $this->restmodel->getfeatures();
		$data["prices"] = $this->restmodel->getprices(NULL);
		
		if($this->input->post("sbt_add")){
			//print_r($_POST);exit;
			$this->form_validation->set_rules("country", "Country", "required");
			$this->form_validation->set_rules("title", "Title", "required");
			$this->form_validation->set_rules("geo_address", "Address", "required");
			$this->form_validation->set_rules("description", "Description", "required");
			$this->form_validation->set_rules("contact", "Phone", "required|numeric");
			$this->form_validation->set_rules("txtemail", "Email", "required|valid_email");
			if($this->form_validation->run()){
			$winery = array(
							"uid" => $this->db_session->userdata("id"),
							"cuisineid" => $this->input->post("selcuisine"),
							"categoryid" => $this->input->post("selcategory"),	
							"title" => $this->input->post("title"),
							"seo" => $this->_createseo($this->input->post("title")),
							"content" => $this->input->post("description"),
							"latitude" => $this->input->post("geo_latitude"),
							"longitude" => $this->input->post("geo_longitude"),
							"geo_address" => $this->input->post("geo_address"),
							"timing" => $this->input->post("timing"),
							"contact" => $this->input->post("contact"),
							"email" => $this->input->post("txtemail"),
							"website" => $this->input->post("website"),
							"twitter" => $this->input->post("twitter"),
							"facebook" =>$this->input->post("facebook"),
							"video" => $this->input->post("video"),
							"price" => $this->input->post("selprice"),
							"special_offers" => $this->input->post("specialoffer"),
							"featureid" => serialize($this->input->post("selfeature")),
							"countryid" => $this->input->post("country"),
							"stateid" => $this->input->post("state"),
							"cityid" => $this->input->post("city"),
							"images" => is_array($this->input->post("imagearray")) ? serialize($this->input->post("imagearray")) : "",
							//"images" => !empty($this->input->post("imagearray")) ? serialize($this->input->post("imagearray")) : "",
							//"images" =>$images,
							"date" => date("Y-m-d h:m:i")
						);
			$where = array("id"=>$id);
			if($this->winemodel->updatewinery($where,$winery)){
				redirect(base_url()."admin/wineries", "refresh");
			}
			}
		}else{
			$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/edit';
			$this->load->vars($data);
	    	$this->load->view($this->_container);	
		}
		}
		function _createseo($postval) {
        $specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
        return $seo = strtolower(str_replace($specialchars, "-", $postval)."-".md5(time()));
   		}
		
	function managephotosbackup(){
		$mesg = null;
		$selected = "";
		$selected1 = ""; 
		if($this->input->post("submitpicks")){
	
			//For Approve
			$checkedarray = $this->input->post("checkedarray");
			$checkedarray = explode(",", $checkedarray);
			//print_r($checkedarray);exit;
			$table = "rest_details";
			foreach($checkedarray as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{

				$where = array("id"=>$arr[1]);

				$res = $this->winemodel->getwinerydetails($where);
				if(!empty($res->images))
				{
					$imgdata = unserialize($res->images);
				}
				$imgdata[] = $arr[6];
				$data = array("images"=>serialize($imgdata));
				
				$mesg = $this->winemodel->updatewinery($where,$data);
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->winery_img))
				{
					$imgdata1 = unserialize($res[0]->winery_img);
					$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
				}
				if(!empty($imgdata1))
				{
					$data = array("winery_img"=>serialize($imgdata1));
				}
				else {
					$data = array("winery_img"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}
			
			//For DisApprove
			$checkedarray1 = $this->input->post("checkedarray1");
			$checkedarray1 = explode(",", $checkedarray1);
			
			foreach($checkedarray1 as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->winery_img))
				{
					$imgdata1 = unserialize($res[0]->winery_img);
					//array_values function is used for reindex of array & array_diff function to remove specific string or value from array
					$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
					
					$this->deletesavedimageWhenDisapprove($arr[6]);
				}
				if(!empty($imgdata1))
				{
					$data = array("winery_img"=>serialize($imgdata1));
				}
				else {
					$data = array("winery_img"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}
		}
		
		$this->load->library("pagination");
		$config["base_url"] = base_url().'/admin/wineries/managephotos/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
		
		$field = "winery_img";
		
		$config["total_rows"] = $this->winemodel->getwineriesextrainfocountforapproval($field);
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		if(is_array($page)&& count($page)>0){
			$page  = explode("=", $page);
		}
		if(is_array($page)){
			$page = "";
		}
		
		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		
		$wineries = $this->winemodel->getwineriesextrainfoforapproval($field,$limit);

		$newwineryarray = array();
		if(isset($wineries)&&!empty($wineries)){
		foreach($wineries as $winery){
			$wineryarray = (array)$winery;
			$wineryobject = (object)$wineryarray;
			$newwineryarray[] = $wineryobject;
		}
		}
		for($i=0; $i<count($newwineryarray); $i++){
			$wineries[$i] = $newwineryarray[$i];
		}
		
		$data["selected"] = "";
		$data["selected1"] = "";
		$table = "wine_details";
 		$data["pickscount"] = 0;
 		$data["mostpopularcount"] = 0;
		$data["mesg"] = $mesg;
		$data["wineries"] = $wineries;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/managephotos';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function managephotos() {
		$mesg = null;
		$selected = "";
		if($this->input->post("submitpicks")){
			
			//For Approve
			$checkedarray = $this->input->post("checkedarray");
			$checkedarray = explode(",", $checkedarray);
			$table = "wine_details";
			foreach($checkedarray as $check) {
				$arr = explode("[]", $check);
				if(!empty($arr[1]))
				{
				if($arr[7] == "database"){
					$where = array("id"=>$arr[1]);
					$res = $this->winemodel->getwineriesdetails($where);
					if(!empty($res->images))
					{
						$imgdata = unserialize($res->images);
					}
					$imgdata[] = $arr[6];
					$data = array("images"=>serialize($imgdata));
					
					$mesg = $this->winemodel->updatewinery($where,$data);
		
					$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
					$res = $this->winemodel->getwineriesextrainfo($where);
	 				if(!empty($res[0]->winery_img))
					{
						$imgdata1 = unserialize($res[0]->winery_img);
						$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
					}
					if(!empty($imgdata1))
					{
						$data = array("winery_img"=>serialize($imgdata1));
					}
					else {
						$data = array("winery_img"=>"");
					}
						
					$this->winemodel->updatewinerieseaxtrainfo($where,$data);
					
				}else{
					$where = array("wid"=>$arr[1]);
					if($this->winemodel->getwineextrainfoapi($where)>0){
						$res = $this->winemodel->getwineextrainfoapi($where);
						if(!empty($res[0]->winery_img)){
							$imgdata = unserialize($res[0]->winery_img);
						}
						$imgdata[] = $arr[6];
						$data = array("winery_img"=>serialize($imgdata));
						$mesg = $this->winemodel->updatewineeaxtrainfoapi($where,$data);
						}else{
							$imgdata[] = $arr[6];
							$data = array("wid"=>$arr[1],
										  "uid"=>$arr[3],
							              "winery_img"=>serialize($imgdata),
										  "date" => date("Y-m-d h:m:i"),
										   "ip" => $_SERVER["REMOTE_ADDR"] );
							$mesg = $this->winemodel->addwineextarinfoapi($data);
						}
						$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
						$res = $this->winemodel->getwineriesextrainfo($where);
		 				if(!empty($res[0]->winery_img))
						{
							$imgdata1 = unserialize($res[0]->winery_img);
							$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
						}
						if(!empty($imgdata1))
						{
							$data = array("winery_img"=>serialize($imgdata1));
						}
						else {
							$data = array("winery_img"=>"");
						}
							
						$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
				}
				
			}
			
			//For DisApprove
			$checkedarray1 = $this->input->post("checkedarray1");
			$checkedarray1 = explode(",", $checkedarray1);
			
			foreach($checkedarray1 as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->winery_img))
				{
					$imgdata1 = unserialize($res[0]->winery_img);
					//array_values function is used for reindex of array & array_diff function to remove specific string or value from array
					$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
					
					$this->deletesavedimageWhenDisapprove($arr[6]);
				}
				if(!empty($imgdata1))
				{
					$data = array("winery_img"=>serialize($imgdata1));
				}
				else {
					$data = array("winery_img"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}

		}
		
		$this->load->library("pagination");
		$config["base_url"] = base_url().'admin/wineries/managephotos/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
	
		$field = "winery_img";
		
		$config["total_rows"] = $this->winemodel->getwineriesextrainfocountforapproval($field);
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
		// $venueid = "51273b29e4b0d56d1cd80eb3"; 
		// $venue = $this->_getfoursquarevenue($venueid);
		// print_r($venue);exit;
		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		
		$restaurants = $this->winemodel->getwineriesextrainfoforapproval($field,$limit);
		
		 $newrestaurantarray = array();
		 if(isset($restaurants)&&!empty($restaurants)){
		foreach($restaurants as $restaurant){
			$restaurantarray = (array)$restaurant;
			$where = array("wid"=>$restaurant->wid);
			$rest = $this->winemodel->getwineriesextrainfo($where);
			if($rest[0]->datalocation == "api"){
				$venueid = $restaurant->wid;
				$venue = $this->_getfoursquarevenue($venueid);
				if(isset($venue)&&!empty($venue)){
					$restaurantarray["title"] = $venue;	
				}
			}else{
				$where = array("id"=>$restaurant->wid);
				$gettitle= $this->winemodel->getwineriesdetails($where);
				$restaurantarray["title"] =$gettitle->title; 
			}
			
			$restaurantobject = (object)$restaurantarray;
			$newrestaurantarray[] = $restaurantobject;
		}
		 }
		for($i=0; $i<count($newrestaurantarray); $i++){
			$restaurants[$i] = $newrestaurantarray[$i];
		}
		 // echo"<pre>";
		 // print_r($restaurants);exit;
	 	
		$data["selected"] = "";
		$data["selected1"] = "";
		$table = "wine_details";
 		$data["pickscount"] = 0;
 		$data["mostpopularcount"] = 0;
		$data["mesg"] = $mesg;
		$data["wineries"] = $restaurants;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/managephotos';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function managefeatures() {
		$mesg = null;
		$selected = ""; 
		if($this->input->post("submitpicks")){
			
			//For Approve
			$checkedarray = $this->input->post("checkedarray");
			$checkedarray = explode(",", $checkedarray);
			//print_r($checkedarray);exit;
			$table = "wine_details";
			foreach($checkedarray as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{
					if($arr[7]=="database"){
						$where = array("id"=>$arr[1]);
						$res = $this->winemodel->getwineriesdetails($where);
						if(!empty($res->featureid))
						{
							$featuredata = unserialize($res->featureid);
							if(!in_array($arr[6], $featuredata)){
							$featuredata[] = $arr[6];
							}
						}else{
							$featuredata[] = $arr[6];
						}
						
						//print_r($featuredata);
						//print_r($arr[6]);
						//$featuredata[] = $arr[6];
						$data = array("featureid"=>serialize($featuredata));
						
						$mesg = $this->winemodel->updatewinery($where,$data);
			
						$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
						$res = $this->winemodel->getwineriesextrainfo($where);
		 				if(!empty($res[0]->featureid))
						{
							$featuredata1 = unserialize($res[0]->featureid);
							$featuredata1 = array_values(array_diff($featuredata1, array( $arr[6]), array("")));
						}
						if(!empty($featuredata1))
						{
							$data = array("featureid"=>serialize($featuredata1));
						}
						else {
							$data = array("featureid"=>"");
						}
							
						$this->winemodel->updatewinerieseaxtrainfo($where,$data);
					}else{
						$where = array("wid"=>$arr[1]);
						if($this->winemodel->getwineextrainfoapi($where)>0){
							$res = $this->winemodel->getwineextrainfoapi($where);
							if(!empty($res[0]->featureid)){
								$imgdata = unserialize($res[0]->featureid);
							}
							$imgdata[] = $arr[6];
							$data = array("featureid"=>serialize($imgdata));
							$mesg = $this->winemodel->updatewineeaxtrainfoapi($where,$data);
							}else{
								$imgdata[] = $arr[6];
								$data = array("wid"=>$arr[1],
											  "uid"=>$arr[3],
								              "featureid"=>serialize($imgdata),
											  "date" => date("Y-m-d h:m:i"),
											   "ip" => $_SERVER["REMOTE_ADDR"] );
								$mesg = $this->winemodel->addwineextarinfoapi($data);
							}
							$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
							$res = $this->winemodel->getwineriesextrainfo($where);
			 				if(!empty($res[0]->featureid))
							{
								$imgdata1 = unserialize($res[0]->featureid);
								$imgdata1 = array_values(array_diff($imgdata1, array( $arr[6]), array("")));
							}
							if(!empty($imgdata1))
							{
								$data = array("featureid"=>serialize($imgdata1));
							}
							else {
								$data = array("featureid"=>"");
							}
								
							$this->winemodel->updatewinerieseaxtrainfo($where,$data);
					}
				
				}
				
			}
			
			//For DisApprove
			$checkedarray1 = $this->input->post("checkedarray1");
			$checkedarray1 = explode(",", $checkedarray1);

			foreach($checkedarray1 as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->featureid))
				{
					$featuredata1 = unserialize($res[0]->featureid);
					//array_values function is used for reindex of array & array_diff function to remove specific string or value from array
					$featuredata1 = array_values(array_diff($featuredata1, array( $arr[6]), array("")));
				}
				if(!empty($featuredata1))
				{
					$data = array("featureid"=>serialize($featuredata1));
				}
				else {
					$data = array("featureid"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}

		}
		
		$this->load->library("pagination");
		$config["base_url"] = base_url().'admin/wineries/managefeatures/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
	
		$field = "wine_extrainfo.featureid";
		
		$config["total_rows"] = $this->winemodel->getwineriesextrainfocountforapproval($field);
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}

		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		
		$restaurants = $this->winemodel->getwineriesextrainfoforapproval($field,$limit);
		$newrestaurantarray = array();
		 if(isset($restaurants)&&!empty($restaurants)){
		foreach($restaurants as $restaurant){
			$restaurantarray = (array)$restaurant;
			$where = array("wid"=>$restaurant->wid);
			$rest = $this->winemodel->getwineriesextrainfo($where);
			if($rest[0]->datalocation == "api"){
				$venueid = $restaurant->wid;
				$venue = $this->_getfoursquarevenue($venueid);
				if(isset($venue)&&!empty($venue)){
					$restaurantarray["title"] = $venue;	
				}
			}else{
				$where = array("id"=>$restaurant->wid);
				$gettitle= $this->winemodel->getwineriesdetails($where);
				$restaurantarray["title"] =$gettitle->title; 
			}
			
			$restaurantobject = (object)$restaurantarray;
			$newrestaurantarray[] = $restaurantobject;
		}
		 }
		for($i=0; $i<count($newrestaurantarray); $i++){
			$restaurants[$i] = $newrestaurantarray[$i];
		}
		
		// echo"<pre>";
		 // print_r($restaurants);exit;
		$data["selected"] = "";
		$data["selected1"] = "";
		$table = "wine_details";
 		$data["pickscount"] = 0;
 		$data["mostpopularcount"] = 0;
		$data["mesg"] = $mesg;
		$data["wineries"] = $restaurants;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/managefeatures';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function managefeaturesbackup(){
		$mesg = null;
		$selected = "";
		$selected1 = ""; 
		if($this->input->post("submitpicks")){
	
			//For Approve
			$checkedarray = $this->input->post("checkedarray");
			$checkedarray = explode(",", $checkedarray);
			//print_r($checkedarray);exit;
			$table = "rest_details";
			foreach($checkedarray as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{

				$where = array("id"=>$arr[1]);

				$res = $this->winemodel->getwinerydetails($where);
				if(!empty($res->featureid))
				{
					$featuredata = unserialize($res->featureid);
				}
				$featuredata[] = $arr[6];
				$data = array("featureid"=>serialize($featuredata));
				
				$mesg = $this->winemodel->updatewinery($where,$data);
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->featureid))
				{
					$featuredata1 = unserialize($res[0]->featureid);
					$featuredata1 = array_values(array_diff($featuredata1, array( $arr[6]), array("")));
				}
				if(!empty($featuredata1))
				{
					$data = array("featureid"=>serialize($featuredata1));
				}
				else {
					$data = array("featureid"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}
			
			//For DisApprove
			$checkedarray1 = $this->input->post("checkedarray1");
			$checkedarray1 = explode(",", $checkedarray1);
			
			foreach($checkedarray1 as $check) {
				$arr = explode("[]", $check);
				
				if(!empty($arr[1]))
				{
	
				$where = array("id"=>$arr[2], "wid"=>$arr[1], "uid"=>$arr[3]);
				$res = $this->winemodel->getwineriesextrainfo($where);
 				if(!empty($res[0]->featureid))
				{
					$featuredata1 = unserialize($res[0]->featureid);
					//array_values function is used for reindex of array & array_diff function to remove specific string or value from array
					$featuredata1 = array_values(array_diff($featuredata1, array( $arr[6]), array("")));
					
					$this->deletesavedimageWhenDisapprove($arr[6]);
				}
				if(!empty($featuredata1))
				{
					$data = array("winery_img"=>serialize($featuredata1));
				}
				else {
					$data = array("winery_img"=>"");
				}
					
				$this->winemodel->updatewinerieseaxtrainfo($where,$data);
				}
				
			}
		}
		
		$this->load->library("pagination");
		$config["base_url"] = base_url().'/admin/wineries/managefeatures/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
		
		$field = "wine_extrainfo.featureid";
		
		$config["total_rows"] = $this->winemodel->getwineriesextrainfocountforapproval($field);
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		if(is_array($page)&& count($page)>0){
			$page  = explode("=", $page);
		}
		if(is_array($page)){
			$page = "";
		}
		
		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		
		$wineries = $this->winemodel->getwineriesextrainfoforapproval($field,$limit);

		$newwineryarray = array();
		if(isset($wineries)&&!empty($wineries)){
		foreach($wineries as $winery){
			$wineryarray = (array)$winery;
			$wineryobject = (object)$wineryarray;
			$newwineryarray[] = $wineryobject;
		}
		}
		for($i=0; $i<count($newwineryarray); $i++){
			$wineries[$i] = $newwineryarray[$i];
		}
		
		$data["selected"] = "";
		$data["selected1"] = "";
		$table = "wine_details";
 		$data["pickscount"] = 0;
 		$data["mostpopularcount"] = 0;
		$data["mesg"] = $mesg;
		$data["wineries"] = $wineries;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/managefeatures';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function deletesavedimageWhenDisapprove($filename) {
	 				
		$filename = trim($filename);
		if(isset($filename) && $filename != "") {
			$response = array();
			
			$uploadpath = $this->config->item("winery_upload_home");
			$temparr["path"] = $uploadpath;
			
			if(file_exists($uploadpath."/".$filename)) {
				unlink($uploadpath."/".$filename);
				
				$uploadpath = $this->config->item("winery_upload_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
				
				$uploadpath = $this->config->item("winery_1004x500_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
				
				$uploadpath = $this->config->item("winery_650x350_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
				
				$uploadpath = $this->config->item("winery_275x198_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
				
				$uploadpath = $this->config->item("winery_100x100_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
			} else {
				$temparr["msg"] = "not found";
				array_push($response, $temparr);
				echo json_encode(array("images" => $response));
			}
		}
	}
	function _getfoursquarevenue($venueid) {
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
		
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/".$venueid);
		$venues = json_decode($response);
		//echo "<pre>";
		//print_r($response);exit;
		//print_r($venues->response->venue);exit;
		return $venues->response->venue->name;
	  }
	  
	  function _getfoursquarevenuecountry($venueid) {
			
		$client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
		$client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
		
		// Load the Foursquare API library
		$config = array(
							"client_id" => $client_key,
							"client_secret" => $client_secret
						);
		$this->load->library("foursquareapi",$config);
		
		// Perform a request to a public resource
		$response = $this->foursquareapi->GetPublic("venues/".$venueid);
		$venues = json_decode($response);
		//echo "<pre>";
		//print_r($response);exit;
		//print_r($venues->response->venue);exit;
		return $venues->response->venue->location->country;
	  }
	
	
	  function suggestions(){
	  	$mesg =null;
	  	if($this->input->post("submitsuggestions")){
	  		$msg = "";
	  		$radionamearray = $this->input->post("radionamearray");
			$radionamearray = explode(",", $radionamearray);
			$approved = array();
			foreach($radionamearray as $radioname){
				$approved[] = $this->input->post($radioname);
			}
			$approved = array_unique($approved);
			if(isset($approved)){
			foreach($approved as $approve){
				if(!empty($approve)){
					$where = array("id"=>$approve);
					$result = $this->winemodel->getsuggestions($where,"","");
					$result = $result[0];
					$where = array("wid"=>$result->wid,
									"name"=>$result->name
								   );
				    $data = array("isapproved"=>"0");
					$this->winemodel->updatesuggestions($data,$where);
					$where = array("id"=>$approve);
					$data = array("isapproved"=>"1",
								  "approval_date"=>date("Y-m-d H:i:s")
					);
					$mesg = $this->winemodel->updatesuggestions($data,$where);
						//$msg = "Suggestions Approved Successfully";
					//}
				}
			}
			}
			$deletesuggestions = array();
			$deletesuggestions = $this->input->post("deletesuggestions");
			if(!empty($deletesuggestions)){
				foreach($deletesuggestions as $deleteid){
					$where = array("id"=>$deleteid);
					$mesg = $this->winemodel->deletesuggestions($where);	
				}
				
			}
	  	}
	  	$this->load->library("pagination");
		$config["base_url"] = base_url().'admin/wineries/suggestions/';
		$config["uri_segment"] = 4;
		$config['num_links'] = 1;
		$config["per_page"] = 5;
		$config["full_tag_open"] = '<div id="pagination">';
		$config ["full_tag_close"] = '</div>';
		$config["cur_tag_open"] = '<b>';
		$config["cur_tag_close"] = '</b>';
		$config["next_link"] = '&gt';
		$config["prev_link"] = '&lt';
	
		$where = array("isapproved"=>"0");
		$limit = "";
		$order_by="";
		$config["total_rows"] = count($this->winemodel->getsuggestions($where,$limit,$order_by));
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4,0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}

		$limit = array('start'=>$config['per_page'], 'end'=>$page);
		$suggestions = array();
		$order_by = "1";
		//$group_by = "";
		$suggestionsall = $this->winemodel->getsuggestions($where,$limit,$order_by);
		//echo "<pre>";
		//print_r($suggestionsall);exit;
		if(!empty($suggestionsall)){
		foreach($suggestionsall as $suggestionsingle){
			$winery_array = array();
			$winery_array = "";
			$winery_object = "";
			$winery_array["winery_name"] = "";
			$winery_array["winery_country"] = "";
			$where = array("id"=>$suggestionsingle->wid);
			if(is_numeric($suggestionsingle->wid) && str_word_count($suggestionsingle->wid)<5){
				$winery_details = $this->winemodel->getwinerydetails($where);
				if(isset($winery_details)){
				$winery_array["winery_name"] = isset($winery_details->title)?$winery_details->title:"";
				if(isset($winery_details->countryid)){
					$where = array("id"=>$winery_details->countryid);
					$winery_country_data = $this->winemodel->getcountry($where);
					$winery_array["winery_country"] = isset($winery_country_data->name)?$winery_country_data->name:"";	
				}
			}
				
			}else{
				// $winery_array["winery_name"] = "";
				$winery_array["winery_name"] = $this->_getfoursquarevenue($suggestionsingle->wid);
				if(!isset($winery_array["winery_name"]) && empty($winery_array["winery_name"])){
					$winery_array["winery_name"] ="";
				}
				$winery_array["winery_country"] = $this->_getfoursquarevenuecountry($suggestionsingle->wid);
				if(!isset($winery_array["winery_country"]) && empty($winery_array["winery_country"])){
					$winery_array["winery_country"] ="";
				}
				
			}
			$winery_array["id"] = $suggestionsingle->id;
			$winery_array["name"] = $suggestionsingle->name;
			$winery_array["suggested"] = $suggestionsingle->suggested;
			$winery_array["radioname"] = str_replace(" ", "_", $suggestionsingle->name).$suggestionsingle->wid;
			$winery_object = (object) $winery_array;
			$suggestions[] = $winery_object;
			
			
		}
		}
		$data["mesg"] = $mesg;
		$data["suggestions"] = $suggestions;
		$data['pagination']= $this->pagination->create_links();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/wineries/suggestions';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	  }
}
