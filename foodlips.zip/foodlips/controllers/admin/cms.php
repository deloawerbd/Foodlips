<?php

class Cms extends Controller {
	
	function Cms() {
		parent::Controller();
        
        ////////////////////////////
		//CHECKING FOR PERMISSIONS
		///////////////////////////
		//-------------------------------------------------
        //only 'admin' and 'superadmin' can manage users
        
        $this->freakauth_light->check('admin');
        
        //-------------------------------------------------
        //END CHECKING FOR PERMISSION
        
        $this->load->library('pagination');
		$this->load->library('form_validation');
		
		$this->load->helper('url');
		$this->load->helper('form');
		
        $this->_container = $this->config->item('FAL_template_dir').'template_admin/container';
	}
	
	function index() {
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/cms/home';
		$data['result'] = $this->_getallpages();
        $this->load->vars($data);
	    $this->load->view($this->_container);
	} 
}

?>