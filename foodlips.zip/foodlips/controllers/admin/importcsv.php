<?php

class Importcsv extends Controller{
	function importcsv(){
		parent::Controller();
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->library("form_validation");
		$this->load->model("crudmodel");
		$this->load->model("communitymodel");
		$this->freakauth_light->check('admin');
	}
	function import_countries(){
		$this->load->model("restaurants/restaurantmodel","restmodel");
		$data["page"] = "pages/countriescsvupload";
		$this->load->view("template/template", $data);
	}
	function import_recipe(){
		$this->load->model("csv/Importcsvmodel","importcsvmodel");
		$data["page"] = "pages/recipecsvupload";
		$this->load->view("template/template", $data);
	}
	
	function uploadimage() {
		
		if($this->input->post("submitimage")) {
			$this->load->model("crudmodel");
			$this->load->library("upload");
			//$recipeid = $this->input->post("recipeid");
			$filecount = count($_FILES["userfile"]["name"]);
			$i = 0;
			// while($i < $filecount){
				// $name = $_FILES["userfile"]["name"][$i];
				// print_r($name);
				// echo "<br>";
				// $i++;
			// };exit;
			while($i < $filecount){
				$singlefile = "";
				$response = array();
				$recipeuploadpath = $this->config->item("recipe_upload_path");
				$config = array(
							"upload_path" => $recipeuploadpath,
							"allowed_types" => "jpg|jpeg|gif|png"
						);
				$this->upload->initialize($config);
				$filename = "";
				$name = $_FILES["userfile"]["name"][$i];
                $ext = pathinfo($_FILES["userfile"]["name"][$i], PATHINFO_EXTENSION);
				$origname = pathinfo($_FILES['userfile']['name'][$i], PATHINFO_FILENAME);
				$filename = $origname.".".$ext;
				$singlefile["name"] = $filename;
                $singlefile["type"] = $_FILES["userfile"]["type"][$i];
                $singlefile["tmp_name"] = $_FILES["userfile"]["tmp_name"][$i];
                $singlefile["error"] = $_FILES["userfile"]["error"][$i];
                $singlefile["size"] = $_FILES["userfile"]["size"][$i];
                $_FILES["singlefile"] = $singlefile;
				
				if($this->upload->do_upload("singlefile", true)) {
					
						$image_data = $this->upload->data();
					
						$imagestypes = array(
											"index_upload_path" => $this->config->item("index_upload_path"),
											"recipe_home_upload_path" => $this->config->item("recipe_home_upload_path"),
											"recipe_detail_upload_path" => $this->config->item("recipe_detail_upload_path"),
											"recipe_media_upload_path" => $this->config->item("recipe_media_upload_path"),
											"recipe_25x25_upload_path" => $this->config->item("recipe_25x25_upload_path")
										);
						$this->load->library("image_lib");
						foreach ($imagestypes as $imagetype) {
								
							$width = 100;
							$heigth = 100;
							
							if($imagetype == $this->config->item("index_upload_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("recipe_home_upload_path")) {
								$width = 650;
								$heigth = 350;
							}
							else if($imagetype == $this->config->item("recipe_detail_upload_path")) {
								$width = 275;
								$heigth = 198;
							}
							else if($imagetype == $this->config->item("recipe_media_upload_path")) {
								$width = 50;
								$heigth = 50;
							}
							else if($imagetype == $this->config->item("recipe_25x25_upload_path")) {
								$width = 25;
								$heigth = 25;
							}
							
							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
								
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
					}
				$i++;
				}
		}
		$this->load->model("csv/Importcsvmodel","importcsvmodel");
		$data["page"] = "pages/recipecsvuploadimage";
		$this->load->view("template/template", $data);
		
	}
	
	
}
?>
