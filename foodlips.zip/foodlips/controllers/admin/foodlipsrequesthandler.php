<?php

class Foodlipsrequesthandler extends Controller {

	function Foodlipsrequesthandler() {
		parent::Controller();

		$this->load->model("recipe/recipemodel");
	}
	
	function isloggedin() {
		$response = array();

		if($this->db_session->userdata("id")) {
			$temparr["msg"] = "true";
		}
		else {
			$temparr["msg"] = "false";
		}
			
		array_push($response, $temparr);
		echo json_encode(array("login" => $response));
	}
	
	function setrecipeofday() {
		if($this->input->post("recipeid")) {
			$response = array();

			$recipeid = $this->input->post("recipeid");
			$where = array(
							"id" => $recipeid
						);
			$fileds = "approved";

			$recipe = $this->recipemodel->getrecipe($where, $fileds);
			if(!empty($recipe)) {
				if($recipe->approved == "1") {
					
					$recipe = array(
									"recipeofday" => "0"
								);
					if($this->recipemodel->updateallrecipe($recipe)) {
						$recipe = array(
										"recipeofday" => "1"
									);
						if($this->recipemodel->updaterecipe($recipeid, $recipe)) {
							$temparr["msg"] = "success";
						}
						else {
							$temparr["msg"] = "fail";
						}
					}
					else {
						$temparr["msg"] = "fail";
					}
				}
				else {
					$temparr["msg"] = "notapproved";
				}
			}
			else {
				$temparr["msg"] = "recipenotfound";
			}
			
			array_push($response, $temparr);
			echo json_encode(array("recipe" => $response));
		}
	}
	
}