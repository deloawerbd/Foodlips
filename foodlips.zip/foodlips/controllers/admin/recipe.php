<?php
class Recipe extends Controller {

	function Recipe() {
		//'http://www.facebook.com/pages/Fantastic-Food-World/155269231173554
		//https://twitter.com/FantasticFWorld
		parent::Controller();
		$this->load->model('crudmodel');
		$this->load->library('form_validation');
		$this->load->library('email');
		$this->load->library('pagination');
		$this->load->helper('text');
		$this->load->helper("url");
		$this->_container = $this->config->item('FAL_template_dir').'template_admin/container';
	}

	function index() {
		$this->load->model("recipe/recipemodel");
		$config['base_url'] =base_url().'admin/recipe/recipe/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromrecipe();
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
		 $limit = array('start' => $config['per_page'],
                      'end' => $page
            	 );
		$data['pagination']= $this->pagination->create_links();
		$data['records']=$this->recipemodel->getlimitedrecipe($limit);
		//$data["records"] = $this->recipemodel->getrecipes();
		$result = $data["records"];
		foreach($result as $row) {
			$data["categoryname"][$row -> categoryid] = $this->recipemodel->getcategorynamebyid($row->categoryid);	
		}
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/recipe/recipe';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function homeimage() {
		
		
		// $config['base_url'] =base_url().'admin/recipe/homeimage';
		// $config['uri_segment'] = 4;
		// $config['num_links'] = 1;
		// $config['per_page'] = 7; 
		// $config['full_tag_open'] = '<div id="pagination">';
		// $config['full_tag_close'] = '</div>';
		// $config['cur_tag_open'] = '<b>';
		// $config['cur_tag_close'] = '</b>';
		// $config['next_link'] = '&gt';
		// $config['prev_link'] = '&lt';
       	// $config['total_rows'] = $this->recipemodel->getnoofrowsfromimage();
		// $this->pagination->initialize($config);
		// $page = $this->uri->segment(4, 0);
				 // $limit = array('start' => $config['per_page'],
                              // 'end' => $page
                    	 // );
		// $data['pagination']= $this->pagination->create_links();
		$this->load->model("recipe/recipemodel");
		$data['images']=$this->recipemodel->getimages();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/homeimage/homeimage';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	
	}

	function addimage() {
		
		if($this->input->post("sbt_add")) {
			$this->load->model("recipe/recipemodel");	
			$imagedata="";
			
			$this->form_validation->set_rules('title', 'Title', 'required');
			$checkimage=$_FILES["userfile"]["name"];
			if($checkimage==NULL) {
				$this->form_validation->set_rules('userfile', 'Image', 'required');
			}
			
			if ($this->form_validation->run() == TRUE) 	{
				
				$homeuploadpath = $this->config->item("home_upload_path");
				
				$config = array(
					'upload_path' => $homeuploadpath,
					"allowed_types" => "jpg|jpeg|gif|png"
				);
				$filename = $_FILES["userfile"]["name"];
				$filename = explode(".", $filename);
				$filename[0] = $filename[0].time().".".$filename[1];
				$_FILES["userfile"]["name"] = $filename[0];
			
				$this->load->library("upload", $config);
					
				if($this->upload->do_upload()) {
						
					$image_data = $this->upload->data();
					
					$imagestypes = array(
											// "home_upload_path" => $this->config->item("home_upload_path"),
											"home_slider_path" => $this->config->item("home_slider_path"),
											"homepage_upload_path" => $this->config->item("homepage_upload_path")
										);
						
					$this->load->library("image_lib");
					
					foreach ($imagestypes as $imagetype) {
							
							$width = 50;
							$heigth = 50;
							
							if($imagetype == $this->config->item("home_slider_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("homepage_upload_path")) {
								$width = 50;
								$heigth = 50;
							}
							
							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
								
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
				}
				
				$data = array(
					"title" => $this->input->post("title"),
				  	 "image" => $image_data["file_name"],
				  	 "link" => $this->input->post("imglink")
		       	);
				if($this->recipemodel->addimage($data)) { 
			 		$data["success"]="Record Added Successfully";
					redirect("admin/recipe/homeimage", "refresh");
				}else {
					$data["fail"]="please try again...";
				}
			}
			
		}
		
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/homeimage/addimage';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function editimage() {
		$id=NULL;
		
		if($id=="") {
			$id=$this->uri->segment(4);
		}
		$this->load->model("recipe/recipemodel");
		if($this->input->post("sbt_update")) {	
			$id=$this->input->post("id");
			
			$this->form_validation->set_rules('title', 'Title', 'required');
			if($this->input->post("hiddenname")==NULL) {
				$this->form_validation->set_rules('userfile', 'Image', 'required');
			}
				
			if ($this->form_validation->run() == TRUE)	{
				
				$newname=$_FILES["userfile"]["name"];
				if($newname==NULL){
					$newname =$this->input->post("hiddenname");
				}else {
					
				$homeuploadpath = $this->config->item("home_upload_path");
				
				$config = array(
					'upload_path' => $homeuploadpath,
					"allowed_types" => "jpg|jpeg|gif|png"
				);
				$filename = $_FILES["userfile"]["name"];
				$filename = explode(".", $filename);
				$filename[0] = $filename[0].time().".".$filename[1];
				$_FILES["userfile"]["name"] = $filename[0];
			
				$this->load->library("upload", $config);
					
				if($this->upload->do_upload()) {
						
					$image_data = $this->upload->data();
					$newname=$image_data["file_name"];
					
					$imagestypes = array(
											// "home_upload_path" => $this->config->item("home_upload_path"),
											"home_slider_path" => $this->config->item("home_slider_path"),
											"homepage_upload_path" => $this->config->item("homepage_upload_path"),
										);
						
					$this->load->library("image_lib");
					
					foreach ($imagestypes as $imagetype) {
								
							$width = 50;
							$heigth = 50;
							
							if($imagetype == $this->config->item("home_slider_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("homepage_upload_path")) {
								$width = 50;
								$heigth = 50;
							}
							
							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
								
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
					}
				}
				$data = array(
					"title"=>$this->input->post("title"),
				  	 "image"=>$newname,
				  	 "link" => $this->input->post("imglink")
		       	);
				
				if($this->recipemodel->editimagebyid($id,$data)) {
					$data["succes"]="Record Update Successfully";
					redirect("admin/recipe/homeimage", "refresh");
				}else {
					$data["fail"]="Upload fail please try again...";
				}
				
			}
		}
		$data["images"]=$this->recipemodel->gethomebyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/homeimage/editimage';
		$this->load->view($this->_container,$data);			
	}

	function deleteimage() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deleteimagebyid($this->uri->segment(4));
		redirect("admin/recipe/homeimage", "refresh");
	}
	
	function editrecipe() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			 $id = $this->uri->segment(4);
		}
		
		if($this->input->post("sbt_update")) {
			
			$id = $this->input->post("id");
			//code added by majid
			//print_r($_POST);exit;
			$title = $this->input->post('title');
			$specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
			$title = str_replace($specialchars, " ", $title);
			$title = trim($title);
			$category = $this->input->post('category');
			$category_name_for_seo = $this->recipemodel->getcategorynamebyid($category);
			$course = $this->input->post('course');
			$type = $this->input->post('type');
			$cuisine = $this->input->post('cuisine');
			$season = $this->input->post('season');
			$method = $this->input->post('method');
			$preparation_details = $this->input->post('preparation_details');
			$ingredient_details = $this->input->post('ingredient_details');
			$calories = $this->input->post('calories');
			$serves = $this->input->post('serves');
			//code ends here
			$deletedimages = $this->input->post("pdeleteimages");
			$deletedimages = rtrim($deletedimages,",");
			$deleteimagesarr=explode(',',$deletedimages);
			if(isset($success)) {
			if($deleteimages!=NULL) {
				foreach ($deleteimagesarr as $name ) {
					unlink("public/frontend/images/recipe/1004x400/$name");	
					unlink("public/frontend/images/recipe/275x198/$name");
					unlink("public/frontend/images/recipe/50x50/$name");
					unlink("public/frontend/images/recipe/650x350/$name");
					unlink("public/frontend/images/recipe/$name");
				}
			}
			}
			$approval = "0";
			if($this->input->post("papproval")) {
				$approval = "1";
			}
			// $data = array(
	            // "approved" => $approval,
	          	 // "images" => $this->input->post("pimagename")
	       	 // );
	       	 $data = array(
	       	 	"title"=>$title,
	       	 	"seo" => $this->_getseo($category_name_for_seo." ".$title),
	       	 	"categoryid"=>$category,
	       	 	"courseid"=>$course,
	       	 	"typeid"=>$type,
	       	 	"cuisineid"=>$cuisine,
	       	 	"seasonid"=>$season,
	       	 	"methodid"=>$method,
	       	 	"preparationdetails"=>$preparation_details,
	       	 	"ingredientdetails"=>$ingredient_details,
	       	 	"calories"=>$calories,
	       	 	"serves"=>$serves,
	            "approved" => $approval,
	          	"images" => $this->input->post("pimagename")
	       	 );
			
			if($this->recipemodel->updaterecipe($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/recipe");
					
				}else {
					$data["fail"]="please try again...";
				}
		}
		
		
		$this -> load -> model("recipe/recipemodel");
		//code added by majid
		$this->load->model("crudmodel");
		$data["all_categories"] = $this->crudmodel->getallcategories();
		$data["all_courses"] = $this->crudmodel->getallcourses();
		$data["all_types"] = $this->crudmodel->getalltypes();
		$data["all_cuisines"] = $this->crudmodel->getallcuisines();
		$data["all_seasons"] = $this->crudmodel->getallseasons();
		$data["all_seasons"] = $this->crudmodel->getallseasons();
		$data["all_methods"] = $this->crudmodel->getallmethods();
		//code ends here
		$data["recipedetails"] = $this->recipemodel->getrecipesbyid($id);
		$recipedetails = $data["recipedetails"];
		$recipedetails = $recipedetails[0];
		
		$data["categoryname"] = $this->recipemodel->getcategorynamebyid($recipedetails->categoryid);
		$data["coursename"] = $this->recipemodel->getcoursenamebyid($recipedetails->courseid);
		$data["typename"] = $this->recipemodel->gettypeamebyid($recipedetails->typeid);
		$data["cuisinename"] = $this->recipemodel->getcuisinesnamebyid($recipedetails->cuisineid);
		$data["seasonname"] = $this->recipemodel->getseasonnamebyid($recipedetails->seasonid);
		$data["methodname"] = $this->recipemodel->getmethodnamebyid($recipedetails->methodid);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/recipe/editrecipe';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}

	function deleterecipe() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deleteimagebyid($this->uri->segment(4));
		redirect("admin/recipe");
	}
	
	function comments() {
		
		$this->load->model("recipe/recipemodel");
		$config['base_url'] =base_url().'admin/recipe/comments/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromcomment();
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array(
								'start' => $config['per_page'],
                             	 'end' => $page
                    		 );
		$data['pagination']= $this->pagination->create_links();
		$data['comments']=$this->recipemodel->getlimitedcomment($limit);
		//$data["comments"] = $this->recipemodel->getcomments();
		$result = $data["comments"];
		foreach($result as $row) {
			$data["username"][$row->uid]= $this->recipemodel->getusernamebyuid($row->uid);
			$data["recipename"][$row->recipeid]= $this->recipemodel->getrecipenamebyid($row->recipeid);		
			$data["recipeimage"][$row->recipeid]= $this->recipemodel->getrecipeimagebyid($row->recipeid);
		}
		//print_r($data);
		//die();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/comments/comments';
		
		$this->load->vars($data);
	    $this->load->view($this->_container);
	
	}

	 function viewcomments() {
	 	$id=NULL;
		if($id==null){
			 $id = $this->uri->segment(4);
		}
		$this -> load -> model("recipe/recipemodel");
		
		$data["comments"] = $this->recipemodel->getcommentsbyid($id);
		$result = $data["comments"];
		$data["username"]= $this->recipemodel->getusernamebyuid($result->uid);
		$data["recipename"]= $this->recipemodel->getrecipenamebyid($result->recipeid);		
		$data["recipeimage"]= $this->recipemodel->getrecipeimagebyid($result->recipeid);
		$data["body"]=$result->comment;
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/comments/viewcomments';
		$this->load->vars($data);
		$this->load->view($this->_container);
	 }

	function deletecomments() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletecommentsbyid($this->uri->segment(4));
		redirect("admin/recipe/comments");
	}
	
	function category() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/category/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromcategory();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
		 $limit = array('start' => $config['per_page'],
                      'end' => $page
            	 );
		$data['pagination']= $this->pagination->create_links();
		$data['categories']=$this->recipemodel->getlimitedcategory($limit);
		
		//$data["categories"] = $this->recipemodel->getcategory();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/categories/category';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function category_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("categories");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("category_check", "This Category already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addcategory() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_category_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addcategory($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/category");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/categories/addcategory';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editcategory() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			$id=$this -> uri -> segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_category_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editcategorybyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/category");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["categories"] = $this->recipemodel->getcategorybyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/categories/editcategory';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deletecategory() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletecategorybyid($this->uri->segment(4));
		redirect("admin/recipe/category");
		
	}
	
	function courses() {
		$this -> load -> model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/courses/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromcourse();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['courses']=$this->recipemodel->getlimitedcourse($limit);
		
		//$data["courses"] = $this -> recipemodel -> getcourse();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/course/course';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function course_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("courses");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("course_check", "This Course already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addcourse() {
		$this -> load -> model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_course_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addcourse($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/courses");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/course/addcourse';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editcourse() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null) {
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_course_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editcoursebyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/courses");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["courses"] = $this->recipemodel->getcoursebyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/course/editcourse';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deletecourse() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletecoursebyid($this->uri->segment(4));
		redirect("admin/recipe/courses");
	}
	
	function types() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/types/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromtype();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['types']=$this->recipemodel->getlimitedtype($limit);
		//$data["types"] = $this->recipemodel->gettypes();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/types/type';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	function type_check($name)
	{
		 $this->db->where("name",$name);
		 $result=$this->db->get("types");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("type_check", "This Type already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addtype() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_type_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addtype($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/types");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/types/addtype';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function edittype() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null) {
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_type_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->edittypebyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/types");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this -> load -> model("recipe/recipemodel");
		$data["types"] = $this -> recipemodel -> gettypebyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/types/edittype';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deletetype() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletetypebyid($this->uri->segment(4));
		redirect("admin/recipe/types");
	}
	
	function cuisines() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/cuisines/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromcuisine();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['cuisines']=$this->recipemodel->getlimitedcuisine($limit);
	//	$data["cuisines"] = $this->recipemodel->getcuisines();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/cuisine/cuisine';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function cuisine_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("cuisines");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("cuisine_check", "This cuisine already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addcuisine() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_cuisine_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addcuisine($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/cuisines");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/cuisine/addcuisine';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editcuisine() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_cuisine_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editcuisinebyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/cuisines");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["cuisines"] = $this->recipemodel->getcuisinebyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/cuisine/editcuisine';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deletecuisine() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletecuisinebyid($this->uri->segment(4));
		redirect("admin/recipe/cuisines");
	}
	
	function seasons() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/seasons/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 2; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromseason();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['seasons']=$this->recipemodel->getlimitedseason($limit);
		//$data["seasons"] = $this->recipemodel->getseasons();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/seasons/season';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function season_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("seasons");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("season_check", "This season already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addseason() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_season_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addseason($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/seasons");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/seasons/addseason';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editseason() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_season_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editseasonbyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/seasons");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["seasons"] = $this->recipemodel->getseasonbyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/seasons/editseason';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deleteseason() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deleteseasonbyid($this->uri->segment(4));
		redirect("admin/recipe/seasons");
	}
	
	function methods() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/methods/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfrommethod();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['methods']=$this->recipemodel->getlimitedmethod($limit);
		//$data["methods"] = $this->recipemodel->getmethods();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/methods/method';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function method_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("methods");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("method_check", "This method already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addmethods() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_method_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addmethod($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/methods");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/methods/addmethod';
		//$data['page'] = $this->config->item('FAL_template_dir').'template_admin/methods/addmethod';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editmethod() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_method_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editmethodbyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/methods");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["methods"] = $this->recipemodel->getmethodbyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/methods/editmethod';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deletemethod() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deletemethodbyid($this->uri->segment(4));
		redirect("admin/recipe/methods");
	}
	
	function ingredients() {
		$this->load->model("recipe/recipemodel");
		
		$config['base_url'] =base_url().'admin/recipe/ingredients/';
		$config['uri_segment'] = 4;
		$config['num_links'] = 1;
		$config['per_page'] = 7; 
		$config['full_tag_open'] = '<div id="pagination">';
		$config['full_tag_close'] = '</div>';
		$config['cur_tag_open'] = '<b>';
		$config['cur_tag_close'] = '</b>';
		$config['next_link'] = '&gt';
		$config['prev_link'] = '&lt';
       	$config['total_rows'] = $this->recipemodel->getnoofrowsfromingredient();
		$this->pagination->initialize($config);
		
		$page = $this->uri->segment(4, 0);
		$page = explode("=",$page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}
		if(is_array($page)) {
			$page = "";
		}
				 $limit = array('start' => $config['per_page'],
                              'end' => $page
                    	 );
		$data['pagination']= $this->pagination->create_links();
		$data['ingredients']=$this->recipemodel->getlimitedingredient($limit);
		
		//$data["ingredients"] = $this->recipemodel->getingredients();
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/ingredients/ingredient';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function ingredient_check($name) {
		 $this->db->where("name",$name);
		 $result=$this->db->get("ingredients");
		 if($result->num_rows() > 0){
			 $this->form_validation->set_message("ingredient_check", "This Ingredient already exist");
			 return FALSE;
		 }else{
			 return TRUE;
		 }
	}
	
	function addingredient() {
		$this->load->model("recipe/recipemodel");
		 if($this->input->post("sbt_add")) {
		 	$this->form_validation->set_rules("name","Name","trim|required|callback_ingredient_check");
			if ($this->form_validation->run() == TRUE) {
				$data = array (
				 	"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->addingredient($data)) {
					$data["success"]="Record Add Successfully";
					redirect("admin/recipe/ingredients");
				}else {
					$data["fail"]="please try again...";
				}
			}
		 }
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/ingredients/addingredient';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function editingredient() {
		$this->load->model("recipe/recipemodel");
		$id = NULL;
		if($id==null){
			$id=$this->uri->segment(4);
		}
		if($this->input->post("sbt_update")) {
			$id=$this->input->post("id");
			$this->form_validation->set_rules("name","Name","trim|required");
			if($this->input->post("hiddenname")!=$this->input->post("name")) {
				$this->form_validation->set_rules("name","Name","trim|required|callback_ingredient_check");	
			}
			if ($this->form_validation->run() == TRUE) {
				$data=array(
					"name"=>$this->input->post("name"),
				);
				if($this->recipemodel->editingredientbyid($id,$data)) {
					$data["success"]="Record Update Successfully";
					redirect("admin/recipe/ingredients");
				}else {
					$data["fail"]="please try again...";
				}
			}
		}
		$this->load->model("recipe/recipemodel");
		$data["ingredients"] = $this->recipemodel->getingredientbyid($id);
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/ingredients/editingredient';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	
	function deleteingredient() {
		$this->load->model("recipe/recipemodel");
		$this->recipemodel->deleteingredientbyid($this->uri->segment(4));
		redirect("admin/recipe/ingredients");
	}
	
	function frontvideo() {
		$this->load->model("recipe/recipemodel");		
			
		$frontvideo =$this->recipemodel->getvideo();		
		
		if($this->input->post('sbt_save'))
		{
			$this->form_validation->set_rules('video', 'Front Video', 'required');			
			if($this->form_validation->run())
			{
				if(!empty($frontvideo))
				{
					$data['id'] = $frontvideo->id;
				}
				$data['title'] = $this->input->post('title');
				$data['description'] = $this->input->post('description');
				$data['video'] = $this->input->post('video');				
				$data['updateddate'] = date("Y-m-d h:i:s");
				
				$update = $this->recipemodel->savevideo($data);
				
				if($update)
				{
					$update;
					//redirect("admin/recipe/frontvideo", "refresh");
					redirect("admin/recipe/frontvideo");
				}
			}
		}		
		
		$data['frontvideo'] = $frontvideo;
		$data['page'] = $this->config->item('FAL_template_dir').'template_admin/frontvideo/video';
		$this->load->vars($data);
	    $this->load->view($this->_container);
	}
	function _getseo($seo) {
		
		$seo = $this->_makeslugs($seo);

		$duplicaterecipe = $this->crudmodel->getrecipe(array("seo" => $seo));

		if(empty($duplicaterecipe)) {
			return $seo;
		}
		else {
			return $this->_getnewseo($seo);
		}
	}
	function _makeslugs($string, $maxlen = 0) {
  		$newStringTab = array();
      	$string = strtolower($this->_nodiacritics($string));
      	if(function_exists("str_split")) {
     		$stringTab=str_split($string);
		}
      	else {
     		$stringTab = $this->_mystrsplit($string);
		}

      	$numbers=array("0","1","2","3","4","5","6","7","8","9","-");
      	//$numbers=array("0","1","2","3","4","5","6","7","8","9");

      	foreach($stringTab as $letter) {
     		if(in_array($letter, range("a", "z")) || in_array($letter, $numbers)) {
        		$newStringTab[]=$letter;
            	//print($letter);
         	}
         	elseif($letter == " ") {
        		$newStringTab[] = "-";
			}
      	}

      	if(count($newStringTab)) {
     		$newString = implode($newStringTab);
         	if($maxlen > 0) {
            	$newString = substr($newString, 0, $maxlen);
			}
         
 			$newString = $this->_removeduplicates('--', '-', $newString);
		}
      	else {
     		$newString='';
		}
  		
  		return $newString;
	}
	
	function _getnewseo($seo) {
		
		$newseo = $seo."-".$this->_getuniquekey();
		$duplicaterecipe = $this->crudmodel->getrecipe(array("seo" => $newseo));
		if(empty($duplicaterecipe)) {
			return $newseo;
		}
		else {
			return $this->_getnewseo($seo);
		}
	}
	function _getuniquekey() {
		$this->load->helper("string");
	    return random_string("numeric", 8);
	}
	function _mystrsplit($string) {
  		$slen = strlen($string);
  		for($i = 0; $i < $slen; $i++) {
     		$sArray[$i] = $string{$i};
		}
      	return $sArray;
	}
	
	function _removeduplicates($sSearch, $sReplace, $sSubject) {
		$i = 0;
      	do {
     		$sSubject = str_replace($sSearch, $sReplace, $sSubject);
			$pos = strpos($sSubject, $sSearch);
			$i++;
			if($i > 100) {
            	die('removeduplicates() loop error');
			}
      	}
      	while($pos !== false);
		return $sSubject;
	}
	function _nodiacritics($string) {
		//cyrylic transcription
      	$cyrylicFrom = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я');
      	$cyrylicTo = array('A', 'B', 'W', 'G', 'D', 'Ie', 'Io', 'Z', 'Z', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'Ch', 'C', 'Tch', 'Sh', 'Shtch', '', 'Y', '', 'E', 'Iu', 'Ia', 'a', 'b', 'w', 'g', 'd', 'ie', 'io', 'z', 'z', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'ch', 'c', 'tch', 'sh', 'shtch', '', 'y', '', 'e', 'iu', 'ia'); 
      
		$from = array("Á", "À", "Â", "Ä", "Ă", "Ā", "Ã", "Å", "Ą", "Æ", "Ć", "Ċ", "Ĉ", "Č", "Ç", "Ď", "Đ", "Ð", "É", "È", "Ė", "Ê", "Ë", "Ě", "Ē", "Ę", "Ə", "Ġ", "Ĝ", "Ğ", "Ģ", "á", "à", "â", "ä", "ă", "ā", "ã", "å", "ą", "æ", "ć", "ċ", "ĉ", "č", "ç", "ď", "đ", "ð", "é", "è", "ė", "ê", "ë", "ě", "ē", "ę", "ə", "ġ", "ĝ", "ğ", "ģ", "Ĥ", "Ħ", "I", "Í", "Ì", "İ", "Î", "Ï", "Ī", "Į", "Ĳ", "Ĵ", "Ķ", "Ļ", "Ł", "Ń", "Ň", "Ñ", "Ņ", "Ó", "Ò", "Ô", "Ö", "Õ", "Ő", "Ø", "Ơ", "Œ", "ĥ", "ħ", "ı", "í", "ì", "i", "î", "ï", "ī", "į", "ĳ", "ĵ", "ķ", "ļ", "ł", "ń", "ň", "ñ", "ņ", "ó", "ò", "ô", "ö", "õ", "ő", "ø", "ơ", "œ", "Ŕ", "Ř", "Ś", "Ŝ", "Š", "Ş", "Ť", "Ţ", "Þ", "Ú", "Ù", "Û", "Ü", "Ŭ", "Ū", "Ů", "Ų", "Ű", "Ư", "Ŵ", "Ý", "Ŷ", "Ÿ", "Ź", "Ż", "Ž", "ŕ", "ř", "ś", "ŝ", "š", "ş", "ß", "ť", "ţ", "þ", "ú", "ù", "û", "ü", "ŭ", "ū", "ů", "ų", "ű", "ư", "ŵ", "ý", "ŷ", "ÿ", "ź", "ż", "ž");
      	$to = array("A", "A", "A", "A", "A", "A", "A", "A", "A", "AE", "C", "C", "C", "C", "C", "D", "D", "D", "E", "E", "E", "E", "E", "E", "E", "E", "G", "G", "G", "G", "G", "a", "a", "a", "a", "a", "a", "a", "a", "a", "ae", "c", "c", "c", "c", "c", "d", "d", "d", "e", "e", "e", "e", "e", "e", "e", "e", "g", "g", "g", "g", "g", "H", "H", "I", "I", "I", "I", "I", "I", "I", "I", "IJ", "J", "K", "L", "L", "N", "N", "N", "N", "O", "O", "O", "O", "O", "O", "O", "O", "CE", "h", "h", "i", "i", "i", "i", "i", "i", "i", "i", "ij", "j", "k", "l", "l", "n", "n", "n", "n", "o", "o", "o", "o", "o", "o", "o", "o", "o", "R", "R", "S", "S", "S", "S", "T", "T", "T", "U", "U", "U", "U", "U", "U", "U", "U", "U", "U", "W", "Y", "Y", "Y", "Z", "Z", "Z", "r", "r", "s", "s", "s", "s", "B", "t", "t", "b", "u", "u", "u", "u", "u", "u", "u", "u", "u", "u", "w", "y", "y", "y", "z", "z", "z");
      
      	$from = array_merge($from, $cyrylicFrom);
		$to = array_merge($to, $cyrylicTo);

      $newstring = str_replace($from, $to, $string);
      return $newstring;
   	}
}
?>