<?php

class Recipe extends Controller {

	function Recipe() {
		parent::Controller();

		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->library("form_validation");

		$this->load->model("crudmodel");
		$this->load->model("communitymodel");
	}

	function index() {

		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/index/";
		$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$where = array(
					"approved" => "1"
				);

		$query = $this->crudmodel->getallrecipes($where);
		//$query = $this->crudmodel->getallrecipesnew($where);

		$config["total_rows"] = $query->num_rows();

		$this->pagination->initialize($config);

		$query->free_result();
		$page = $this->uri->segment(3, 0);
    	$page = explode("=", $page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}

		// check if $page is still array if yes then make it as non array variable
		// it is necessary to avoid db err as we cannot use array in place of start or end limit
		if(is_array($page)) {
			$page = "";
		}

    	$limit = array(
						"start" => $config["per_page"],
    				  	"end" => $page
					);

		if($this->input->post("search_btn")) {

			$search = array(
					"title" => $this->input->post("search")
				);

			$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

			//$query = $this->crudmodel->getallrecipes($limit);
		}
		else {
			$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);

			//if(count($data["recipes"])) {
				//$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
			//}
			//$data["userimage"] = $this->crudmodel->getuserdetailsbyid();
		}

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);
	}

    var $object;
	function test() {

        echo md5("foodlipsshare");
        echo "</br>session id: ".$this->db_session->userdata("session_id");
        echo "</br>ip: ".$_SERVER["REMOTE_ADDR"];
        echo "</br>agent: ".substr($_SERVER["HTTP_USER_AGENT"], 0, 50);

        /* $this->load->model("communitymodel");
        $where = array(
                        "ip_address" => $_SERVER["REMOTE_ADDR"],
                        "user_agent" => substr($_SERVER["HTTP_USER_AGENT"], 0, 50)
                    );
        $cisession = $this->communitymodel->getcisession($where);
        if(!empty($cisession)) {
            if(!empty($cisession->session_data)) {
                $userdata = unserialize($cisession->session_data);
                if(is_array($userdata) && !empty($userdata)) {
                    echo "</br>data: "; print_r($userdata);
                    if(isset($userdata["id"]) && $userdata["id"] > 0) {
                        echo "</br>true";
                    }
                    else {
                        echo "</br>no uid";
                    }
                }
                else {
                    echo "</br>no array";
                }
            }
            else {
                echo "</br>no data";
            }
        }
        else {
            echo "</br>no result";
        } */

        //echo "</br><pre>"; print_r(unserialize('a:10:{s:2:"id";s:2:"50";s:9:"user_name";s:7:"Cicilie";s:10:"country_id";s:2:"13";s:5:"email";s:30:"cicilie@fantasticfoodworld.com";s:4:"role";s:4:"user";s:10:"last_visit";s:19:"2013-10-23 03:38:39";s:7:"created";s:19:"2013-10-23 03:38:39";s:8:"modified";s:19:"0000-00-00 00:00:00";s:5:"image";s:22:"Foodlips1380164713.jpg";s:4:"name";s:7:"Cicilie";}'));
        exit();

        $this->db->where("session_id", $_COOKIE["FreakAuth"]);
        //$this->db->where("ip_address", $_SERVER["REMOTE_ADDR"]);
        $this->db->where("user_agent", substr($_SERVER["HTTP_USER_AGENT"], 0, 50));
        //$this->db->where_not_in("session_data", "NULL");
        $this->db->limit("1");
        $query = $this->db->get("ci_sessions");
		echo "</br>rows: ".$query->num_rows();

		$str = substr($_SERVER["HTTP_USER_AGENT"], 0, 50);
		echo "</br>len: ".strlen($str)." agent: ".$str;

		echo "</br>-------------";
		foreach($query->result() as $row) {
			$str = substr($row->user_agent, 0, 50);
			echo "</br>len: ".strlen($str)." agent: ".$str;
		}

        echo "</br>cookie: ".$_COOKIE["FreakAuth"];

        //$this->object =& get_instance();
        //setcookie("FreakAuth", $_COOKIE["FreakAuth"], time()-3600, $this->object->config->item('cookie_path'), $this->object->config->item('cookie_domain'), 0);
        setcookie("FreakAuth", $_COOKIE["FreakAuth"], time()-3600, "/", "", 0);

        echo "</br>cookie: ".$_COOKIE["FreakAuth"];
        //echo "</br>data: <pre>"; print_r($_SERVER);

		//$this->object =& get_instance();
		//echo "<pre>";
		//var_dump($this->object);
		//print_r($this->object);

		?>
			<script>
				//alert(navigator.userAgent);
			</script>
		<?php
	}

	function _isloggedin() {
		if($this->db_session->userdata("id") != "") {
			return true;
		}

		$recipe = base64_encode("recipe");
		//redirect("https://www.foodlips.com/community?$recipe=$recipe");
		redirect("https://www.foodlips.com/shared/auth/login");
	}

	function loginlogout() {
		$this->load->view("pages/loginlogout");
	}

	function searchform() {
		$this->load->view("pages/searchform");
	}

	function sitetopmenu() {
		$this->load->view("community/template/topmenu");
	}

	function advancesearch() {

		if($this->input->post("sbt_search")) {

			/* $this->load->library("pagination");

			$config["base_url"] = base_url()."recipe/index";
			$config["uri_segment"] = 3;
			$config["per_page"] = 5;
			$config["full_tag_open"] = "<p>";
			$config["full_tag_close"] = "</p>";
			$config["cur_tag_open"] = "<b>";
			$config["cur_tag_close"] = "</b>";
			$config["next_link"] = "&gt";
			$config["prev_link"] = "&lt";

			$query = $this->crudmodel->getallrecipes();

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();

			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						); */

			//echo "data: <pre>"; print_r($_POST);

			$from = $this->input->post("from");
			$to = $this->input->post("to");

			$name = $this->input->post("name");
			$categories = $this->input->post("categories");
			$courses = $this->input->post("courses");
			$types = $this->input->post("types");
			$cuisines = $this->input->post("cuisines");
			$seasons = $this->input->post("seasons");
			$methods = $this->input->post("methods");
			$preparationtime = $this->input->post("preparationtime");
			$calories = $this->input->post("calories");
			$serves = $this->input->post("serves");
			$ingredient = $this->input->post("ingredient");

			$advancesearch = array();
			$advancesearchfor = "";

			if($from != "") {
				$advancesearchfor = "From $from";
			}

			if($to != "") {
				$advancesearchfor .= " To $to ";
			}

			if($name != "") {
				$advancesearch["title"] = $name;
				$advancesearchfor .= $name;
			}

			if($categories != "0") {
				$advancesearch["categoryid"] = $categories;

				$advancesearchfor .= ", Category ".$this->crudmodel->getcategorynamebyid($categories);
			}

			if($courses != "0") {
				$advancesearch["courseid"] = $courses;

				$advancesearchfor .= ", Course ".$this->crudmodel->getcoursenamebyid($courses);
			}

			if($types != "0") {
				$advancesearch["typeid"] = $types;

				$advancesearchfor .= ", Type ".$this->crudmodel->gettypenamebyid($types);
			}

			if($cuisines != "0") {
				$advancesearch["cuisineid"] = $cuisines;

				$advancesearchfor .= ", Cuisines ".$this->crudmodel->getcuisinesnamebyid($cuisines);
			}

			if($seasons != "0") {
				$advancesearch["seasonid"] = $seasons;

				$advancesearchfor .= ", Season ".$this->crudmodel->getseasonnamebyid($seasons);
			}

			if($methods != "0") {
				$advancesearch["methodid"] = $methods;

				$advancesearchfor .= ", Method ".$this->crudmodel->getmethodnamebyid($methods);
			}

			if($preparationtime != "") {
				$advancesearch["preparationtime"] = $preparationtime;

				$advancesearchfor .= ", Prepartion time ".$preparationtime;
			}

			if($calories != "") {
				$advancesearch["calories"] = $calories;

				$advancesearchfor .= ", Calories ".$calories;
			}

			if($serves != "") {
				$advancesearch["serves"] = $serves;

				$advancesearchfor .= ", Serve ".$serves;
			}

			// $data["recipes"] = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to, $limit);
			$data["recipes"] = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to);
			$data["categories"] = $this->crudmodel->getallcategories();

			if($this->db_session->userdata("id") != "") {
				$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
			}

			if($advancesearchfor == "") {
				$advancesearchfor = "All";
			}

			$data["advancesearchfor"] = $advancesearchfor;

			//$data["pagination_links"] = $this->pagination->create_links();

			$data["page"] = "pages/home";
			$this->load->view("template/template", $data);
		}
		else {
			$data["categories"] = $this->crudmodel->getallcategories();
			$data["courses"] = $this->crudmodel->getallcourses();
			$data["types"] = $this->crudmodel->getalltypes();
			$data["cuisines"] = $this->crudmodel->getallcuisines();
			$data["seasons"] = $this->crudmodel->getallseasons();
			$data["methods"] = $this->crudmodel->getallmethods();
			$data["ingredients"] = $this->crudmodel->getallingredient();

			$data["page"] = "pages/advancesearch";
			$this->load->view("template/template", $data);
		}
	}

	function advancesearch_backup() {

		if($this->input->post("sbt_search")) {

			$this->load->library("pagination");

			$config["base_url"] = base_url()."recipe/advancesearch";
			$config["uri_segment"] = 3;
			$config["per_page"] = 5;
			$config["full_tag_open"] = "<p>";
			$config["full_tag_close"] = "</p>";
			$config["cur_tag_open"] = "<b>";
			$config["cur_tag_close"] = "</b>";
			$config["next_link"] = "&gt";
			$config["prev_link"] = "&lt";



			//echo "data: <pre>"; print_r($_POST);

			$from = $this->input->post("from");
			$to = $this->input->post("to");

			$name = $this->input->post("name");
			$categories = $this->input->post("categories");
			$courses = $this->input->post("courses");
			$types = $this->input->post("types");
			$cuisines = $this->input->post("cuisines");
			$seasons = $this->input->post("seasons");
			$methods = $this->input->post("methods");
			$preparationtime = $this->input->post("preparationtime");
			$calories = $this->input->post("calories");
			$serves = $this->input->post("serves");
			$ingredient = $this->input->post("ingredient");

			$advancesearch = array();
			$advancesearchfor = "";

			if($from != "") {
				$advancesearchfor = "From $from";
			}

			if($to != "") {
				$advancesearchfor .= " To $to ";
			}

			if($name != "") {
				$advancesearch["title"] = $name;
				$advancesearchfor .= $name;
			}

			if($categories != "0") {
				$advancesearch["categoryid"] = $categories;

				$advancesearchfor .= ", Category ".$this->crudmodel->getcategorynamebyid($categories);
			}

			if($courses != "0") {
				$advancesearch["courseid"] = $courses;

				$advancesearchfor .= ", Course ".$this->crudmodel->getcoursenamebyid($courses);
			}

			if($types != "0") {
				$advancesearch["typeid"] = $types;

				$advancesearchfor .= ", Type ".$this->crudmodel->gettypenamebyid($types);
			}

			if($cuisines != "0") {
				$advancesearch["cuisineid"] = $cuisines;

				$advancesearchfor .= ", Cuisines ".$this->crudmodel->getcuisinesnamebyid($cuisines);
			}

			if($seasons != "0") {
				$advancesearch["seasonid"] = $seasons;

				$advancesearchfor .= ", Season ".$this->crudmodel->getseasonnamebyid($seasons);
			}

			if($methods != "0") {
				$advancesearch["methodid"] = $methods;

				$advancesearchfor .= ", Method ".$this->crudmodel->getmethodnamebyid($methods);
			}

			if($preparationtime != "") {
				$advancesearch["preparationtime"] = $preparationtime;

				$advancesearchfor .= ", Prepartion time ".$preparationtime;
			}

			if($calories != "") {
				$advancesearch["calories"] = $calories;

				$advancesearchfor .= ", Calories ".$calories;
			}

			if($serves != "") {
				$advancesearch["serves"] = $serves;

				$advancesearchfor .= ", Serve ".$serves;
			}

			// $data["recipes"] = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to, $limit);
			$data["recipes"] = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to);

			//for pagination
			$query = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to);

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();

			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);
			//pagination ends
			$data["recipes"] = $this->crudmodel->getadvancesearchrecipes($advancesearch, $from, $to,$limit);

			$data["categories"] = $this->crudmodel->getallcategories();

			if($this->db_session->userdata("id") != "") {
				$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
			}

			if($advancesearchfor == "") {
				$advancesearchfor = "All";
			}

			$data["advancesearchfor"] = $advancesearchfor;

			$data["pagination_links"] = $this->pagination->create_links();

			$data["page"] = "pages/home";
			$this->load->view("template/template", $data);
		}
		else {
			$data["categories"] = $this->crudmodel->getallcategories();
			$data["courses"] = $this->crudmodel->getallcourses();
			$data["types"] = $this->crudmodel->getalltypes();
			$data["cuisines"] = $this->crudmodel->getallcuisines();
			$data["seasons"] = $this->crudmodel->getallseasons();
			$data["methods"] = $this->crudmodel->getallmethods();
			$data["ingredients"] = $this->crudmodel->getallingredient();

			$data["page"] = "pages/advancesearch";
			$this->load->view("template/template", $data);
		}
	}

	function aboutus() {
		$data["page"] = "pages/aboutus";
		$this->load->view("template/template", $data);
	}

	function contactus() {

		if($this->input->post("sbt_contact")) {
			$this->form_validation->set_rules("email", "Email", "trim|required|valid_email");
			$this->form_validation->set_rules("subject", "Subject", "required");
			$this->form_validation->set_rules("message", "Message", "required");

			if ($this->form_validation->run() == FALSE) {

			}
			else {
				$message = "<p><b>Contact mail:</b></p>";
				$message .= "<p>".$this->input->post("email")."</p>";
				$message .= "<p><b>Message:</b></p>";
				$message .= "<p>".$this->input->post("message")."</p>";

				if($this->_sendcontactmail($message)) {
					$data["msg"] = "success";
				}
				else {
					$data["msg"] = "fail";
				}
			}
		}

		$data["page"] = "pages/contactus";
		$this->load->view("template/template", $data);
	}

	function _sendcontactmail($message) {
		$config = array();
        $config['useragent']           = "CodeIgniter";
        $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
        $config['protocol']            = "smtp";
        $config['smtp_host']           = "localhost";
        $config['smtp_port']           = "25";
        $config['mailtype'] = 'html';
        $config['charset']  = 'utf-8';
        $config['newline']  = "\r\n";
        $config['wordwrap'] = TRUE;

        $this->load->library('email');

        $this->email->initialize($config);

        $this->email->from($this->config->item("FAL_user_support"));
		$this->email->to("contact@foodlips.com");
		$this->email->subject($this->config->item("FAL_website_name").": Contact");
		$this->email->message($message);

		if($this->email->send()) {
			return true;
		}
		else{
			show_error($this->email->print_debugger());
			return false;
		}
	}

	function submitrecipe() {

		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			/**
			 * Here for first time to add new recipe
			 */
			if($this->uri->segment("3") != "" && !is_numeric($this->uri->segment("3")) && $this->uri->segment("3") == "recipe") {
				$data["categories"] = $this->crudmodel->getallcategories();
				$data["courses"] = $this->crudmodel->getallcourses();
				$data["types"] = $this->crudmodel->getalltypes();
				$data["cuisines"] = $this->crudmodel->getallcuisines();
				$data["seasons"] = $this->crudmodel->getallseasons();
				$data["methods"] = $this->crudmodel->getallmethods();

				$data["page"]= "pages/submitrecipe";
				$this->load->view("template/template", $data);
			}
			/**
			 * Here for first time to submit new recipe
			 */
			else if($this->input->post("sbt_recipe")) {
				$this->form_validation->set_rules("title", "Title", "required");
				$this->form_validation->set_rules("preparationtime", "Preparation time", "required");
				$this->form_validation->set_rules("serves", "Serve", "required");

				$data["categories"] = $this->crudmodel->getallcategories();
				$data["courses"] = $this->crudmodel->getallcourses();
				$data["types"] = $this->crudmodel->getalltypes();
				$data["cuisines"] = $this->crudmodel->getallcuisines();
				$data["seasons"] = $this->crudmodel->getallseasons();
				$data["methods"] = $this->crudmodel->getallmethods();

				if ($this->form_validation->run() == FALSE) {
						$data["page"]= "pages/submitrecipe";
				}
				else {
					$isvaliddata = true;

					if($this->input->post("categories") == 0) {
						$data["categoryerr"] = "The Caterory field is required.";
						$isvaliddata = false;
					}
					else {
						$categoryid = $this->input->post("categories");
						$isvaliddata = true;
					}

					if($this->input->post("courses") == 0) {
						$data['courseerr'] = "The Course field is required.";
						$isvaliddata = false;
				 	}
				 	else {
					 	$courseid = $this->input->post("courses");
					 	$isvaliddata = true;
				 	}

					if($this->input->post("types") == 0) {
						$data['typeerr'] = "The Type field is required.";
						$isvaliddata = false;
					}
					else {
						$typeid = $this->input->post("types");
						$isvaliddata = true;
					}

					if($this->input->post("cuisines") == 0) {
						$data['cuisineerr'] = "The Cuisine field is required.";
						$isvaliddata = false;
					}
					else {
						$cuisineid = $this->input->post("cuisines");
						$isvaliddata = true;
					}

					/*if($this->input->post("seasons") == 0) {
						$data['seasonerr'] = "The Season field is required.";
					 	$isvaliddata = false;
					}*/
					//else {
						$seasonid = $this->input->post("seasons");
						$isvaliddata = true;
					//}

					if($this->input->post("methods") == 0) {
						$data['methoderr'] = "The method field is required.";
						$isvaliddata = false;
					}
					else {
						$methodid = $this->input->post("methods");
						$isvaliddata = true;
					}

					$data["categoryid"] = $this->input->post("categories");
					$data["courseid"] = $this->input->post("courses");
					$data["typeid"] = $this->input->post("types");
					$data["cuisineid"] = $this->input->post("cuisines");
					$data["seasonid"] = $this->input->post("seasons");
					$data["methodid"] = $this->input->post("methods");

					$recipeid = $this->input->post("recipeid");

					if($isvaliddata) {
						$specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
						$title = str_replace($specialchars, " ", $this->input->post("title"));
						$title = trim($title);

						$datetime = date("Y-m-d H:i:s");

						$categoryname = $this->crudmodel->getcategorynamebyid($this->input->post("categories"));

						$recipe = array(
							"uid" => $this->db_session->userdata("id"),
							"title" => $title ,//$this->input->post("title"),
							"categoryid" => $this->input->post("categories"),
							"courseid" => $this->input->post("courses"),
							"typeid" => $this->input->post("types"),
							"cuisineid" => $this->input->post("cuisines"),
							"seasonid" => $this->input->post("seasons"),
							"methodid" => $this->input->post("methods"),
							"preparationtime" => $this->input->post("preparationtime"),
							"calories" => $this->input->post("calories"),
							"serves" => $this->input->post("serves"),
							"seo" => $this->_getseo($categoryname." ".$title),
							"date" => $datetime
						);

						if($recipeid == "") {

							$datetime = date("Y-m-d H:i:s", strtotime("-10 minutes", strtotime($datetime)));

							$where = array(
									"title" => $this->input->post("title"),
									"uid" => $this->db_session->userdata("id")
								);

							$data["ingredients"] = $this->crudmodel->getallingredient();

							if($this->crudmodel->isrecipeexistsinlast10mins($where, $datetime)) {
								$this->crudmodel->updaterecipeinlast10mins($where, $recipe, $datetime);
								$recipe = $this->crudmodel->getrecipeinlast10mins($where, $datetime);
								if(isset($recipe)) {
									$data["recipe"] = $recipe;
									$data["recipeid"] = $recipe->id;
								}
								else {
									redirect("recipe");
								}
							}
							else {
								$recipeid = $this->crudmodel->addrecipe($recipe);
								if($recipeid > 0 ) {
									$data["recipeid"] = $recipeid;
									$data["title"] = $title;
									/*$info = array(
													"recipeid" => $recipeid,
													"title" => $title ,
													"date" => date("y-m-d H:i:s")
												);
									$activity = array(
														"uid" => $this->db_session->userdata("id"),
														"content" => $this->config->item("recipe_submitted"),
														"info" => serialize($info),
														"date" => date("Y-m-d H:i:s")
													);
									$this->load->model("communitymodel");
									$this->communitymodel->addactivity($activity);*/
								}
							}
							$data["page"]= "pages/recipemedia";
						}
						else {
							$where = array(
											"id" => $recipeid,
											"uid" => $this->db_session->userdata("id")
										);
							if($this->crudmodel->updaterecipe($recipe, $where)) {
								$recipe = $this->crudmodel->getrecipebyid($recipeid);
								if(isset($recipe)) {
									$data["recipe"] = $recipe;
									$data["recipeid"] = $recipeid;
									$data["ingredientdetails"] = $this->crudmodel->getingredientdetails($data["recipeid"]);
									$data["ingredients"] = $this->crudmodel->getallingredient();
									$data["page"]= "pages/recipemedia";
								}
								else {
									redirect("recipe");
								}
							}
							else {
								$data["recipeid"] = $recipeid;
								$data["page"]= "pages/submitrecipe";
							}
						}
					}
					else {
						$data["recipeid"] = $recipeid;
						$data["page"]= "pages/submitrecipe";
					}
				}

				$this->load->view("template/template", $data);
			}
			/**
			 * Here if user click on back
			 */
			else if($this->uri->segment("3") != "" && is_numeric($this->uri->segment("3"))) {
				$data["recipeid"] = $this->uri->segment("3");
				$data["recipe"] = $this->crudmodel->getrecipebyid($this->uri->segment("3"));
				$data["categories"] = $this->crudmodel->getallcategories();
				$data["courses"] = $this->crudmodel->getallcourses();
				$data["types"] = $this->crudmodel->getalltypes();
				$data["cuisines"] = $this->crudmodel->getallcuisines();
				$data["seasons"] = $this->crudmodel->getallseasons();
				$data["methods"] = $this->crudmodel->getallmethods();

				$data["page"]= "pages/submitrecipe";
				$this->load->view("template/template", $data);
			}
			/**
			 * Here if all details submitted by user i.e images, videos, ingredient etc
			 */
			else if($this->input->post("sbt_recipemedia")) {
				//print_r($_POST); exit();
				$data["recipeid"] = $this->input->post("recipeid");
				$data["ingredientdetails"] = $this->crudmodel->getingredientdetails($data["recipeid"]);
				$data["ingredients"] = $this->crudmodel->getallingredient();
				/*if($this->input->post("youtuberadio") == "1"){
					$this->form_validation->set_rules("youtubeuser", "Youtube Username", "required");
					$this->form_validation->set_rules("youtubeurl", "Youtube Url", "required");
				}else{
					$this->form_validation->set_rules("video", "Video", "required");
				}*/

				$this->form_validation->set_rules("preparationdetails", "Preparation details", "required");

				if ($this->form_validation->run() == FALSE) {
					$data["page"]= "pages/recipemedia";
				}
				else {
					//$isvalidata = true;

					$video = $this->input->post("video");
					$ingredientdetails = $this->input->post("itemGaylords");

					/* if($video == "" && $ingredientdetails == "") {
						$isvalidata = false;
					} */

					//if($isvalidata) {
						$ingredientforsearch = "";
						if($this->input->post("ingredient")) {
							$ingredientforsearch = implode(",", $this->input->post("ingredient"));
						}
						$ingredientadd = "";
						if($this->input->post("itemGaylords")) {
							$ingredientadd = implode("|", $this->input->post("itemGaylords"));
						}

						$where = array(
								"id" => $data["recipeid"],
								"uid" => $this->db_session->userdata("id")
							);
						if($this->input->post("youtuberadio") == "1"){
							$recipe = array(
										"isyoutube" => $this->input->post("youtuberadio"),
										"youtubeusername" => $this->input->post("youtubeuser"),
										"youtubeurl" => $this->input->post("youtubeurl"),
										"preparationdetails" => $this->input->post("preparationdetails"),
										"ingredientdetails" =>  $ingredientadd,
										"ingredientid" => $ingredientforsearch
									);
						}else{
							$recipe = array(
										"video" => $this->input->post("video"),
										"preparationdetails" => $this->input->post("preparationdetails"),
										"ingredientdetails" =>  $ingredientadd,
										"ingredientid" => $ingredientforsearch
									);
						}
						if($this->crudmodel->updaterecipe($recipe, $data["recipeid"])) {
							//$this->_notify($data["recipeid"], "newrecipe");
							// code for insert data into newsfeed actitvity
							$recipetittle = $this->crudmodel->getrecipebyid($data["recipeid"]);
							$info = array(
											"recipeid" => $data["recipeid"],
											"title" => $recipetittle->title,
											"date" => date("y-m-d H:i:s")
										);
							$activity = array(
												"uid" => $this->db_session->userdata("id"),
												"content" => $this->config->item("recipe_submitted"),
												"info" => serialize($info),
												"date" => date("Y-m-d H:i:s")
											);
							$this->load->model("communitymodel");
							$this->communitymodel->addactivity($activity);

							$this->db_session->set_userdata("submitted", "1");
							redirect("recipe/success", "refresh");
							//redirect("recipe", "refresh");
						}
						else {
							$data["errmsg"] = "Fail to submit recipe. Please try again.";
							$data["page"]= "pages/recipemedia";
						}
					//}
					/* else {
						$data["errmsg"] = "Video Or Ingredients field required.";
						$data["page"]= "pages/recipemedia";
					} */
				}

				$this->load->view("template/template", $data);
			}
			/**
			 * Here if user click cancel button
			 */
			else if($this->input->post("sbt_cancel")) {
				$recipeid = $this->input->post("recipeid");
				if($recipeid != "") {
					$where = array(
								"id" => $recipeid,
								"uid" => $this->db_session->userdata("id")
							);
					if($this->crudmodel->deleterecipe($where)) {
						redirect("recipe", "refresh");
					}
				}
				else {
					redirect("recipe", "refresh");
				}
			}
			/**
			 * Here redirect to home if non of the action above
			 */
			else {
				redirect("recipe", "refresh");
			}
		}
	}

	function success() {
		if($this->db_session->userdata("submitted") == "1") {

			$this->db_session->unset_userdata("submitted");

			$data["page"] = "pages/success";
			$this->load->view("template/template", $data);
		}
		else {
			redirect("recipe", "refresh");
		}
	}

	function category() {

		$selectedcategory = "";
		$categoryid = "";

    	if($this->uri->segment(3) != "" && !is_numeric($this->uri->segment(3))) {
    		$selectedcategory = $this->uri->segment(3);

			if($selectedcategory != "All") {
				if (strpos($this->uri->segment(3),"_") !== false) {
					$selectedcategory = str_replace("_", " ", $this->uri->segment(3));
				}
				$categoryid = $this->crudmodel->getcategoryidbycategoryname($selectedcategory);
			}
		}
		/* else if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {
			$categoryid = $this->uri->segment(3);
		} */

		//$selectedcategory = $this->uri->segment(3);

		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/category/".$selectedcategory."/";
		$config["uri_segment"] = 4;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$page = $this->uri->segment(4, 0);
    	$page = explode("=", $page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}

		// check if $page is still array if yes then make it as non array variable
		// it is necessary to avoid db err as we cannot use array in place of start or end limit
		if(is_array($page)) {
			$page = "";
		}

    	$limit = array(
						"start" => $config["per_page"],
    				  	"end" => $page
					);

		if($categoryid != "") {
			$data["recipes"] = $this->crudmodel->getallrecipesbycategoryid($categoryid, $limit);
			$data["categoryid"] = $categoryid;
		}

		//$query = $this->crudmodel->getallrecipes();

		/* $query = $this->crudmodel->getallrecipes();

		$config["total_rows"] = $query->num_rows();
		$this->pagination->initialize($config);

		$query->free_result(); */

		/* if($selectedcategory != "All") {
			if (strpos($this->uri->segment(3),"_") !== false) {
				$selectedcategory = str_replace("_", " ", $this->uri->segment(3));
			}

			$categoryid = $this->crudmodel->getcategoryidbycategoryname($selectedcategory);
			$data["recipes"] = $this->crudmodel->getallrecipesbycategoryid($categoryid, $limit);
			$data["categoryid"] = $categoryid;
		}
		else {
			$data["recipes"] = $this->crudmodel->getrecipes($limit);
		} */

		if($selectedcategory == "All") {

			$page = $this->uri->segment(4, 0);

    		$limit = array(
						"start" => $config["per_page"],
    				  	"end" => $page
					);
			$config["uri_segment"] = 4;

			$where = array(
							"approved" => "1"
						);

			$query = $this->crudmodel->getallrecipes($where);
			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
		}
		else {
			$config["total_rows"] = count($this->crudmodel->getallrecipesbycategoryid($categoryid));
			$this->pagination->initialize($config);
		}

		$data["top5recipes"] = $this->crudmodel->gettop5recipes();
		$data["categories"] = $this->crudmodel->getallcategories();

	 	if(count($data["recipes"])) {
			$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
	 	}

		$data["pagination_links"] = $this->pagination->create_links();

		$data["page"] = "pages/home";
		$this -> load -> view("template/template", $data);
		/* }
		else {
			redirect("recipe");
		} */
    }

	function freetextsearch(){
		//$search_term = $this->input->post("search");
		$search_term = ''; // default when no term in session or POST
		if ($this->input->post('search'))
		{
		    // use the term from POST and set it to session
		    $search_term = $this->input->post('search');
		    $this->db_session->set_userdata('search_term', $search_term);
		}
		elseif ($this->db_session->userdata('search_term'))
		{
		    // if term is not in POST use existing term from session
		    $search_term = $this->db_session->userdata('search_term');
		}
		$this->load->library("pagination");
		//$config["base_url"] = base_url()."recipe/freetextsearch/".$search."/";
		$config["base_url"] = base_url()."recipe/freetextsearch/".$search_term."/";

		$config["uri_segment"] = 4;
		//$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";
		$search = array(
					"title" => $search_term
				);
		$limit = "";
		$query = $this->crudmodel->getsearchrecipes($search);
		$config["total_rows"] = count($query);
		$this->pagination->initialize($config);
		$page = $this->uri->segment(4, 0);
		//$page = $this->uri->segment(3, 0);
    	$page = explode("=", $page);
		if(is_array($page) && count($page) > 1) {
			$page = $page[1];
		}

		// check if $page is still array if yes then make it as non array variable
		// it is necessary to avoid db err as we cannot use array in place of start or end limit
		if(is_array($page)) {
			$page = "";
		}
    	$limit = array(
						"start" => $config["per_page"],
    				  	"end" => $page
					);

		$search = array(
					"title" => $search_term
				);

		$data["recipes"] = $this->crudmodel->getadvancesearchrecipes($search,"","", $limit);

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);

	}
	function details() {

//        echo '<pre>$this->uri->segment(3)::'.print_r($this->uri->segment(3),true).'</pre>';
//        echo '<pre>$this->uri->segment(4)::'.print_r($this->uri->segment(4),true).'</pre>';
		if($this->uri->segment(3) != "") {

			$where = array(
							"seo" => urldecode($this->uri->segment(3)),
							"approved" => "1"
						);

			$recipe = $this->crudmodel->getrecipe($where);
//                   echo '<pre>$recipe::'.print_r($recipe,true).'</pre>';
//            die("-1 XXZ");


			if(!empty($recipe)) {

				$data["recipe"] = $recipe;
				$data["categories"] = $this->crudmodel->getallcategories();

				if($this->db_session->userdata("id") != "") {
					$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
				}

				$data["categoryname"] = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
				$data["coursename"] = $this->crudmodel->getcoursenamebyid($recipe->courseid);
				$data["typename"] = $this->crudmodel->gettypenamebyid($recipe->typeid);
				$data["cuisinename"] = $this->crudmodel->getcuisinesnamebyid($recipe->cuisineid);
				$data["seasonname"] = $this->crudmodel->getseasonnamebyid($recipe->seasonid);
				$data["methodname"] = $this->crudmodel->getmethodnamebyid($recipe->methodid);
				$data["rating"] = $this->crudmodel->avarageratingbyid($recipe->ratingid);
				$data["commentscount"] = $this->crudmodel->getcommentcountbyrecipeid($recipe->id);
				$data["comments"] = $this->crudmodel->getcommentsbyrecipeid($recipe->id);
				//$data["reviewscount"] = $this->crudmodel->getreviewscountbyrecipeid($recipe->id);
				//$data["reviews"] = $this->crudmodel->getreviewsbyrecipeid($recipe->id);

				if($this->uri->segment(4) != "" && $this->uri->segment(4) == "iscommented") {
					$data["iscommented"] = true;
				}

				$data["mayalsolike"] = $this->crudmodel->getrecipesbycategoryid($recipe->categoryid);

				$data["page"] = "pages/details";
				$this->load->view("template/template", $data);
			}
			else {
				redirect("recipe");
			}
		}
		else {
			redirect("recipe");
		}

		/* if($this->uri->segment(3) != "" && !is_numeric($this->uri->segment(3))) {

			$categoryid = $this->crudmodel->getcategoryidbycategoryname($this->uri->segment(3));

			if(isset($categoryid)) {

				if($this->uri->segment(4) != "" && !is_numeric($this->uri->segment(4))) {

					$title = $this->uri->segment(4);

					if (strpos($title, "_") !== false) {
						$title = str_replace("_", " ", $title);
					}

					$where = array(
									"categoryid" => $categoryid,
									"title" => $title
								);

					$recipe = $this->crudmodel->getrecipebytitleandcategoryid($where);

					if(isset($recipe)) {
						$data["recipe"] = $recipe;
						$data["categories"] = $this->crudmodel->getallcategories();

						if($this->db_session->userdata("id") != "") {
							$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
						}

						$data["categoryname"] = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
						$data["coursename"] = $this->crudmodel->getcoursenamebyid($recipe->courseid);
						$data["typename"] = $this->crudmodel->gettypenamebyid($recipe->typeid);
						$data["cuisinename"] = $this->crudmodel->getcuisinesnamebyid($recipe->cuisineid);
						$data["seasonname"] = $this->crudmodel->getseasonnamebyid($recipe->seasonid);
						$data["methodname"] = $this->crudmodel->getmethodnamebyid($recipe->methodid);
						$data["rating"] = $this->crudmodel->avarageratingbyid($recipe->ratingid);
						$data["commentscount"] = $this->crudmodel->getcommentcountbyrecipeid($recipe->id);
						$data["comments"] = $this->crudmodel->getcommentsbyrecipeid($recipe->id);
						$data["reviewscount"] = $this->crudmodel->getreviewscountbyrecipeid($recipe->id);
						$data["reviews"] = $this->crudmodel->getreviewsbyrecipeid($recipe->id);

						if($this->uri->segment(4) != "" && $this->uri->segment(4) == "iscommented") {
							$data["iscommented"] = true;
						}

						$data["page"] = "pages/details";
						$this->load->view("template/template", $data);
					}
					else {
						redirect("recipe");
					}
				}
				else {
						redirect("recipe");
					}
			}
			else {
				redirect("recipe");
			}
		}
		else {
			redirect("recipe");
		} */

		/* if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {

			$recipe = $this->crudmodel->getrecipebyid($this->uri->segment(3));

			if(isset($recipe)) {
				$data["recipe"] = $recipe;
				$data["categories"] = $this->crudmodel->getallcategories();

				if($this->db_session->userdata("id") != "") {
					$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
				}

				$data["categoryname"] = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
				$data["coursename"] = $this->crudmodel->getcoursenamebyid($recipe->courseid);
				$data["typename"] = $this->crudmodel->gettypenamebyid($recipe->typeid);
				$data["cuisinename"] = $this->crudmodel->getcuisinesnamebyid($recipe->cuisineid);
				$data["seasonname"] = $this->crudmodel->getseasonnamebyid($recipe->seasonid);
				$data["methodname"] = $this->crudmodel->getmethodnamebyid($recipe->methodid);
				$data["rating"] = $this->crudmodel->avarageratingbyid($recipe->ratingid);
				$data["commentscount"] = $this->crudmodel->getcommentcountbyrecipeid($recipe->id);
				$data["comments"] = $this->crudmodel->getcommentsbyrecipeid($recipe->id);

				if($this->uri->segment(4) != "" && $this->uri->segment(4) == "iscommented") {
					$data["iscommented"] = true;
				}

				$data["page"] = "pages/details";
				$this->load->view("template/template", $data);
			}
			else {
				redirect("recipe");
			}
		}
		else {
			redirect("recipe");
		} */
	}

	function comment() {
		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			if($this->input->post("sbt_comment")) {

				$recipeid = $this->input->post("recipeid");

				if($recipeid > 0) {

					$this->form_validation->set_rules("comment", "Comment", "trim|required");

					if ($this->form_validation->run() == FALSE) {
						$recipe = $this->crudmodel->getrecipebyid($recipeid);
						if(isset($recipe)) {
							$data["recipe"] = $recipe;
							$data["categories"] = $this->crudmodel->getallcategories();
							$data["categoryname"] = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
							$data["coursename"] = $this->crudmodel->getcoursenamebyid($recipe->courseid);
							$data["typename"] = $this->crudmodel->gettypenamebyid($recipe->typeid);
							$data["cuisinename"] = $this->crudmodel->getcuisinesnamebyid($recipe->cuisineid);
							$data["seasonname"] = $this->crudmodel->getseasonnamebyid($recipe->seasonid);
							$data["methodname"] = $this->crudmodel->getmethodnamebyid($recipe->methodid);
							$data["rating"] = $this->crudmodel->avarageratingbyid($recipe->ratingid);
							$data["comments"] = $this->crudmodel->getcommentsbyrecipeid($recipe->id);

							$data["page"] = "pages/details";
							$this->load->view("template/template", $data);
						}
						else {
							redirect("recipe", "refresh");
						}
					}
					else {
						$comment = array (
										"comment" => $this->input->post("comment"),
										"recipeid" => $recipeid,
										"uid" => $this->db_session->userdata("id"),
										"date" => date("y-m-d H:i:s"),
										"notified" => "1"
									);

						if($this->crudmodel->addcomment($comment) > 0) {

							//$this->_notify($recipeid, "comment");
							//$this->_notifyComment($this->db_session->userdata("user_name"), $recipeid);

							redirect("recipe/details/$recipeid/iscommented");
						}
						else {
							$recipe = $this->crudmodel->getrecipebyid($recipeid);

							if(isset($recipe)) {
								$data["recipe"] = $recipe;
								$data["categories"] = $this->crudmodel->getallcategories();
								$data["categoryname"] = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
								$data["coursename"] = $this->crudmodel->getcoursenamebyid($recipe->courseid);
								$data["typename"] = $this->crudmodel->gettypenamebyid($recipe->typeid);
								$data["cuisinename"] = $this->crudmodel->getcuisinesnamebyid($recipe->cuisineid);
								$data["seasonname"] = $this->crudmodel->getseasonnamebyid($recipe->seasonid);
								$data["methodname"] = $this->crudmodel->getmethodnamebyid($recipe->methodid);
								$data["rating"] = $this->crudmodel->avarageratingbyid($recipe->ratingid);
								$data["comments"] = $this->crudmodel->getcommentsbyrecipeid($recipe->id);

								$data["commenterr"] = "Fail to post your comment. Please try again.";

								$data["page"] = "pages/details";
								$this->load->view("template/template", $data);
							}
							else {
								redirect("recipe");
							}
						}
					}
				}
				else {
					redirect("recipe");
				}
			}
			else {
				redirect("recipe");
			}
		}
	}

	function _notifyComment($username, $recipeid) {

		if($username != "" && $recipeid > 0) { ?>

			<div id="sendToCommunity" style="display:none;">
            	this div is just to send notification on community
            </div>

			<script type="text/javascript">

				var username = "<?=$username;?>";
				var recipeid = "<?=$recipeid;?>";

				var msg = username + " commented on " + baseurl + "recipe/details/" + recipeid;

				$("#sendToCommunity").load("https://www.foodlips.com/community/thewire/all", { msg: msg, k: "rcp" }, function(data) {
					$("#sendToCommunity").hide();
				});

			</script>

		<?php }

	}

	function _emailtofriend() {

		//$this->freakauth_light->check();

		//if($this->_isloggedin()) {

			if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {

				$data["recipeid"] = $this->uri->segment(3);
				$data["categories"] = $this->crudmodel->getallcategories();
				$data["page"] = "pages/email";
				$this->load->view("template/template", $data);
			}
			else if ($this->input->post("sbt_send")) {

			 	$recipeid = $this->input->post("recipeid");

				$username = $this->crudmodel->getusernamebyrecipeid($recipeid);

				$data["recipeid"] = $recipeid;

			 	if($this->_sendmail($this->input->post("to"), $this->input->post("message"), $username, $recipeid)) {
				 	//redirect("recipe/details/$recipeid");
				 	$data["successmsg"] = "Your mail sent successfully.";
			 	}
				else {
					$data["failmsg"] = "Mail sending failed. Please try again or try after sometime.";
				}
				$data["page"] = "pages/email";
				$this->load->view("template/template", $data);
			}
			else {
				redirect("recipe", "refresh");
			}
		//}
	}

	function _sendmail($to, $message, $username, $recipeid) {
		$this->load->library("email");
		$this->email->set_newline("\r\n");

		$data["mailtype"] = "html";
		$this->email->initialize($data);

		$this->email->from($this->config->item("email"));
		$this->email->to($to);
		$this->email->subject($this->config->item("FAL_website_name").": Recipe");
		$this->email->message($this->_getmailinformat($message, $username, $recipeid));

		if($this->email->send()) {
			return true;
		}
		else{
			show_error($this->email->print_debugger());
			return false;
		}
	}

	function _getmailinformat($message, $username, $recipeid) {
		$body = "<p>".$username." has suggested you recipe</p>";
		$body .= "<p>Click on following link to view recipe</p>";
		$body .= base_url()."recipe/details/".$recipeid;

		return $body;
	}
	/**
	 * function for multi login using cURl request
	 */
	function curllogin() {
		if($this->input->post("login")) {
			//echo $this->input->post("login");

			$user_name = "";
			$password = $this->input->post("password");
			$siteurl = "https://www.foodlips.com/";

			if (strpos($this->input->post("user_name"), '@') !== false) {
				$user = $this->crudmodel->getuserbyemail($this->input->post("user_name"));
				$user_name = $user->user_name;
			} else {
				$user_name = $this->input->post("user_name");
			}

			if($user_name == $this->db_session->userdata("user_name")) {
                $this->db_session->unset_userdata('user_name');
                $this->db_session->sess_destroy();
            }

			/*
			// INIT CURL
			$ch = curl_init();

			// SET URL FOR THE POST FORM LOGIN
			curl_setopt($ch, CURLOPT_URL, 'https://www.foodlips.com/shared/wineries/wp-login.php');

			// ENABLE HTTP POST
			curl_setopt ($ch, CURLOPT_POST, 1);

			// SET POST PARAMETERS : FORM VALUES FOR EACH FIELD
			curl_setopt ($ch, CURLOPT_POSTFIELDS, array(
						'login' => $user_name,
						'pwd' => $password,
						'testcookie' => '1'
					));

			// IMITATE CLASSIC BROWSER'S BEHAVIOUR : HANDLE COOKIES
			//curl_setopt ($ch, CURLOPT_COOKIEJAR, 'cookie.txt');

			# Setting CURLOPT_RETURNTRANSFER variable to 1 will force cURL
			# not to print out the results of its query.
			# Instead, it will return the results as a string return value
			# from curl_exec() instead of the usual true/false.
			curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);

			// EXECUTE 1st REQUEST (FORM LOGIN)
			$store = curl_exec ($ch);
			var_dump($store);
			echo $user_name.$password;exit;

			// CLOSE CURL
			curl_close ($ch);


			// Get cURL resource
			//$curl = curl_init();

			curl_setopt_array($curl, array(
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_URL => 'auth/login',
				CURLOPT_POST => 1,
				CURLOPT_POSTFIELDS => array(
					'user_name' => $user_name,
					'password' => $password,
					'login' => 'Login'
				)
			));
			if($res = curl_exec($curl)){
				curl_close($curl);
				echo $res;
				//redirect("community");
				//1. Blog Login
				// Set some options - we are passing in a useragent too here
				curl_setopt_array($curl, array(
					CURLOPT_RETURNTRANSFER => 1,
					CURLOPT_URL => $siteurl.'blog/wp-login.php',
					CURLOPT_POST => 1,
					CURLOPT_POSTFIELDS => array(
						'log' => $user_name,
						'pwd' => $password,
						'wpSubmit' => 'Log In',
						'testcookie' => '1'
					)
				));
				if($res = curl_exec($curl)){
					//2. Restaurants Login
					curl_setopt($curl, CURLOPT_URL, $siteurl.'restaurants/wp-login.php');
					if($res = curl_exec($curl)){
						//1. wineries Login
						curl_setopt($curl, CURLOPT_URL, $siteurl.'wineries/wp-login.php');
						if($res = curl_exec($curl)){
							curl_close($curl);
							redirect("community");
						}
					}
				}
			}*/
    	  }
	}

	/**
	 * this function name is login() but it is renamed to oldlogin() bcoz we are using the cURL login above is the cURL login() function
	 */
	function login() {
		if($this->input->post("login")) {
			//echo $this->input->post("login");
			$user_name = "";
			$password = $this->input->post("password");
			$siteurl = "https://www.foodlips.com/";

			if (strpos($this->input->post("user_name"), '@') !== false) {
				$user = $this->crudmodel->getuserbyemail($this->input->post("user_name"));
				$user_name = $user->user_name;
			} else {
				$user_name = $this->input->post("user_name");
			}

			if($user_name == $this->db_session->userdata("user_name")) {
                $this->db_session->unset_userdata('user_name');
                $this->db_session->sess_destroy();
            }
			?>

	        <script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.7.2.min.js"></script>

	        <?php
	        	//echo "u: ".$user_name." p: ".$password;
	        	//exit();
			?>

	        <?php
				/**
				 * RECIPE LOGIN
				 */
			?>
	        <form id="recipe_loginform" method="post" action="<?=base_url();?>/auth/login" style="display: none;">
				<input type="text" name="user_name" value="<?=$user_name;?>" id="user_name" maxlength="30" size="30" />
				<input type="password" name="password" value="<?=$password;?>" id="password" maxlength="30" size="30" />
				<input type="submit" name="login" value="Login" id="login" class="submit" />
			</form>

			<?php
				/**
				 * BLOG LOGIN
				 */
			?>
	        <form id="blog_loginform" method="post" action="<?=$siteurl;?>blog/wp-login.php" name="loginform" style="display: none;">
				<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
				<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
				<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
				<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
				<input type="hidden" name="testcookie" value="1" />
			</form>

			<?php
				/**
				 * FORUM LOGIN for admin
				 */
			?>
		 	<? /* <form id="forum_loginfrom" method="post" action="/foodlips/forum/admin/index.php?" style="display: none;">
				<input type="text" id="username" name="username" value="<?=$user_name;?>" />
				<input type="password" id="password" name="password" value="<?=$this->input->post("password");?>" />
				<input type="hidden" name="do" value="login" />
				<input value="Login" type="submit">
			</form> */ ?>

			<? /* <form id="forum_loginfrom" method="post" action="<?=$siteurl;?>/forum/member.php" style="display: none;">
				<input type="hidden" name="action" value="do_login" />
				<input type="hidden" name="url" value="<?=$siteurl;?>/forum/member.php" />
				<input type="hidden" name="quick_login" value="1" />
				<input type="text" id="quick_login_username" name="quick_username" value="<?=$user_name;?>" />
				<input type="password" id="quick_login_password" name="quick_password" value="<?=$password;?>" />
				<input type="submit" name="submit" value="Login" />
			</form> */ ?>

			<?php
			 	/**
				 * RESTAURANT LOGIN
				 */
			?>
			<form id="restaurant_loginform" method="post" action="<?=$siteurl;?>restaurants/wp-login.php" name="loginform" style="display: none;">
				<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
				<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
				<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
				<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
				<input type="hidden" name="testcookie" value="1" />
			</form>

			<?php
			 	/**
				 * WINERY LOGIN
				 */
			?>
			<form id="winery_loginform" method="post" action="<?=$siteurl;?>wineries/wp-login.php" name="loginform" style="display: none;">
				<input type="text" name="log" id="user_login" class="input" value="<?=$user_name;?>" size="20" /></label>
				<input type="password" name="pwd" id="user_pass" class="input" value="<?=$password;?>" size="20" />
				<input type="submit" name="wp-submit" id="wp-submit" value="Log In" />
				<input type="hidden" name="redirect_to" value="<?=$siteurl;?>" />
				<input type="hidden" name="testcookie" value="1" />
			</form>


			<? /* <form name="loginwidgetform" id="loginwidgetform" action="#login_widget" method="post">
       	 		<input name="widgetptype" value="login" type="hidden">
       			<input name="log" id="widget_user_login" type="text">
            	<input name="pwd" id="widget_user_pass" type="password">
           		<input name="redirect_to" value="https://www.foodlips.com/recipes/" type="hidden">
				<input name="testcookie" value="1" type="hidden">
				<div class="form_row clearfix">
        			<input name="submit" value="Sign In" class="b_signin" type="submit">
				</div>
			</form> */ ?>


	        <script type="text/javascript">
	            $("document").ready(function() {

            		$.post("<?=base_url();?>auth/login", $("#recipe_loginform").serialize(),
						function(data) {
						    //alert("ok");
						})
						.error(function(err) { /*alert("Recipe Error occurred: " + err.responseText);*/ })
						.complete(function() {
							$.post("<?=$siteurl;?>blog/wp-login.php", $("#blog_loginform").serialize(),
							function(data) {
								//alert(data);
							})
							.error(function(err) { /*alert("Blog Error occurred: " + err.responseText);*/ })
							.complete(function() {
								$.post("<?=$siteurl;?>restaurants/wp-login.php", $("#restaurant_loginform").serialize(),
								function(data) {
									//alert(data);
								})
								.error(function(err) { /*alert("Restaurant Error occurred: "  + err.responseText);*/ })
								.complete(function() {
									$.post("<?=$siteurl;?>wineries/wp-login.php", $("#winery_loginform").serialize(),
									function(data) {
										//alert(data);
									})
									.error(function(err) { /*alert("Winery Error occurred: " + err.responseText);*/ })
									.complete(function() { });
								});
							});
						});
				});
	        </script>

	        <script type="text/javascript">
	        	var timeInterval = setInterval(startTimer, 1000);
	        	function startTimer() {
					window.location = "https://www.foodlips.com/shared/recipe/checklogin";
				}
			</script>

    	<?php /*redirect("recipe", "refresh");*/  }
	}

    function _login_Curl() {
        if($this->input->post("login")) {
            echo "</br>1";
            //echo $this->input->post("login");
            $user_name = "";
            $password = $this->input->post("password");
            $siteurl = "https://www.foodlips.com/";

            if (strpos($this->input->post("user_name"), '@') !== false) {
                echo "</br>2";
                $user = $this->crudmodel->getuserbyemail($this->input->post("user_name"));
                $user_name = $user->user_name;
            } else {
                echo "</br>3";
                $user_name = $this->input->post("user_name");
            }
            echo "</br>4";
            // with curl_multi, you only have to wait for the longest-running request
            // build the individual requests as above, but do not execute them

            $postfields = "user_name=$user_name&password=$password&login=Login";
            //curl_setopt($ch_1, CURLOPT_RETURNTRANSFER, true);
            $ch_1 = curl_init(base_url()."auth/login");
            curl_setopt($ch_1, CURLOPT_POST, 1);
            curl_setopt($ch_1, CURLOPT_POSTFIELDS, $postfields);
            $response_1 = curl_exec($ch_1);
            curl_close($ch_1);
            echo "</br>5";

            $postfields = "log=$user_name&pwd=$password&wp-submit=Log In";
            //curl_setopt($ch_2, CURLOPT_RETURNTRANSFER, true);
            $ch_2 = curl_init("https://www.foodlips.com/blog/wp-login.php");
            curl_setopt($ch_2, CURLOPT_POST, 1);
            curl_setopt($ch_2, CURLOPT_POSTFIELDS, $postfields);
            $response_2 = curl_exec($ch_2);
            curl_close($ch_2);
            echo "</br>6";

            echo "$response_1 $response_2"; // same output as first example
        }
    }

	function communitylogin() {
		if($this->input->post("login")) {
			$user_name = "";
			$password = $this->input->post("password");
			$siteurl = "https://www.foodlips.com/";

			if (strpos($this->input->post("user_name"), '@') !== false) {
				$user = $this->crudmodel->getuserbyemail($this->input->post("user_name"));
				$user_name = $user->user_name;
			}
			else {
				$user_name = $this->input->post("user_name");
			} ?>

			<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.7.2.min.js"></script>

			<form id="recipeLoginForm" method="post" action="<?=base_url();?>/auth/login" style="display: none;">
				<input type="text" name="user_name" value="<?=$user_name;?>" id="user_name" maxlength="30" size="30" />
				<input type="password" name="password" value="<?=$password;?>" id="password" maxlength="30" size="30" />
				<input type="submit" name="login" value="Login" id="login" class="submit" />
			</form>

			<script type="text/javascript">
				$("document").ready(function() {
    				$.post("<?=base_url();?>auth/login", $("#recipeLoginForm").serialize(),
						function(data) {
							alert("contoller: " + data);
						})
						.error(function(err) { alert("Recipe Error occurred: " + err.responseText); })
						.complete(function() { });
				});
			</script>

		<?php	}
	 }

	function checklogin() {
		redirect("recipe", "refresh");
	}

	function _logout() { ?>
		<script type="text/javascript" src="<?=base_url();?>js/jquery-1.7.2.min.js"></script>

		<?php $siteurl = "https://www.foodlips.com/"; ?>

		<? /* <a id="recipe_logout" href="<?=base_url();?>auth/logout" style="display: none;">Logout</a>
		<a id="community_logout" href="<?=$siteurl;?>community/action/logout" style="display: none;">Logout</a>
		<a id="blog_logout" href="<?=$siteurl;?>blog/wp-login.php?action=logout" style="display: none;">Logout</a>
		<a id="restaurant_logout" href="<?=$siteurl;?>restaurants/wp-login.php?action=logout" style="display: none;">Logout</a>
		<a id="winery_logout" href="<?=$siteurl;?>wineries/wp-login.php?action=logout" style="display: none;">Logout</a>
		<a id="forum_logout" href="<?=$siteurl;?>forum/member.php?action=logout" style="display: none;">Logout</a> */ ?>

		<div class="container-fluid">
            <h3>Signing out please wait. You will be redirected in less then <b><span id="seconds">10</span></b> seconds.</h3>
        </div>

		<script type="text/javascript">
            $("document").ready(function() {
            	timeInterval = setInterval(startTimer, 1000);

                $.post("<?=base_url();?>auth/logout",function() {
                    $.post("<?=$siteurl;?>community/action/logout",function() {
                        $.post("<?=$siteurl;?>blog/wp-login.php?action=logout",function() {
                            $.post("<?=$siteurl;?>restaurants/wp-login.php?action=logout",function() {
                            	$.post("<?=$siteurl;?>wineries/wp-login.php?action=logout",function() {
                            		$.post("<?=$siteurl;?>forum/member.php?action=logout",function() {

                    				});
                    			});
                    		});
                    	});
                    });
                });

                function startTimer() {
					var seconds = $("#seconds").text();

					if(seconds == 0) {
						$("#seconds").text("");
	        			$("#seconds").text("0");

	        			clearInterval(timeInterval);

	        			window.location = "https://www.foodlips.com/recipes/";
					}
	 				else {
        				seconds -= 1;
        				$("#seconds").text("");
       					$("#seconds").text(seconds);
        			}
				}
        	});
        </script>

	<?php /* redirect("recipe", "refresh"); */ }

	/* function profile() {

		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			$data["recipes"] = $this->crudmodel->getuserrecipes($this->db_session->userdata("id"));

			$data["page"] = "pages/profile";
			$this->load->view("template/template", $data);
		}
	} */

	function books() {
		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));

			$data["page"] = "pages/mybooks";
			$this->load->view("template/template", $data);
		}
	}

	function updateshoppinglist(){
		if($this->input->post("sbt_update")){
			$where = array("recipeid" => $this->input->post("recipeid"));
			//if(!empty($this->input->post("ingredients"))){

				$ingredients = implode("|", $this->input->post("ingredients"));
				$data = array("ingredients" =>$ingredients);

				if($this->crudmodel->updateshoppinglist($data,$where)) {
					//redirect($base_url.'community');
					echo "success";
				}
			//}
		}
	}

	function shoppinglist() {
		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			$data["shoppinglist"] = $this->crudmodel->getshoppinglistbyuserid($this->db_session->userdata("id"));

			$data["page"] = "pages/shoppinglist";
			$this->load->view("template/template", $data);
		}
	}

	function addbook() {
		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			if($this->input->post("sbt_addbook")) {

				$book = array(
								"name" => $this->input->post("name"),
								"uid" => $this->db_session->userdata("id")
							);

				if($this->crudmodel->addbook($book) > 0) {
					$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
					$data["page"] = "pages/mybooks";
				}
				else {
					$data["err"] = "Fail to add book. Please try again or try after sometime.";
					$data["page"] = "pages/addbook";
				}

				$this->load->view("template/template", $data);
			}
			//else if($this->uri->segment("3") != "" && $this->uri->segment("3") = "mybooks") {
			else {
				$data["page"] = "pages/addbook";
				$this->load->view("template/template", $data);
			}
			/* else {
				redirect("recipe", "refresh");
			} */
		}
	}

	function bookdetails() {
		//$this->freakauth_light->check();

		if($this->_isloggedin()) {

			if($this->uri->segment(3) != "" && !is_numeric($this->uri->segment(3))) {

				$bookname = $this->uri->segment(3);

				if (strpos($bookname, "_") !== false) {
					$bookname = str_replace("_", " ", $bookname);
				}

				$bookid = $this->crudmodel->getbookidbyname($bookname);
				$recipeids = $this->crudmodel->getbookrecipeidsbybookid($bookid);
				$data["recipes"] = $this->crudmodel->getbookrecipesbyrecipeids(explode(",", $recipeids));
				$data["bookname"] = $bookname;

				//$data["recipes"] = $this->crudmodel->getbookrecipesbyrecipeids($this->crudmodel->getbookrecipeidsbybookid($this->crudmodel->getbookidbyname($this->uri->segment(3))));

				$data["page"] = "pages/bookdetails";
				$this->load->view("template/template", $data);

				/* if(isset($data["recipes"]) && count($data["recipes"]) > 0) {
					$data["page"] = "pages/bookdetails";
					$this->load->view("template/template", $data);
				}
				else {
					redirect("recipe/profile");
				} */
			}
			else {
				redirect("recipe", "refresh");
			}
		}
	}

	function _notify($recipeid = "", $action = "") {

		if($this->db_session->userdata("id") != "" && $recipeid != "" && $action != "") {
	 		$msg = "";
			$username = $this->db_session->userdata("user_name");

			if($action == "newrecipe") {
				$msg = $username." added new recipe in ".$this->crudmodel->getcategorynamebyrecipeid($recipeid).".";
			}
			else if($action == "comment") {
				$msg = $username." commented on ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
			}

			if($msg != "") {
				$msg .= " ".base_url()."recipe/details/$recipeid"; ?>

				<script type="text/javascript" src="<?=base_url();?>public/frontend/js/jquery-1.7.2.min.js"></script>

				<form id="notify" action="https://www.foodlips.com/community/export.php" method="post">
				    <input type="hidden" name="msg" value="<?=$msg;?>" />
		    		<input type="hidden" name="action" value="<?=$action;?>" />
		    		<input type="hidden" name="recipeid" value="<?=$recipeid;?>" />
		    		<? /* <input type="text" name="msg" value="veenaay likes Chocolate Pudding. https://www.foodlips.com/recipes/recipe/details/176" /> */ ?>
		    		<input type="hidden" name="key" value="recipe" />
				    <input type="submit" value="Submit" />
				</form>

				<script type="text/javascript">
					$(document).ready(function() {
						$("#notify").submit();
						//alert("ok 1");
					});
				</script>

			<?php }
	 	}
		else {
			redirect("recipe", "refresh");
		}
	 }

	function _notify1($recipeid = "", $action = "") {
		//extract($_POST);

		//set POST variables
		/* $fields = array(
	            "username" => $_POST["username"],
	            "password" => $_POST["password"]
	        ); */

	 	if($this->db_session->userdata("id") != "" && $recipeid != "" && $action != "") {
	 		$msg = "";
			$username = $this->db_session->userdata("user_name");

			if($action == "newrecipe") {
				$msg = $username." added new recipe in ".$this->crudmodel->getcategorynamebyrecipeid($recipeid).".";
			}
			else if($action == "comment") {
				$msg = $username." commented on ".$this->crudmodel->getrecipetitlebyid($recipeid).".";
			}

			if($msg != "") {
				$msg .= " ".base_url()."recipe/details/$recipeid";

				$fields = array(
			            "msg" => $msg
			        );

		 		$fields_string = "msg=".$msg;

				//url-ify the data for the POST
				/* foreach($fields as $key => $value) {
					$fields_string .= $key.'='.$value.'&';
				} */
				rtrim($fields_string, '&');

				/* echo "data: ".$fields_string;
				exit(); */

				//open connection
				$ch = curl_init();
				$url = "https://www.foodlips.com/community/export.php";

				//set the url, number of POST vars, POST data
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_POST, count($fields));
				curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);

				//execute post
				$result = curl_exec($ch);

				//close connection
				curl_close($ch);
			}
		}
	}

	function commonusers() {

		//echo "data: ".$this->input->post("users");
		//echo "</br>data: <pre>"; print_r($_POST);
		echo "1";
		if($this->input->post("commonuser") && $this->input->post("commonuser") == base64_encode("somekey")) {
			echo "2";
			$users = $this->input->post("users");
			echo "3";

			//echo "type: ".$users;

			//$users = json_decode($users);

			$users = (array) unserialize($users);

			echo "</br>u: ".gettype($users);

			/* foreach ($users as $user) {
				//echo "</br>u: "; print_r($user);
				echo "</br>u: ".$user->plain;
			} */

			//echo "</br>data: ".$this->input->post("users");

			//echo "</br>type: ".gettype($users);
			//$users = (array) $users;
			//echo "</br>type: ".gettype($users);
			echo "4";
			//echo "data: <pre>";print_r($users);

			//if(is_array($users)) {
				echo "5";

				//for($i = 0; $i < count($users); $i++) {
					//echo "</br>1 u: ".$users[$i];
				//}

				//foreach($users as $user) {
					//echo "before type: ".gettype($user);
					//$user = (object) $user;
					//echo "after type: ".gettype($user);



					/*foreach ($user as $key => $value) {
						$value = (array) $value;
						//echo "</br>key: $key val: $value[0]";
						$value = (object) $value[0];
						echo "</br>val: ".$value->username;
					}*/

					//echo "</br>2 u: "; print_r($user);
					/* foreach ($user as $key => $value) {
						echo "</br>user: ".$value;
					} */
				//}
				echo "6";
			//}
			echo "7";
		}
		echo "8";
	}

	function register() {
		//echo "</br>data: <pre>"; print_r($_POST);

		if($this->input->post("username") && $this->input->post("password")) {

			$user = array(
						"user_name" => $this->input->post("username"),
						"password" => $this->_encode($this->input->post("password")),
						"email" => $this->_encode($this->input->post("email"))
					);

			$this->crudmodel->adduser($user);

		}
	}

	function recipeusers() {
		if($this->input->post("commonuser") && $this->input->post("commonuser") == base64_encode("somekey")) {

			$commonusers = $this->crudmodel->getnonimportedcommonusers();

			if(isset($commonusers)) {

				foreach($commonusers as $commonuser) {

					if($commonuser->recipeimported == "0") {
						$whereusername = array(
									"user_name" => $commonuser->username
								);

						$whereemail = array(
									"email" => $commonuser->email
								);

						if(!$this->crudmodel->isuserexsits($whereusername) && !$this->crudmodel->isuserexsits($whereemail)) {

							$user = array(
								"name" => $commonuser->name,
								"user_name" => $commonuser->username,
								"password" => $this->_encode($commonuser->password),
								"email" => $commonuser->email
							);

							$recipeuid = $this->crudmodel->adduser($user);

							if($recipeuid > 0) {
								$user = array(
												"recipeuid" => $recipeuid
											);

								$where = array(
												"id" => $commonuser->id
											);

								$this->crudmodel->updatecommonuser($user, $where);
							}
						}
					}
				}
			}
		}
	}

	function recipeupdatepassword() {

		if($this->input->post("commonuser") && $this->input->post("commonuser") == base64_encode("somekey")) {

			$commonusers = $this->crudmodel->getnewpasswordcommonusers();

			if(isset($commonusers)) {

				foreach($commonusers as $commonuser) {

					if($commonuser->recipepasswordupdate == "0") {

						$where = array(
									"id" => $commonuser->id
								);

						$user = array(
									"recipepasswordupdate" => "1"
								);

						$this->crudmodel->updatecommonuser($user, $where);
					}
				}
			}
		}
	}

	function _encode($password) {
		$this->CI=& get_instance();
		$majorsalt = null;
		// if you set your encryption key let's use it
  		if ($this->CI->config->item("encryption_key") != "") {
			// conctenates the encryption key and the password
			$_password = $this->CI->config->item("encryption_key").$password;
		}
		else {
			$_password = $password;
		}

		// if PHP5
		if (function_exists("str_split")) {
		    $_pass = str_split($_password);
		}
		// if PHP4
		else {
			$_pass = array();
	    	if (is_string($_password)) {
	    		for ($i = 0; $i < strlen($_password); $i++) {
	        		array_push($_pass, $_password[$i]);
	        	}
	     	}
		}

		// encrypts every single letter of the password
		foreach ($_pass as $_hashpass) {
			$majorsalt .= md5($_hashpass);
		}

        // encrypts the string combinations of every single encrypted letter
        // and finally returns the encrypted password
		return $password = md5($majorsalt);
  	}

	/* function like() {
		if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {

			$recipeid = $this->uri->segment(3);

			$like = array (
						"recipeid" => $recipeid,
						"uid" => 2,
						//"userid" => $this->db_session->userdata("id")
						"date" => date("y-m-d H:i:s")
					);

			if($this->crudmodel->addlike($like) > 0) {
				redirect("recipe/details/$recipeid");
			}
		}
		else {
			redirect("recipe");
		}
	}

	function made() {
		if($this->uri->segment(3) != "" && is_numeric($this->uri->segment(3))) {

			$recipeid = $this->uri->segment(3);

			$made = array (
						"recipeid" => $recipeid,
						"uid" => 2,
						//"userid" => $this->db_session->userdata("id")
						"date" => date("y-m-d H:i:s")
					);

			if($this->crudmodel->addmade($made) > 0) {
				redirect("recipe/details/$recipeid");
			}
		}
		else {
			redirect("recipe");
		}
	} */

	/* function community() {

		//if($this->_isloggedin()) {
			$user = $this->crudmodel->getuserbyid($this->db_session->userdata("id"));

			if(isset($user) && $user != "") {
				$data["likescount"] = $this->crudmodel->getlikecountbyuserid($user->id);

				$data["recipes"] = $this->crudmodel->getallrecipesbyuserid($user->id);
				$data["recipescount"] = count($data["recipes"]);

				$data["groups"] = $this->crudmodel->getallgroupsbyuserid($user->id);
				$data["groupscount"] = count($data["groups"]);

				$data["reviewscount"] = $this->crudmodel->getreviewscountbyuserid($user->id);

				$data["followers"] = $this->crudmodel->getalluserfollowers($user->id);
				$data["followerscount"] = count($data["followers"]);

				$data["about"] = $this->crudmodel->getuseraboutinfo($user->id);

				$data["followings"] = $this->crudmodel->getalluserfollowings($user->id);

				$data["shoppinglist"] = $this->crudmodel->getshoppinglistbyuserid($user->id);

				$data["activities"] = $this->crudmodel->getallactivities();

				$data["made"] = $this->crudmodel->getallmadebyuserid($user->id);

				$data["favorites"] = $this->crudmodel->getallfavoriterecipesbyuserid($user->id);

				$data["favoriteblogs"] = $this->crudmodel->getallfavoriteblogsbyuserid($user->id);

				$data["outsiderecipes"] = $this->crudmodel->getalloutsiderecipesbyuserid($user->id);

				$data["onlinevideos"] = $this->crudmodel->getallonlinevideosbyuserid($user->id);

				$data["user"] = $user;

				$data["page"] = "community/profile";
				$this->load->view("template/template", $data);
			}
			else {
				redirect("recipe/newsfeed");
			}

			//else {
				//redirect("recipe");
			//}
		//}
	} */

	/* function profile() {

		if($this->uri->segment("3") != "") {
			$where = array(
							"user_name" => $this->uri->segment("3")
						);

			$user = $this->crudmodel->getuser($where);

			if(isset($user) && $user != "") {
				$data["likescount"] = $this->crudmodel->getlikecountbyuserid($user->id);

				$data["recipes"] = $this->crudmodel->getallrecipesbyuserid($user->id);
				$data["recipescount"] = count($data["recipes"]);

				$data["groups"] = $this->crudmodel->getallgroupsbyuserid($user->id);
				$data["groupscount"] = count($data["groups"]);

				$data["reviewscount"] = $this->crudmodel->getreviewscountbyuserid($user->id);

				$data["followers"] = $this->crudmodel->getalluserfollowers($user->id);
				$data["followerscount"] = count($data["followers"]);

				$data["about"] = $this->crudmodel->getuseraboutinfo($user->id);

				$data["followings"] = $this->crudmodel->getalluserfollowings($user->id);

				$data["shoppinglist"] = $this->crudmodel->getshoppinglistbyuserid($user->id);

				$data["activities"] = $this->crudmodel->getallactivities();

				$data["made"] = $this->crudmodel->getallmadebyuserid($user->id);

				$data["favorites"] = $this->crudmodel->getallfavoriterecipesbyuserid($user->id);

				$data["favoriteblogs"] = $this->crudmodel->getallfavoriteblogsbyuserid($user->id);

				$data["outsiderecipes"] = $this->crudmodel->getalloutsiderecipesbyuserid($user->id);

				$data["onlinevideos"] = $this->crudmodel->getallonlinevideosbyuserid($user->id);

				$data["isowner"] = false;
				if($user->id == $this->db_session->userdata("id")) {
					$data["isowner"] = true;
				}

				if(!$data["isowner"]) {
					$where = array(
									"uid" => $user->id
								);
					$data["isfriend"] = $this->crudmodel->isfriend($where);

					if(!$data["isfriend"]) {
						$data["isrequested"] = $this->crudmodel->isfriendrequested($where, $this->db_session->userdata("id"));
					}
				}

				$data["user"] = $user;
			}

			$data["page"] = "community/profile";
			$this->load->view("template/template", $data);
		}
		else {
			redirect("recipe/community");
		}
	} */

	/* function creategroup() {
		if($this->_isloggedin()) {

			if($this->input->post("sbt_creategroup")) {
				$this->form_validation->set_rules("name", "Name", "trim|required|callback__isgroupexists");

				if ($this->form_validation->run() == FALSE) {
					$data["page"] = "community/creategroup";
					$this->load->view("template/template", $data);
				}
				else {
					$image = "defaultgroup.png";

					if($_FILES["userfile"]["name"] != "") {
						$groupuploadpath = $this->config->item("group_original_upload_path");

						$config = array(
								"upload_path" => $groupuploadpath,
								"allowed_types" => "jpg|jpeg|gif|png"
							);

						$filename = $_FILES["userfile"]["name"];
						$filename = explode(".", $filename);
						$filename[0] = $filename[0].time().".".$filename[1];
						$_FILES["userfile"]["name"] = $filename[0];

						$this->load->library("upload", $config);

						if($this->upload->do_upload()) {

							$image_data = $this->upload->data();

							$imagestypes = array(
											"group_200x200_upload_path" => $this->config->item("group_200x200_upload_path"),
											"group_50x50_upload_path" => $this->config->item("group_50x50_upload_path")
										);

							$this->load->library("image_lib");

							foreach ($imagestypes as $imagetype) {

								$width = 200;
								$heigth = 200;

								if($imagetype == $this->config->item("group_200x200_upload_path")) {
									$width = 200;
									$heigth = 200;
								}
								else if($imagetype == $this->config->item("group_25x25_upload_path")) {
									$width = 25;
									$heigth = 25;
								}

								$config = array(
											"source_image" => $image_data["full_path"],
											"new_image" => $imagetype,
											"maintain_ration" => true,
											"width" => $width,
											"height" => $heigth
										);

								$this->image_lib->initialize($config);
								$this->image_lib->resize();
							}

							$image = $image_data["file_name"];
						}

						//$this->upload->display_errors();
					}

					$seo = strtolower(str_replace(" ", "-", $this->input->post("name"))."-".md5(time()));

					$uid = $this->db_session->userdata("id");
					$date = date("Y-m-d H:i:s");

					$group = array(
								"uid" => $uid,
								"name" => $this->input->post("name"),
								"description" => $this->input->post("description"),
								"visibility" => $this->input->post("visibility"),
								"image" => $image,
								"seo" => $seo,
								"date" => $date
							);

					$groupid = $this->crudmodel->addgroup($group);
					if($groupid > 0) {

						$activity = array(
										"uid" => $uid,
										"type" => $this->config->item("newgroup"),
										"date" => $date
									);

						$this->crudmodel->addactivity($group);

						redirect("recipe/group/$seo");
					}
					else {
						$data["fail"] = "Fail to create new group. Please try again.";
						$data["page"] = "community/creategroup";
						$this->load->view("template/template", $data);
					}
				}
			}
			else {
				//echo $seo = strtolower(str_replace(" ", "-", "New GROUP TesT")."-".md5(time()));
				$data["page"] = "community/creategroup";
				$this->load->view("template/template", $data);
			}
		}
	} */

	/* function _isgroupexists($name) {

		$where = array(
						"name" => $name
					);

		if($this->crudmodel->isgroupexists($where)) {
			$this->form_validation->set_message("_isgroupexists", "Group already exist with this name.");
			return false;
		}

		return true;
	} */

	/* function group() {
		if($this->uri->segment("3") != "") {

			$where = array(
						"seo" => $this->uri->segment("3")
					);

			$group = $this->crudmodel->getgroup($where);

			$data["group"] = $group;

			if(isset($group) && $group != "") {

				$where = array(
						"gid" => $group->id,
						"uid" => $group->uid
					);

				$data["topics"] = $this->crudmodel->getalltopics($where);

				$data["user"] = $this->crudmodel->getuserbyid($group->uid);

				$uid = $this->db_session->userdata("id");

				$isgroupowner = false;
				if($group->uid == $uid) {
					$isgroupowner = true;
					$data["isgroupowner"] = $isgroupowner;
				}

				if(!$isgroupowner) {
					if($group->members != "") {
						if(in_array($uid, unserialize($group->members))) {
							$data["isgroupmember"] = true;
						}
					}
				}

				$where = array(
						"gid" => $group->id
					);

				$data["groupwallposts"] = $this->crudmodel->getallgroupwallpost($where);
			}

			$data["page"] = "community/group";
			$this->load->view("template/template", $data);
		}
		else {
			redirect("recipe/community");
		}
	} */

	/* function groups() {
		$data["groups"] = $this->crudmodel->getallgroups();

		$data["page"] = "community/allgroups";
		$this->load->view("template/template", $data);
	} */

	/* function editgroup() {
		if($this->_isloggedin()) {

			$uid = $this->db_session->userdata("id");

			if($this->uri->segment("3") != "") {

				$where = array(
							"uid" => $uid,
							"seo" => $this->uri->segment("3")
						);

				$group = $this->crudmodel->getgroup($where);

				if(isset($group) && $group != "") {
					if($group->uid == $uid) {
						$data["group"] = $group;
						$data["page"] = "community/editgroup";
						$this->load->view("template/template", $data);
					}
					else {
						redirect("recipe/community");
					}
				}
				else {
					redirect("recipe/community");
				}
			}
			else if($this->input->post("sbt_updategroup")) {
				$gid = $this->input->post("gid");
				$seo = $this->input->post("seo");

				if($this->input->post("name") != $this->input->post("oldname")) {
					$this->form_validation->set_rules("name", "Name", "trim|required|callback__isgroupexists");
				}
				else {
					$this->form_validation->set_rules("name", "Name", "trim|required");
				}

				if ($this->form_validation->run() == FALSE) {
					$data["page"] = "community/editgroup";
					$this->load->view("template/template", $data);
				}
				else {
					$image = "defaultgroup.png";
					if($this->input->post("oldimage") != "") {
						$image = $this->input->post("oldimage");
					}

					if($_FILES["userfile"]["name"] != "") {
						$groupuploadpath = $this->config->item("group_original_upload_path");

						$config = array(
								"upload_path" => $groupuploadpath,
								"allowed_types" => "jpg|jpeg|gif|png"
							);

						$filename = $_FILES["userfile"]["name"];
						$filename = explode(".", $filename);
						$filename[0] = $filename[0].time().".".$filename[1];
						$_FILES["userfile"]["name"] = $filename[0];

						$this->load->library("upload", $config);

						if($this->upload->do_upload()) {

							$image_data = $this->upload->data();

							$imagestypes = array(
											"group_200x200_upload_path" => $this->config->item("group_200x200_upload_path"),
											"group_50x50_upload_path" => $this->config->item("group_50x50_upload_path")
										);

							$this->load->library("image_lib");

							foreach ($imagestypes as $imagetype) {

								$width = 200;
								$heigth = 200;

								if($imagetype == $this->config->item("group_200x200_upload_path")) {
									$width = 200;
									$heigth = 200;
								}
								else if($imagetype == $this->config->item("group_25x25_upload_path")) {
									$width = 25;
									$heigth = 25;
								}

								$config = array(
											"source_image" => $image_data["full_path"],
											"new_image" => $imagetype,
											"maintain_ration" => true,
											"width" => $width,
											"height" => $heigth
										);

								$this->image_lib->initialize($config);
								$this->image_lib->resize();
							}

							$image = $image_data["file_name"];
						}

						//$this->upload->display_errors();
					}

					$seo = strtolower(str_replace(" ", "-", $this->input->post("name"))."-".md5(time()));

					$group = array(
								"name" => $this->input->post("name"),
								"description" => $this->input->post("description"),
								"visibility" => $this->input->post("visibility"),
								"image" => $image,
								"seo" => $seo,
								"date" => date("Y-m-d H:i:s")
							);

					$where = array(
							"id" => $this->input->post("gid"),
							"uid" => $uid
						);

					if($this->crudmodel->updategroup($group, $where)) {
						redirect("recipe/group/$seo");
					}
					else {
						$data["fail"] = "Fail to update group. Please try again.";
						$data["page"] = "community/editgroup";
						$this->load->view("template/template", $data);
					}
				}
			}
			else {
				redirect("recipe/community");
			}
		}
	} */

	/* function addtopic() {
		if($this->_isloggedin()) {
			if($this->input->post("sbt_addtopic")) {
				$this->form_validation->set_rules("title", "Title", "trim|required");
				$this->form_validation->set_rules("message", "Message", "trim|required");

				if ($this->form_validation->run() == FALSE) {
					$data["page"] = "community/addtopic";
					$this->load->view("template/template", $data);
				}
				else {
					$gid = $this->input->post("gid");
					$uid = $this->db_session->userdata("id");

					$where = array(
							"id" => $gid,
							"uid" => $uid
						);

					$group = $this->crudmodel->getgroup($where);
					$data["group"] = $group;

					if(isset($group) && $group != "") {
						if($group->uid == $uid) {
							$seo = strtolower(str_replace(" ", "-", $this->input->post("title"))."-".md5(time()));

							$topic = array(
										"gid" => $gid,
										"uid" => $this->db_session->userdata("id"),
										"title" => $this->input->post("title"),
										"message" => $this->input->post("message"),
										"seo" => $seo,
										"date" => date("Y-m-d H:i:s")
									);

							$topicid = $this->crudmodel->addtopic($topic);
							if($topicid > 0) {
								redirect("recipe/topic/$seo");
							}
							else {
								$data["fail"] = "Fail to add topic. Please try again.";
								$data["page"] = "community/addtopic";
								$this->load->view("template/template", $data);
							}
						}
						else {
							redirect("recipe/community");
						}
					}
					else {
						$data["fail"] = "Fail to add topic. Please try again.";
						$data["page"] = "community/addtopic";
						$this->load->view("template/template", $data);
					}
				}
			}
			else if($this->uri->segment("3") != "") {
				$uid = $this->db_session->userdata("id");

				$where = array(
							"uid" => $uid,
							"seo" => $this->uri->segment("3")
						);

				$group = $this->crudmodel->getgroup($where);
				if(isset($group) && $group != "") {
					if($group->uid == $uid) {
						$data["group"] = $group;
						$data["page"] = "community/addtopic";
						$this->load->view("template/template", $data);
					}
					else {
						redirect("recipe/community");
					}
				}
				else {
					redirect("recipe/community");
				}
			}
			else {
				redirect("recipe/community");
			}
		}
	} */

	/* function topic() {
		if($this->uri->segment("3") != "") {

			$where = array(
						"seo" => $this->uri->segment("3")
					);

			$topic = $this->crudmodel->gettopic($where);

			$group = "";
			$replies = "";

			if(isset($topic) && $topic != "") {
				$data["topic"] = $topic;

				$where = array(
								"id" => $topic->gid
							);

				$group = $this->crudmodel->getgroup($where);
				$data["group"] = $group;

				$where = array(
								"gid" => $topic->gid,
								"tid" => $topic->id
							);

				$replies = $this->crudmodel->getallreply($where);
				$data["replies"] = $replies;

				$uid = $this->db_session->userdata("id");

				$isgroupowner = false;
				if($topic->uid == $uid) {
					$isgroupowner = true;
					$data["isgroupowner"] = $isgroupowner;
				}

				if(!$isgroupowner) {
					if($group->members != "") {
						if(in_array($uid, unserialize($group->members))) {
							$data["isgroupmember"] = true;
						}
					}
				}

				$data["user"] = $this->crudmodel->getuserbyid($topic->uid);
			}

			$data["page"] = "community/topic";
			$this->load->view("template/template", $data);
		}
		// not used for now
		else if($this->input->post("sbt_reply")) {
			if($this->_isloggedin()) {
				$this->form_validation->set_rules("message", "Message", "trim|required");

				if ($this->form_validation->run() == FALSE) {

				}
				else {
					$reply = array(
								"gid" => $this->input->post("gid"),
								"tid" => $this->input->post("tid"),
								"uid" => $this->db_session->userdata("id"),
								"message" => $this->input->post("message"),
								"date" => date("Y-m-d H:i:s")
							);

					$replyid = $this->crudmodel->addreply($reply);

					if($replyid <= 0) {
						$data["fail"] = "Fail to reply. Please try again.";

						$where = array(
							"id" => $this->input->post("tid")
						);

						$data["topic"] = $this->crudmodel->gettopic($where);

						$where = array(
									"gid" => $this->input->post("gid"),
									"tid" => $this->input->post("tid")
								);

						$replies = $this->crudmodel->getallreply($where);
						$data["replies"] = $replies;

						$data["page"] = "community/topic";
						$this->load->view("template/template", $data);
					}
					else {
						$seo = $this->input->post("seo");
						redirect("recipe/topic/$seo");
					}
				}
			}
		}
		else {
			redirect("recipe/community");
		}
	} */

	/* function invite() {
		if($this->input->post("sbt_invite")) {

		}
		$data["page"] = "community/invite";
		$this->load->view("template/template", $data);
	}

	function newsfeed() {
		$data["page"] = "community/newsfeed";
		$this->load->view("template/template", $data);
	}

	function searchmember() {
		$data["page"] = "community/searchmember";
		$this->load->view("template/template", $data);
	} */

	/* function to show list of liked recipes if approved*/
	/* function likes() {
		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/likes";
		$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$uid = $this->db_session->userdata("id");
		$likes = $this->crudmodel->getlikesbyuserid($uid);
		if(isset($likes) && $likes != ""){
			foreach($likes as $like ){
					$where[] = $like->recipeid;
				}
			$query = $this->crudmodel->getalllikedrecipes($where);

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();
			//echo "test1";
			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);

			if($this->input->post("sbt_search")) {

				$search = array(
						"title" => $this->input->post("search")
					);

				$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

				//$query = $this->crudmodel->getallrecipes($limit);
			}
			else {

				//$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
				$data["recipes"] = $this->crudmodel->getlikedrecipes($where, $limit);
			}
		}

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		//echo "test2";
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);
	} */

	/* function to show list of recipes submitted by user*/
	/* function submitted() {

		if($this->uri->segment("3")) {

			$where = array(
							"user_name" => $this->uri->segment("3")
						);
			$user = $this->crudmodel->getuser($where);

			if(!empty($user)) {
				$this->load->library("pagination");

				$config["base_url"] = base_url()."recipe/submitted/".$user->user_name."/";
				$config["uri_segment"] = 3;
				$config["per_page"] = 5;
				$config["full_tag_open"] = "<p>";
				$config["full_tag_close"] = "</p>";
				$config["cur_tag_open"] = "<b class='current'>";
				$config["cur_tag_close"] = "</b>";
				$config["next_link"] = "&gt";
				$config["prev_link"] = "&lt";

				$where = array(
								"uid" => $user->id,
								"approved" => "1"
							);

				$query = $this->crudmodel->getallrecipes($where);

				$config["total_rows"] = $query->num_rows();
				$this->pagination->initialize($config);

				$query->free_result();
				//echo "test1";
				$page = $this->uri->segment(4, 0);

		    	$limit = array(
								"start" => $config["per_page"],
		    				  	"end" => $page
							); */

				/* if($this->input->post("sbt_search")) {

					$search = array(
							"title" => $this->input->post("search")
						);

					$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

					//$query = $this->crudmodel->getallrecipes($limit);
				}
				else {
					$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);

					//if(count($data["recipes"])) {
						//$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
					//}
					//$data["userimage"] = $this->crudmodel->getuserdetailsbyid();
				} */

				/* $data["recipes"] = $this->crudmodel->getrecipes($where, $limit);

				if($this->db_session->userdata("id") != "") {
					$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
				}

				$data["pagination_links"] = $this->pagination->create_links();
				//echo "test2";
			}

			$data["categories"] = $this->crudmodel->getallcategories();
			$data["top5recipes"] = $this->crudmodel->gettop5recipes();

			$data["page"] = "pages/home";
			$this->load->view("template/template", $data);
		}
	} */

	function submitted() {
		$this->_loadrecipesbyuser("submitted");
	}

	function made() {
		$this->_loadrecipesbyuser("made");
	}

	function favourite() {
		$this->_loadrecipesbyuser("favourite");
	}

	function reviewed() {
		$this->_loadrecipesbyuser("reviewed");
	}

	function likes() {
		$this->_loadrecipesbyuser("likes");
	}

	function _loadrecipesbyuser($type="") {

		if(!empty($type)) {

			$where = array(
							"user_name" => $this->uri->segment("3")
						);
			$user = $this->crudmodel->getuser($where);

			if(!empty($user)) {
				$this->load->library("pagination");

				if($type == "submitted") {
					$config["base_url"] = base_url()."recipe/submitted/".$user->user_name."/";
				}
				else if($type == "made") {
					$config["base_url"] = base_url()."recipe/made/".$user->user_name."/";
				}
				else if($type == "favourite") {
					$config["base_url"] = base_url()."recipe/favourite/".$user->user_name."/";
				}
				else if($type == "reviewed") {
					$config["base_url"] = base_url()."recipe/reviewed/".$user->user_name."/";
				}
				else if($type == "likes") {
					$config["base_url"] = base_url()."recipe/likes/".$user->user_name."/";
				}

				$config["uri_segment"] = 4;
				$config["per_page"] = 5;
				$config["full_tag_open"] = "<p>";
				$config["full_tag_close"] = "</p>";
				$config["cur_tag_open"] = "<b class='current'>";
				$config["cur_tag_close"] = "</b>";
				$config["next_link"] = "&gt";
				$config["prev_link"] = "&lt";

				if($type == "submitted") {
					$where = array(
									"uid" => $user->id,
									"approved" => "1"
								);
					$query = $this->crudmodel->getallrecipes($where);
				}
				else if($type == "made") {
					//$mades = $this->crudmodel->getmadesbyuserid($user->id);
					$where = array(
									"uid" => $user->id
									);
					$mades = $this->crudmodel->getalltriedrecipes($where);
					$wherein = array();
					if(!empty($mades)) {
						foreach($mades as $made) {
							$wherein[] = $made->recipeid;
						}
						//$this->output->enable_profiler(true);
					}

					if(!empty($wherein)) {
						$query = $this->crudmodel->getrecipeswherein($wherein, "", true);
					}
				}
				else if($type == "favourite") {
					//$favourites = $this->crudmodel->getfavouritebyuserid($uid);
					$where = array(
									"uid" => $user->id
									);
					$favourites = $this->crudmodel->getallfavouriterecipes($where);
					$wherein = array();
					if(!empty($favourites)) {
						foreach($favourites as $favourite ) {
							$wherein[] = $favourite->recipeid;
						}
					}

					if(!empty($wherein)) {
						$query = $this->crudmodel->getrecipeswherein($wherein, "", true);
					}
				}
				else if($type == "reviewed") {
					$where = array(
									"uid" => $user->id
									);
					//$reviews = $this->crudmodel->getallreviewrecipes($where);
					$reviews = $this->crudmodel->getallcommentsandreviews($where);
					$wherein = array();
					if(!empty($reviews)) {
						foreach($reviews as $review) {
							$wherein[] = $review->recipeid;
						}
					}

					if(!empty($wherein)) {
						$query = $this->crudmodel->getrecipeswherein($wherein, "", true);
					}
				}
				else if($type == "likes") {
					$where = array(
									"uid" => $user->id
									);
					$likes = $this->crudmodel->getalllikesrecipes($where);
					$wherein = array();
					if(!empty($likes)) {
						foreach($likes as $like) {
							$wherein[] = $like->recipeid;
						}
					}

					if(!empty($wherein)) {
						$query = $this->crudmodel->getrecipeswherein($wherein, "", true);
					}
				}

				if(isset($query) && !empty($query)) {
					$config["total_rows"] = $query->num_rows();
					$this->pagination->initialize($config);

					$query->free_result();
				}

				$page = $this->uri->segment(4, 0);
    			$page = explode("=", $page);
				if(is_array($page) && count($page) > 1) {
					$page = $page[1];
				}

				// check if $page is still array if yes then make it as non array variable
				// it is necessary to avoid db err as we cannot use array in place of start or end limit
				if(is_array($page)) {
					$page = "";
				}

		    	$limit = array(
								"start" => $config["per_page"],
		    				  	"end" => $page
							);

				if($type == "submitted") {
					$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
				}
				else if($type == "made" || $type == "favourite" || $type == "reviewed" || $type == "likes") {
					if(!empty($wherein)) {
						$data["recipes"] = $this->crudmodel->getrecipeswherein($wherein, $limit, false);
					}
				}

				if($this->db_session->userdata("id") != "") {
					$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
				}

				$data["pagination_links"] = $this->pagination->create_links();
			}

			$data["categories"] = $this->crudmodel->getallcategories();
			$data["top5recipes"] = $this->crudmodel->gettop5recipes();

			$data["page"] = "pages/home";
			$this->load->view("template/template", $data);
		}
	}

	/* function to show list of recipes tried by user */

	/* function recipetired() {

		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/recipetired";
		$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$uid = $this->db_session->userdata("id");
		$mades = $this->crudmodel->getmadesbyuserid($uid);
		if(isset($mades) && $mades != ""){
			foreach($mades as $made ){
					$where[] = $made->recipeid;
				}
			$query = $this->crudmodel->getalltriedrecipes($where);

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();
			//echo "test1";
			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);

			if($this->input->post("sbt_search")) {

				$search = array(
						"title" => $this->input->post("search")
					);

				$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

				//$query = $this->crudmodel->getallrecipes($limit);
			}
			else {

				//$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
				$data["recipes"] = $this->crudmodel->gettriedrecipes($where, $limit);
			}
		}

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		//echo "test2";
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);
	}*/

	/* function to show list of favourite recipes by user */

	/* function favouriterecipes() {

		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/favouriterecipes";
		$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$uid = $this->db_session->userdata("id");
		$favourites = $this->crudmodel->getfavouritebyuserid($uid);
		if(isset($favourites) && $favourites != ""){
			foreach($favourites as $favourite ){
					$where[] = $favourite->recipeid;
				}
			$query = $this->crudmodel->getalltriedrecipes($where); //getalltriedrecipes() it returns the recipe details by id so it is common for all

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();
			//echo "test1";
			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);

			if($this->input->post("sbt_search")) {

				$search = array(
						"title" => $this->input->post("search")
					);

				$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

				//$query = $this->crudmodel->getallrecipes($limit);
			}
			else {

				//$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
				$data["recipes"] = $this->crudmodel->gettriedrecipes($where, $limit); //gettriedrecipes() it returns the recipe details by id so it is common for all
			}
		}

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		//echo "test2";
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);
	} */

	/* function to show list recipes where user submitted reviews */

	/* function recipereviewed() {

		$this->load->library("pagination");

		$config["base_url"] = base_url()."recipe/recipereviewed";
		$config["uri_segment"] = 3;
		$config["per_page"] = 5;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";

		$uid = $this->db_session->userdata("id");
		$limit = "all";
		$reviews = $this->crudmodel->getrecipereviewsbyuserid($uid,$limit);

		if(isset($reviews) && $reviews != ""){
			foreach($reviews as $review ){
					$where[] = $review->recipeid;
				}
			$query = $this->crudmodel->getalltriedrecipes($where);

			$config["total_rows"] = $query->num_rows();
			$this->pagination->initialize($config);

			$query->free_result();
			//echo "test1";
			$page = $this->uri->segment(3, 0);

	    	$limit = array(
							"start" => $config["per_page"],
	    				  	"end" => $page
						);

			if($this->input->post("sbt_search")) {

				$search = array(
						"title" => $this->input->post("search")
					);

				$data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

				//$query = $this->crudmodel->getallrecipes($limit);
			}
			else {

				//$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
				$data["recipes"] = $this->crudmodel->gettriedrecipes($where, $limit);
			}
		}

		$data["categories"] = $this->crudmodel->getallcategories();
		$data["top5recipes"] = $this->crudmodel->gettop5recipes();

		if($this->db_session->userdata("id") != "") {
			$data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
		}

		$data["pagination_links"] = $this->pagination->create_links();
		//echo "test2";
		$data["page"] = "pages/home";
		$this->load->view("template/template", $data);
	} */

	/**
	 * function to add extra information about restaurants
	 */

	function addrestaurentsinfo() {
		if($this->input->post("sbt_submit")) {
			//echo "<pre>"; print_r($_FILES);
			//exit();
			$config["upload_path"] = $this->config->item("restaurent_upload_path");
			$path = $config["upload_path"];
			$config["allowed_types"] = "gif|jpg|jpeg|png";
			//$config["max_size"] = "1024";
			//$config["max_width"] = "1920";
			//$config["max_height"] = "1280";
			$this->load->library("upload");
			$this->load->library("image_lib");
			foreach ($_FILES as $fieldname => $fileObject) { //fieldname is the form field name

			    if (!empty($fieldname["name"])) {
			        $this->upload->initialize($config);
			        if (!$this->upload->do_upload($fieldname)) {
			            $errors = $this->upload->display_errors();
			            flashMsg($errors);
			        }
			        else {
			             // Code After Files Upload Success GOES HERE
			             //echo "ok";

					 	$image_data[] = $this->upload->data();

						/*$imagestypes = array(
											"restaurent_index_upload_path" => $this->config->item("restaurent_index_upload_path"),
											"restaurent_home_upload_path" => $this->config->item("restaurent_home_upload_path"),
											"restaurent_detail_upload_path" => $this->config->item("restaurent_detail_upload_path"),
										);

							//$this->load->library("image_lib");



						foreach ($imagestypes as $imagetype) {

							$width = 100;
							$heigth = 100;

							if($imagetype == $this->config->item("restaurent_index_upload_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("restaurent_home_upload_path")) {
								$width = 650;
								$heigth = 350;
							}
							else if($imagetype == $this->config->item("restaurent_detail_upload_path")) {
								$width = 275;
								$heigth = 198;
							}

							$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);

							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}*/
			        }
			    }
			}
			//print_r($image_data);

			$breakfast = array(
								"mon" => $this->input->post("breakfast_m"),
								"tue" => $this->input->post("breakfast_tu"),
								"wed" => $this->input->post("breakfast_w"),
								"thu" => $this->input->post("breakfast_th"),
								"fri" => $this->input->post("breakfast_f"),
								"sat" => $this->input->post("breakfast_st"),
								"sun" => $this->input->post("breakfast_su")
							);
			$lunch = array(
							"mon" => $this->input->post("lunch_m"),
							"tue" => $this->input->post("lunch_tu"),
							"wed" => $this->input->post("lunch_w"),
							"thu" => $this->input->post("lunch_th"),
							"fri" => $this->input->post("lunch_f"),
							"sat" => $this->input->post("lunch_st"),
							"sun" => $this->input->post("lunch_su")
						);
			$dinner = array(
							"mon" => $this->input->post("dinner_m"),
							"tue" => $this->input->post("dinner_tu"),
							"wed" => $this->input->post("dinner_w"),
							"thu" => $this->input->post("dinner_th"),
							"fri" => $this->input->post("dinner_f"),
							"sat" => $this->input->post("dinner_st"),
							"sun" => $this->input->post("dinner_su")
						);

			$date = date("Y-m-d H:i:s");
			$restaurent = array(
								"pid" => $this->input->post("postid"),
								"restaurent_img" => (isset($image_data[0]["file_name"]) ? $image_data[0]["file_name"] : ""),
								"menus" => $this->input->post("menu"),
								"menu_img" => (isset($image_data[1]["file_name"]) ? $image_data[1]["file_name"] : ""),
								"breakfast" => serialize($breakfast),
								"lunch" => serialize($lunch),
								"dinner" => serialize($dinner),
								"date" => $date,
								"ip" => $this->input->ip_address()
							);
			$postlink = $this->input->post("link");
			if($this->crudmodel->addrestaurantinfo($restaurent)) {
				//<script> //alert("success");</script>
				redirect($postlink);
			}
		}

		/*if($this->input->post("sbt_submit")) {
			if(isset($_FILES) && !empty($_FILES)) {

				$imagename = array();
				//echo "<pre>"; print_r($_FILES);

				foreach($_FILES as $index => $value) {

					$restaurentuploadpath = $this->config->item("restaurent_upload_path");
					$config = array(
									"upload_path" => $restaurentuploadpath,
									"allowed_types" => "jpg|jpeg|gif|png"
									);
					/*$filename = $image;//$_FILES["restaurantimg"]["name"];
					$filename = explode(".", $filename);
					$filename[0] = $filename[0].time().".".$filename[1];
					//$_FILES["restaurantimg"]["name"] = $filename[0];
					$image = $filename[0];*/

					/*$this->load->library("upload", $config);

					if($this->upload->do_upload()) {

						$image_data = $this->upload->data();

						$imagestypes = array(
											"restaurent_index_upload_path" => $this->config->item("restaurent_index_upload_path"),
											"restaurent_home_upload_path" => $this->config->item("restaurent_home_upload_path"),
											"restaurent_detail_upload_path" => $this->config->item("restaurent_detail_upload_path"),
											);
						$this->load->library("image_lib");

						foreach ($imagestypes as $imagetype) {
							$width = 100;
							$heigth = 100;

							if($imagetype == $this->config->item("restaurent_index_upload_path")) {
								$width = 1004;
								$heigth = 400;
							}
							else if($imagetype == $this->config->item("restaurent_home_upload_path")) {
								$width = 650;
								$heigth = 350;
							}
							else if($imagetype == $this->config->item("restaurent_detail_upload_path")) {
								$width = 275;
								$heigth = 198;
							}

							$config = array(
											"source_image" => $image_data["full_path"],
											"new_image" => $imagetype,
											"maintain_ration" => true,
											"width" => $width,
											"height" => $heigth
											);
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
						$imagename =array();
						$imagename=  $image_data["file_name"];
						echo "</br>1";
						print_r($imagename);exit();
					}
					//$this->upload->display_errors();
				}//foreach
				echo "</br>2";
				print_r($imagename);exit();

			//}
			//$uid = $this->db_session->userdata("id");
			//print_r($imagename);exit();
			$breakfast = array(
								"mon" => $this->input->post("breakfast_m"),
								"tue" => $this->input->post("breakfast_tu"),
								"wed" => $this->input->post("breakfast_w"),
								"thu" => $this->input->post("breakfast_th"),
								"fri" => $this->input->post("breakfast_f"),
								"sat" => $this->input->post("breakfast_st"),
								"sun" => $this->input->post("breakfast_su")
							);
			$lunch = array(
							"mon" => $this->input->post("lunch_m"),
							"tue" => $this->input->post("lunch_tu"),
							"wed" => $this->input->post("lunch_w"),
							"thu" => $this->input->post("lunch_th"),
							"fri" => $this->input->post("lunch_f"),
							"sat" => $this->input->post("lunch_st"),
							"sun" => $this->input->post("lunch_su")
						);
			$dinner = array(
							"mon" => $this->input->post("dinner_m"),
							"tue" => $this->input->post("dinner_tu"),
							"wed" => $this->input->post("dinner_w"),
							"thu" => $this->input->post("dinner_th"),
							"fri" => $this->input->post("dinner_f"),
							"sat" => $this->input->post("dinner_st"),
							"sun" => $this->input->post("dinner_su")
						);

			$date = date("Y-m-d H:i:s");
			$restaurent = array(
								"pid" => $this->input->post("postid"),
								"restaurent_img" => $imagename[0],
								"menus" => $this->input->post("menu"),
								"menu_img" => $imagename[1],//$this->input->post("blogurl"),
								"breakfast" => serialize($breakfast),
								"lunch" => serialize($lunch),
								"dinner" => serialize($dinner),
								"date" => $date,
								"ip" => $this->input->ip_address()
							);
			if($this->crudmodel->addrestaurantinfo($restaurent)) {
				?><script> alert("success");</script><?
				//redirect("recipe");
			}
		}
		}*/
		//redirect("community");
	}

	/*
	 * function to add extra information about winery*/
	 function addwineryinfo(){
	 	if($this->input->post("sbt_submit")) {
	 		//echo "<pre>"; print_r($_FILES);
			//exit();
			$config["upload_path"] = $this->config->item("winery_upload_path");
			$path = $config["upload_path"];
			$config["allowed_types"] = "gif|jpg|jpeg|png";
			//$config["max_size"] = "1024";
			//$config["max_width"] = "1920";
			//$config["max_height"] = "1280";
			$this->load->library("upload");
			$this->load->library("image_lib");
			foreach ($_FILES as $fieldname => $fileObject) { //fieldname is the form field name

			    if (!empty($fieldname["name"])) {
			        $this->upload->initialize($config);
			        if (!$this->upload->do_upload($fieldname)) {
			            $errors = $this->upload->display_errors();
			            flashMsg($errors);
			        }
			        else {
			             // Code After Files Upload Success GOES HERE
			             //echo "ok";
					 	$image_data[] = $this->upload->data();
			        }
			    }
			}
			//print_r($image_data);

			$breakfast = array(
								"mon" => $this->input->post("breakfast_m"),
								"tue" => $this->input->post("breakfast_tu"),
								"wed" => $this->input->post("breakfast_w"),
								"thu" => $this->input->post("breakfast_th"),
								"fri" => $this->input->post("breakfast_f"),
								"sat" => $this->input->post("breakfast_st"),
								"sun" => $this->input->post("breakfast_su")
							);
			$lunch = array(
							"mon" => $this->input->post("lunch_m"),
							"tue" => $this->input->post("lunch_tu"),
							"wed" => $this->input->post("lunch_w"),
							"thu" => $this->input->post("lunch_th"),
							"fri" => $this->input->post("lunch_f"),
							"sat" => $this->input->post("lunch_st"),
							"sun" => $this->input->post("lunch_su")
						);
			$dinner = array(
							"mon" => $this->input->post("dinner_m"),
							"tue" => $this->input->post("dinner_tu"),
							"wed" => $this->input->post("dinner_w"),
							"thu" => $this->input->post("dinner_th"),
							"fri" => $this->input->post("dinner_f"),
							"sat" => $this->input->post("dinner_st"),
							"sun" => $this->input->post("dinner_su")
						);

			$date = date("Y-m-d H:i:s");
			$winery = array(
								"pid" => $this->input->post("postid"),
								"winery_img" => (isset($image_data[0]["file_name"]) ? $image_data[0]["file_name"] : ""),
								"menus" => $this->input->post("menu"),
								"menu_img" => (isset($image_data[1]["file_name"]) ? $image_data[1]["file_name"] : ""),
								"breakfast" => serialize($breakfast),
								"lunch" => serialize($lunch),
								"dinner" => serialize($dinner),
								"date" => $date,
								"ip" => $this->input->ip_address()
							);
			$postlink = $this->input->post("link");
			if($this->crudmodel->addwineryinfo($winery)) {
				//<script> //alert("success");</script>
				redirect($postlink);
			}
		}
	 }

	function _getseo($seo) {

		$seo = $this->_makeslugs($seo);

		$duplicaterecipe = $this->crudmodel->getrecipe(array("seo" => $seo));

		if(empty($duplicaterecipe)) {
			return $seo;
		}
		else {
			return $this->_getnewseo($seo);
		}
	}

	function _getnewseo($seo) {
		$newseo = $seo."-".$this->_getuniquekey();
		$duplicaterecipe = $this->crudmodel->getrecipe(array("seo" => $newseo));
		if(empty($duplicaterecipe)) {
			return $newseo;
		}
		else {
			return $this->_getnewseo($seo);
		}
	}

	function _getuniquekey() {
		$this->load->helper("string");
	    return random_string("numeric", 8);
	}

	function _makeslugs($string, $maxlen = 0) {
  		$newStringTab = array();
      	$string = strtolower($this->_nodiacritics($string));
      	if(function_exists("str_split")) {
     		$stringTab=str_split($string);
		}
      	else {
     		$stringTab = $this->_mystrsplit($string);
		}

      	$numbers=array("0","1","2","3","4","5","6","7","8","9","-");
      	//$numbers=array("0","1","2","3","4","5","6","7","8","9");

      	foreach($stringTab as $letter) {
     		if(in_array($letter, range("a", "z")) || in_array($letter, $numbers)) {
        		$newStringTab[]=$letter;
            	//print($letter);
         	}
         	elseif($letter == " ") {
        		$newStringTab[] = "-";
			}
      	}

      	if(count($newStringTab)) {
     		$newString = implode($newStringTab);
         	if($maxlen > 0) {
            	$newString = substr($newString, 0, $maxlen);
			}

 			$newString = $this->_removeduplicates('--', '-', $newString);
		}
      	else {
     		$newString='';
		}

  		return $newString;
	}

	function _nodiacritics($string) {
		//cyrylic transcription
      	$cyrylicFrom = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я');
      	$cyrylicTo = array('A', 'B', 'W', 'G', 'D', 'Ie', 'Io', 'Z', 'Z', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'Ch', 'C', 'Tch', 'Sh', 'Shtch', '', 'Y', '', 'E', 'Iu', 'Ia', 'a', 'b', 'w', 'g', 'd', 'ie', 'io', 'z', 'z', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'ch', 'c', 'tch', 'sh', 'shtch', '', 'y', '', 'e', 'iu', 'ia');

		$from = array("Á", "À", "Â", "Ä", "Ă", "Ā", "Ã", "Å", "Ą", "Æ", "Ć", "Ċ", "Ĉ", "Č", "Ç", "Ď", "Đ", "Ð", "É", "È", "Ė", "Ê", "Ë", "Ě", "Ē", "Ę", "Ə", "Ġ", "Ĝ", "Ğ", "Ģ", "á", "à", "â", "ä", "ă", "ā", "ã", "å", "ą", "æ", "ć", "ċ", "ĉ", "č", "ç", "ď", "đ", "ð", "é", "è", "ė", "ê", "ë", "ě", "ē", "ę", "ə", "ġ", "ĝ", "ğ", "ģ", "Ĥ", "Ħ", "I", "Í", "Ì", "İ", "Î", "Ï", "Ī", "Į", "Ĳ", "Ĵ", "Ķ", "Ļ", "Ł", "Ń", "Ň", "Ñ", "Ņ", "Ó", "Ò", "Ô", "Ö", "Õ", "Ő", "Ø", "Ơ", "Œ", "ĥ", "ħ", "ı", "í", "ì", "i", "î", "ï", "ī", "į", "ĳ", "ĵ", "ķ", "ļ", "ł", "ń", "ň", "ñ", "ņ", "ó", "ò", "ô", "ö", "õ", "ő", "ø", "ơ", "œ", "Ŕ", "Ř", "Ś", "Ŝ", "Š", "Ş", "Ť", "Ţ", "Þ", "Ú", "Ù", "Û", "Ü", "Ŭ", "Ū", "Ů", "Ų", "Ű", "Ư", "Ŵ", "Ý", "Ŷ", "Ÿ", "Ź", "Ż", "Ž", "ŕ", "ř", "ś", "ŝ", "š", "ş", "ß", "ť", "ţ", "þ", "ú", "ù", "û", "ü", "ŭ", "ū", "ů", "ų", "ű", "ư", "ŵ", "ý", "ŷ", "ÿ", "ź", "ż", "ž");
      	$to = array("A", "A", "A", "A", "A", "A", "A", "A", "A", "AE", "C", "C", "C", "C", "C", "D", "D", "D", "E", "E", "E", "E", "E", "E", "E", "E", "G", "G", "G", "G", "G", "a", "a", "a", "a", "a", "a", "a", "a", "a", "ae", "c", "c", "c", "c", "c", "d", "d", "d", "e", "e", "e", "e", "e", "e", "e", "e", "g", "g", "g", "g", "g", "H", "H", "I", "I", "I", "I", "I", "I", "I", "I", "IJ", "J", "K", "L", "L", "N", "N", "N", "N", "O", "O", "O", "O", "O", "O", "O", "O", "CE", "h", "h", "i", "i", "i", "i", "i", "i", "i", "i", "ij", "j", "k", "l", "l", "n", "n", "n", "n", "o", "o", "o", "o", "o", "o", "o", "o", "o", "R", "R", "S", "S", "S", "S", "T", "T", "T", "U", "U", "U", "U", "U", "U", "U", "U", "U", "U", "W", "Y", "Y", "Y", "Z", "Z", "Z", "r", "r", "s", "s", "s", "s", "B", "t", "t", "b", "u", "u", "u", "u", "u", "u", "u", "u", "u", "u", "w", "y", "y", "y", "z", "z", "z");

      	$from = array_merge($from, $cyrylicFrom);
		$to = array_merge($to, $cyrylicTo);

      $newstring = str_replace($from, $to, $string);
      return $newstring;
   	}

	function _mystrsplit($string) {
  		$slen = strlen($string);
  		for($i = 0; $i < $slen; $i++) {
     		$sArray[$i] = $string{$i};
		}
      	return $sArray;
	}

	function _removeduplicates($sSearch, $sReplace, $sSubject) {
		$i = 0;
      	do {
     		$sSubject = str_replace($sSearch, $sReplace, $sSubject);
			$pos = strpos($sSubject, $sSearch);
			$i++;
			if($i > 100) {
            	die('removeduplicates() loop error');
			}
      	}
      	while($pos !== false);
		return $sSubject;
	}
	/**
	 * function to import data from csv file to restaurants and winery database tables
	 **/
	function importcsv_countries(){
		$this->load->model("restaurants/restaurantmodel","restmodel");
		$data["page"] = "pages/countriescsvupload";
		$this->load->view("template/template", $data);
	}

}

?>