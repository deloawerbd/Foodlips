<?php

/* ======This controller is only used for Wineries Site ====== */

class Wineries extends Controller {

    function Wineries() {

        parent::Controller();
        $this->load->helper("url");

        $this->load->model("crudmodel");
        $this->load->model("communitymodel");
        $this->load->model("wineries/winemodel");
        $this->load->model("restaurants/restaurantmodel", "restmodel");
    }

    function index() {
        $this->load->view('wineries/wineries_view.php');
    }

    /**
     * Here we are checking country name and and display Wineries as per country
     */
    function country() {

        $countryarray = array("United-States", "Argentina", "Brazil", "Australia", "New-Zealand", "Germany", "Italy", "Portugal", "France", "Spain", "South-Africa", "Chile");

        $this->load->library("pagination");
        $next_page_no_of_recs_for_api = 0;
        $next_page_no_of_recs_for_api = 1;
        $rec_per_page = 0;
        $rec_per_page = 10;

        $config["uri_segment"] = 3;
        $config['num_links'] = 1;
        $config["per_page"] = $rec_per_page;
        $config["full_tag_open"] = "<p>";
        $config["full_tag_close"] = "</p>";
        $config["cur_tag_open"] = "<b class='current'>";
        $config["cur_tag_close"] = "</b>";
        $config["next_link"] = "&gt";
        $config["prev_link"] = "&lt";

        $fields = "id,categoryid,title,seo,images,price,content";

        if ($this->uri->segment('2') != "" && in_array($this->uri->segment('2'), $countryarray)) {
            $segment2 = $this->uri->segment('2');
        } else {
            $segment2 = "Australia";
        }
        $parameter = array();
        if (strpos($segment2, '-') !== false) {

            $country = explode('-', $segment2);
            $data["countryname"] = $country[0] . " " . $country[1];
        } else {
            $data["countryname"] = $segment2;
        }

        if (isset($data["countryname"]) && !empty($data["countryname"])) {
            $countryrow = $this->restmodel->getcountry(array("name" => $data["countryname"]));
            $parameter["countryid"] = $countryrow->id;
        }
        $where = array("countryid" => $parameter["countryid"], "iscapitalcity" => "1");
        $cities = $this->restmodel->getcitieswhere($where);
        //if(!empty($cities)){
        if (!empty($cities) && count($_SERVER['REQUEST_URI']) == 1) {
            $capitalcity = $cities[0]->name;
            $capitalstate = $this->restmodel->getstatesbycountryid(array("id" => $cities[0]->stateid));
            $address = $capitalcity . "," . $capitalstate[0]->state_name . "," . $data["countryname"];

            $data["searchstate"] = $capitalstate[0]->state_name;
            $where = array("stateid" => $capitalstate[0]->id);
            $data['cities'] = $this->restmodel->getcitieswhere($where);
            $data["searchcity"] = $capitalcity;
        }
        /*
          $data["searchstate"] = -1;
          $data["searchcity"] = -1;
          $data["searchcuisine"] = -1;
          $data["searchfeature"] = -1;
          $data["searchprice"] = -1;
          $parameter["cuisineid"] = 0;
          $parameter["featureid"] = 0;
          $parameter["price"] = 0;
         */
        $keyword = "";
        $searchfeature = "";
        $url = parse_url($_SERVER['REQUEST_URI']);
        if (isset($url["query"]) && !empty($url["query"])) {
            $data["hideslider"] = "1";
            parse_str($url["query"], $query);
            if (isset($query["keyword"]) && !empty($query["keyword"])) {
                $keyword = $query["keyword"];
                $data["searchkeyword"] = $query["keyword"];
            }
            if (isset($query["state"]) && !empty($query["state"])) {
                $address = $query["state"] . "," . $data["countryname"];
                $stateid = $this->restmodel->getstateidbyname(array("state_name" => $query["state"]));
                $parameter["stateid"] = $stateid;
                $data["searchstate"] = $query["state"];
                $searchstate = $query["state"];
            }

            if (isset($query["city"]) && !empty($query["city"])) {
                $address = $query["city"] . "," . @$address;
                $cityrow = $this->restmodel->getcitieswhere(array("name" => $query["city"]));
                $parameter["cityid"] = $cityrow[0]->id;
                $data["searchcity"] = $query["city"];
            }


            if (isset($query["cuisine"]) && !empty($query["cuisine"])) {
                $parameter["cuisineid"] = $query["cuisine"];
                $data["searchcuisine"] = $query["cuisine"];
            }


            if (isset($query["feature"]) && !empty($query["feature"])) {
                //$parameter["featureid"] = $query["feature"];
                $searchfeature = '"' . $query["feature"] . '"';
                $data["searchfeature"] = $query["feature"];
            }



            if (isset($query["price"]) && !empty($query["price"])) {
                $parameter["price"] = $query["price"];
                $data["searchprice"] = $query["price"];
            }
        }
        $data["country"] = $this->winemodel->getcountry(array("name" => $data["countryname"]));



        $config["base_url"] = base_url() . '/wineries/' . str_replace(' ', '-', $data["countryname"]) . '/';

        $page = $this->uri->segment(3, 0);
        $page = explode("=", $page);
        if (is_array($page) && count($page) > 1) {
            $page = $page[1];

            if (empty($page)) {
                $page = 0;
            }
        }

        if (is_array($page)) {
            $page = 0;
        }

        $pagesfordb = 0;
        $total_rows = 0;
        $limitforapi = 0;
        $offset = 0;

        $where = array();
        $where = array("countryid" => $data["country"]->id);

        $total_rows = count($this->_getwineriesformdbpagination($fields, $parameter, $keyword, $searchfeature, "", "", null));

        $pagesfordb = $total_rows;
        {
            if (($total_rows < ($page + $rec_per_page)) && ($pagesfordb > 0)) {
                $total_rows = $total_rows + (($page + $rec_per_page) - $total_rows);
            } else {
                $total_rows = $page + $rec_per_page;
            }
            //$total_rows = $total_rows + ($rec_per_page * 2);
            $total_rows = $total_rows + $next_page_no_of_recs_for_api;
        }
        //$config["total_rows"] = $total_rows; 
        //$this->pagination->initialize($config);

        $limit = array('start' => $config['per_page'], 'end' => $page);

        $order_by = "";
        $order = "";

        $wineriesfromdb = array();
        $wineriesfromapi = array();

        if ($page <= $pagesfordb) {
            $wineriesfromdb = $this->_getwineriesformdbpagination($fields, $parameter, $keyword, $searchfeature, $order_by, $order, $limit);
        }

        if ($pagesfordb > 0) {
            if (($page + $rec_per_page) >= $pagesfordb) {
                if (($page + $rec_per_page - $pagesfordb) < $rec_per_page) {
                    $limitforapi = ($rec_per_page - ($pagesfordb - $page));
                    $offset = 0;
                } else {
                    $offset = ($page - $pagesfordb);
                    $limitforapi = $rec_per_page;
                }

                $wineriesfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $limitforapi, $offset);
                $total_rows = $total_rows - ($limitforapi - count($wineriesfromapi));

                $wineriesfromapicount = count($this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $next_page_no_of_recs_for_api, (count($wineriesfromapi) + $offset)));

                if ($wineriesfromapicount == 0) {
                    $total_rows = $total_rows - 1;
                }
            }
        } else {
            $offset = $page;
            $limitforapi = $rec_per_page;

            $wineriesfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $limitforapi, $offset);
            $total_rows = $total_rows - ($limitforapi - count($wineriesfromapi));

            $wineriesfromapicount = count($this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"], $parameter, $keyword, $searchfeature, NULL, $next_page_no_of_recs_for_api, (count($wineriesfromapi) + $offset)));

            if ($wineriesfromapicount == 0) {
                $total_rows = $total_rows - 1;
            }
        }

        $config["total_rows"] = $total_rows;

        $this->pagination->initialize($config);


        $wineries = array();
        $wineryarray = array();
        if (!empty($wineriesfromdb)) {

            foreach ($wineriesfromdb as $winery) {

                $wineryarray["from"] = "db";

                $wineryarray["title"] = $winery->title;
                $wineryarray["res_link"] = $winery->seo;
                $wineryarray["content"] = $winery->content;

                $images = unserialize($winery->images);
                $wineryarray["image"] = "winedefault.jpg";
                if (!empty($images)) {
                    $wineryarray["image"] = $images[0];
                }


                $wineryarray["price"] = "";
                $wineryarray["category"] = "";

                $where = array("id" => $winery->price);
                $res = $this->winemodel->getprices($where);
                if (!empty($res)) {
                    $wineryarray["price"] = $res->name;
                }
                $where = array("id" => $winery->categoryid);
                $res = $this->winemodel->getcategorybyid($where);
                if (!empty($res)) {
                    $wineryarray["category"] = $res->name;
                }
                //to get the likes
                $where = array("wid" => $winery->id,
                    "liked" => "1"
                );
                $like = $this->winemodel->countlike($where);
                $where = array("wid" => $winery->id);
                $total_like = $this->winemodel->countlike($where);
                if ($like && $total_like) {
                    $wineryarray["calculated_likes"] = ($like * 10) / $total_like;
                } else {
                    $wineryarray["calculated_likes"] = 0;
                }
                $wineries[] = (object) $wineryarray;
            }
        }

        $markers = array();
        $markersarray = array();
        if (!empty($wineriesfromapi)) {
            foreach ($wineriesfromapi as $venue) {
                if (!empty($keyword) || !empty($searchfeature)) {
                    if (isset($venue->location->lat) && property_exists($venue->location, "lat")) {
                        $markers["position"] = $venue->location->lat . "," . $venue->location->lng;
                    }
                } else {
                    if (isset($venue->venue->location->lat) && property_exists($venue->venue->location, "lat")) {
                        $markers["position"] = $venue->venue->location->lat . "," . $venue->venue->location->lng;
                    }
                }

                if (!empty($keyword) || !empty($searchfeature)) {
                    $markers["id"] = isset($venue->id) ? $venue->id : "";
                    $markers["name"] = isset($venue->name) ? $venue->name : "No Name";
                } else {
                    $markers["id"] = isset($venue->venue->id) ? $venue->venue->id : "";
                    $markers["name"] = isset($venue->venue->name) ? $venue->venue->name : "No Name";
                }

                if (!empty($keyword) || !empty($searchfeature)) {
                    if (isset($venue->categories->icon) && !empty($venue->categories->icon)) {
                        $markers["image"] = $venue->categories->icon->prefix . $venue->categories->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/home/100x100/Restaurantdefault.jpg";
                    }
                    if (!empty($venue->respnse->venues->categories)) {
                        if (property_exists($venue->response->venues->categories['0'], "name")) {
                            $markers["type"] = $venue->response->venues->categories['0']->name;
                        }
                    }
                } else {
                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $markers["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/home/100x100/Restaurantdefault.jpg";
                    }
                    if (!empty($venue->venue->price) && property_exists($venue->venue, "price")) {
                        $markers["price"] = $venue->venue->price->message;
                    }
                    if (!empty($venue->venue->categories)) {
                        if (property_exists($venue->venue->categories['0'], "name")) {
                            $markers["type"] = $venue->venue->categories['0']->name;
                        }
                    }
                }
                //push markers details into array 
                $markersarray[] = (object) $markers;

                $wineryarray["from"] = "api";

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    $wineryarray["title"] = !empty($venue->name) ? $venue->name : "No Name";
                    $wineryarray["res_link"] = ("venue/" . $venue->id);
                    $wineryarray["content"] = "";
                } else {
                    $wineryarray["title"] = !empty($venue->venue->name) ? $venue->venue->name : "No Name";
                    if (!empty($venue->venue->name)) {
                        $specialchars = array("'", "|", "%", ",", "!", "@", "$", "^", "*", "&", "-", "#", "?", "/", "-");
                        $titleforurl = str_replace($specialchars, "", $venue->venue->name);
                        $titleforurl = preg_replace('/\s+/', '_', $titleforurl);
                    }
                    //print_r($titleforurl);
                    //echo"<br>";
                    $titleforurl = filter_var($titleforurl, FILTER_SANITIZE_URL);
                    if (isset($venue->venue->price->message) && $venue->venue->price->message == "Very Expensive") {
                        $priceappend = "-ve";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Expensive") {
                        $priceappend = "-e";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Moderate") {
                        $priceappend = "-m";
                    } elseif (isset($venue->venue->price->message) && $venue->venue->price->message == "Cheap") {
                        $priceappend = "-c";
                    } else {
                        $priceappend = "";
                    }
                    $wineryarray["res_link"] = !empty($venue->venue->id) ? ("venue/" . $titleforurl . "-" . $venue->venue->id . $priceappend) : "";
                    //$wineryarray["res_link"] = !empty($venue->venue->id)?("venue/" . $venue->venue->id):"";
                    $wineryarray["content"] = "";
                }

                // $wineryarray["title"] = !empty($venue->venue->name) ? $venue->venue->name : "No Name";
                // $wineryarray["res_link"] = ("venue/" . $venue->venue->id);
                // $wineryarray["content"] = "";

                $wineryarray["image"] = base_url() . "public/frontend/images/wineries/100x100/winedefault.jpg";

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    //Fouresquare Api Integration
                    $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
                    $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";
                    // Load the Foursquare API library
                    $config = array(
                        "client_id" => $client_key,
                        "client_secret" => $client_secret
                    );
                    $this->load->library("foursquareapi", $config);
                    $venueId = $venue->id;
                    $image_response = $this->foursquareapi->GetPublic("venues/$venueId/photos");
                    $venue_image = json_decode($image_response);
                    if (!empty($venue_image->response->photos->items[0]->suffix) && !empty($venue_image->response->photos->items[0]->prefix)) {
                        //echo"<pre>";
                        //print_r($venue_image);exit;
                        //print_r($venue_image->response->photos->items[0]->prefix.$venue_image->response->photos->items[0]->suffix);exit;
                        $wineryarray["image"] = $venue_image->response->photos->items[0]->prefix . "100x100" . $venue_image->response->photos->items[0]->suffix;
                    }
                    //$response_image = $response_image->photos->items;
                    //print_r($venue->categories[0]->icon);exit;
                    // if(isset($venue->categories[0]->icon) && !empty($venue->categories[0]->icon)) {
                    // print_r($this->foursquareapi->GetPublic("venues/photos"));exit;
                    // $image_venues = json_decode($imageresponse);
                    // print_r($image_response);exit;
                    // $images = "https://api.foursquare.com/v2/venues/".$venue->id."/photos";
                    // $restaurantarray["image"] = "https://api.foursquare.com/v2/venues/".$venue->id."/photos";
                    // //$restaurantarray["image"] = $venue->categories[0]->icon->prefix.$venue->categories[0]->icon->suffix;
                    // print_r($restaurantarray["image"]);exit;
                    // }		
                } else {
                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $wineryarray["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    }
                }

                // if(isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                // $wineryarray["image"] = $venue->venue->photos->groups[0]->items[0]->prefix."100x100".$venue->venue->photos->groups[0]->items[0]->suffix;
                // }

                $wineryarray["price"] = "";
                $wineryarray["category"] = "";

                if (($keyword == "vit") || ($searchfeature == "vit")) {
                    if (!empty($venue->categories) && property_exists($venue->categories['0'], "name")) {
                        $wineryarray["category"] = $venue->categories['0']->name;
                    }
                } else {
                    if (!empty($venue->venue->price) && property_exists($venue->venue, "price")) {
                        $wineryarray["price"] = $venue->venue->price->message;
                    }
                    if (!empty($venue->venue->categories) && property_exists($venue->venue->categories['0'], "name")) {
                        $wineryarray["category"] = $venue->venue->categories['0']->name;
                    }
                }

                // if(!empty($venue->venue->price) && property_exists($venue->venue,"price")){
                // $wineryarray["price"] = $venue->venue->price->message;
                // }
                // //if(property_exists($venue->venue->categories['0'],"name")){
                // if(!empty($venue->venue->categories['0']) && property_exists($venue->venue->categories['0'],"name")){
                // $wineryarray["category"] = $venue->venue->categories['0']->name;
                // }
                //to get the likes
                $restaurantarray["calculated_likes"] = "";
                $venueid = $venue->venue->id;
                if (isset($venueid) && !empty($venueid)) {
                    $where = array("wid" => $venueid,
                        "liked" => "1"
                    );
                    $like = $this->winemodel->countlike($where);
                    $where = array("wid" => $venueid);
                    $total_like = $this->winemodel->countlike($where);
                    if ($like && $total_like) {
                        $wineryarray["calculated_likes"] = ($like * 10) / $total_like;
                    } else {
                        $wineryarray["calculated_likes"] = 0;
                    }
                }
                $wineries[] = (object) $wineryarray;
            }
        }

        $data["wineries"] = $wineries;

        $data["pagination_links"] = $this->pagination->create_links();
        $data["venues"] = $this->_getfoursquarevenus(isset($address) ? $address : $data["countryname"], NULL, NULL);
        $where = array("country_id" => $data["country"]->id);

        $data['states'] = $this->restmodel->getstatesbycountryid($where);
        if (!empty($searchstate)) {
            $where = array("state_name" => $searchstate);
            $stateid = $this->restmodel->getstateidbyname($where);
            $where = array("stateid" => $stateid);
            $data['cities'] = $this->restmodel->getcitieswhere($where);
        }
        // not sorted by states insufficiant data
        //$data['cities'] = $this->restmodel->getcities();
        $data['cuisines'] = $this->winemodel->getcuisines(NULL);
        $data['features'] = $this->winemodel->getfeatures();
        $data['prices'] = $this->winemodel->getprices(NULL);

        $data['countrymap'] = $this->_getcoutrymap($data["countryname"], $markersarray);

        $data["page"] = "wineries/home";
        $this->load->view("template/templaterestaurant", $data);

        // }else{
        // $data["countryname"] = "Australia";
// 
        // $config["base_url"] = base_url().'/wineries/'.$data["countryname"].'/';
// 
        // $page = $this->uri->segment(3,0);
        // $page = explode("=",$page);
        // if(is_array($page) && count($page) > 1) {
        // $page = $page[1];
        // }
        // if(is_array($page)) {
        // $page = 0;
        // }
// 			
        // $pagesfordb = 0; 
        // $total_rows = 0;
        // $limitforapi = 0;
        // $offset = 0;
// 			
        // $where = array();
        // if(!empty($data["countryname"])){
        // $countryrow = $this->winemodel->getcountry(array("name" => $data["countryname"]));
        // $where = array("countryid" => $countryrow->id); 
        // }
// 			
        // $total_rows = $this->winemodel->getwineriesdetailcountforpagination($fields,$where); 
// 			
        // $pagesfordb = $total_rows;
// 			
        // if($total_rows <= ($page + $rec_per_page))
        // {
        // if(($total_rows < ($page + $rec_per_page)) && ($pagesfordb > 0))
        // {
        // $total_rows = $total_rows + (($page + $rec_per_page) - $total_rows);
        // }
        // $total_rows = $total_rows + ($rec_per_page * 2);
        // }
        // $config["total_rows"] = $total_rows;
// 			
        // $this->pagination->initialize($config);
// 	
        // $limit = array('start'=>$config['per_page'], 'end'=>$page);
// 			
        // $order_by = "";
        // $order = "";
// 			
        // $wineriesfromdb = array();
        // $wineriesfromapi = array();
// 						
        // if(($page <= $pagesfordb) && ($pagesfordb > 0))
        // {
        // $wineriesfromdb = $this->_getwineriesformdbpagination($fields,$data["countryname"],$order_by,$order,$limit);
        // }
// 			
        // if($pagesfordb > 0)
        // {
        // if(($page + $rec_per_page)  >= $pagesfordb)
        // {
        // if(($page + $rec_per_page - $pagesfordb) < $rec_per_page)
        // {
        // $limitforapi = ($rec_per_page - ($pagesfordb - $page));
        // $offset = 0;			
        // }
        // else
        // {
        // $offset = ($page - $pagesfordb);
        // $limitforapi = $rec_per_page;
        // }
// 
        // $wineriesfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"],NULL,NULL,$limitforapi,$offset);
        // }
        // }
        // else
        // {
        // $offset = $page;
        // $limitforapi = $rec_per_page;
// 				
        // $wineriesfromapi = $this->_getfoursquarevenusForPagination(isset($address) ? $address : $data["countryname"],NULL,NULL,$limitforapi,$offset);
// 				
        // }
// 			
        // $wineries = array();
        // $wineryarray = array();
        // if(!empty($wineriesfromdb)){
//                 
        // foreach($wineriesfromdb as $winery){
//                 	                    
        // $wineryarray["from"] = "db"; 
//                     
        // $wineryarray["title"] = $winery->title;
        // $wineryarray["res_link"] = $winery->seo;
        // $wineryarray["content"] = $winery->content;
//                     
        // $images = unserialize($winery->images);
        // $wineryarray["image"] = "winedefault.jpg";
        // if(!empty($images))
        // {
        // $wineryarray["image"] = $images[0];
        // }
// 
// 
        // $wineryarray["price"] = "";
        // $wineryarray["category"] = "";
//                                         
        // $where = array("id" => $winery->price);
        // $res = $this->winemodel->getprices($where);
        // if(!empty($res))
        // {
        // $wineryarray["price"] = $res->name;
        // }
        // $where = array("id" => $winery->categoryid);
        // $res = $this->winemodel->getcategorybyid($where);
        // if(!empty($res))
        // {
        // $wineryarray["category"] = $res->name;
        // }
//                   
        // $wineries[] = (object) $wineryarray;
// 
        // }
        // }
// 			
// //			$data["venues"] = $this->_getfoursquarevenus("Australia",NULL,NULL);
// 			
        // // create markers array
        // $markers = array();
        // $markersarray = array();
        // if(!empty($wineriesfromapi)){
        // foreach($wineriesfromapi as $venue){
        // if(property_exists($venue->venue->location,"lat")){
        // $markers["position"] = $venue->venue->location->lat.",".$venue->venue->location->lng;
        // }
        // $markers["id"] = isset($venue->venue->id) ? $venue->venue->id : "";
        // $markers["name"] = isset($venue->venue->name) ? $venue->venue->name : "No Name";
// 					
        // if(isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
        // $markers["image"] = $venue->venue->photos->groups[0]->items[0]->prefix."100x100".$venue->venue->photos->groups[0]->items[0]->suffix;
        // }else{
        // $markers["image"] = base_url()."public/frontend/images/wineries/100x100/winedefault.jpg";
        // }
        // if(property_exists($venue->venue,"price")){
        // $markers["price"] = $venue->venue->price->message;
        // }
        // if(property_exists($venue->venue->categories['0'],"name")){
        // $markers["type"] = $venue->venue->categories['0']->name;
        // }
        // //push markers details into array 
        // $markersarray[] = (object) $markers;
// 					
        // $wineryarray["from"] = "api";
//                     
        // $wineryarray["title"] = !empty($venue->venue->name) ? $venue->venue->name : "No Name";
        // $wineryarray["res_link"] = ("venue/" . $venue->venue->id);
        // $wineryarray["content"] = "";
//                     
        // $wineryarray["image"] = base_url()."public/frontend/images/wineries/100x100/winedefault.jpg";
        // if(isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
        // $wineryarray["image"] = $venue->venue->photos->groups[0]->items[0]->prefix."100x100".$venue->venue->photos->groups[0]->items[0]->suffix;
        // }
//                     
        // $wineryarray["price"] = "";
        // $wineryarray["category"] = "";
        // if(property_exists($venue->venue,"price")){
        // $wineryarray["price"] = $venue->venue->price->message;
        // }
        // if(property_exists($venue->venue->categories['0'],"name")){
        // $wineryarray["category"] = $venue->venue->categories['0']->name;
        // }					
//                     
        // $wineries[] = (object) $wineryarray;
        // }
        // }
// 
        // $data["wineries"] = $wineries;
// 			
        // $data["pagination_links"]= $this->pagination->create_links();
// 			
        // $data["country"] = $this->winemodel->getcountry(array("name"=> $data["countryname"]));
// 			
        // $where = array("country_id" => $data["country"]->id);
        // $data['states'] = $this->restmodel->getstatesbycountryid($where);
        // // not sorted by states insufficiant data
        // //$data['cities'] = $this->restmodel->getcities();
        // $data['cuisines'] = $this->restmodel->getcuisines(NULL);
        // $data['features'] = $this->restmodel->getfeatures();
        // $data['prices'] = $this->restmodel->getprices(NULL);
        // $data["venues"] = $this->_getfoursquarevenus(isset($address) ? $address : $data["countryname"],NULL,NULL);
        // $data['countrymap'] = $this->_getcoutrymap('Australia',$markersarray);
// 						
        // $data["page"] = "wineries/home";
        // $this->load->view("template/templaterestaurant", $data);
        // }
    }

    function index07072014() {
        // $this->load->library("pagination");
        // $config["base_url"] = base_url().wineries/index();
        // $config["uri_segment"] = 3;
        // $config["per_page"] = 5;
        // $config["full_tag_open"] = "<p>";
        // $config["full_tag_close"] = "</p>";
        // $config["cur_tag_open"] = "<b class='current'>";
        // $config["cur_tag_close"] = "</b>";
        // $config["next_link"] = "&gt";
        // $config["prev_link"] = "&lt";
        // $winecount = $this->winemodel->rowcount();
        // $venuecount = 
        // $config["total_rows"] =$winecount+$venuecount;
        // $this->pagination->initialize($config);

        $countryarray = array("United-States", "Argentina", "Brazil", "Australia", "New-Zealand", "Germany", "Italy", "Portugal", "France", "Spain", "South-Africa", "Chile");

        if ($this->uri->segment('2') != "" && in_array($this->uri->segment('2'), $countryarray)) {
            if (strpos($this->uri->segment('2'), '-') !== false) {

                $country = explode('-', $this->uri->segment('2'));
                $data["countryname"] = $country[0] . " " . $country[1];
            } else {
                $data["countryname"] = $this->uri->segment('2');
            }

            $url = parse_url($_SERVER['REQUEST_URI']);
            if (isset($url["query"]) && !empty($url["query"])) {

                parse_str($url["query"], $query);

                if (isset($query["state"]) && !empty($query["state"])) {
                    $address = $query["state"] . "," . $data["countryname"];
                }
                if (isset($query["city"]) && !empty($query["city"])) {
                    $address = $query["city"] . "," . @$address;
                }

                if (isset($query["cuisine"]) && !empty($query["cuisine"])) {
                    $parameter["cuisine"] = $query["cuisine"];
                } elseif (isset($query["feature"]) && !empty($query["feature"])) {
                    $parameter["feature"] = $query["feature"];
                } elseif (isset($query["price"]) && !empty($query["price"])) {
                    $parameter["price"] = $query["price"];
                }
            }
            $data["country"] = $this->restmodel->getcountry(array("name" => $data["countryname"]));
            $data["wineries"] = $this->_getwineriesformdb($data["countryname"]);
            $data["venues"] = $this->_getfoursquarevenus(isset($address) ? $address : $data["countryname"], NULL, NULL);
            // echo "<pre>";
            // print_r($data["wineries"]);exit;

            $markers = array();
            $markersarray = array();
            if (isset($data["venues"]) && !empty($data["venues"])) {
                foreach ($data["venues"] as $venue) {

                    if (isset($venue->location->lat) && property_exists($venue->venue->location, "lat")) {
                        $markers["position"] = $venue->venue->location->lat . "," . $venue->venue->location->lng;
                    }

                    $markers["id"] = isset($venue->venue->id) ? $venue->venue->id : "";
                    $markers["name"] = isset($venue->venue->name) ? $venue->venue->name : "No Name";

                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $markers["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/Restaurantdefault.jpg";
                    }
                    if (isset($venue->venue->price) && property_exists($venue->venue, "price")) {
                        $markers["price"] = $venue->venue->price->message;
                    }
                    if (property_exists($venue->venue->categories['0'], "name")) {
                        $markers["type"] = $venue->venue->categories['0']->name;
                    }
                    //push markers details into array 
                    $markersarray[] = (object) $markers;
                }
            }
            $where = array("country_id" => $data["country"]->id);

            $data['states'] = $this->restmodel->getstatesbycountryid($where);
            // not sorted by states insufficiant data
            $data['cities'] = $this->restmodel->getcities();

            //$data['cuisines'] = $this->restmodel->getcuisines(NULL);
            //$data['features'] = $this->restmodel->getfeatures();
            //$data['prices'] = $this->restmodel->getprices(NULL);

            $data['countrymap'] = $this->_getcoutrymap($data["countryname"], $markersarray);

            $data["page"] = "wineries/home07072014";
            $this->load->view("template/templaterestaurant", $data);
        } else {
            $data["countryname"] = "Australia";

            $data["venues"] = $this->_getfoursquarevenus("Australia", NULL, NULL);

            // create markers array
            $markers = array();
            $markersarray = array();
            if (isset($data["venues"]) && !empty($data["venues"])) {
                foreach ($data["venues"] as $venue) {
                    if (isset($venue->venue->location->lat) && property_exists($venue->venue->location, "lat")) {
                        $markers["position"] = $venue->venue->location->lat . "," . $venue->venue->location->lng;
                    }
                    $markers["id"] = isset($venue->venue->id) ? $venue->venue->id : "";
                    $markers["name"] = isset($venue->venue->name) ? $venue->venue->name : "No Name";

                    if (isset($venue->venue->photos->groups[0]->items[0]) && !empty($venue->venue->photos->groups[0]->items[0])) {
                        $markers["image"] = $venue->venue->photos->groups[0]->items[0]->prefix . "100x100" . $venue->venue->photos->groups[0]->items[0]->suffix;
                    } else {
                        $markers["image"] = base_url() . "public/frontend/images/restaurents/Restaurantdefault.jpg";
                    }
                    if (property_exists($venue->venue, "price")) {
                        $markers["price"] = $venue->venue->price->message;
                    }
                    if (property_exists($venue->venue->categories['0'], "name")) {
                        $markers["type"] = $venue->venue->categories['0']->name;
                    }
                    //push markers details into array 
                    $markersarray[] = (object) $markers;
                }
            }

            $data["country"] = $this->restmodel->getcountry(array("name" => $data["countryname"]));

            $where = array("country_id" => $data["country"]->id);
            $data['states'] = $this->restmodel->getstatesbycountryid($where);
            // not sorted by states insufficiant data
            $data['cities'] = $this->restmodel->getcities();
            //$data['cuisines'] = $this->restmodel->getcuisines(NULL);
            //$data['features'] = $this->restmodel->getfeatures();
            //$data['prices'] = $this->restmodel->getprices(NULL);

            $data['countrymap'] = $this->_getcoutrymap('Australia', $markersarray);

            $data["page"] = "wineries/home07072014";
            $this->load->view("template/templaterestaurant", $data);
        }
    }

    /**
     * Function to generate Google maps countrywise
     * @country: name of the country 
     * @markers : array of the marker with full address 
     */
    function _getcoutrymap($country, $markers = array()) {
        if (isset($country) && $country !== "") {

            // load maps library
            $this->load->library('googlemaps');
            $config['center'] = $country;
            $config['zoom'] = '4';
            $config['map_name'] = 'map_country';
            $config['map_div_id'] = 'map_canvas_country';
            $config['cluster'] = TRUE;

            $this->googlemaps->initialize($config);
            //print_r($markers);exit;
            if (isset($markers) && !empty($markers)) {
                foreach ($markers as $mark) {
                    //echo $mark->pos;
                    if (isset($marker["position"])) {
                        $marker["position"] = $mark->position;
                    }
                    $marker["icon"] = "http://chart.apis.google.com/chart?cht=mm&chs=24x32&chco=FFFFFF,008CFF,000000&ext=.png";
                    $marker['infowindow_content'] = $this->_markerpopup($mark);
                    $marker["animation"] = "DROP";
                    $this->googlemaps->add_marker($marker);
                }
            }

            $map = $this->googlemaps->create_map();
            return $map;
        }
    }

    /**
     * function to create popup window for google maps marker
     */
    function _markerpopup($marker) {

        $window = "<div class='marker_outerbox'>";
        $window .= "<div class='marker_imgbox'><img src='" . $marker->image . "'/></div>";
        $window .= "<div class='marker_content'>";
        $window .= "<h4><a target='_blank' href='" . base_url() . "winery/details/venue/" . $marker->id . "'>" . $marker->name . "</a></h4>";
        $window .= "<p>Type : " . @$marker->type . "</p>";
        $window .= "<p>Price : " . @$marker->price . "</p>";
        $window .= "</div>";
        $window .= "</div>";

        return $window;
    }

    /**
     * Function to get data from Foursqure API
     */
    function _getfoursquarevenus($country, $search, $venueid) {

        //Fouresquare Api Integration
        $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
        $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";

        // Load the Foursquare API library
        $config = array(
            "client_id" => $client_key,
            "client_secret" => $client_secret
        );

        $this->load->library("foursquareapi", $config);
        //$this->load->model("restaurants/restaurantmodel","restmodel");
        $address = explode(",", $country);
        //print_r(count($address));exit;
        if (count($address) == 3) {
            $where = array("name" => $address[0]);
            $city = $this->restmodel->getlatlng($where, "cities");

            if ($city[0]->latitude != "" && $city[0]->longitude != "") {
                $lat = $city[0]->latitude;
                $lng = $city[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);
                //$where = array("name" =>$address[0]);
                //$this->restmodel->addlatlng($data,$where,"cities");
            }
        } elseif (count($address) == 2) {

            $where = array("state_name" => $address[0]);
            $state = $this->restmodel->getlatlng($where, "state");

            if ($state[0]->latitude != "" && $state[0]->longitude != "") {
                $lat = $state[0]->latitude;
                $lng = $state[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;

                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);

                $where = array("state_name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "state");
            }
        } elseif (count($address) == 1) {

            $where = array("name" => $address[0]);
            $countries = $this->restmodel->getlatlng($where, "countries");
            //print_r($countries);exit;

            if ($countries[0]->latitude != "" && $countries[0]->longitude != "") {
                $lat = $countries[0]->latitude;
                $lng = $countries[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);

                $data = array("latitude" => $lat, "longitude" => $lng);
                $where = array("name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "countries");
            }
        }
        //bar and winery cat id  = 4bf58dd8d48988d14b941735  4d4b7105d754a06376d81259 
        // Prepare parameters
        /* 		
          $params = array(
          "ll" => "$lat,$lng",
          "llAcc" => "100",
          "radius"=>"100000",
          "categoryId"=>"4d4b7105d754a06376d81259,4bf58dd8d48988d14b941735",
          "venuePhotos" => 1,
          "sortByDistance" => 1,
          "limit" => 20
          );
         */
        $params = array(
            "ll" => "$lat,$lng",
            "llAcc" => "100",
            "radius" => "100000",
            "categoryId" => "4bf58dd8d48988d14b941735",
            "venuePhotos" => 1,
            "sortByDistance" => 1,
            "limit" => 20
        );

        // Perform a request to a public resource
        $response = $this->foursquareapi->GetPublic("venues/explore", $params);
        $venues = json_decode($response);
        // echo "cnt: ".$count = count($venues->response->groups[0]->items);
        // echo "<pre>";
        // print_r($venues);
        // exit;
        return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
    }

    function _getfoursquarevenusForPagination($country, $search, $keyword, $searchfeature, $venueid, $limit, $offset) {

        //Fouresquare Api Integration
        $client_key = "AEMK2ZNEZU2KM0VLIOKEVW0GJP0QCUBAYBE4RUMMDPCXOCGO";
        $client_secret = "P1DRIO1IZBM20F3P5LRRIG4SWC4JA0NISFEHQ3I2E5GJ5SGK";

        // Load the Foursquare API library
        $config = array(
            "client_id" => $client_key,
            "client_secret" => $client_secret
        );

        $this->load->library("foursquareapi", $config);
        //$this->load->model("restaurants/restaurantmodel","restmodel");

        $address = explode(",", $country);
        //print_r(count($address));exit;
        if (count($address) == 3) {

            $countryrow = $this->restmodel->getcountry(array("name" => $address[2]));
            $staterow = $this->restmodel->getstatesbycountryid(array("state_name" => $address[1]));

            $where = array("name" => $address[0], "stateid" => $staterow[0]->id, "countryid" => $countryrow->id);
            $city = $this->restmodel->getlatlng($where, "cities");

            if ($city[0]->latitude != "" && $city[0]->longitude != "") {
                $lat = $city[0]->latitude;
                $lng = $city[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);
                //$where = array("name" =>$address[0]);
                //$this->restmodel->addlatlng($data,$where,"cities");
            }
        } elseif (count($address) == 2) {

            $countryrow = $this->restmodel->getcountry(array("name" => $address[1]));
            $where = array("state_name" => $address[0], "country_id" => $countryrow->id);
            $state = $this->restmodel->getlatlng($where, "state");

            if ($state[0]->latitude != "" && $state[0]->longitude != "") {
                $lat = $state[0]->latitude;
                $lng = $state[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;

                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);
                $data = array("latitude" => $lat, "longitude" => $lng);

                $where = array("state_name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "state");
            }
        } elseif (count($address) == 1) {
            $where = array("name" => $address[0]);
            $countries = $this->restmodel->getlatlng($where, "countries");
            //print_r($countries);exit;

            if ($countries[0]->latitude != "" && $countries[0]->longitude != "") {
                $lat = $countries[0]->latitude;
                $lng = $countries[0]->longitude;
            } else {
                $data["location"] = array_key_exists("location", $_GET) ? $_GET['location'] : $country;
                // Generate a latitude/longitude pair using Google Maps API
                list($lat, $lng) = $this->foursquareapi->GeoLocate($country);

                $data = array("latitude" => $lat, "longitude" => $lng);
                $where = array("name" => $address[0]);
                $this->restmodel->addlatlng($data, $where, "countries");
            }
        }
        //bar and winery cat id  = 4bf58dd8d48988d14b941735  4d4b7105d754a06376d81259 
        // Prepare parameters
        /* 		
          $params = array(
          "ll" => "$lat,$lng",
          "llAcc" => "100",
          "radius"=>"100000",
          "categoryId"=>"4d4b7105d754a06376d81259,4bf58dd8d48988d14b941735",
          "venuePhotos" => 1,
          "sortByDistance" => 1,
          "limit" => 20
          );
         */

        $params = array(
            "ll" => "$lat,$lng",
            "llAcc" => "100000", //"100",
            "categoryId" => "4bf58dd8d48988d14b941735",
            "radius" => "100000",
            "venuePhotos" => 1,
            "sortByDistance" => 1,
            "limit" => $limit,
            "offset" => $offset,
            "intent" => "browse"
        );
        if (!empty($keyword)) {
            //print_r($keyword);exit;
            //$params["categoryId"] = "";
            $params["query"] = $keyword;
            $params["intent"] = "browse";
            //$params["intent"] = 'match';
        }
        if (!empty($searchfeature)) {
            //print_r($keyword);exit;
            $params["query"] = $searchfeature;
            $params["intent"] = "browse";
            //$params["intent"] = 'match';
            //$params["categoryId"] = "";
        }

        // Perform a request to a public resource
        if (!empty($keyword) || !empty($searchfeature)) {
            $response = $this->foursquareapi->GetPublic("venues/explore", $params);
            $venues = json_decode($response);
            return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
            //print_r($venues->response->venues);exit;
            //return isset($venues->response->venues) ? $venues->response->venues : "";
        } else {
            $response = $this->foursquareapi->GetPublic("venues/explore", $params);
            $venues = json_decode($response);
            return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
        }
        //$response = $this->foursquareapi->GetPublic("venues/explore",$params);
        //$venues = json_decode($response);
        // echo "cnt: ".$count = count($venues->response->groups[0]->items);
        // echo "<pre>";
        // print_r($venues);
        // exit;
        //return isset($venues->response->groups[0]->items) ? $venues->response->groups[0]->items : "";
    }

    /**
     * Function to get restaurants for our site database
     */
    function _getwineriesformdb($country) {
        if (isset($country) && !empty($country)) {
            $countryrow = $this->restmodel->getcountry(array("name" => $country));
            $parameters["countryid"] = $countryrow->id;
        }
        $url = parse_url($_SERVER['REQUEST_URI']);
        if (isset($url["query"]) && !empty($url["query"])) {
            parse_str($url["query"], $query);

            if (isset($query["state"]) && !empty($query["state"])) {
                $staterow = $this->restmodel->getstatesbycountryid(array("state_name" => trim($query["state"])));
                $parameters["stateid"] = $staterow[0]->id;
            }
            if (isset($query["city"]) && !empty($query["city"])) {
                $cityrow = $this->restmodel->getcitieswhere(array("name" => trim($query["city"])));
                $parameters["cityid"] = $cityrow[0]->id;
            }
            if (isset($query["cuisine"]) && !empty($query["cuisine"])) {
                $parameters["cuisineid"] = $query["cuisine"];
            }
            if (isset($query["feature"]) && !empty($query["feature"])) {
                //$parameter["feature"] = $query["feature"];
            }
            if (isset($query["price"]) && !empty($query["price"])) {
                $parameters["price"] = $query["price"];
            }
        }
        return $this->winemodel->getwineries($parameters);
    }

    function _getwineriesformdbpagination($fields, $parameters, $keyword, $feature, $order_by, $order, $limit) {
        $searchfeatures = "";
        if (!empty($keyword)) {
            $table = "rest_features";
            $results = $this->winemodel->searchFreeKeyword($keyword, $table);
            if ($results) {
                foreach ($results as $result) {
                    $searchfeatures[] = $result->id;
                }
            }
        }
        //print_r($searchfeatures);exit;
        return $this->winemodel->getwineriesdetailforpagination($fields, $parameters, $keyword, $searchfeatures, $feature, $order_by, $order, $limit);
    }

}

?>