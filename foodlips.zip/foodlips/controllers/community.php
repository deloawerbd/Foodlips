<?php

class Community extends Controller {
    
    function Community() {
        error_reporting(1);
        parent::Controller();

        $this->load->helper("url");
        $this->load->helper("form");
        $this->load->library("form_validation");

        if($this->uri->segment("2") != "share") {
            //$this->freakauth_light->check();
        }
        
        $this->load->model("crudmodel");
        $this->load->model("communitymodel");
		$this->load->model("restaurants/restaurantmodel","restmodel");
        //$this->load->model("cfunctions");
        
        //$this->output->enable_profiler(true);
    }
    
    
    function index() {
        $this->freakauth_light->check();
		
        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                    );

        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            //$this->db_session->set_userdata("image", $user->image);
            //$this->db_session->set_userdata("name", $user->name);
            
            if(empty($user->image)) {
                $updateuser = array(
                                    "image" => "noavatar.png"
                                );
                $this->communitymodel->updateuser($updateuser, $where);
                $user = $this->communitymodel->getuser($where);
            }
            
            $data = $this->_gettopboxcontent($user);

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["notifications"] = $this->_getnotifications();

            $where = array("uid" => $user->id);
            //$data["images"] = $this->communitymodel->getuserimages($where);

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
            
            $data["contacts"] = $this->communitymodel->getcontact($where);

            $data["followings"] = $this->communitymodel->getalluserfollowings($user->id);

            $data["shoppinglists"] = $this->crudmodel->getshoppinglistbyuserid($user->id);
            //$start = 0;
            $activities = $this->communitymodel->getlatestactivitiesbyuser($where);
            $newactivities = array();

            if(isset($activities) && $activities != "") {
                
                foreach ($activities as $activity) {
                    $array = (array) $activity;

                    $where = array(
                        "id" => $activity->uid
                    );
                    $activityuser = $this->communitymodel->getuser($where);

                    $userimg = "noavatar.png";

                    if(isset($activityuser) && $activityuser != "") {
                        $array["name"] = $activityuser->user_name;
                        if(!empty($activityuser->name)) {
                            $array["name"] = $activityuser->name;
                        }
                        $array["user_name"] = $activityuser->user_name;

                        if($activityuser->image != "") {
                            $userimg = $activityuser->image;
                        }
                    }
                    
                    $array["image"] = $userimg;
                    $array["content"] = $this->_getactivitycontent($activity->uid, $activity->content, $activity->info);

                    $where = array(
                                "aid" => $activity->id
                                );
                    $likes = $this->communitymodel->getactivitylikes($where);
                    $newlikes = array();
                    if(!empty($likes)) {
                        foreach($likes as $like) {
                            $likearray = (array) $like;

                            if($like->uid != $user->id) {
                                $where = array(
                                                "id" => $like->uid
                                            );
                                $likeuser = $this->communitymodel->getuser($where, "user_name, name");

                                if(!empty($likeuser)) {
                                    $likearray["name"] = $likeuser->user_name;
                                    if(!empty($likeuser->name)) {
                                        $likearray["name"] = $likeuser->name;
                                    }
                                }
                            }
                            else {
                                $likearray["isownerlike"] = true;
                            }
                            
                            $likeobject = (object) $likearray;
                            $newlikes[] = $likeobject;
                        }
                        
                        for($i = 0; $i < count($likes); $i++) {
                            $likes[$i] = $newlikes[$i];
                        }
                    }
                    
                    $array["likes"] = $likes;
                    $array["likescnt"] = count($likes);

                    $array["timeago"] = $this->_timeago($activity->date);

                    $where = array(
                        "aid" => $activity->id
                    );

                    $communitycomments = $this->communitymodel->getcommunitycomments($where);
                    $newcommunitycomments = array();

                    if(isset($communitycomments) && $communitycomments != "") {
                        foreach ($communitycomments as $communitycomment) {
                            $communityarray = (array) $communitycomment;
                            $communityarray["timeago"] = $this->_timeago($communitycomment->date);;

                            $communityobject = (object) $communityarray;
                            $newcommunitycomments[] = $communityobject;
                        }
                    }
                    
                    $array["communitycomments"] = $newcommunitycomments;

                    $object = (object) $array;

                    $newactivities[] = $object;
                }
    
                for($i = 0; $i < count($activities); $i++) {
                    $activities[$i] = $newactivities[$i];
                }
            }
    
            $data["activities"] = $activities;

            $data["made"] = $this->communitymodel->getallmadebyuserid($user->id,6);

            $data["favorites"] = $this->communitymodel->getallfavoriterecipesbyuserid($user->id,6);

            $data["favoriteblogs"] = $this->communitymodel->getallfavoriteblogsbyuserid($user->id);
			
			$this->load->model("wineries/winemodel");

            $data["favouritewineries"] = $this->communitymodel->getallfavouritewineriesbyuser($user->user_name, 6);
						
            $data["favoriterestaurants"] = $this->communitymodel->getallfavoriterestaurantbyuser($user->user_name);
                        			
            $data["outsiderecipes"] = $this->communitymodel->getalloutsiderecipesbyuserid($user->id);

            $data["onlinevideos"] = $this->communitymodel->getallonlinevideosbyuserid($user->id);
            
            $data["imagegallery"] = $this->communitymodel->getimagegallery($user->id, 2);
            
            $data["videogallery"] = $this->communitymodel->getvideogallery($user->id);

            $data["liqureandspirits"] = $this->communitymodel->getliqureandspiritsbyuserid($user->id);

            $data["drinkrecipes"] = $this->communitymodel->getalldrinkrecipesbyuserid($user->id);

            $data["commborecipes"] = $this->crudmodel->getrecipes();

            $data["winenbeers"] = $this->communitymodel->getallwinenbeerbyuserid($user->id);

            $data["recipereviews"] = $this->crudmodel->getrecipereviewsbyuserid($user->id);

            $data["usersonline"] = $this->_getonlineusers();

            $where = array(
                            "uid" => $user->id
                        );
            //$data["settings"] = $this->communitymodel->getsettings($where);

            $data["isowner"] = false;
            if($user->id == $this->db_session->userdata("id")) {
                $data["isowner"] = true;
                $data["types"] = $this->crudmodel->getalltypes();
                $data["courses"] = $this->crudmodel->getallcourses();
				$data["categories"] = $this->crudmodel->getallcategories();
         	}
            
            $data["admin"] = false;
            if($this->db_session->userdata('role') == "admin" || $this->db_session->userdata('role') == "superadmin")
            {
                $data["admin"] = true;
            }
             
            $data["user"] = $user;
            $data["isfriend"] = TRUE;
            
            $where = array('user_name'=>base64_encode($user->user_name));
            $data["membership"] = $this->communitymodel->getmembership($where);
								
            $data["page"] = "community/profile";
            $this->load->view("template/newtemplate", $data);
        }   
        else {
            redirect("community/newsfeed");
        }
    }
    
    /**
     * Function for the creation of the seo
     */
    function _createseo($postval) {
        $specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
        return $seo = strtolower(str_replace($specialchars, "-", $postval)."-".md5(time()));
    }
    
    function register() {
        $data["page"] = "community/registersuccess";
        $this->load->view("template/newtemplate", $data);
    }
    
    function share() {
        if ($this->uri->segment("2") == "share") {
            $link = explode("?",$_SERVER["REQUEST_URI"]);
            //echo "link: ".rawurldecode($link[1]);
            if(is_array($link) && !empty($link)) {
                $data["link"] = preg_replace("/u=/", "", rawurldecode($link[1]), 1);
                $this->load->view("community/share", $data);
            }
            else {
                redirect("community");
            }
        }
        else {
            redirect("community" );
        }
    }

    function logout() {

        $this->db->where(array("session_id" => $this->db_session->userdata("session_id")));
        $this->db->delete("ci_sessions");
        $this->db->limit("1");

        $siteurl = "https://www.foodlips.com/"; ?>
        
        <script type="text/javascript" src="<?=base_url(); ?>public/frontend/js/jquery-1.7.2.min.js"></script>
        <div class="container-fluid">
            <h3>Signing out please wait. You will be redirected in less then <b><span id="seconds">10</span></b> seconds.</h3>
        </div>
        <script type="text/javascript">
            var timeInterval = "";
            $("document").ready(function() {
                timeInterval = setInterval(startTimer, 1000);
                <? /* $("#commonLogout").load("<?=$siteurl;?>blog/logout.php", function() {
                    $("#commonLogout").load("<?=$siteurl;?>restaurants/logout.php", function() {
                        alert("done");
                    });
                }); */ ?>
                <? /* timeInterval = setInterval(startTimer, 1000);
                    //$("#blogLogout").load("<?=$siteurl;?>blog/logout.php");
                    //$("#restaurantLogout").load("<?=$siteurl;?>restaurants/logout.php"); */ ?>
    
                //$("someid").load("logout url here");
                $.post("<?=base_url();?>auth/logout", { }, function(data) {
                    //alert(data);
                })
                .error(function(err) { /* alert("Error occurred: " + err.responseText); */ })
                .complete(function() {
                    $.post("<?=$siteurl;?>blog/logout.php", { }, function(data) {
                    //alert(data);
                    })
                    .error(function(err) { /* alert("Error occurred: " + err.responseText); */ })
                    .complete(function() {
                        $.post("<?=$siteurl; ?>restaurants/logout.php", { }, function(data) {
                        //alert(data);
                        })
                        .error(function(err) { })
                        .complete(function() {
                            $.post("<?=$siteurl; ?>wineries/logout.php", { }, function(data) {
                            //alert(data);
                            })
                            .error(function(err) { })
                            .complete(function() {
                                window.location = "<?=base_url();?>";
                            });
                        });
                    });
               });
            });
            
            function startTimer() {
                var seconds = $("#seconds").text();

                if(seconds == 0) {
                    $("#seconds").text("");
                    $("#seconds").text("0");

                    clearInterval(timeInterval);
                }
                else {
                    seconds -= 1;
                    $("#seconds").text("");
                    $("#seconds").text(seconds);
                }
            }
       </script>
    <?php }

    /* function topmenu() {
    if($this->db_session->userdata("id") != "") {
    $this->load->view("community/template/topmenu");
    }
    } */
    
    function newlogin() {
        if ($this -> db_session -> userdata("id") == "") {
            $data["page"] = "newlogin";
            $this -> load -> view("template/newtemplate", $data);
        }
        else {
            redirect("community");
        }
    }
    
    /**
    * This function is used to get notification.
    * @return $data, an array of data.
    */
    function _getnotifications() {
        $where = array("uid" => $this -> db_session -> userdata("id"));

        $data["friendrequests"] = $this -> communitymodel -> getfriendrequests($where);

        return $data;
    }
    
    
    /**
    * This function is used to get top box content as well it gets data for groups, followers etc just to reduce database number of call.
    * @param $user.
    * @return $data, an array of data.
    */
    function _gettopboxcontent($user) {
        $data["likescount"] = $this -> crudmodel -> getlikecountbyuserid($user -> id);

        $data["recipes"] = $this -> communitymodel -> getallrecipesbyuserid($user -> id);
        $data["recipescount"] = $this -> communitymodel -> getrecipescountbyuserid($user -> id);

        $data["groups"] = $this->communitymodel->getallgroupsbyuserid($user->id,6);
		$where = array("uid" => $user->id);
		$groupsjoined = $this->communitymodel->getuserjoinedgroups($where);
		if(isset($groupsjoined) && !empty($groupsjoined)){
				
			$groupsjoined = unserialize($groupsjoined->groups);
			if(isset($groupsjoined) && !empty($groupsjoined)&&!empty($data["groups"]) && isset($data["groups"])){
				$data["groupsjoined"] = $this->communitymodel->getgroupwherein($groupsjoined);
				$data["groups"] = array_merge($data["groups"],$data["groupsjoined"]);
			}
		}else if(isset($groupjoined) && !empty($groupjoined)){
			$data["groups"] = $data["groupsjoined"];
		}
		
		/*foreach($groupsjoined as $gruopid){
			$where = array("id" => $gruopid);
			$data["groupsjoined"] = $this->communitymodel->getgroup($where);
		}*/
		
        /* $groups = $this->communitymodel->getallgroups();
        $counter = 0;
        if(isset($groups) && $groups != "") {
            foreach($groups as $group) {
                if($group->uid == $user->id) {
                    $counter++;
                }
                else if($group->visibility == "1") {
                    if($group->members != "") {
                        $member = unserialize($group->members);
                        if(isset($member) && $member!= "") {
                            if(in_array($user->id, $member)) {
                              $counter++;
                            }
                        }
                    }
                }
                else {
                    if($group->members != "") {
                        $member = unserialize($group->members);
                        if(isset($member) && $member!= "") {
                            if(in_array($user->id, $member)) {
                                $counter++;
                            }
                        }
                    }
                }
            }
        }
        $data["groupscount"] = $counter; // count($data["groups"]);  */
        
        $data["groupscount"] = $this -> communitymodel -> getgroupscountbyuserid($user -> id);

        $data["reviewscount"] = $this -> communitymodel -> getreviewscountbyuserid($user -> id);

        $allfollowers = $this -> communitymodel -> getalluserfollowers($user -> id);
        $data["followers"] = $allfollowers;
        if (isset($allfollowers)) {
            $follower = unserialize($allfollowers -> followers);
            $data["followerscount"] = count($follower);
            //($data["followers"]);
        }

        return $data;
    }

    function profile() {
        $this -> freakauth_light -> check();

        if ($this -> uri -> segment("3") != "") {
            $where = array("user_name" => $this -> uri -> segment("3"));

            $user = $this -> communitymodel -> getuser($where);

            if (isset($user) && $user != "") {

                $data = $this -> _gettopboxcontent($user);

                $uid = $this -> db_session -> userdata("id");
                $data["uid"] = $uid;

                $data["notifications"] = $this -> _getnotifications();

                $where = array("uid" => $user -> id);
                //$data["images"] = $this->communitymodel->getuserimages($where);

                $data["aboutme"] = $this -> communitymodel -> getuseraboutinfo($user -> id);
				
				$contacts = $this -> communitymodel -> getcontact($where);
				$isfriend = FALSE;
				if(!empty($contacts) && ($contacts->friends != "")){
					$members = unserialize($contacts->friends);
					//echo "<pre>";print_r($contacts);exit;
					if(in_array($uid, $members)){
						$isfriend = TRUE;
					}elseif($uid == $contacts->uid){
						$isfriend = TRUE;
					}
				}

                if($user->id == $uid){
                    $isfriend = TRUE;
                }
				
				$data["contacts"] = $contacts;
				
                $data["followings"] = $this -> communitymodel -> getalluserfollowings($user -> id);

                $data["shoppinglists"] = $this -> crudmodel -> getshoppinglistbyuserid($user -> id);

                //$data["activities"] = $this->communitymodel->getlatestactivities();
                $activities = $this -> communitymodel -> getlatestactivitiesbyuser($where);
                $newactivities = array();

                if (isset($activities) && $activities != "") {
                    foreach ($activities as $activity) {
                        $array = (array)$activity;

                        $where = array("id" => $activity -> uid);
                        $activityuser = $this -> communitymodel -> getuser($where);

                        $userimg = "noavatar.png";

                        if (isset($activityuser) && $activityuser != "") {
                            $array["name"] = $activityuser -> user_name;
                            if (!empty($activityuser -> name)) {
                                $array["name"] = $activityuser -> name;
                            }

                            $array["user_name"] = $activityuser -> user_name;

                            if ($activityuser -> image != "") {
                                $userimg = $activityuser -> image;
                            }
                        }

                        $array["image"] = $userimg;
                        $array["content"] = $this -> _getactivitycontent($activity -> uid, $activity -> content, $activity -> info);

                        $where = array("aid" => $activity -> id);
                        $likes = $this -> communitymodel -> getactivitylikes($where);
                        $newlikes = array();
                        if (!empty($likes)) {
                            foreach ($likes as $like) {
                                $likearray = (array)$like;

                                if ($like -> uid != $this -> db_session -> userdata("id")) {
                                    $where = array("id" => $like -> uid);
                                    $likeuser = $this -> communitymodel -> getuser($where, "user_name, name");

                                    if (!empty($likeuser)) {
                                        $likearray["name"] = $likeuser -> user_name;
                                        if (!empty($likeuser -> name)) {
                                            $likearray["name"] = $likeuser -> name;
                                        }
                                    }
                                }
                                else {
                                    $likearray["isownerlike"] = true;
                                }

                                $likeobject = (object)$likearray;
                                $newlikes[] = $likeobject;
                            }

                            for ($i = 0; $i < count($likes); $i++) {
                                $likes[$i] = $newlikes[$i];
                            }
                        }

                        $array["likes"] = $likes;
                        $array["likescnt"] = count($likes);

                        $array["timeago"] = $this -> _timeago($activity -> date);

                        $where = array("aid" => $activity -> id);

                        $communitycomments = $this -> communitymodel -> getcommunitycomments($where);
                        $newcommunitycomments = array();

                        if (isset($communitycomments) && $communitycomments != "") {
                            foreach ($communitycomments as $communitycomment) {
                                $communityarray = (array)$communitycomment;
                                $communityarray["timeago"] = $this -> _timeago($communitycomment -> date);

                                $communityobject = (object)$communityarray;
                                $newcommunitycomments[] = $communityobject;
                            }
                        }

                        $array["communitycomments"] = $newcommunitycomments;

                        $object = (object)$array;
                        $newactivities[] = $object;
                    }

                    for ($i = 0; $i < count($activities); $i++) {
                        $activities[$i] = $newactivities[$i];
                    }
                }

                $data["activities"] = $activities;

                $data["made"] = $this -> communitymodel -> getallmadebyuserid($user -> id, 6);

                $data["favorites"] = $this -> communitymodel -> getallfavoriterecipesbyuserid($user -> id, 6);

                $data["favoriteblogs"] = $this -> communitymodel -> getallfavoriteblogsbyuserid($user -> id);
				
				$this->load->model("wineries/winemodel");

                $data["favouritewineries"] = $this -> communitymodel -> getallfavouritewineriesbyuser($user -> user_name, 6);

                $data["favoriterestaurants"] = $this -> communitymodel -> getallfavoriterestaurantbyuser($user -> user_name);

                $data["outsiderecipes"] = $this -> communitymodel -> getalloutsiderecipesbyuserid($user -> id);

                $data["imagegallery"] = $this -> communitymodel -> getimagegallery($user -> id, 2);

                //$data["onlinevideos"] = $this->communitymodel->getallonlinevideosbyuserid($user->id);
                $data["videogallery"] = $this -> communitymodel -> getvideogallery($user -> id);

                $data["liqureandspirits"] = $this -> communitymodel -> getliqureandspiritsbyuserid($user -> id);

                $data["drinkrecipes"] = $this -> communitymodel -> getalldrinkrecipesbyuserid($user -> id);

                $data["commborecipes"] = $this -> crudmodel -> getrecipes();

                $data["winenbeers"] = $this -> communitymodel -> getallwinenbeerbyuserid($user -> id);

                $data["recipereviews"] = $this -> crudmodel -> getrecipereviewsbyuserid($user -> id);

                $data["usersonline"] = $this -> _getonlineusers();

                $where = array("uid" => $user -> id);
                //$data["settings"] = $this->communitymodel->getsettings($where);

                $data["isowner"] = false;
                if ($user -> id == $uid) {
                    $data["isowner"] = true;
                    $data["types"] = $this->crudmodel->getalltypes();
                	$data["courses"] = $this->crudmodel->getallcourses();
					$data["categories"] = $this->crudmodel->getallcategories();
                }
                if (!$data["isowner"]) {
                    $where = array("uid" => $uid);
                    $data["isfriend"] = $this -> communitymodel -> isfriend($where, $uid, $user -> id);
                    if (!$data["isfriend"]) {$where = array("uid" => $user -> id);
                        $data["isrequested"] = $this -> communitymodel -> isfriendrequested($where, $uid);
                    }

                    $where = array("uid" => $user -> id);
                    $data["isfollow"] = $this -> communitymodel -> isfollow($where, $uid, $user -> id);

                }
                $data["admin"] = false;
                if ($this -> db_session -> userdata('role') == "admin" || $this -> db_session -> userdata('role') == "superadmin") {
                    $data["admin"] = true;
                }
                //echo "owner: ".$data["isowner"]." isfriend: ".$data["isfriend"]." isrequested: ".$data["isrequested"];
                //exit();

                $where = array('user_name' => base64_encode($user -> user_name));
                $data["membership"] = $this -> communitymodel -> getmembership($where);

                $data["user"] = $user;
				$data['isfriend'] = $isfriend;
            }

            $data["page"] = "community/profile";
            $this -> load -> view("template/newtemplate", $data);
        }
        else {
            redirect("community");
        }
    }

    /**
    * Thsi function is used to create new group
    */
    function creategroup() {
        $this->freakauth_light->check();

        $where = array(
                    "id" => $this->db_session->userdata("id"),
                    "user_name" => $this->db_session->userdata("user_name")
                );

        $user = $this->communitymodel->getuser($where);
        if(!empty($user)) {
            $data["user"] = $user;

            if($this->input->post("sbt_creategroup")) {
                $this->form_validation->set_rules("name", "Name", "trim|required|callback__isgroupexists");

                if ($this->form_validation->run() == FALSE) {
                    $data["page"] = "community/creategroup";
                    $this->load->view("template/newtemplate", $data);
                }
                else {
                    //exit();
                    $image = "defaultgroup.png";

                    if($_FILES["userfile"]["name"] != "") {
                        $groupuploadpath = $this->config->item("group_original_upload_path");

                        $config = array(
                                        "upload_path" => $groupuploadpath,
                                        "allowed_types" => "jpg|jpeg|gif|png"
                                    );

                        $filename = $_FILES["userfile"]["name"];
                        $filename = explode(".", $filename);
                        $filename[0] = $filename[0].time().".".$filename[1];
                        $_FILES["userfile"]["name"] = $filename[0];

                        $this->load->library("upload", $config);

                        if($this->upload->do_upload()) {

                            $image_data = $this->upload->data();

                            $imagestypes = array(
                                                    "group_200x200_upload_path" => $this->config->item("group_200x200_upload_path"),
                                                    "group_50x50_upload_path" => $this->config->item("group_50x50_upload_path"),
                                                    "group_25x25_upload_path" => $this->config->item("group_25x25_upload_path")
                                                );

                            $this->load->library("image_lib");

                            foreach ($imagestypes as $imagetype) {
                                $width = 200;
                                $heigth = 200;

                                if($imagetype == $this->config->item("group_200x200_upload_path")) {
                                    $width = 200;
                                    $heigth = 200;
                                }
                                else if($imagetype == $this->config->item("group_50x50_upload_path")) {
                                    $width = 50;
                                    $heigth = 50;
                                }
                                else if($imagetype == $this->config->item("group_25x25_upload_path")) {
                                    $width = 25;
                                    $heigth = 25;
                                }

                                $config = array(
                                    "source_image" => $image_data["full_path"],
                                    "new_image" => $imagetype,
                                    "maintain_ration" => true,
                                    "width" => $width,
                                    "height" => $heigth
                                );

                                $this->image_lib->initialize($config);
                                $this->image_lib->resize();
                            }

                            $image = $image_data["file_name"];
                       }
                       //$this->upload->display_errors();
                }
                //$specialchars = array("'", "|", "%", " ", ",", "!", "@", "$", "^", "*", "&");
                //$seo = strtolower(str_replace($specialchars, "-", $this->input->post("name"))."-".md5(time()));
                $seo = $this->_createseo($this->input->post("name"));

                //$uid = $this->db_session->userdata("id");
                $date = date("Y-m-d H:i:s");

                $group = array(
                                "uid" => $user->id,
                                "name" => $this->input->post("name"),
                                "description" => $this->input->post("description"),
                                "visibility" => $this->input->post("visibility"),
                                "image" => $image,
                                "seo" => $seo,
                                "date" => $date,
                                "isdeleted" => "0"
                            );

                    $groupid = $this->communitymodel->addgroup($group);
                    if($groupid > 0) {
                        $info = array(
                                      "gid" => $groupid,
                                      "gname" => $this->input->post("name"),
                                      "gseo" => $seo
                                   );

                        $activity = array(
                                        "uid" => $user->id,
                                        "content" => $this->config->item("new_group"),
                                        "info" => serialize($info),
                                        "date" => $date,
                                        "isnotified" => "0"
                                    );

                        $this->communitymodel->addactivity($activity);
						
						$activity = array(
                                        "uid" => $user->id,
                                        "gid" => $groupid,
                                        "content" => $this->config->item("new_group"),
                                        "info" => serialize($info),
                                        "date" => $date,
                                        "isnotified" => "0"
                                    );
						
						$this->communitymodel->addgroupactivity($activity);

                        redirect("community/group/$seo");
                    }
                    else {
                        $data["fail"] = "Fail to create new group. Please try again.";
                        $data["page"] = "community/creategroup";
                        $this->load->view("template/newtemplate", $data);
                    }
                }
            }
            else {
                $group = $this->communitymodel->getallgroups();
                if(!empty($group)) {
                    $data["groups"] = $group;
                }
                //echo $seo = strtolower(str_replace(" ", "-", "New GROUP TesT")."-".md5(time()));
                $data["page"] = "community/creategroup";
                $this->load->view("template/newtemplate", $data);
            }
        }
    }

    function _isgroupexists($name) {
        $where = array("name" => $name);

        if($this->communitymodel->isgroupexists($where)) {
            $this->form_validation->set_message("_isgroupexists", "Group already exist with this name.");
            return false;
        }

        return true;
    }

    function group() {
        $this->freakauth_light->check();

        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                    );

        $user = $this->communitymodel->getuser($where);
        if(!empty($user)) {

            $data["user"] = $user;

            if($this->uri->segment("3") != "") {

              	$where = array(
                                "seo" => $this->uri->segment("3"),
                                "isdeleted" => "0"
                            );

                $group = $this->communitymodel->getgroup($where);

                if(!empty($group)) {
                    $data["group"] = $group;

                    $where = array(
                                    "gid" => $group->id,
                                    "uid" => $group->uid
                                );

                    //$data["topics"] = $this->communitymodel->getalltopics($where);
                    //$data["polls"] = $this->communitymodel->getallpolls($where);
                    //$data["questions"] = $this->communitymodel->getallquestions($where);
                    $where = array(
                                    "id" => $group->uid
                                );

                    $data["groupowner"] = $this->communitymodel->getuser($where);

                    $uid = $this->db_session->userdata("id");

                    $isgroupowner = false;
                    if($group->uid == $uid) {
                        $isgroupowner = true;
                    }
					$data["isgroupowner"] = $isgroupowner;

                    $isadmin = false;
                    if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin") {
                        $isadmin = true;
                    }
                    $data["isadmin"] = $isadmin;

                    //if(!$isgroupowner && !$isadmin) {
                    $data["isgroupmember"] = false;
                    if(!$isgroupowner) {
                        if($group->members != "") {
                            if(in_array($uid, unserialize($group->members))) {
                                $data["isgroupmember"] = true;
                            }
                        }
                    }

                    $where = array(
                                    "gid" => $group->id,
                                    "isdeleted"=>"0"
                                );

                    //$data["groupwallposts"] = $this->communitymodel->getallgroupwallpost($where);
                    $groupwallposts = $this->communitymodel->getallgroupwallpost($where);
                    // for display time
                    $newgroupwallposts = array();
                    if(!empty($groupwallposts)) {

                        foreach ($groupwallposts as $groupwallpost) {
                            $array = (array) $groupwallpost;

                            $array["timeago"] = $this->_timeago($groupwallpost->date);
							//$info = isset($groupwallpost->info)? unserialize($groupwallpost->info):"";
                            $info = $groupwallpost->info;
                            if(isset($info)){
                                $info = preg_replace_callback ( '!s:(\d+):"(.*?)";!', function($match) {      
                                    return ($match[1] == strlen($match[2])) ? $match[0] : 's:' . strlen($match[2]) . ':"' . $match[2] . '";';
                                },$info );
                                unserialize($info);
                            }
							
							if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
								$activity = "<div class='previewImagesPosted'>";
								$activity .= "<div class='previewImagePosted'>";
								$activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
								if($info["isvideolink"] == "yes") {
									$activity .= "<span class='videoPostPlay'></span>";
								}
								$activity .= "</div>";
								$activity .= "</div>";
								$activity .= "<div class='previewContentPosted'>";
								$activity .= "<div class='previewTitlePosted'>";
								$activity .= "<a target='_blank' href='".$info["link"]."'>";
								$activity .= "<span style='color: #A90101;'>".$info["linktitle"]."</span>";
								$activity .= "</a>";
								$activity .= "</div>";
								$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
								$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
								$activity .= "</div>";
								$activity .= "<div style='clear: both'></div>";
								
								$array["content"] = $activity;
							}
							if(!empty($info["video"])) {
								$activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
								$array["content"] = $activity;
							}
							

                         	$where = array(
                                            "groupwallpostid" => $groupwallpost->id,
                                            "isdeleted"=>"0"
                                        );
                            $comments = $this->communitymodel->getgroupwallpostcomment($where);
                            $newcomments = array();

                            if(!empty($comments)) {
                                foreach ($comments as $comment) {
                                    $commentarray = (array) $comment;
                                    $commentarray["timeago"] = $this->_timeago($comment->date);

                                    $commentobject = (object) $commentarray;
                                    $newcomments[] = $commentobject;
                                }
                            }
                            $array["communitycomments"] = $newcomments;

                            $object = (object) $array;
                            $newgroupwallposts[] = $object;
                        }

                        for($i = 0; $i < count($groupwallposts); $i++) {
                            $groupwallposts[$i] = $newgroupwallposts[$i];
                        }
                    }

					$where = array(
                            "gid" => $group->id,
                            "isdeleted" => "0"
                        );
            		$groupmeet = $this->communitymodel->getmeetdetails($where);
					
					$data["groupmeet"] = $groupmeet;

                    $data["groupwallposts"] = $groupwallposts;
                    /*if(isset($groupwallposts) &&  $groupwallposts!="") {
                        $data["groupwallposts"] = $groupwallposts;
                    }*/

                    $data["usersonline"] = $this->_getonlineusers();
                }

                $data["page"] = "community/group";
                $this->load->view("template/newtemplate", $data);
            }
            else {
                redirect("community");
            }
        }
    }

    function groups() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                        "user_name" => $user_name
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;

            $group = $this->communitymodel->getallgroups();
            if(!empty($group)) {
                $data["groups"] = $group;
            }

            $getcontent = "group";
            $activities = $this->communitymodel->getallgroupsactivity();
            if(!empty($activities)) {
                foreach ($activities as $activity) {
                    $array = (array) $activity;
                    $userimg = "noavatar.png";
                    $where = array(
                                    "id" => $activity->uid
                                );
                    $activityuser = $this->communitymodel->getuser($where);
                    if(!empty($activityuser)) {
                        $array["name"] = $activityuser->user_name;
                        if(!empty($activityuser->name)) {
                            $array["name"] = $activityuser->name;
                        }
                        $array["user_name"] = $activityuser->user_name;
                        if($activityuser->image != "") {
                            $userimg = $activityuser->image;
                        }
                    }

                    $array["image"] = $userimg;
                    $array["content"] = $this->_getgroupactivity( $activity->content, $activity->info);
                    $array["timeago"] = $this->_timeago($activity->date);

                    $where = array(
                                    "aid" => $activity->id
                                    );
                    $communitycomments = $this->communitymodel->getcommunitycomments($where);
                    $newcommunitycomments = array();

                    if(!empty($communitycomments)) {
                        foreach ($communitycomments as $communitycomment) {
                            $communityarray = (array) $communitycomment;
                            $communityarray["timeago"] = $this->_timeago($communitycomment->date);

                            $communityobject = (object) $communityarray;
                            $newcommunitycomments[] = $communityobject;
                        }
                    }

                    $array["communitycomments"] = $newcommunitycomments;

                    $object = (object) $array;

                    $newactivities[] = $object;
                }

                for($i = 0; $i < count($activities); $i++) {
                    $activities[$i] = $newactivities[$i];
                }
            }

            $data["activities"] = $activities;

            $data["page"] = "community/allgroups";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }

    /**
    * function to show users groups and groups activities
    **/
    function mygroups() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");
        
        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                    "user_name" => $user_name
            );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["isowner"] = false;
            if($user->user_name == $this->db_session->userdata("user_name")) {
                $data["isowner"] = true;
            }

            $data["ownedgroups"] = $this->communitymodel->getallgroupsbyuserid($user->id);
			
			//get joined groups data
			$groupsjoined = $this->communitymodel->getuserjoinedgroups(array("uid" => $user->id));
			$groupsjoined = unserialize($groupsjoined->groups);
			$group = $this->communitymodel->getgroupwherein($groupsjoined);
			
            //$group = $this->communitymodel->getallgroups();
            if(!empty($group)) {
                $data["groups"] = $group;
            }

            $getcontent = "group";
            $activities = $this->communitymodel->getallgroupsactivity($getcontent);
            if(isset($activities) && $activities != "") {
                foreach ($activities as $activity) {
                    $array = (array) $activity;

                    $where = array(
                                    "id" => $activity->uid
                                );
                    $activityuser = $this->communitymodel->getuser($where);
                    $userimg = "noavatar.png";

                    if(isset($activityuser) && $activityuser != "") {
                        $array["name"] = $activityuser->user_name;
                        if(!empty($activityuser->name)) {
                            $array["name"] = $activityuser->name;
                        }
                        $array["user_name"] = $activityuser->user_name;
                        if($activityuser->image != "") {
                            $userimg = $activityuser->image;
                        }
                    }

                    $array["image"] = $userimg;
                    $array["content"] = $this->_getgroupactivity( $activity->content, $activity->info);
                    $array["timeago"] = $this->_timeago($activity->date);

                    $where = array(
                                    "aid" => $activity->id
                                );
                    $communitycomments = $this->communitymodel->getcommunitycomments($where);
                    $newcommunitycomments = array();

                    if(isset($communitycomments) && $communitycomments != "") {
                        foreach ($communitycomments as $communitycomment) {
                            $communityarray = (array) $communitycomment;
                            $communityarray["timeago"] = $this->_timeago($communitycomment->date);

                            $communityobject = (object) $communityarray;
                            $newcommunitycomments[] = $communityobject;
                        }
                    }

                    $array["communitycomments"] = $newcommunitycomments;

                    $object = (object) $array;

                    $newactivities[] = $object;
                }

                for($i = 0; $i < count($activities); $i++) {
                    $activities[$i] = $newactivities[$i];
                }
            }
            $data["activities"] = $activities;

            $data["user"] = $user;

            $data["page"] = "community/groupsactivity";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }

    function _getgroupactivity($content, $info) {
        $activity = "";

        if(isset($content) && $content != "" && isset($info) && $info != "") {
            $info = unserialize($info);

            if($content == $this->config->item("group_join")) {
                $activity = "Joined group <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            else if($content == $this->config->item("group_wall_post")) {
                $activity = "Posted on <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a> wall.";
            }
            else if($content == $this->config->item("new_question")) {
                $activity = "Asked new question <a target='_blank' href='".base_url()."community/question/".$info["gseo"]."'>".$info["question"]."</a> in group <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            else if($content == $this->config->item("reply_on_question")) {
                $activity = "Replied on question <a target='_blank' href='".base_url()."community/question/".$info["gseo"]."'>".$info["question"]."</a> under group <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            else if($content == $this->config->item("new_poll")) {
                $activity = "submitted new poll <a target='_blank' href='".base_url()."community/poll/".$info["gseo"]."'>".$info["question"]."</a> in group <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            else if($content == $this->config->item("vote_on_poll")) {
                $activity = "votted on poll <a href='".base_url()."community/poll/".$info["gseo"]."'></a> in group <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            else if($content == $this->config->item("comment_on_groupwallpost")) {
                $activity = "Commented on ".$info["message"]." under <a target='_blank' href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a> group.";
            }
        }

        return $activity;
    }

    function editgroup() {
        $this->freakauth_light->check();

        $uid = $this->db_session->userdata("id");

        if($this->uri->segment("3") != "") {

            $where = array(
                            "uid" => $uid,
                            "seo" => $this->uri->segment("3"),
                            "isdeleted" => "0"
                        );
    
            $group = $this->communitymodel->getgroup($where);
    
            if(isset($group) && $group != "") {
                if($group->uid == $uid) {
                    $isgroupowner = true;
                    $data["isgroupowner"] = $isgroupowner;
                    $where = array(
                                    "id" => $group->uid
                                );
                    $data["user"] = $this->communitymodel->getuser($where);
                    $data["group"] = $group;
                    $data["page"] = "community/editgroup";
                    $this->load->view("template/newtemplate", $data);
                }
                if(!$isgroupowner) {
                    if($group->members != "") {
                        if(in_array($uid, unserialize($group->members))) {
                            $data["isgroupmember"] = true;
                        }
                    }
                }
            }
            else {
                redirect("community");
            }
        }
        else if($this->input->post("sbt_updategroup")) {
            $gid = $this->input->post("gid");
            $seo = $this->input->post("seo");
    
            if($this->input->post("name") != $this->input->post("oldname")) {
                $this->form_validation->set_rules("name", "Name", "trim|required|callback__isgroupexists");
            }
            else {
                $this->form_validation->set_rules("name", "Name", "trim|required");
            }
    
            if ($this->form_validation->run() == FALSE) {
                $data["page"] = "community/editgroup";
                $this->load->view("template/template", $data);
            }
            else {
                $image = "defaultgroup.png";
                if($this->input->post("oldimage") != "") {
                    $image = $this->input->post("oldimage");
                }
    
                if($_FILES["userfile"]["name"] != "") {
                    $groupuploadpath = $this->config->item("group_original_upload_path");
    
                    $config = array(
                                    "upload_path" => $groupuploadpath,
                                    "allowed_types" => "jpg|jpeg|gif|png"
                                    );
    
                    $filename = $_FILES["userfile"]["name"];
                    $filename = explode(".", $filename);
                    $filename[0] = $filename[0].time().".".$filename[1];
                    $_FILES["userfile"]["name"] = $filename[0];
    
                    $this->load->library("upload", $config);
    
                    if($this->upload->do_upload()) {
                        $image_data = $this->upload->data();
    
                        $imagestypes = array(
                                            "group_200x200_upload_path" => $this->config->item("group_200x200_upload_path"),
                                            "group_50x50_upload_path" => $this->config->item("group_50x50_upload_path")
                                        );
    
                        $this->load->library("image_lib");
    
                        foreach ($imagestypes as $imagetype) {
    
                            $width = 200;
                            $heigth = 200;
    
                            if($imagetype == $this->config->item("group_200x200_upload_path")) {
                                $width = 200;
                                $heigth = 200;
                            }
                            else if($imagetype == $this->config->item("group_25x25_upload_path")) {
                                $width = 25;
                                $heigth = 25;
                            }
    
                            $config = array(
                                            "source_image" => $image_data["full_path"],
                                            "new_image" => $imagetype,
                                            "maintain_ration" => true,
                                            "width" => $width,
                                            "height" => $heigth
                                        );
    
                            $this->image_lib->initialize($config);
                            $this->image_lib->resize();
                        }
    
                        $image = $image_data["file_name"];
                    }
                    //$this->upload->display_errors();
                }
                
                $seo = strtolower(str_replace(" ", "-", $this->input->post("name"))."-".md5(time()));
    
                $group = array(
                                "name" => $this->input->post("name"),
                                "description" => $this->input->post("description"),
                                "visibility" => $this->input->post("visibility"),
                                "image" => $image,
                                "seo" => $seo,
                                "date" => date("Y-m-d H:i:s")
                            );

                $where = array(
                                "id" => $this->input->post("gid"),
                                "uid" => $uid
                            );

                if($this->communitymodel->updategroup($group, $where)) {
                    redirect("community/group/$seo");
                }
                else {
                    $data["fail"] = "Fail to update group. Please try again.";
                    $data["page"] = "community/editgroup";
                    $this->load->view("template/newtemplate", $data);
                }
            }
        }
        else {
            redirect("community");
        }
    }

    //function addtopic()
    function addquestion() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addquestion")) {
            $this->form_validation->set_rules("title", "Title", "trim|required");
            //$this->form_validation->set_rules("message", "Message", "trim|required");

            if ($this->form_validation->run() == FALSE) {
                //$data["page"] = "community/addtopic";
                $data["page"] = "community/group";
                $this->load->view("template/template", $data);
            }
            else {
                $gid = $this->input->post("gid");
                $uid = $this->db_session->userdata("id");

                $where = array(
                                "id" => $gid,
                                "uid" => $uid,
                                "isdeleted" => "0"
                            );

                $group = $this->communitymodel->getgroup($where);
                $data["group"] = $group;

                if(isset($group) && $group != "") {
                    if($group->uid == $uid) {
                        // $seo = strtolower(str_replace(" ", "-", $this->input->post("title"))."-".md5(time()));
                        $seo = strtolower(strtok($this->input->post("title")," ")."-".md5(time()));
                        $date = date("Y-m-d H:i:s");
                        $question = array(
                                            "gid" => $gid,
                                            "uid" => $this->db_session->userdata("id"),
                                            "question" => $this->input->post("title"),
                                            //"title" => $this->input->post("title"),
                                            //"message" => $this->input->post("message"),
                                            "seo" => $seo,
                                            "date" => $date
                                        );

                        $questionid = $this->communitymodel->addquestion($question);
                        if($questionid > 0) {
                            $info = array(
                                            "gid" => $gid,
                                            "gname" => $group->name,
                                            "gseo" => $group->seo,
                                            "qid" => $questionid,
                                            "question" => $this->input->post("title"),
                                            "qseo" => $seo
                                        );

                            $activity = array(
                                            "uid" => $uid,
                                            "content" => $this->config->item("new_question"),
                                            "info" => serialize($info),
                                            "date" => $date,
                                            "isnotified" => "0"
                                        );

                            $this->communitymodel->addactivity($activity);
							
							$activity = array(
                                            "uid" => $uid,
                                            "gid" => $gid,
                                            "content" => $this->config->item("new_question"),
                                            "info" => serialize($info),
                                            "date" => $date,
                                            "isnotified" => "0"
                                        );
                            $this->communitymodel->addgroupactivity($activity);

                            redirect("community/question/$seo");
                        }
                        else {
                            $data["fail"] = "Fail to Ask question. Please try again.";
                            //$data["page"] = "community/addquestion";
                            $data["page"] = "community/group";
                            $this->load->view("template/template", $data);
                        }
                    }
                    else {
                        redirect("community");
                    }
                }
                else {
                    $data["fail"] = "Fail to Ask question. Please try again.";
                    //$data["page"] = "community/addquestion";
                    $data["page"] = "community/group";
                    $this->load->view("template/template", $data);
                }
            }
        }
        else if($this->uri->segment("3") != "") {
            $uid = $this->db_session->userdata("id");

            $where = array(
                            "uid" => $uid,
                            "seo" => $this->uri->segment("3"),
                            "isdeleted" => "0"
                        );

            $group = $this->communitymodel->getgroup($where);
            if(isset($group) && $group != "") {
                if($group->uid == $uid) {
                    $data["group"] = $group;
                    //$data["page"] = "community/addquestion";
                    $data["page"] = "community/group";
                    $this->load->view("template/template", $data);
                }
                else {
                    redirect("community");
                }
            }
            else {
                redirect("community");
            }
        }
        else {
            redirect("community");
        }
    }

    //function topic()
    /*function question() {
    $this->freakauth_light->check();

    if($this->uri->segment("3") != "") {

    $where = array(
    "seo" => $this->uri->segment("3")
    );
    $question = $this->communitymodel->getquestion($where);

    $group = "";
    $replies = "";

    if(isset($question) && $question != "") {
    $data["question"] = $question;

    $where = array(
    "id" => $question->gid
    );

    $group = $this->communitymodel->getgroup($where);
    $data["group"] = $group;

    $where = array(
    "gid" => $question->gid,
    "qid" => $question->id
    );

    $replies = $this->communitymodel->getallreply($where);

    $data["replies"] = $replies;

    $uid = $this->db_session->userdata("id");

    $isgroupowner = false;
    if($question->uid == $uid) {
    $isgroupowner = true;
    $data["isgroupowner"] = $isgroupowner;
    }

    if(!$isgroupowner) {
    if($group->members != "") {
    if(in_array($uid, unserialize($group->members))) {
    $data["isgroupmember"] = true;
    }
    }
    }

    $where = array(
    "id" => $question->uid
    );
    $data["user"] = $this->communitymodel->getuser($where);
    }

    //$data["page"] = "community/question";
    $data["page"] = "community/group";
    $this->load->view("template/template", $data);
    }
    // not used for now
    else if($this->input->post("sbt_reply")) {
    $this->form_validation->set_rules("message", "Message", "trim|required");

    if ($this->form_validation->run() == FALSE) {

    }
    else {
    $gid = $this->input->post("gid");
    $qid = $this->input->post("qid");

    $where = array(
    "id" => $gid
    );
    $group = $this->communitymodel->getgroup($where);

    if(isset($group) && $group != "") {

    $where = array(
    "id" => $qid
    );

    $question = $this->communitymodel->getquestion($where);
    if(isset($question) && $question != "") {

    $data["question"] = $question;

    $reply = array(
    "gid" => $gid,
    "qid" => $qid,
    "uid" => $this->db_session->userdata("id"),
    "message" => $this->input->post("message"),
    "date" => date("Y-m-d H:i:s")
    );

    $replyid = $this->communitymodel->addreply($reply);

    if($replyid <= 0) {
    $data["fail"] = "Fail to reply. Please try again.";

    $where = array(
    "id" => $qid
    );

    $data["question"] = $this->communitymodel->getquestion($where);

    $where = array(
    "gid" => $gid,
    "qid" => $qid
    );

    $replies = $this->communitymodel->getallreply($where);
    $data["replies"] = $replies;

    //$data["page"] = "community/question";
    $data["page"] = "community/group";
    $this->load->view("template/template", $data);
    }
    else {
    $info = array(
    "gid" => $gid,
    "gname" => $group->name,
    "gseo" => $group->seo,
    "qid" => $qid,
    "question" => $question->title,
    "qseo" => $question->seo,
    "rid" => $replyid
    );

    $activity = array(
    "uid" => $uid,
    "content" => $this->config->item("reply_on_question"),
    "info" => serialize($info),
    "date" => $date,
    "isnotified" => "0"
    );

    $this->communitymodel->addactivity($activity);

    $seo = $this->input->post("seo");
    redirect("community/question/$seo");
    }
    }
    else {
    $data["fail"] = "This question does not exists. It may have been removed by its owner.";

    $where = array(
    "id" => $qid
    );

    $data["question"] = $this->communitymodel->getquestion($where);

    $where = array(
    "gid" => $gid,
    "qid" => $qid
    );

    $replies = $this->communitymodel->getallreply($where);
    $data["replies"] = $replies;

    //$data["page"] = "community/question";
    $data["page"] = "community/group";
    $this->load->view("template/template", $data);
    }
    }
    else {
    $data["fail"] = "The group of this question does not exists. It may have been removed by its owner.";

    $where = array(
    "id" => $qid
    );

    $data["question"] = $this->communitymodel->getquestion($where);

    $where = array(
    "gid" => $gid,
    "qid" => $qid
    );

    $replies = $this->communitymodel->getallreply($where);
    $data["replies"] = $replies;

    //$data["page"] = "community/question";
    $data["page"] = "community/group";
    $this->load->view("template/template", $data);
    }
    }
    }
    else {
    redirect("community");
    }
    }*/

    function question() {
        $this->freakauth_light->check();

        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;

            if($this->uri->segment("3") != "") {

                $where = array(
                                "seo" => $this->uri->segment("3"),
                                "isdeleted" => "0"
                            );

                $group = $this->communitymodel->getgroup($where);

                if(!empty($group)) {
                    $data["group"] = $group;
                    $where = array(
                                    "gid" => $group->id
                                    //"uid" => $group->uid
                                );

                    //$data["questions"] = $this->communitymodel->getallquestions($where);
                    $questions = $this->communitymodel->getallquestions($where);
                    // for display time
                    $newquestions = array();
                    if(!empty($questions)) {
                        foreach ($questions as $question) {
                            $array = (array) $question;
                            //$array["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
                            $array["timeago"] = $this->_timeago($question->date);
                            $where = array(
                                            "qid" => $question->id
                                        );
                            $answers = $this->communitymodel->getallreply($where);
                            $newanswers = array();

                            if(isset($answers) && $answers != "") {
                                foreach ($answers as $answer) {
                                    $answerarray = (array) $answer;
                                    $answerarray["timeago"] = $this->_timeago($answer->date);
                                    $answerobject = (object) $answerarray;
                                    $newanswers[] = $answerobject;
                                }
                            }
                            $array["communitycomments"] = $newanswers;

                            $object = (object) $array;
                            $newquestions[] = $object;
                        }

                        for($i = 0; $i < count($questions); $i++) {
                            $questions[$i] = $newquestions[$i];
                        }
                    }

                    $data["questions"] = $questions;

                    $where = array(
                                    "id" => $group->uid
                                );
                    $groupowner = $this->communitymodel->getuser($where);
                    if(!empty($groupowner)) {
                        $data["groupowner"] = $groupowner;
                        $uid = $this->db_session->userdata("id");
						 
						 /*$where = array(
                                        "gid" => $group->id
                                        );
                        $data["groupwallposts"] = $this->communitymodel->getallgroupwallpost($where);*/
                        $where = array(
                                        "gid" => $group->id
                                    );

                        $data["groupwallposts"] = $this->communitymodel->getallgroupwallpost($where);
                        /* if(isset($groupwallposts) &&  $groupwallposts != "") {
                                $data["groupwallposts"] = $groupwallposts;
                        }*/
                    }
					$isgroupowner = false;
                    if($group->uid == $uid) {
                        $isgroupowner = true;
                    }
					$data["isgroupowner"] = $isgroupowner;

                    $isadmin = false;
                    if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin") {
                        $isadmin = true;
                    }
                    $data["isadmin"] = $isadmin;

                    //if(!$isgroupowner && !$isadmin) {
                    $data["isgroupmember"] = false;
                    if(!$isgroupowner) {
                        if($group->members != "") {
                            if(in_array($uid, unserialize($group->members))) {
                                $data["isgroupmember"] = true;
                            }
                        }
                    }
                }

                $data["page"] = "community/question";
                $this->load->view("template/newtemplate", $data);
            }
            else {
                redirect("community");
            }
        }
    }

    function poll() {
        $this->freakauth_light->check();

        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                        );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;
            if($this->uri->segment("3") != "") {

                $where = array(
                            "seo" => $this->uri->segment("3"),
                            "isdeleted" => "0"
                        );
    
                $group = $this->communitymodel->getgroup($where);
    
                if(!empty($group)) {

                    $data["group"] = $group;
                    $where = array(
                                    "gid" => $group->id
                                    //"uid" => $group->uid
                                );
    
                    //$data["topics"] = $this->communitymodel->getalltopics($where);
                    //$data["polls"] = $this->communitymodel->getallpolls($where);
                    $polls = $this->communitymodel->getallpolls($where);
                    
                    // for display time
                    $newpolls = array();
                    if(isset($polls) && $polls != "") {
                        foreach ($polls as $poll) {
                            $array = (array) $poll;
                            //$array["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
                            $array["timeago"] = $this->_timeago($poll->date);
                            
                            $object = (object) $array;
                            $newpolls[] = $object;
                        }

                        for($i = 0; $i < count($polls); $i++) {
                            $polls[$i] = $newpolls[$i];
                        }
                    }

                    $data["polls"] = $polls;
					
                    $where = array(
                                    "gid" => $group->id
                                );

                    $data["groupwallposts"] = $this->communitymodel->getallgroupwallpost($where);

					$where = array("id" => $group->uid);
                    $data["groupowner"] = $this->communitymodel->getuser($where);
    
                    $uid = $this->db_session->userdata("id");
					
					$isgroupowner = false;
                    if($group->uid == $uid) {
                        $isgroupowner = true;
                    }
					$data["isgroupowner"] = $isgroupowner;

                    $isadmin = false;
                    if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin") {
                        $isadmin = true;
                    }
                    $data["isadmin"] = $isadmin;

                    //if(!$isgroupowner && !$isadmin) {
                    $data["isgroupmember"] = false;
                    if(!$isgroupowner) {
                        if($group->members != "") {
                            if(in_array($uid, unserialize($group->members))) {
                                $data["isgroupmember"] = true;
                            }
                        }
                    }
                }

				

                $data["page"] = "community/poll";
                $this->load->view("template/newtemplate", $data);
            }
            else {
                redirect("community");
            }
        }
    }

    /**
    * This function is used to send group invitation to friends.
    */
    function invite() {
        $this->freakauth_light->check();

        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;

            if($this->input->post("sbt_invite")) {

                $gid = $this->input->post("gid");
                $uid = $this->db_session->userdata("id");

                $where = array(
                                "id" => $gid,
                                "uid" => $uid,
                                "isdeleted" => "0"
                            );

                $group = $this->communitymodel->getgroup($where);
                $data["group"] = $group;

                if(!empty($group)) {
                    if($group->uid == $uid) {
                        $gseo = $group->seo;
                        $friends = $this->input->post("friends");
                        $date = date("Y-m-d H:i:s");

                        $where = array("gid" => $group->id,
                        				"uid" => $uid);

                        $isinvitationsuccessfull = false;

                        if($this->communitymodel->isinvitationexists($where)) {

                            $groupinvitation = $this->communitymodel->getinvitation($where);
                            $invitations = unserialize($groupinvitation->invitations);

                            $newinvitation = array();

                            if(isset($invitations) && $invitations != "") {
                                foreach($friends as $id) {
                                    if(!in_array($id, $invitations)) {
                                        $newinvitation[] = $id;
                                    }
                                }
                            }

                            if(isset($invitations) && $invitations != "") {
                                foreach($invitations as $invitation) {
                                    if(!in_array($invitation, $newinvitation)) {
                                        $newinvitation[] = $invitation;
                                    }
                                }
                            }

                            $invites = array(
                                                "invitations" => serialize($newinvitation),
                                                "date" => $date
                                            );
    
                            $where = array(
                                            "gid" => $gid,
                                            "uid" => $uid
                                        );
                            if($this->communitymodel->updategroupinvitation($invites, $where)) {
                                $isinvitationsuccessfull = true;
                            }
                        }
                        else {
                            $invites = array(
                                            "gid" => $gid,
                                            "uid" => $uid,
                                            "invitations" => serialize($friends)
                                        );
    
                            if($this->communitymodel->addinvitation($invites) > 0) {
                                $isinvitationsuccessfull = true;
                            }
                        }

                        if($isinvitationsuccessfull) {
                            foreach($friends as $fid) {
                                $where = array(
                                                "content" => $this->config->item("invite_friend"),
                                                "uid" => $fid
                                            );
                                if($this->communitymodel->isnotificationexists($where)) {
                                    $notification = $this->communitymodel->getnotificationbyuser($where);
                                    if(isset($notification) && !empty($notification)) {
                                        $info = unserialize($notification->info);
                                        if(isset($info) && !empty($info)) {
                                            if($notification->uid == $fid && $info["gid"] == $group->id) {
                                                $notificationupdate = array(
                                                                            "date" => $date,
                                                                            "isnotified" => "0"
                                                                            );
                                                $where = array(
                                                                "id" => $notification->id
                                                            );
                                                $this->communitymodel->updatenotifications($notificationupdate, $where);
                                            }
                                            else {
                                                $memberscnt = 0;
                                                if($group->members != "") {
                                                    $memberscnt = count(unserialize($group->members));
                                                }
    
                                                $where = array(
                                                                "id"=>$group->uid
                                                            );
                                                $owner = $this->communitymodel->getgroupowner($where);
                                                $groupowner = $owner->name;
												$groupimg = "defaultgroup.png";
                                                if($group->image != "") {
                                                    if(file_exists($this->config->item("group_25x25_upload_path")."/".$group->image)) {
                                                        $groupimg = $group->image;
                                                    }
                                                }
    
                                                $newinfo = array(
                                                                    "gname" => $group->name,
                                                                    "gid" => $group->id,
                                                                    "gseo" => $group->seo,
                                                                    "gmember" => $memberscnt,
                                                                    "groupimage" => $groupimg,
                                                                    "groupowner" => $groupowner,
                                                                    "user_name" => $this->db_session->userdata("user_name")
                                                                );
    
                                                $newnotification = array(
                                                                        "uid" => $fid,
                                                                        "content" => $this->config->item("invite_friend"),
                                                                        "info" => serialize($newinfo),
                                                                        "date" => $date,
                                                                        "isnotified" => "0"
                                                                    );
    
                                                $this->communitymodel->addnotification($newnotification);
                                            }
                                        }
                                    }
                                }
                                else {
                                    $members = unserialize($group->members);
                                    if(isset($members)) {
                                        $gmembercount = count($members);
                                    }
                                    else {
                                        $gmembercount = number_format(0);
                                    }
                                    $where = array(
                                                    "id" => $group->uid
                                                );
                                    $owner = $this->communitymodel->getgroupowner($where);
                                    $groupowner = $owner->name;
									
                                    $groupimg = "defaultgroup.png";
                                    if($group->image != "") {
                                        if(file_exists($this->config->item("group_25x25_upload_path")."/".$group->image)) {
                                            $groupimg = $group->image;
                                        }
                                    }
    
                                    $info = array(
                                                    "gname" => $group->name,
                                                    "gid" => $group->id,
                                                    "gseo" => $group->seo,
                                                    "gmember" => $gmembercount,
                                                    "groupimage" => $groupimg,
                                                    "groupowner" => $groupowner,
                                                    "user_name" => $this->db_session->userdata("user_name")
                                                );
    
                                    $notification = array(
                                                        "uid" =>$fid,
                                                        "content" => $this->config->item("invite_friend"),
                                                        "info" => serialize($info),
                                                        "date" => $date,
                                                        "isnotified" => "0"
                                                );
    
                                    $notifications = $this->communitymodel->addnotification($notification);
                                }
                            }
    
                            redirect("community/group/$gseo");
                        }
                        else {
                            $invitationerr = "Fail to send invitaion. Please try again later.";
                            $this->_loadgroupinvitationview($gseo, $invitationerr, $user);
                        }
                    }
                }
            }
            else if($this->uri->segment("3") != "") {
                $this->_loadgroupinvitationview($this->uri->segment("3"), "", $user);
            }
            else {
                redirect("community");
            }
        }
    }

    /*
    * This function is for Set Up A Meet
    * */
    function meet() {

        $this->freakauth_light->check();

        $where = array(
                        "id" => $this->db_session->userdata("id"),
                        "user_name" => $this->db_session->userdata("user_name")
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;

            if(($this->uri->segment("3") != "") || $this->input->post("seo")) {

                $data["seo"] = ($this->uri->segment("3") != '') ? $this->uri->segment("3") : $this->input->post("seo");

                $where = array(
                                "seo" => $data["seo"], "isdeleted" => "0"
                            );
                $group = $this->communitymodel->getgroup($where);

                $data["group"] = $group;

                if(isset($group) && $group != "") {

                    $where = array(
                                    "id" => $group->uid
                                );
                    $data["groupowner"] = $this->communitymodel->getuser($where);

                    $uid = $this->db_session->userdata("id");

                    $isgroupowner = false;
                    $isgroupmember = false;
                    if($group->uid == $uid) {
                        $isgroupowner = true;

                        /** Code for Saving process start**/
                        if($this->input->post("addmeet")) {
                            $this->form_validation->set_rules("name", "Name", "trim|required|min_length[5]|max_length[20]");
                            $this->form_validation->set_rules("address", "Address", "trim|required");
                            $this->form_validation->set_rules("place", "Place", "trim|required|min_length[5]|max_length[20]");
                            $this->form_validation->set_rules("description", "Description", "trim|required");
                            $this->form_validation->set_rules("meet_date", "Date", "trim|required");
                            $this->form_validation->set_rules("meet_time", "Time", "trim|required");

                            if($this->form_validation->run()) {
                                $image = "";
                                if($_FILES["userfile"]["name"] != "") {
                                    $meetuploadpath = $this->config->item("meet_upload_path");
                                    $config = array(
                                                    "upload_path" => $meetuploadpath,
                                                    "allowed_types" => "jpg|jpeg|gif|png"
                                                );

                                    $filename = $_FILES["userfile"]["name"];
                                    $filename = explode(".", $filename);
                                    $filename[0] = $filename[0].time().".".$filename[1];
                                    $_FILES["userfile"]["name"] = $filename[0];

                                    $this->load->library("upload", $config);

                                    if($this->upload->do_upload()) {
                                        $image_data = $this->upload->data();
                                        $imagestypes = array(
                                                            "meet_50x50_upload_path" => $this->config->item("meet_50x50_upload_path"),
                                                            "meet_25x25_upload_path" => $this->config->item("meet_25x25_upload_path")
                                                        );

                                        $this->load->library("image_lib");

                                        foreach ($imagestypes as $imagetype) {
                                            $width = 100;
                                            $heigth = 100;

                                            if($imagetype == $this->config->item("meet_50x50_upload_path")) {
                                                $width = 50;
                                                $heigth = 50;
                                            }
                                            else if($imagetype == $this->config->item("meet_25x25_upload_path")) {
                                                $width = 25;
                                                $heigth = 25;
                                            }

                                            $config = array(
                                                            "source_image" => $image_data["full_path"],
                                                            "new_image" => $imagetype,
                                                            "maintain_ration" => true,
                                                            "width" => $width,
                                                            "height" => $heigth
                                                        );

                                            $this->image_lib->initialize($config);
                                            $this->image_lib->resize();
                                        }

                                        $image = $image_data["file_name"];
                                    }
                                    //echo $this->upload->display_errors();
                                }

                                $date = $this->input->post("meet_date");
                                $time = $this->input->post("meet_time");
                                $dateTime = $date." ".$time;

                                $meetingArray = array(
                                                    "gid" => $this->input->post("gid"),
                                                    "uid" => $uid,
                                                    "name" => $this->input->post("name"),
                                                    "address" => $this->input->post("address"),
                                                    "place" => $this->input->post("place"),
                                                    "description" => $this->input->post("description"),
                                                    "time" => $dateTime,
                                                    "image" => $image,
                                                    "seo" => $this->_createseo($this->input->post("name")),
                                                );
                                $meetings = $this->communitymodel->addmeeting($meetingArray);
                                if($meetings > 0) {
                                    $meetingArray["id"] = $meetings;
                                    //$this->_sendmeetmail($meetingArray);
                                    redirect("community/meet/".$this->input->post("seo"));
                                }
                            }
                        }
                        /** Code for Saving process end**/
                    }
                    else {
                        $members = unserialize($group->members);
                        if(in_array($uid,$members)) {
                            $isgroupmember = true;
                        }
                    }

                    $data["isgroupowner"] = $isgroupowner;
                    $data["isgroupmember"] = $isgroupmember;

                    $where = array(
                                    "gid" => $group->id,
                                    "isdeleted"=>"0"
                                );
                    $data["groupmeets"] = $this->communitymodel->getallmeets($where);
					$data["usersonline"] = $this->_getonlineusers();
                }

                $data["page"] = "community/meet";

                $this->load->view("template/newtemplate", $data);
            }
            else {
                redirect("community");
            }
        }
    }

    /*
    * Function for the invitation of the Set Up a meet
    * */
    function _sendmeetmail($meetingArray = null, $memberId = null) {
        if($meetingArray!=null) {
            $this->load->library('email');

            $where = array("id" => $meetingArray['gid']);
            $result = $this->communitymodel->getgroup($where);

            if(count($result) > 0) {
                $url = base_url()."community/meetinvitation/".$meetingArray['seo'];
                $where = array(
                                "id" => $result->uid
                            );
                $groupowner = $this->communitymodel->getuser($where);
				$members = unserialize($result->members);
				$membersCount = count($members);
				$date = date("Y-m-d H:i:s");
				if($memberId!=null){
					
					$where = array("id" => $memberId);
                    $groupmember = $this->communitymodel->getuser($where);

                    $this->email->set_newline("\r\n");
                    $config["mailtype"] = "html";
                    $this->email->initialize($config);

                    $this->email->from($groupowner->email, $groupowner->name);
                    $this->email->to($groupmember->email);
                    //$this->email->to("skmuqeet.09@gmail.com");
                    $this->email->subject('Foodlips - Invitation for '.$meetingArray['name']);
                    $this->email->message("Please <a href='".$url."'>Click Here</a> view the meeting details");
                    $this->email->send();
                    //echo $this->email->print_debugger();
                    
                    /** Code for setting notification **/
                    $info = array("gname" => $meetingArray['name'],
								"gid" => $meetingArray['id'],
								"gseo" => $meetingArray['seo'],
								"gmember" => $membersCount,
								"groupimage" => $meetingArray['image'],
								"groupowner" => $groupowner->name,
								"user_name" => $this->db_session->userdata("user_name"));

					$notification = array("uid" =>$groupmember->id,
									    "content" => $this->config->item("group_meet_invitaion"),
									    "info" => serialize($info),
									    "date" => $date,
									    "isnotified" => "0");

					$notifications = $this->communitymodel->addnotification($notification);
					
				}else{	                
	                if(!empty($members)) {	                	
	                    foreach($members as $memb) {
	                        $where = array("id" => $memb);
	                        $groupmember = $this->communitymodel->getuser($where);
	
	                        $this->email->set_newline("\r\n");
	                        $config["mailtype"] = "html";
	                        $this->email->initialize($config);
	
	                        $this->email->from($groupowner->email, $groupowner->name);
	                        $this->email->to($groupmember->email);
	                        //$this->email->to("skmuqeet.09@gmail.com");
	                        $this->email->subject('Foodlips - Invitation for '.$meetingArray['name']);
	                        $this->email->message("Please <a href='".$url."'>Click Here</a> view the meeting details");
	                        $this->email->send();
	                        //echo $this->email->print_debugger();
	                        
	                        /** Code for setting notification **/
	                        $info = array("gname" => $meetingArray['name'],
										"gid" => $meetingArray['id'],
										"gseo" => $meetingArray['seo'],
										"gmember" => $membersCount,
										"groupimage" => $meetingArray['image'],
										"groupowner" => $groupowner->name,
										"user_name" => $this->db_session->userdata("user_name"));
	
							$notification = array("uid" =>$groupmember->id,
											    "content" => $this->config->item("group_meet_invitaion"),
											    "info" => serialize($info),
											    "date" => $date,
											    "isnotified" => "0");
	
							$notifications = $this->communitymodel->addnotification($notification);
						}
	                }
				}
            }
        }
    }
    
    /*
	 * Function to Invite users to Group Meet
	 * */
	function meetinvite(){
		if(($this->uri->segment("3") != "")) {
        	$uid = $this->db_session->userdata("id");

			/*** Fetching Group Meet Details ***/
			$where = array("seo" => $this->uri->segment("3"),"isdeleted" => "0");
            $groupmeet = $this->communitymodel->getmeetdetails($where);
			
			if(!empty($groupmeet)){
				
				$groupmeetArr = (array)$groupmeet;
					
				$data['groupmeet'] = $groupmeet;
				if($this->input->post('sbt_invite'))
				{
					$friends = $this->input->post('friends');
					foreach($friends as $frdId){						
						$this->_sendmeetmail($groupmeetArr, $frdId);
					}
				}
				
				/*** Fetching Group Details ***/
				$where = array("id" => $groupmeet->gid, "isdeleted" => "0");
	            $group = $this->communitymodel->getgroup($where);
				$data['group'] = $group;
				
				$where = array("id" => $group->uid);
		        $data["groupowner"] = $this->communitymodel->getuser($where);
				
				$where = array("gid" => $group->id, "isdeleted"=>"0");
				$data["groupmeets"] = $this->communitymodel->getallmeets($where);
				
				/*** Getting Members List ***/
				if(!empty($group->members)){
					$members = unserialize($group->members);
					
					$attainding = array();
					if(!empty($groupmeet->attainding)){
						$attainding = unserialize($groupmeet->attainding);
						foreach($attainding as $id){
							$attaindeingUser[$id] = array();
							
							$where = array("id" => $id);
		                    $attaindeingUserDetails = $this->communitymodel->getuser($where);
							
							$attaindeingUser[$id]['name'] = $attaindeingUserDetails->name;
							$attaindeingUser[$id]['image'] = $attaindeingUserDetails->image;
						}
					}
					
					$maybeattainding = array();
					if(!empty($groupmeet->maybeattainding)){
						$maybeattainding = unserialize($groupmeet->maybeattainding);
						foreach($maybeattainding as $id){
							$maybeattaindeingUser[$id] = array();
							
							$where = array("id" => $id);
		                    $maybeattaindeingUserDetails = $this->communitymodel->getuser($where);
							
							$maybeattaindeingUser[$id]['name'] = $maybeattaindeingUserDetails->name;
							$maybeattaindeingUser[$id]['image'] = $maybeattaindeingUserDetails->image;
						}
					}
					
					$notattainding = array();
					if(!empty($groupmeet->notattainding)){
						$notattainding = unserialize($groupmeet->notattainding);
						foreach($notattainding as $id){
							$notattaindingUser[$id] = array();
							
							$where = array("id" => $id);
		                    $notattaindingUserDetails = $this->communitymodel->getuser($where);
							
							$notattaindingUser[$id]['name'] = $notattaindingUserDetails->name;
							$notattaindingUser[$id]['image'] = $notattaindingUserDetails->image;
						}
					}
					
					foreach($members as $id){
						if(!in_array($id,$attainding) && !in_array($id,$maybeattainding) && !in_array($id,$notattainding)){
							$memberDetails[$id] = array();
							
							$where = array("id" => $id);
		                    $groupmember = $this->communitymodel->getuser($where);
							
							$memberDetails[$id]['name'] = $groupmember->name;
							$memberDetails[$id]['image'] = $groupmember->image;
						}
					}
				}

				$isgroupowner = FALSE;
				$isgroupmember = FALSE;
				
				if($groupmeet->uid == $uid){
					$isgroupowner = TRUE;
				}else{
					$isgroupmember = TRUE;
				}
			}
			
			if(isset($memberDetails)){
				$data['memberDetails'] = $memberDetails;
			}else{
				$data['inviteMessage'] = "There is no member(s) to invite.";
			}
			$data['isgroupowner'] = $isgroupowner;
			$data['isgroupmember'] = $isgroupmember;
			$data["page"] = "community/meetmemberinvite";
            $this->load->view("template/newtemplate", $data);
			
		}		
	}

    /*
    * Function for getting the reply of the user for the meeting
    */
    function meetinvitation() {
        $this->freakauth_light->check();

        if(($this->uri->segment("3") != "")) {
        	$uid = $this->db_session->userdata("id");
			$isowner = false;
			$ismember = false;
			$answered = false;
			
			$where = array(
                            "seo" => $this->uri->segment("3"),
                            "isdeleted" => "0"
                        );
            $groupmeet = $this->communitymodel->getmeetdetails($where);
			
			if($this->input->post("submit") || $this->input->post("send")) {                
                //$uid = $this->input->post("uid");
                $where = array(
                                "id" => $groupmeet->gid, "isdeleted" => "0"
                            );
                $group = $this->communitymodel->getgroup($where);

                $members = unserialize($group->members);
                if(in_array($uid, $members)) {
                    if($this->input->post("meetinvite")) {
                        $this->_checkmemberinvitepost($groupmeet,$uid);
                    }

                    $update = array();
                    if($this->input->post("meetinvite") == "attainding") {
                        if(!empty($groupmeet->attainding)) {
                            $attainding = unserialize($groupmeet->attainding);
                            $attainding[] = $uid;
                            $attainding = array_unique($attainding);
                        }
                        else {
                            $attainding[] = $uid;
                        }
                        $update['attainding'] = serialize($attainding);
                    }

                    if($this->input->post("meetinvite") == "notattainding") {
                        if(!empty($groupmeet->notattainding)) {
                            $notattainding = unserialize($groupmeet->notattainding);
                            $notattainding[] = $uid;
                            $notattainding = array_unique($notattainding);
                        }
                        else {
                            $notattainding[] = $uid;
                        }
                        $update["notattainding"] = serialize($notattainding);
                    }

                    if($this->input->post("meetinvite") == "maybe") {
                        if(!empty($groupmeet->maybeattainding)) {
                            $maybeattainding = unserialize($groupmeet->maybeattainding);
                            $maybeattainding[] = $uid;
                            $maybeattainding = array_unique($maybeattainding);
                        }
                        else {
                            $maybeattainding[] = $uid;
                        }
                        $update['maybeattainding'] = serialize($maybeattainding);
                    }

                    if(!empty($update)) {
                        $where = "id = ".$groupmeet->id;
                        if($this->communitymodel->updatetable("groupmeeting",$where,$update)) {
                        	if($this->input->post("send")){
                        		redirect("community/meetdetails/".$groupmeet->seo);
                        	}else{
                        		redirect("community/meetinvitation/".$groupmeet->seo);
                        	}
                        }
                    }
                }
            }

            if(!empty($groupmeet->attainding))
			{
				$attaindingArr = unserialize($groupmeet->attainding);
				if(in_array($uid, $attaindingArr))
				{
					$data['message'] = "You will attaind this event.";
					$answered = true;
				}
			}
			if(!empty($groupmeet->notattainding))
			{
				$notattaindingArr = unserialize($groupmeet->notattainding);
				if(in_array($uid, $notattaindingArr))
				{
					$data['message'] = "You will not attainding this event.";
					$answered = true;
				}
			}
			if(!empty($groupmeet->maybeattainding))
			{
				$maybeattaindingArr = unserialize($groupmeet->maybeattainding);
				if(in_array($uid, $maybeattaindingArr))
				{
					$data['message'] = "You might be attainding this event.";
					$answered = true;
				}
			}
			
			$where = array( "id" => $groupmeet->gid,
                            "isdeleted" => "0");

            $group = $this->communitymodel->getgroup($where);
			
			$isgroupowner = false;
			$isgroupmember = false;

			if($group->uid == $uid){
                $isgroupowner = true;
			}
            else{
                $members = unserialize($group->members);
				
				if(in_array($uid,$members)){
                    $isgroupmember = true;
					
				}
            }
			
			$data['isgroupowner'] = $isgroupowner;			
			$data['isgroupmember'] = $isgroupmember;
			
			
			$data['answered'] = $answered;
			$data['group'] = $group;
			$data['groupmeet'] = $groupmeet;

            $data["page"] = "community/meetinvite";

            $this->load->view("template/newtemplate", $data);
        }
    }

    /*
    * Function for checking the available id
    * in attainding, notattainding, maybeattainding columns
    * of groupmeeting table
    * */
    function _checkmemberinvitepost($grpmeet, $uid) {
        $update = array();
        if(!empty($grpmeet->attainding)) {
            $attainding = unserialize($grpmeet->attainding);
                if(in_array($uid,$attainding)) {
                    if(($key = array_search($uid, $attainding)) !== false) {
                        unset($attainding[$key]);
                    }
                    $update['attainding'] = !empty($attainding) ? serialize($attainding) : "";
                }
            }

            if(!empty($grpmeet->maybeattainding)) {
                $maybeattainding = unserialize($grpmeet->maybeattainding);
                if(in_array($uid,$maybeattainding)) {
                    if(($key = array_search($uid, $maybeattainding)) !== false) {
                        unset($maybeattainding[$key]);
                    }
                    $update['maybeattainding'] = !empty($maybeattainding) ? serialize($maybeattainding) : "";
                }
            }

            if(!empty($grpmeet->notattainding)) {
                $notattainding = unserialize($grpmeet->notattainding);
                if(in_array($uid,$notattainding)) {
                    if(($key = array_search($uid, $notattainding)) !== false) {
                        unset($notattainding[$key]);
                    }
                    $update['notattainding'] = !empty($notattainding) ? serialize($notattainding) : "";
                }
            }

        if(!empty($update)) {
            $where = "id = ".$grpmeet->id;
            $this->communitymodel->updatetable("groupmeeting",$where,$update);
        }
    }

    /*
    * Fucntion for getting the groups by user id
    * */
    function mygroupmeet() {
        $this->freakauth_light->check();

        if(($this->uri->segment("2") != "")) {
            $userid = $this->db_session->userdata("id");
			$where = array("id" => $userid);
        	$data["user"] = $this->communitymodel->getuser($where);
			
            $data["groupmeets"] = $this->communitymodel->getallmeetsbyuserid($userid, "all");
            $data["isgroupowner"] = false;

            $where = array(
                            "user_name"=>base64_encode($this->db_session->userdata("user_name"))
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            $data["page"] = "community/mygroupmeet";
            $this->load->view("template/newtemplate", $data);
        }
    }

    /*
    * Function for getting the reply of the user for the meeting
    */
    function meetdetails() {
        $this->freakauth_light->check();

        if(($this->uri->segment("3") != "")) {
            $uid = $this->db_session->userdata("id");

            $where = array(
                            "seo" => $this->uri->segment("3")
                        );
            $groupmeet = $this->communitymodel->getmeetdetails($where);
			
			if(!empty($groupmeet)){
				// code for google map
				$this->load->library('googlemaps');
				//$config['center'] = '37.4419, -122.1419';
				$config['center'] = '13';
				$config['zoom'] = 'auto';
				$this->googlemaps->initialize($config);
				
				$marker = array();
				//$marker['position'] = '37.429, -122.1419';
				$marker['position'] = $groupmeet->address;
				$this->googlemaps->add_marker($marker);
				$data['map'] = $this->googlemaps->create_map();
				
				//end
				
	            $where = array(
	                            "meetseo" => $groupmeet->seo,
	                            "parentid"=>"0",
	                            "isdeleted"=>"0"
	                        );
	            $groupmeetquestions = $this->communitymodel->getallmeetsquestions($where);
	
	            $where = array(
	                            "id" => $groupmeet->gid,
	                            "isdeleted" => "0"
	                            );
	            $group = $this->communitymodel->getgroup($where);
	
	            if($this->input->post("askquestion")) {
	                if($this->input->post("questionbox")) {
	                    $meetquestionArray = array(
	                                                "meetseo" => $this->input->post("seo"),
	                                                "gid" => $this->input->post("gid"),
	                                                "uid" => $uid,
	                                                "post" => urlencode($this->input->post('questionbox'))
	                                            );
	                    if($this->input->post("parentid")) {
	                        $meetquestionArray['parentid'] = $this->input->post("parentid");
	                    }
	                    $meetings = $this->communitymodel->savemeetquestion($meetquestionArray);
	                    if($meetings) {
	                        redirect("community/meetdetails/".$groupmeet->seo);
	                    }
	                }
	            }
	
	            $where = array(
	                            "id"=>$group->uid
	                        );
	            $groupowner = $user = $this->communitymodel->getuser($where);
	
	            $data['group'] = $group;
	            $data['groupowner'] = $groupowner;
	            $data['no_of_members'] = count(unserialize($group->members));
	            $data['groupmeet'] = $groupmeet;
	            $data['groupmeetquestions'] = $groupmeetquestions;
	            $isgroupowner = FALSE;
	            $isgroupmember = FALSE;
	
	            if($group->uid == $uid) {
	                $isgroupowner = TRUE;
	            }
	            else {
	                $members = unserialize($group->members);
	                if(in_array($uid,$members)) {
	                    $isgroupmember = true;
	                }
	            }
	
	            $data['isgroupowner'] = $isgroupowner;
	            $data['isgroupmember'] = $isgroupmember;
				$data["usersonline"] = $this->_getonlineusers();
				
				if(!empty($groupmeet->attainding)){
					$data['attainding'] = unserialize($groupmeet->attainding);
				}
				
				if(!empty($groupmeet->maybeattainding)){
					$data['maybeattainding'] = unserialize($groupmeet->maybeattainding);
				}
				
				if(!empty($groupmeet->notattainding)){
					$data['notattainding'] = unserialize($groupmeet->notattainding);
				}
	        }
            $data["page"] = "community/meetdeatils";

            $this->load->view("template/newtemplate", $data);
        }
    }
	
	function updatemeetdetails(){
		$this->freakauth_light->check();
		/** Code for Saving process start**/
						if($this->input->post('cancelupdate')){
							$seo = $this->input->post('seo');
							redirect("community/meetdetails/".$seo);
						}
                        if($this->input->post("updatemeet")) {
                            $this->form_validation->set_rules("name", "Name", "trim|required|min_length[5]|max_length[20]");
                            $this->form_validation->set_rules("address", "Address", "trim|required");
                            $this->form_validation->set_rules("place", "Place", "trim|required|min_length[5]|max_length[20]");
                            $this->form_validation->set_rules("description", "Description", "trim|required");
                            $this->form_validation->set_rules("meet_date", "Date", "trim|required");
                            $this->form_validation->set_rules("meet_time", "Time", "trim|required");

                            if($this->form_validation->run()) {
                                $image = "";
                                if($_FILES["userfile"]["name"] != "") {
                                    $meetuploadpath = $this->config->item("meet_upload_path");
                                    $config = array(
                                                    "upload_path" => $meetuploadpath,
                                                    "allowed_types" => "jpg|jpeg|gif|png"
                                                );

                                    $filename = $_FILES["userfile"]["name"];
                                    $filename = explode(".", $filename);
                                    $filename[0] = $filename[0].time().".".$filename[1];
                                    $_FILES["userfile"]["name"] = $filename[0];

                                    $this->load->library("upload", $config);

                                    if($this->upload->do_upload()) {
                                        $image_data = $this->upload->data();
                                        $imagestypes = array(
                                                            "meet_50x50_upload_path" => $this->config->item("meet_50x50_upload_path"),
                                                            "meet_25x25_upload_path" => $this->config->item("meet_25x25_upload_path")
                                                        );

                                        $this->load->library("image_lib");

                                        foreach ($imagestypes as $imagetype) {
                                            $width = 100;
                                            $heigth = 100;

                                            if($imagetype == $this->config->item("meet_50x50_upload_path")) {
                                                $width = 50;
                                                $heigth = 50;
                                            }
                                            else if($imagetype == $this->config->item("meet_25x25_upload_path")) {
                                                $width = 25;
                                                $heigth = 25;
                                            }

                                            $config = array(
                                                            "source_image" => $image_data["full_path"],
                                                            "new_image" => $imagetype,
                                                            "maintain_ration" => true,
                                                            "width" => $width,
                                                            "height" => $heigth
                                                        );

                                            $this->image_lib->initialize($config);
                                            $this->image_lib->resize();
                                        }

                                        $image = $image_data["file_name"];
                                    }
                                    //echo $this->upload->display_errors();
                                }
								
                                $date = $this->input->post("meet_date");
                                $time = $this->input->post("meet_time");
                                $dateTime = $date." ".$time;
								$newseo = $this->_createseo($this->input->post("name"));
                                $meetingArray = array(
                                                    "gid" => $this->input->post("gid"),
                                                    "uid" => $this->input->post("uid"),
                                                    "name" => $this->input->post("name"),
                                                    "address" => $this->input->post("address"),
                                                    "place" => $this->input->post("place"),
                                                    "description" => $this->input->post("description"),
                                                    "time" => $dateTime,
                                                    "seo" => $newseo
                                                );
								if(!empty($image)){
									$meetingArray["image"] = $image;	
								}
								
								$where = array('seo'=>$this->input->post('seo'));
                                $meetings = $this->communitymodel->updatemeeting($meetingArray,$where);
                                // if($meetings > 0) {
                                    // $meetingArray["id"] = $meetings;
                                    // //$this->_sendmeetmail($meetingArray);
//                                     
                                // }
								redirect("community/meetdetails/".$newseo);
                            }
                        }
                        /** Code for Saving process end**/
        if(($this->uri->segment("3") != "")) {
            $uid = $this->db_session->userdata("id");

            $where = array(
                            "seo" => $this->uri->segment("3")
                        );
            $groupmeet = $this->communitymodel->getmeetdetails($where);
			//print_r($groupmeet);exit;
			
			if(!empty($groupmeet)){
				// code for google map
				$this->load->library('googlemaps');
				//$config['center'] = '37.4419, -122.1419';
				$config['center'] = '13';
				$config['zoom'] = 'auto';
				$this->googlemaps->initialize($config);
				
				$marker = array();
				//$marker['position'] = '37.429, -122.1419';
				$marker['position'] = $groupmeet->address;
				$this->googlemaps->add_marker($marker);
				$data['map'] = $this->googlemaps->create_map();
				
				//end
				
	            $where = array(
	                            "meetseo" => $groupmeet->seo,
	                            "parentid"=>"0",
	                            "isdeleted"=>"0"
	                        );
	            $groupmeetquestions = $this->communitymodel->getallmeetsquestions($where);
	
	            $where = array(
	                            "id" => $groupmeet->gid,
	                            "isdeleted" => "0"
	                            );
	            $group = $this->communitymodel->getgroup($where);
	
	            if($this->input->post("askquestion")) {
	                if($this->input->post("questionbox")) {
	                    $meetquestionArray = array(
	                                                "meetseo" => $this->input->post("seo"),
	                                                "gid" => $this->input->post("gid"),
	                                                "uid" => $uid,
	                                                "post" => urlencode($this->input->post('questionbox'))
	                                            );
	                    if($this->input->post("parentid")) {
	                        $meetquestionArray['parentid'] = $this->input->post("parentid");
	                    }
	                    $meetings = $this->communitymodel->savemeetquestion($meetquestionArray);
	                    if($meetings) {
	                        redirect("community/meetdetails/".$groupmeet->seo);
	                    }
	                }
	            }
	
	            $where = array(
	                            "id"=>$group->uid
	                        );
	            $groupowner = $user = $this->communitymodel->getuser($where);
	
	            $data['group'] = $group;
	            $data['groupowner'] = $groupowner;
	            $data['no_of_members'] = count(unserialize($group->members));
	            $data['groupmeet'] = $groupmeet;
	            $data['groupmeetquestions'] = $groupmeetquestions;
	            $isgroupowner = FALSE;
	            $isgroupmember = FALSE;
	
	            if($group->uid == $uid) {
	                $isgroupowner = TRUE;
	            }
	            else {
	                $members = unserialize($group->members);
	                if(in_array($uid,$members)) {
	                    $isgroupmember = true;
	                }
	            }
	
	            $data['isgroupowner'] = $isgroupowner;
	            $data['isgroupmember'] = $isgroupmember;
				$data["usersonline"] = $this->_getonlineusers();
				
				if(!empty($groupmeet->attainding)){
					$data['attainding'] = unserialize($groupmeet->attainding);
				}
				
				if(!empty($groupmeet->maybeattainding)){
					$data['maybeattainding'] = unserialize($groupmeet->maybeattainding);
				}
				
				if(!empty($groupmeet->notattainding)){
					$data['notattainding'] = unserialize($groupmeet->notattainding);
				}
	        }
            $data["page"] = "community/updatemeetdetails";

            $this->load->view("template/newtemplate", $data);
        }
	}
    /**
    * This funciton is used to load group invitation view.
    * @param gseo, required the seo of group to load.
    * @param invitationerr, optional invitation error if sending invitation failed.
    */
    function _loadgroupinvitationview($gseo, $invitationerr="", $user="") {

        if(!empty($user)) {
            $where = array(
                            "seo" => $gseo,
                            "isdeleted" => "0"
                        );

            $group = $this->communitymodel->getgroup($where);

            if(!empty($group)) {
                $data["group"] = $group;

                $where = array(
                                "id" => $group->uid
                            );
                $data["groupowner"] = $this->communitymodel->getuser($where);

                $uid = $this->db_session->userdata("id");
				$isgroupowner = false;
                if($group->uid == $uid) {
                    $isgroupowner = true;
                }
				$data["isgroupowner"] = $isgroupowner;

                $isadmin = false;
                if($this->db_session->userdata("role") == "admin" || $this->db_session->userdata("role") == "superadmin") {
                    $isadmin = true;
                }
                $data["isadmin"] = $isadmin;

                //if(!$isgroupowner && !$isadmin) {
                $data["isgroupmember"] = false;
                if(!$isgroupowner) {
                    if($group->members != "") {
                        if(in_array($uid, unserialize($group->members))) {
                            $data["isgroupmember"] = true;
                        }
                    }
                }
				
                $where = array(
                                "gid" => $group->id
                                );

                $groupwallposts = $this->communitymodel->getallgroupwallpost($where);
                // for display time
                $newgroupwallposts = array();
                if(isset($groupwallposts) && $groupwallposts != "") {
                    foreach ($groupwallposts as $groupwallpost) {
                        $array = (array) $groupwallpost;
                        $array["timeago"] = $this->_timeago($groupwallpost->date);
						
						$info = isset($groupwallpost->info)? unserialize($groupwallpost->info):"";
							
						if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
							$activity = "<div class='previewImagesPosted'>";
							$activity .= "<div class='previewImagePosted'>";
							$activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
							if($info["isvideolink"] == "yes") {
								$activity .= "<span class='videoPostPlay'></span>";
							}
							$activity .= "</div>";
							$activity .= "</div>";
							$activity .= "<div class='previewContentPosted'>";
							$activity .= "<div class='previewTitlePosted'>";
							$activity .= "<a target='_blank' href='".$info["link"]."'>";
							$activity .= "<span style='color: #A90101;'>".$info["linktitle"]."</span>";
							$activity .= "</a>";
							$activity .= "</div>";
							$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
							$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
							$activity .= "</div>";
							$activity .= "<div style='clear: both'></div>";
							
							$array["content"] = $activity;
						}
						if(!empty($info["video"])) {
							$activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
							$array["content"] = $activity;
						}

                        $where = array(
                                        "groupwallpostid" => $groupwallpost->id
                                    );
                        $comments = $this->communitymodel->getgroupwallpostcomment($where);

                        $newcomments = array();

                        if(isset($comments) && $comments != "") {
                            foreach ($comments as $comment) {
                                $commentarray = (array) $comment;
                                $commentarray["timeago"] = $this->_timeago($comment->date);

                                $commentobject = (object) $commentarray;
                                $newcomments[] = $commentobject;
                            }
                        }
                        $array["communitycomments"] = $newcomments;

                        $object = (object) $array;
                        $newgroupwallposts[] = $object;
                    }

                    for($i = 0; $i < count($groupwallposts); $i++) {
                        $groupwallposts[$i] = $newgroupwallposts[$i];
                    }
                }

                $data["groupwallposts"] = $groupwallposts;

                $where = array(
                                "uid" => $this->db_session->userdata("id")
                            );
                $friendids = $this->communitymodel->getallfriends($where);

                $friends = array();
                if(isset($friendids) && $friendids != "") {
                    foreach($friendids as $id) {
                        $members = unserialize($group->members);
                        if(isset($members) && $members !="") {
                            if($members != "" && !in_array($id, $members)) {
                                $where = array(
                                                "id" => $id
                                            );
                                $user = $this->communitymodel->getuser($where);
                                if(isset($user) && $user != "") {
                                    $friends[] = $user;
                                }
                            }
                        }
                        else {
                            $where = array(
                                            "id" => $id
                                        );
                            $user = $this->communitymodel->getuser($where);

                            if(isset($user) && $user != "") {
                                $friends[] = $user;
                            }
                        }
                    }
                }

                $data["invitationerr"] = $invitationerr;
                $data["friends"] = $friends;

                $data["page"] = "community/invite";
                $this->load->view("template/newtemplate", $data);
            }
        }
    }

    /**function invite() {
    if($this->input->post("sbt_invite")) {

    $gid = $this->input->post("gid");
    $uid = $this->db_session->userdata("id");
    $gseo = "";

    $where = array(
    "id" => $gid,
    "uid" => $uid
    );

    $group = $this->communitymodel->getgroup($where);
    $data["group"] = $group;

    if(isset($group) && $group != "") {
    if($group->uid == $uid) {
    $gseo = $group->seo;
    $friends = $this->input->post("friends");
    $date = date("Y-m-d H:i:s");

    $where = array(
    "gid" => $group->id,
    "uid" => $uid
    );

    if($this->communitymodel->isinvitationexists($where)) {

    $groupinvitation = $this->communitymodel->getinvitation($where);
    $invitations = unserialize($groupinvitation->invitations);

    $newinvitation = array();

    if(isset($invitations) && $invitations != "") {
    foreach($friends as $id) {
    if(!in_array($id, $invitations)) {
    $newinvitation[] = $id;
    }
    }
    }

    if(isset($invitations) && $invitations != "") {
    foreach($invitations as $invitation) {
    if(!in_array($invitation, $newinvitation)) {
    $newinvitation[] = $invitation;
    }
    }
    }

    $invites = array(
    "invitations" => serialize($newinvitation)
    );

    $where = array(
    "gid" => $gid,
    "uid" => $uid
    );
    $this->communitymodel->updategroupinvitation($invites, $where);
    }
    else {

    $gseo = $group->seo;
    $invites = array(
    "gid" => $gid,
    "uid" => $uid,
    "invitations" => serialize($friends)
    );

    if($this->communitymodel->addinvitation($invites) > 0) {
    // success
    }
    }

    foreach($friends as $fid) {

    $where = array(
    "content" => $this->config->item("invite_friend"),
    "uid" => $fid
    );
    if($this->communitymodel->isnotificationexists($where)) {
    $notification = $this->communitymodel->getnotificationbyuser($where);
    if(isset($notification) && !empty($notification)) {
    $info = unserialize($notification->info);
    if(isset($info) && !empty($info)) {
    if($notification->uid == $fid && $info["gid"] == $group->id) {
    $notificationupdate = array(
    "date" => $date,
    "isnotified" => "0"
    );
    $where = array(
    "id" => $notification->id
    );

    $this->communitymodel->updatenotifications($notificationupdate, $where);
    }
    else {
    $members = unserialize($group->members);
    $gmembercount = 0;
    if(isset($members) && !empty($members)) {
    $gmembercount = number_format(count($members));
    }

    $where = array(
    "id"=>$group->uid
    );
    $owner = $this->communitymodel->getgroupowner($where);
    $groupowner = $owner->name;

    $groupimg = "defaultgroup.png";
    if($group->image != "") {
    $groupimg = $group->image;
    }

    $newinfo = array(
    "gname" => $group->name,
    "gid" => $group->id,
    "gseo" => $group->seo,
    "gmember" => $gmembercount,
    "groupimage" => $groupimg,
    "groupowner" => $groupowner
    );

    $newnotification = array(
    "uid" => $fid,
    "content" => $this->config->item("invite_friend"),
    "info" => serialize($newinfo),
    "date" => $date,
    "isnotified" => "0"
    );

    $this->communitymodel->addnotification($newnotification);
    }
    }
    }
    }
    else {
    $members = unserialize($group->members);
    if(isset($members)) {
    $gmembercount = count($members);
    }
    else{
    $gmembercount = number_format(0);
    }

    $where = array(
    "id" => $group->uid
    );
    $owner = $this->communitymodel->getgroupowner($where);
    $groupowner = $owner->name;

    if($group->image != "") {
    $groupimg = $group->image;
    }
    else {
    $groupimg = "defaultgroup.png";
    }

    $info = array(
    "gname" => $group->name,
    "gid" => $group->id,
    "gseo" => $group->seo,
    "gmember" => $gmembercount,
    "groupimage" => $groupimg,
    "groupowner" => $groupowner
    );

    $notification = array(
    "uid" =>$fid,
    "content" => $this->config->item("invite_friend"),
    "info" => serialize($info),
    "date" => $date,
    "isnotified" => "0"
    );

    $notifications = $this->communitymodel->addnotification($notification);
    }
    }
    }
    }
    redirect("community/group/$gseo");
    }

    }**/

    /**
    * This function is used to load messages view.
    */
    function messages() {

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }

        $where = array(
                        "user_name" => $user_name
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;

            $owner = $this->communitymodel->getuser($where);
            if(!empty($owner)) {
                $uid = $owner->id;

                $where = array(
                                "user_name"=>base64_encode($owner->user_name)
                                );
                $data["membership"] = $this->communitymodel->getmembership($where);

                $newmessagesobj = $this->communitymodel->getnewmsgs();
			    $newmsges = array();
                $uids = array();
                foreach($newmessagesobj as $msg) {
                    if(!in_array($msg->uid, $uids)) {
                        $where = array(
                                        "id" => $msg->uid
                                    );
                        $user = $this->communitymodel->getuser($where);
                        if(isset($user) && !empty($user)) {
                            $newmsges[$msg->uid]["newmessage"] = $msg->message;
                            $newmsges[$msg->uid]["msgcount"] = 1;
                            $newmsges[$msg->uid]["uid"] = $msg->uid;
                        }
                    }
                    else {
                        $newmsges[$msg->uid]["msgcount"]++;
                    }
                    $uids[] = $msg->uid;
                }
                $data["newmsges"] = $newmsges;
				
                $where = array(
                                "ownerid" => $uid
                                 //"isreply" => "0"
                                 );
                $groupby = "";
                $orderby = "id desc";
                //$groupby = "uid";
                /* $orderby = array(
                "field" => "date",
                "order" => "desc"
                ); */

                if($this->uri->segment("3") != "") {
                    $segment = $this->uri->segment("3");
                    $data["segment"] = $segment;
                    $where = array(
                                    "user_name" => $segment
                                );
                    $user = $this->communitymodel->getuser($where);

                    if(isset($user) && !empty($user)) {
                        $where = array(
                                        "ownerid" => $uid,
                                        "uid" => $user->id
                                    );
                    }
                }

                $messages = $this->communitymodel->getmessages($where, $groupby, $orderby);
				
				//print_r($messages); exit;

                if($this->input->post("search")) {
                    $where = "name like '%".$this->input->post("search")."%'";
                    $user = $this->communitymodel->getuser($where);
                    if(isset($user) && !empty($user)) {
                        $where = array(
                                        "ownerid" => $uid,
                                        "uid" => $user->id
                                    );
                        $messages = $this->communitymodel->getmessages($where, $groupby, $orderby);
                        if(empty($messages)) {
                            $data["emptymsg"] = "No match found";
                        }
                    }
                    else {
                        $messages = "";
                        $data['emptymsg'] = "No match found";
                    }
                }

                if(isset($messages) && !empty($messages)) {

                    $newmessages = array();
                    //$newmessagesreply = array();
                    $data["segment"] = "";
                    foreach($messages as $message) {
                        $array = (array) $message;

                        $where = array("id" => $message->uid);
                        $user = $this->communitymodel->getuser($where);
                        $array["image"] = "noavatar.png";
                        if(!empty($user)) {
                            $array["name"] = $user->user_name;
                            if(!empty($user->name)) {
                                $array["name"] = $user->name;
                            }
                            $array["user_name"] = $user->user_name;

                            if(!empty($user->image)) {
                                if(file_exists($this->config->item("user_40x40_upload_path")."/".$user->image)) {
                                    $array["image"] = $user->image;
                                }
                            }
                        }

                        $messagedate = date("Y-m-d", strtotime($message->date));
                        $todays = date("Y-m-d");
                        if($messagedate == $todays) {
                            $array["timeago"] = $this->_timeago($message->date);
                        }
                        else {
                            $array["timeago"] = date("Y-m-d", strtotime($message->date));
                        }
                        $where = array(
                                        "messageid" => $message->id
                                    );

                        $array["messagesreplies"] = $this->communitymodel->getmessagesreplies($where);

                        $object = (object) $array;
                        $newmessages[] = $object;

                        if($data["segment"] == "") {
                            $data["segment"] = $user->user_name;
                        }

                        if(!isset($data["userdisplayname"])) {
                            $data["userdisplayname"] = $user->user_name;
                            if(!empty($user->name)) {
                                $data["userdisplayname"] = $user->name;
                            }
                        }
                    }
                    for($i = 0; $i < count($messages); $i++) {
                        $messages[$i] = $newmessages[$i];
                    }
                }

                if($this->uri->segment("3") != "") {
                    $segment = $this->uri->segment("3");
                    $data["segment"] = $segment;

                    $where = array(
                                    "user_name" => $segment
                                );

                    $user = $this->communitymodel->getuser($where);
                    if(isset($user) && !empty($user)) {
                        if($user->id != $uid) {
                            $data["userdisplayname"] = $user->user_name;
                            if(!empty($user->name)) {
                                $data["userdisplayname"] = $user->name;
                            }
                        }
                        else {
                            //$data["userdisplayname"] = "";
                            redirect("community/messages");
                        }
                    }
                    else {
                        //$data["userdisplayname"] = "";
                        redirect("community/messages");
                    }
                }

                $data["owner"] = $owner;
                $data["messages"] = $messages;

                $data["page"] = "community/messages";
                $this->load->view("template/newtemplate", $data);
            }
            else {
                $this->index();
            }
        }
        else {
            $this->index();
        }
    }

    /*function newsfeed() {
    $this->freakauth_light->check();

    /* $data["newsfeeds"] = $this->communitymodel->getlatestactivities();
    foreach($data["newsfeeds"] as $newsfeed) {
    echo $this->_timeago($newsfeed->date)." ";
    } //
    //$uid = $this->db_session->userdata("id");
    $newsfeeds = $this->communitymodel->getlatestactivities();
    //$newsfeeds = $this->communitymodel->getlatestactivitiesbyuser();
    $newnewsfeeds = array();

    if(isset($newsfeeds) && $newsfeeds != "") {
    foreach ($newsfeeds as $newsfeed) {

    $array = (array) $newsfeed;

    $array["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
    $array["timeago"] = $this->_timeago($newsfeed->date);

    $object = (object) $array;
    $newnewsfeeds[] = $object;
    }

    for($i = 0; $i < count($newsfeeds); $i++) {
    $newsfeeds[$i] = $newnewsfeeds[$i];
    }
    }

    $data["newsfeeds"] = $newsfeeds;
    $data["top3recipes"] = $this->crudmodel->gettop3recipes();

    $data["page"] = "community/newsfeed";
    $this->load->view("template/newtemplate", $data);
    }*/

    function newsfeed() {
        $this->freakauth_light->check();

        /* $data["newsfeeds"] = $this->communitymodel->getlatestactivities();
        foreach($data["newsfeeds"] as $newsfeed) {
        echo $this->_timeago($newsfeed->date)." ";
        } */

        $uid = $this->db_session->userdata("id");
        $where = array(
                        "id" => $uid,
                        "user_name" => $this->db_session->userdata("user_name")
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {

            $data["user"] = $user;

            $where = array(
                            "uid"=>$user->id
                        );
            $contacts = $this->communitymodel->getcontact($where);
            if(isset($contacts) && $contacts != "") {
                $contacts = unserialize($contacts->friends);
                //print_r($contacts);
            }

            $followers = $this->communitymodel->getalluserfollowers($user->id);
            if(isset($followers) && $followers != "") {
                $followers = unserialize($followers->followers);
                /*if(isset($followers) && $followers != ""){
                    foreach($followers as $follower){
                        $followerarray[] = $follower;
                    }
                }*/
            }

            $followings = $this->communitymodel->getalluserfollowings($user->id);
            if(isset($followings) && $followings != "") {
                $followings = unserialize($followings->following);
            }
			
            $result = array();
            //$result[] = $user->id;

            /*if(is_array($contacts)) {
                $result = $contacts;
            }
            else if(is_array($followings)) {
                $result = array_merge($result,$followings);
            }
            else if(is_array($followers)) {
                $result = array_merge($result,$followers);
            } */

            if(is_array($contacts)) {
                $result = $contacts;
            }
            if(is_array($followings)) {
                $result = array_merge($result,$followings);
            }
            if(is_array($followers)) {
                $result = array_merge($result,$followers);
            }
            $result[] = $user->id;

            //echo "</br>result: "; print_r($result);

            /*if(is_array($contacts)) {
                //echo "</br>contacts: "; print_r($contacts);
                $count = count($contacts);
                for($i = 0; $i <= $count; $i++) {
                    //echo "<br>i=".$i;
                    if(isset($contacts[$i])){
                        $result[] = $contacts[$i];
                    }
                }
            }

            if(is_array($followings)) {
                //echo "</br>followings: "; print_r($followings);
                $count = count($followings);
                for($i = 0; $i < $count; $i++) {
                    if(isset($followings[$i])){
                        $result[] = $followings[$i];
                    }
                }
            }

            if(is_array($followers)) {
                //echo "</br>followers: "; print_r($followers);
                $count = count($followers);
                for($i = 0; $i < $count; $i++) {
                    if(isset($followers[$i])) {
                        $result[] = $followers[$i];
                    }
                }
            }*/

            //$result = array_merge($followers,$followings,$contacts);
            $result = array_unique($result);
			$result = array_values($result);
            //print_r($result);
            //echo "</br>-----------------------------------";
            //echo "</br>result: "; print_r($result); exit();
            //$start = $this->uri->segment("3");
            $start = 0;

            $newsfeeds = $this->communitymodel->getlatestactivitiesbyuserwherein($result, $start);
            $newnewsfeeds = array();
            if(isset($newsfeeds) && $newsfeeds != "") {
                foreach ($newsfeeds as $newsfeed) {

                    $array = (array) $newsfeed;
    
                    $array["content"] = $this->_getactivitycontent($newsfeed->uid, $newsfeed->content, $newsfeed->info);
    
                    $where = array(
                        "aid" => $newsfeed->id
                    );
                    $likes = $this->communitymodel->getactivitylikes($where);
                    $newlikes = array();
                    if(!empty($likes)) {
                        foreach($likes as $like) {
                            $likearray = (array) $like;
    
                            if($like->uid != $user->id) {
                                $where = array(
                                            "id" => $like->uid
                                            );
                                $likeuser = $this->communitymodel->getuser($where, "user_name, name");
                                if(!empty($likeuser)) {
                                    $likearray["name"] = $likeuser->user_name;
                                    if(!empty($likeuser->name)) {
                                        $likearray["name"] = $likeuser->name;
                                    }
                                }
                            }
                            else {
                                $likearray["isownerlike"] = true;
                            }
    
                            $likeobject = (object) $likearray;
                            $newlikes[] = $likeobject;
                        }
    
                        for($i = 0; $i < count($likes); $i++) {
                            $likes[$i] = $newlikes[$i];
                        }
                    }
    
                    $array["likes"] = $likes;
                    $array["likescnt"] = count($likes);
    
                    $array["timeago"] = $this->_timeago($newsfeed->date);
    
                    $where = array(
                                    "aid" => $newsfeed->id
                                );
    
                    $communitycomments = $this->communitymodel->getcommunitycomments($where);
                    $newcommunitycomments = array();
    
                    if(isset($communitycomments) && $communitycomments != "") {
                        foreach ($communitycomments as $communitycomment) {
                            $communityarray = (array) $communitycomment;
                            $communityarray["timeago"] = $this->_timeago($communitycomment->date);
                            $communityobject = (object) $communityarray;
                            $newcommunitycomments[] = $communityobject;
                        }
                    }
    
                    $array["communitycomments"] = $newcommunitycomments;
                
                    $object = (object) $array;
                    $newnewsfeeds[] = $object;
                }

                for($i = 0; $i < count($newsfeeds); $i++) {
                    $newsfeeds[$i] = $newnewsfeeds[$i];
                }
            }
            $data["newsfeeds"] = $newsfeeds;
    
            //$data["recipeofday"] = $this->crudmodel->getrecipeofday("id, title, categoryid");
            $recipeofday = $this->crudmodel->getrecipeofday("id, title, categoryid, images, seo");
            if(!empty($recipeofday)) {
                $data["recipeofday"] = $recipeofday;
                //$data["recipeofdaycategory"] = $this->crudmodel->getcategorynamebyid($recipeofday->categoryid);
            }

            //print_r(count($data["newsfeeds"])); exit();
            $data["top3recipes"] = $this->crudmodel->gettop3recipes();
			//print_r($data["top3recipes"]);exit;

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            $data["page"] = "community/newsfeed";
            $this->load->view("template/newtemplate", $data);
        }
    }

    function publicwall() {
        $this->freakauth_light->check();

        /* if($this->input->post("sbt_publicwallpost")) {
            $where = array(
                        "user_name" => base64_encode($this->db_session->userdata("user_name"))
            );

            $membership = $this->communitymodel->getmembership($where);
            if(!empty($membership)) {

                $haveposts = false;
                $data["isexpired"] = false;
                if($membership->type == "1") {
                    if($membership->posts > 0 && $membership->posts <= 10) {
                        $haveposts = true;
                    }
                }
                else if($membership->type == "2") {
                    $haveposts = true;
                }

                if($haveposts) {
                    $today = date("Y-m-d H:i:s");
                    if($today <= $membership->enddate) {
                        $data["publicwall"] = "1";
                    }

                $posttype = $this->input->post("publicwallposttype");
                if($posttype == "article") {
                    $info = array(
                                "article" => $this->input->post("publicwallpost")
                            );
                }
                else if($posttype == "group") {
                    $info = array(
                        "group" => $this->input->post("publicwallpost")
                    );
                }
                else if($posttype == "competition") {
                    $info = array(
                                "competition" => $this->input->post("publicwallpost")
                            );
                }
                else if($posttype == "event") {
                    $info = array(
                            "event" => $this->input->post("publicwallpost")
                    );
                }
                else if($posttype == "advertisement") {
                    $info = array(
                                "advertisement" => $this->input->post("publicwallpost")
                            );
                }

                $activity = array(
                                "uid" => $this->db_session->userdata("id"),
                                "content" => $this->config->item($posttype),
                                "info" => serialize($info),
                                "date" => $today,
                                "isnotified" => "0"
                            );
                if($this->communitymodel->addpublicwallactivity($activity) > 0) {
                    if($membership->type == "1") {
                        $posts = $membership->posts;
                        $posts = $posts - 1;

                        $updatemembership = array(
                                                "posts" => $posts
                                            );
                        $where = array(
                                        "id" => $membership->id,
                                        "type" => $membership->type,
                                        "user_name" => $membership->user_name
                                    );

                        $this->communitymodel->updatemembership($where, $updatemembership);

                        if($posts <= 0) {
                            $user = array(
                                        "publicwall" => "0"
                                    );
                            $where = array(
                                            "id" => $this->db_session->userdata("id")
                                        );
                            $this->communitymodel->updateuser($user, $where);
                        }
                    }

                    //$this->output->enable_profiler(true);
                    header("Location: ".base_url()."community/publicwall");
                }
            }
        }
    }
    else */

        $where = array(
                        "id" => $this->db_session->userdata("id")
                    );
        $user = $this->communitymodel->getuser($where);
        if(!empty($user)) {
            $data["user"] = $user;
            $data["uid"] = $user->id;

            //if($this->input->post("sbt_publicwallpost") || $this->input->post("sbt_publicwallotherpost")) {
            if($this->input->post("sbt_publicwallpost")) {
                $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
                $membership = $this->communitymodel->getmembership($where);
                if(!empty($membership)) {
                    $haveposts = false;
                    $data["isexpired"] = false;
                    if($membership->type == "1") {
                        if($membership->posts > 0 && $membership->posts <= 10) {
                            $haveposts = true;
                        }
                    }
                    else if($membership->type == "2") {
                        $haveposts = true;
                    }
                    if($haveposts) {
                        $today = date("Y-m-d H:i:s");
                        if($today <= $membership->enddate) {
                            $data["publicwall"] = "1";
                            $publicwalluploadpath = $this->config->item("publicwall_image_upload_path");
                            $imagestypes = array(
                                                "publicwall_image_250x250_upload_path" => $this->config->item("publicwall_image_250x250_upload_path")
                                            );
                            $posttype = $this->input->post("posttype");
                            if(!empty($posttype)) {
                                if($posttype == "article") {
                                    $info = array(
                                                    "article" => $this->input->post("publicwallpost")
                                                );
                                    $publicwalluploadpath = $this->config->item("publicwall_image_article_upload_path");
                                    $imagestypes = array(
                                                        "publicwall_image_article_250x250_upload_path" => $this->config->item("publicwall_image_article_250x250_upload_path")
                                                    );
                                }
                                else if($posttype == "group") {
                                    $info = array(
                                                    "group" => $this->input->post("publicwallpost")
                                                );
                                    $publicwalluploadpath = $this->config->item("publicwall_image_group_upload_path");
                                    $imagestypes = array(
                                                        "publicwall_image_group_250x250_upload_path" => $this->config->item("publicwall_image_group_250x250_upload_path")
                                                    );
                                }
                                else if($posttype == "competition") {
                                    $info = array(
                                                    "competition" => $this->input->post("publicwallpost")
                                                );
                                    $publicwalluploadpath = $this->config->item("publicwall_image_competition_upload_path");
                                    $imagestypes = array(
                                                        "publicwall_image_competition_250x250_upload_path" => $this->config->item("publicwall_image_competition_250x250_upload_path")
                                                    );
                                }
                                else if($posttype == "event") {
                                    $info = array(
                                                    "event" => $this->input->post("publicwallpost")
                                                );
                                    $publicwalluploadpath = $this->config->item("publicwall_image_event_upload_path");
                                    $imagestypes = array(
                                                        "publicwall_image_event_250x250_upload_path" => $this->config->item("publicwall_image_event_250x250_upload_path")
                                                    );
                                }
                                else if($posttype == "advertisement") {
                                    $info = array(
                                                    "advertisement" => $this->input->post("publicwallpost")
                                                );
                                    $publicwalluploadpath = $this->config->item("publicwall_image_advertisement_upload_path");
                                    $imagestypes = array(
                                                        "publicwall_image_advertisement_250x250_upload_path" => $this->config->item("publicwall_image_advertisement_250x250_upload_path")
                                                    );
                                }

                                $image = "";
                                $postwithimage = $this->input->post("postwithimage");
                                if($postwithimage == "true") {
                                    // TODO
                                    // do image uploading

                                    if(isset($_FILES["userfile"]["name"]) && $_FILES["userfile"]["name"] != "") {
                                        //$publicwalluploadpath = $this->config->item("publicwall_image_upload_path");
                                        $config = array(
                                                        "upload_path" => $publicwalluploadpath,
                                                        "allowed_types" => "jpg|jpeg|gif|png"
                                                    );

                                        $filename = $_FILES["userfile"]["name"];
                                        $filename = explode(".", $filename);
                                        $filename[0] = $filename[0].time().".".$filename[1];
                                        $_FILES["userfile"]["name"] = $filename[0];

                                        $this->load->library("upload" , $config);
                                        if($this->upload->do_upload()) {
                                            $image_data = $this->upload->data();
                                            $this->load->library("image_lib");
                                            foreach ($imagestypes as $imagetype) {
                                                $width = 200;
                                                $heigth = 200;
                                                //if($imagetype == $this->config->item("publicwall_image_250x250_upload_path")) {
                                                if(strpos($imagetype, "250x250") !== false) {
                                                    $width = 250;
                                                    $heigth = 250;
                                                }

                                                $config = array(
                                                                "source_image" => $image_data["full_path"],
                                                                "new_image" => $imagetype,
                                                                "maintain_ration" => true,
                                                                "width" => $width,
                                                                "height" => $heigth
                                                            );

                                                $this->image_lib->initialize($config);
                                                $this->image_lib->resize();
                                            }
                                            $image = $image_data["file_name"];
                                        }
                                        else {
                                            //$this->upload->display_errors();
                                        }
                                    }
                                }

                                $video = "";
                                $postwithvideo = $this->input->post("postwithvideo");
                                if($postwithvideo == "true") {
                                    $video = $this->input->post("video" );
                                }

                                $info["link"] = $this->input->post("link");
                                $info["linktitle"] = $this->input->post("linktitle");
                                $info["linkdescription"] = "";
                                $linkdescription = $this->input->post("linkdescription");
                                if($linkdescription != "Enter a description" ) {
                                    $info["linkdescription"] = $this->input->post("linkdescription");
                                }
                                $info["linkimage"] = $this->input->post("linkimage");
                                $info["isvideolink"] = $this->input->post("isvideolink");

                                $info["image"] = $image;
                                $info["video"] = $video;

                                $activity = array(
                                                "uid" => $user->id,
                                                "content" => $this->config->item($posttype),
                                                "info" => serialize($info),
                                                "date" => $today,
                                                "isnotified" => "0"
                                            );
                                if($this->communitymodel->addpublicwallactivity($activity) > 0) {
                                    if($membership->type == "1") {
                                        $posts = $membership->posts;
                                        $posts = $posts - 1;
                                        $updatemembership = array(
                                                                    "posts" => $posts
                                                                );
                                        $where = array(
                                                        "id" => $membership->id,
                                                        "type" => $membership->type,
                                                        "user_name" => $membership->user_name
                                                    );

                                        $this->communitymodel->updatemembership($where, $updatemembership);

                                        if($posts <= 0) {
                                            $user = array(
                                                        "publicwall" => "0"
                                                    );
                                            $where = array(
                                                        "id" => $this->db_session->userdata("id")
                                                    );
                                            $this->communitymodel->updateuser($user, $where);
                                        }
                                    }

                                    //$this->output->enable_profiler(true);
                                    header("Location: ".base_url()."community/publicwall");
                                }
                            }
                        }
                        else {
                            $data["isexpired"] = true;
                            $data["publicwallinfo"] = true;
                            $data["publicwall"] = "0";
                            $updateuser = array(
                                                "publicwall" => "0"
                                            );
                            $where = array(
                                            "id" => $user->id
                                        );
                            $this->communitymodel->updateuser($updateuser, $where);

                            if($membership->type == "1") {
                                $where = array(
                                                "id" => $membership->id,
                                                "type" => $membership->type,
                                                "user_name" => $membership->user_name
                                            );
                                $updatemembership = array(
                                                        "posts" => 0
                                                    );

                                $this->communitymodel->updatemembership($where, $updatemembership);
                            }
                        }
                    }
                }
                else {
                    $data["publicwallinfo"] = true;
                }
            }
            else {
                if($user->publicwall == "1") {
                    $where = array(
                                    "user_name" => base64_encode($user->user_name)
                                );
                    $membership = $this->communitymodel->getmembership($where);
                    if(!empty($membership)) {
                        $data["membership"] = $membership;
                        $today = date("Y-m-d H:i:s");
                        if($today > $membership->enddate) {
                            $data["publicwall"] = "0";
                            $data["isexpired"] = true;
                            if($user->id == $this->db_session->userdata("id")) {
                                $updateuser = array(
                                                    "publicwall" => "0"
                                                );
                                $where = array(
                                                "id" => $user->id
                                            );
                                $this->communitymodel->updateuser($updateuser, $where);

                                if($membership->type == "1") {
                                    $where = array(
                                                "id" => $membership->id,
                                                "type" => $membership->type,
                                                "user_name" => $membership->user_name
                                            );
                                    $updatemembership = array(
                                                        "posts" => 0
                                                    );

                                    $this->communitymodel->updatemembership($where, $updatemembership);
                                }
                            }
                        }
                        else {
                            $data["publicwall"] = "1";
                        }
                    }
                    else {
                        $data["publicwall"] = "0";
                    }
                }
                else {
                    $data["publicwall"] = $user->publicwall;
                }
            }

            if($this->uri->segment("3") == "membership") {
                $data["publicwallinfo"] = true;
                if($this->uri->segment("5") != "") {
                    $data["upgrade"] = $this->uri->segment("5");
                }
            }
			$like = '';
			$where = '';
			$sort = '';
			if($this->input->post('search')){
				if($this->input->post('serachtext')){
					$searchText = $this->input->post('serachtext');
					$like = array('description'=>$searchText);
				}
				if($this->input->post('category')){
					$category = $this->input->post('category');
					$where = array('category'=>$category);
				}
				if($this->input->post('sort')){
					$sort = $this->input->post('sort');
				}			
			}
    
            $activities = $this->communitymodel->getpublicwallactivities($like,$where,$sort);
			
            $newactivities = array();

            if(!empty($activities)) {
                foreach ($activities as $activity) {
                    $array = (array) $activity;
    
                    $where = array(
                                    "id" => $activity->uid
                                );
                    $activityuser = $this->communitymodel->getuser($where);
    
                    $userimg = "noavatar.png";

                    if(!empty($activityuser)) {
                        $array["name"] = $activityuser->user_name;
                        if(!empty($activityuser->name)) {
                            $array["name"] = $activityuser->name;
                        }
    
                        $array["user_name"] = $activityuser->user_name;
    
                        if($activityuser->image != "") {
                            $userimg = $activityuser->image;
                        }
                    }

                    $array["image"] = $userimg;
                    $array["content"] = $this->_getactivitycontent($activity->uid, $activity->content, $activity->info);
                    $array["info"] = unserialize($activity->info);
                    $array["type"] = $activity->content;
    
                    $where = array(
                                    "aid" => $activity->id
                                );
                    $likes = $this->communitymodel->getpublicwalllikes($where);
                    $newlikes = array();
                    if(!empty($likes)) {
                        foreach($likes as $like) {
                            $likearray = (array) $like;
                            if($like->uid != $user->id) {
                                $where = array(
                                            "id" => $like->uid
                                        );
                                $likeuser = $this->communitymodel->getuser($where, "user_name, name");
    
                                if(!empty($likeuser)) {
                                    $likearray["name"] = $likeuser->user_name;
                                    if(!empty($likeuser->name)) {
                                        $likearray["name"] = $likeuser->name;
                                    }
                                }
                            }
                            else {
                                $likearray["isownerlike"] = true;
                            }
                            $likeobject = (object) $likearray;
                            $newlikes[] = $likeobject;
                        }
    
                        for($i = 0; $i < count($likes); $i++) {
                            $likes[$i] = $newlikes[$i];
                        }
                    }

                    $array["likes"] = $likes;
                    //$array["likescnt"] = $this->communitymodel->getpublicwalllikecounts(array("aid" => $activity->id));
                    $array["likescnt"] = count($likes);
    
                    $array["timeago"] = $this->_timeago($activity->date);
    
                    $where = array(
                                    "aid" => $activity->id
                                );
    
                    $publicwallcomments = $this->communitymodel->getpublicwallcomments($where);
                    $newpublicwallcomments = array();

                    if(!empty($publicwallcomments)) {
                        foreach ($publicwallcomments as $publicwallcomment) {
                            $publicwallarray = (array) $publicwallcomment;
                            $publicwallarray["timeago"] = $this->_timeago($publicwallcomment->date);;

                            $publicwallobject = (object) $publicwallarray;
                            $newpublicwallcomments[] = $publicwallobject;
                        }
                    }

                    $array["publicwallcomments"] = $newpublicwallcomments;

                    $object = (object) $array;
                    $newactivities[] = $object;
                }

                for($i = 0; $i < count($activities); $i++) {
                    $activities[$i] = $newactivities[$i];
                }
            }

            $data["activities"] = $activities;

            $data["page"] = "community/publicwall";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }

    function _generateRandomString($length = 32) {
        $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $randomString = "";
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    /**
    * function is used to seprate url for the given text and return url with anchor tag as well as remainning string as it is
    * @param $text text string containing url
    */
    /* function _separateurl($text) {
    $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";

    if(preg_match($reg_exUrl, $text, $url)) {
    $url_link = $url[0];
    $src = $this->_seturlimage($url[0]);
    if(!empty($src))
    {
    $url_link = "<img src='".$src."'>";
    }
    return preg_replace($reg_exUrl, "<a id='urlcontent' href='".$url[0]."' target ='_blank' class='livepreview' title='".$url[0]."'>".$url_link."</a>", $text);
    } else {
    $src = $this->_seturlimage($text);
    if(strlen(strstr($text,'http'))===0){
    $text = "http://".$text;
    }

    //return $text;
    return "<a id='urlcontent' href='".$text."' target ='_blank' class='livepreview' title='".$text."'><img src='".$src."'></a>";
    }
    } */

    function _separateurl($text) {
        $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
        //if(preg_match($reg_exUrl, $text, $url)) {
        if(strpos($text, "://") !== false || strpos($text, "http") !== false || strpos($text, "https") !== false || strpos($text, "ftp") !== false || strpos($text, "ftps") !== false) {
            //$url_link = $url[0];
            //$src = $this->_seturlimage($url[0]);
            $src = $this->_seturlimage($text);
            if(!empty($src)) {
                $url_link = "<img src='".$src."'>";
            }
            //return preg_replace($reg_exUrl, "<a id='urlcontent' href='".$url[0]."' target ='_blank' class='livepreview' title='".$url[0]."'>".$url_link."</a>", $text);
            return "<a id='urlcontent' href='".$text."' target ='_blank' class='livepreview' title='".$text."'><img src='".$src."'></a>";
        }else{
        	return $text;
        }
        /* else {
            $src = $this->_seturlimage($text);
            if(strlen(strstr($text, 'http'))===0) {
                $text = "http://".$text;
            }

            //return $text;
            return "<a id='urlcontent' href='".$text."' target ='_blank' class='livepreview' title='".$text."'><img src='".$src."'></a>";
        } */
    }

    function _seturlimage($link="") {
        //return base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png";
        if(strpos($link, "://") !== false || strpos($link, "http") !== false || strpos($link, "https") !== false) {
            //echo "</br>1";
            //echo "</br>link: ".$link;
            if(strpos($link, "http") == 0) {
                //echo "</br>2<pre>";
                $contents = @file_get_contents($link);
                //var_dump($http_response_header);
                if(isset($http_response_header) && !empty($http_response_header)) {
                    if(strpos($http_response_header[0], "404") == false || strpos($http_response_header[0], "302") == false) {
                        //echo "</br>if";
                        //exit();
                        //echo "</br>3";
                        //$file = fopen($link, "r");
                        //$link = "https://www.foodlips.com/recipes/recipe/";
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
                        curl_setopt($ch, CURLOPT_URL, $link);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        /* $result = curl_exec($ch);
                        if ( $result==false ) {
                        echo curl_errno($ch).' '.curl_error($ch);
                        } */
                        $file = curl_exec($ch);
                        //$link = "https://www.foodlips.com/recipes/recipe/";
                        //echo "</br>link: $link </br>file: ".$file; exit();
                        //echo "link: ".$link; exit();
                        curl_close($ch);
                        //exit();
                        if(!empty($file)) {
                            //echo "</br>4"; exit();
                            //while (!feof($file)) {
                            foreach(preg_split("/((\r?\n)|(\r\n?))/", $file) as $line) {
                                //echo "</br>line: ".$line;
                                //$line = fgets ($file, 1024);
                                if (preg_match ("/<img[^>]+>/i", $line, $out)) {
                                    if(strpos($link, "recipe") !== false || strpos($link, "community") !== false || strpos($link, "recipes") !== false ) {
                                        if(preg_match('@src="([^"]+)"@', $out[0], $match)) {
                                            $imgsrc = substr($match[0], 5, -1);
                                        }
                                        elseif(preg_match("@src='([^']+)'@", $out[0], $match)) {
                                            $imgsrc = substr($match[0], 5, -1);
                                        }
    
                                        if(strpos($imgsrc, "frontend/images/recipe/650x350/") !== false || strpos($imgsrc, "frontend/images/recipe/1004x400/") !== false ||
                                            strpos($imgsrc, "frontend/images/group/200x200/") !== false || strpos($imgsrc, "frontend/images/user/250x250/") !== false) {
                                            break;
                                        }
                                        else {
                                            $imgsrc = "";
                                        }
                                    }
                                    else {
                                        if(preg_match('@src="([^"]+)"@', $out[0], $match)) {
                                            $imgsrc = substr($match[0], 5, -1);
                                        }
                                        elseif(preg_match("@src='([^']+)'@", $out[0], $match)) {
                                            $imgsrc = substr($match[0], 5, -1);
                                        }
                                        //echo "</br>src: ".$imgsrc;
                                        //break;
                                        //$file = fopen($imgsrc, "r");
                                        if(!empty($imgsrc)) {
                                            break;
                                        }
                                    }
                                }
                            }
                            //fclose($file);
                        }
                        else {
                            /* echo "</br>else";
                            exit(); */
                        }
                    }
                    else {
                        //echo "</br>else";
                        //exit();
                    }
                }
                else {
                    //echo "</br>else";
                    //exit();
                }
            }
        }
        /* else {
        $reg_exUrl = "/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
        if(preg_match($reg_exUrl, $link, $url)) {
        $file = fopen ("http://".$url[0], "r");
        }
        else {
        return "";
        }
        } */

        if(isset($imgsrc) && !empty($imgsrc)) {
            return $imgsrc;
        }

        //return base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png";
        return base_url()."public/frontend/images/recipe/275x198/preview-not-available.jpg";
    }

    /* function createThumbs( $pathToImages, $pathToThumbs, $thumbWidth ) {
    // open the directory
    $dir = opendir( $pathToImages );

    // loop through it, looking for any/all JPG files:
    while (false !== ($fname = readdir( $dir ))) {
    // parse path for the extension
    $info = pathinfo($pathToImages . $fname);
    // continue only if this is a JPEG image
    if ( strtolower($info['extension']) == 'jpg' ) {
    echo "Creating thumbnail for {$fname} <br />";

    // load image and get image size
    $img = imagecreatefromjpeg( "{$pathToImages}{$fname}" );
    $width = imagesx( $img );
    $height = imagesy( $img );

    // calculate thumbnail size
    $new_width = $thumbWidth;
    $new_height = floor( $height * ( $thumbWidth / $width ) );

    // create a new temporary image
    $tmp_img = imagecreatetruecolor( $new_width, $new_height );

    // copy and resize old image into new image
    imagecopyresized( $tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height );

    // save thumbnail into a file
    imagejpeg( $tmp_img, "{$pathToThumbs}{$fname}" );
    }
    }
    // close the directory
    closedir( $dir );

    // call createThumb function and pass to it as parameters the path
    // to the directory that contains images, the path to the directory
    // in which thumbnails will be placed and the thumbnail's width.
    // We are assuming that the path will be a relative path working
    // both in the filesystem, and through the web for links

    //createThumbs("upload/","upload/thumbs/",100);
    } */

    function linkimage() {
        $this->load->view("linkpreview");
    }

    function highlightUrls() {
        error_reporting(false);
        $text = $_GET["text"];
        $description = $_GET["description"];
        $text = " " . str_replace("\n", " ", $text);
        $description = " " . str_replace("\n", " ", $description);

        $urlRegex = "/(https?\:\/\/|\s)[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})(\/+[a-z0-9_.\:\;-]*)*(\?[\&\%\|\+a-z0-9_=,\.\:\;-]*)?([\&\%\|\+&a-z0-9_=,\:\;\.-]*)([\!\#\/\&\%\|\+a-z0-9_=,\:\;\.-]*)}*/i";
        $currentUrl = "";

        if (preg_match_all($urlRegex, $text, $matches)) {
            for ($i = 0; $i < count($matches[0]); $i++) {
                $currentUrl = $matches[0][$i];
                if ($currentUrl[0] == " ")
                    $currentUrl = "http://" . substr($currentUrl, 1);
                $text = str_replace($matches[0][$i], "<a href='" . $currentUrl . "' target='_blank'>" . $matches[0][$i] . "</a>", $text);
            }
        }

        if (preg_match_all($urlRegex, $description, $matches)) {
            $matches[0] = array_unique($matches[0]);
            $matches[0] = array_values($matches[0]);
            for ($i = 0; $i < count($matches[0]); $i++) {
                $currentUrl = $matches[0][$i];
                if ($currentUrl[0] == " ")
                    $currentUrl = "http://" . substr($currentUrl, 1);
                $description = str_replace($matches[0][$i], "<a href='" . $currentUrl . "' target='_blank' >" . $matches[0][$i] . "</a>", $description);
            }
        }

        $answer = array("urls" => $text, "description" => $description);

        echo json_encode($answer);
    }

    /* function saveDataURL() {
    $dataURL = $_POST["dataURL"];
    $encodedData = explode(',', $dataURL);
    $decodedData = base64_decode($encodedData);
    file_put_contents(base_url()."public/linkpreview/img/urltest.png", $decodedData);
    echo base_url()."public/linkpreview/img/urltest.png";
    }

    function geturldata() {
    if (preg_match($urlRegex, $text, $match)) {
    $raw = "";
    $title = "";
    $images = "";
    $description = "";
    $videoIframe = "";
    $finalUrl = "";
    $finalLink = "";
    $video = "no";

    if (strpos($match[0], " ") === 0)
    $match[0] = "http://" . substr($match[0], 1);

    $finalUrl = $match[0];
    $pageUrl = str_replace("https://", "http://", $finalUrl);

    if (isImage($pageUrl)) {
    $images = $pageUrl;
    }
    else {
    $urlData = getPage($pageUrl);
    if (!$urlData["content"] && strpos($pageUrl, "//www.") === false) {
    if (strpos($pageUrl, "http://") !== false)
    $pageUrl = str_replace("http://", "http://www.", $pageUrl);
    elseif (strpos($pageUrl, "https://") !== false)
    $pageUrl = str_replace("https://", "https://www.", $pageUrl);
    $urlData = getPage($pageUrl);
    }

    $pageUrl = $finalUrl = $urlData["url"];
    $raw = $urlData["content"];
    $hdr = $urlData["header"];

    $metaTags = getMetaTags($raw);

    $tempTitle = extendedTrim($metaTags["title"]);
    if ($tempTitle != "")
    $title = $tempTitle;

    if ($title == "") {
    if (preg_match("/<title(.*?)>(.*?)<\/title>/i", str_replace("\n", " ", $raw), $matching))
    $title = $matching[2];
    }

    $tempDescription = extendedTrim($metaTags["description"]);
    if ($tempDescription != "")
    $description = $tempDescription;
    else
    $description = crawlCode($raw);

    if ($description != "")
    $descriptionUnderstood = true;

    if (($descriptionUnderstood == false && strlen($title) > strlen($description) && !preg_match($urlRegex, $description) && $description != "" && !preg_match('/[A-Z]/', $description)) || $title == $description) {
    $title = $description;
    $description = crawlCode($raw);
    }

    $images = extendedTrim($metaTags["image"]);
    $media = array();

    if (strpos($pageUrl, "youtube.com") !== false) {
    $media = mediaYoutube($pageUrl);
    $images = $media[0];
    $videoIframe = $media[1];
    }
    else if (strpos($pageUrl, "vimeo.com") !== false) {
    $media = mediaVimeo($pageUrl);
    $images = $media[0];
    $videoIframe = $media[1];
    }

    if ($images == "") {
    $images = getImages($raw, $pageUrl, $imageQuantity);
    }

    if ($media != null && $media[0] != "" && $media[1] != "")
    $video = "yes";

    $title = extendedTrim($title);
    $pageUrl = extendedTrim($pageUrl);
    $description = extendedTrim($description);

    $description = preg_replace("/<script(.*?)>(.*?)<\/script>/i", "", $description);
    }

    $finalLink = explode("&", $finalUrl);
    $finalLink = $finalLink[0];

    $answer = array("title" => $title, "titleEsc" => $title, "url" => $finalLink, "pageUrl" => $finalUrl, "cannonicalUrl" => cannonicalPage($pageUrl), "description" => strip_tags($description), "descriptionEsc" => strip_tags($description), "images" => $images, "video" => $video, "videoIframe" => $videoIframe);

    echo json_safe($answer, $hdr);
    }
    } */

    /* function _seturlimage($text){

    if(strlen(strstr($text,'http'))>0)
    {

    $file = fopen ($text, "r");
    }
    else {
    $reg_exUrl = "/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
    if(preg_match($reg_exUrl, $text, $url))
    {
    $file = fopen ("http://".$url[0], "r");
    }
    else{
    return "";
    }
    }
    while (!feof ($file)) {
    $line = fgets ($file, 1024);

    if (preg_match ("/<img[^>]+>/i", $line, $out)) {

    if(preg_match( '@src="([^"]+)"@' , $out[0] , $match ))
    {
    $imgsrc = substr($match[0],5,-1);
    }
    elseif(preg_match( "@src='([^']+)'@" , $out[0] , $match ))
    {
    $imgsrc = substr($match[0],5,-1);
    }

    break;
    }
    }
    fclose($file);

    return $imgsrc;
    exit;
    } */
    
	/*
	 * Note: 1. Anchor tag befor any image tag having data-lightbox attribute is for image preview
	 * */
    function _getactivitycontent($uid, $content, $info) {
        $activity = "";

        if(isset($uid) && $uid != "" && isset($content) && $content != "" && isset($info) && $info != "") {

           // $info = preg_replace_callback('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $info);
            $info = preg_replace_callback ( '!s:(\d+):"(.*?)";!', function($match) {
                return ($match[1] == strlen($match[2])) ? $match[0] : 's:' . strlen($match[2]) . ':"' . $match[2] . '";';
            },$info );
            $info = unserialize($info);

            if($content == $this->config->item("new_group")) {
                $activity = "Created group </br> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>. </br>";
            }
            else if($content == $this->config->item("group_join")) {
                $activity = "Joined group </br> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>. </br>";
            }
            else if($content == $this->config->item("group_wall_post")) {
                $activity = "Posted on </br> <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a> wall. </br>";
            }
            else if($content == $this->config->item("new_question")) {
                $activity = "Asked new question </br> <a href='".base_url()."community/question/".$info["gseo"]."'>".$info["question"]."</a> </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>. </br>";
            }
            else if($content == $this->config->item("reply_on_question")) {
                $activity = "Replied on question </br> <a href='".base_url()."community/question/".$info["gseo"]."'>".$info["question"]."</a> </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>. </br>";
            }
            else if($content == $this->config->item("are_now_friends")) {
                //$activity = "<a href='".base_url()."community/profile/".$info["acceptinguser_username"]."'>".$info["acceptinguser_name"]."</a>".""." and <a href='".base_url()."community/profile/".$info["requestinguser_username"]."'>".$info["requestinguser_name"]."</a> are now friends.";
                $activity = " and <a href='".base_url()."community/profile/".$info["requestinguser_username"]."'>".$info["requestinguser_name"]."</a> are now friends. </br>";
            }
            else if($content == $this->config->item("new_poll")) {
                $activity = "</br> Submitted poll under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>. </br>";
            }
            else if($content == $this->config->item("comment_on_activity")) {
                if($uid != $info["uid"]) {
                    $activity = "Commented on </br> <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["name"]."'s</a> activity. </br>";
                }
            }
            else if($content == $this->config->item("recipe_like")) {
                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
                //$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
                //$activity = "Liked <a href='".base_url()."recipe/details/".$categoryname."/".$recipe->title."'>".$recipe->title."</a>";
                if(!empty($recipe)) {
                    $activity = "Liked recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
                    if($recipe->images != "") {
                        $images = explode(",", $recipe->images);
                        if(count($images)) {
                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
                            	
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title'/>";
								$activity .="</a>";
                            }
                            else {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'/>";
								$activity .="</a>";
                            }
                        }
                    }
                    else {
                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'/>";
                        $activity .= "</a>";
                    }
                }
            }
            else if($content == $this->config->item("recipe_made")) {
                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
                if(!empty($recipe)) {
                    $activity = "Made recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
                    if($recipe->images != "") {
                        $images = explode(",", $recipe->images);
                        if(count($images)) {
                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
                            	
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title'/>";
								$activity .= "</a>";
                            }
                            else {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'>";
								$activity .= "</a>";
                            }
                        }
                    }
                    else {
                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'>";
                        $activity .= "</a>";
                    }
                }
            }
            else if($content == $this->config->item("recipe_favorite")) {
                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
                if(!empty($recipe)) {
                    $activity = "Favorite recipe <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a>";
                    if($recipe->images != "") {
                        $images = explode(",", $recipe->images);
                        if(count($images)) {
                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title'>";
								$activity .="</a>";
                            }
                            else {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'>";
								$activity .="</a>";
                            }
                        }
                    }
                    else {
                    	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'>";
                        $activity .= "</a>";
                    }
                }
            }
            else if($content == $this->config->item("recipe_comment")) {
                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
                if(!empty($recipe)) {
                    //$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
                    //$activity = "Commented on <a href='".base_url()."recipe/details/".$categoryname."/".$recipe->title."'>".$recipe->title."</a>";
                    $activity = "Commented on </br> <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
                    if($recipe->images != "") {
                        $images = explode(",", $recipe->images);
                        if(count($images)) {
                            if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title'>";
								$activity .= "</a>";
                            }
                            else {
                            	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                                $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title'>";
								$activity .= "</a>";
                            }
                        }
                    }
                }
            }
            else if($content == $this->config->item("recipe_submitted")) {
                $recipe = $this->crudmodel->getrecipebyid($info["recipeid"]);
                if(!empty($recipe)) {
                    if($recipe->approved == "1") {
                        //$categoryname = $this->crudmodel->getcategorynamebyid($recipe->categoryid);
                        //$activity = "Submitted recipe <a href='".base_url()."recipe/details/".$categoryname."/".$recipe->title."'>".$recipe->title."</a>";
                        $activity = "Submitted recipe </br> <a href='".base_url()."recipe/details/".$recipe->seo."'>".$recipe->title."</a> </br>";
                        if($recipe->images != "") {
                            $images = explode(",", $recipe->images);
                            if(count($images)) {
                                if(file_exists($this->config->item("recipe_detail_upload_path")."/".$images[0])) {
                                	$activity .= "<a href='".base_url()."public/frontend/images/recipe/$images[0]' data-lightbox='$recipe->title'>";
                                    $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/$images[0]' alt='$recipe->title' title='$recipe->title'>";
									$activity .= "</a>";
                                }
                                else {
                                	$activity .= "<a href='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' data-lightbox='$recipe->title'>";
                                    $activity .= "<img src='".base_url()."public/frontend/images/recipe/275x198/defaultrecipe.png' alt='$recipe->title' title='$recipe->title>";
									$activity .= "</a>";
                                }
                            }
                        }
                    }
                }
            }
            else if($content == $this->config->item("share_link")) {
                //echo "</br>con: ".$content." ".$info["link"];
                if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                	$src = $this->_seturlimage($info["link"]);
                    //echo "</br>src: ".$src;
                    $activity = "Shared <a href='".$info["link"]."'>link</a> ";
                    if(!empty($src)) {
                        $activity .= "<a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50'></a>";
						//$activity .= "<script type='text/javascript' src='http://grabz.it/services/javascript.ashx?key=Mzg1YjMzYTM3MTk4NGVjYWI4MDJhYmVkNDEwN2U4ZWQ=&url=".$info["link"]."'></script>";
                    }
                }
                //else {
                    /* $src = $this->_seturlimage($info["link"]);
                    $activity = "Shared link <a href='http://".$info["link"]."'>Link</a>";
                    if(!empty($src)) {
                        $activity .= "<br><a id='urlcontent' href='http://".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50'></a>";
                    } */
                //}
            }
			else if($content == $this->config->item("profile_wall_post")) {
				if($uid == $info["uid"]) {
					//echo $this->_separateurl($info["status"]);
					if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
						//$exlink = preg_replace('/(https?|ssh|ftp):\/\/[^\s"]+/','<br /><a href="$0" target="_blank" style="color: #A90101;">$0</a>', $info["link"]);
						
						$activity = "Posted a <a href='".$info["link"]."' style='color: #A90101;'>Link</a>";
						//$activity = "Posted ".$exlink;
						$activity .= "<p>".$info["status"]."</p>";
						$activity .= "<div class='previewImagesPosted'>";
						$activity .= "<div class='previewImagePosted'>";
						$activity .= "<img src='".$info["linkimage"]."' class='imgIframe' />";
						if($info["isvideolink"] == "yes") {
							$activity .= "<span class='videoPostPlay'></span>";
						}
						$activity .= "</div>";
						$activity .= "</div>";
						$activity .= "<div class='previewContentPosted'>";
						$activity .= "<div class='previewTitlePosted'>";
						//$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
						$activity .= "<a target='_blank' href='".$info["link"]."'>";
						$activity .= "<span style='color: #A90101;'>".$info["linktitle"]."</span>";
						$activity .= "</a>";
						$activity .= "</div>";
						$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
						$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
						$activity .= "</div>";
						$activity .= "<div style='clear: both'></div>";
						if(!empty($info["image"])) {
							//$activity .= "</br>Image</br><a href='".$info["link"]."' target='_blank'><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' width='250' height='250' /></a></br> on self wall";
							$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
							$activity.= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."'/> </a>";
						}
					}
					else {
						$activity = "Posted ". $info["status"];
						if(!empty($info["image"])) {
							$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
							$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."'/></a>";
						}
					}
					
					if(!empty($info["video"])) {
						$activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
					}
					$activity .= " on self wall";
				}
				else{
					$where = array("id" => $uid);
					$user = $this->communitymodel->getuser($where);
					if(!empty($user)) {
						$name = $user->user_name;
						if(!empty($user->name)) {
							$name = $user->name;
						}
						if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
							//$exlink = preg_replace('/(https?|ssh|ftp):\/\/[^\s"]+/','<br /><a href="$0" target="_blank" style="color: #A90101;">$0</a>', $info["link"]);
							
							$activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
							$activity .= "Posted a <a href='".$info["link"]."' style='color: #A90101;'>Link</a>";
							$activity .= "<p>".$info["status"]."</p>";
							
							$activity .= "<div class='previewImagesPosted'>";
							$activity .= "<div class='previewImagePosted'>";
							$activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
							if($info["isvideolink"] == "yes") {
								$activity .= "<span class='videoPostPlay'></span>";
							}
							$activity .= "</div>";
							$activity .= "</div>";
							$activity .= "<div class='previewContentPosted'>";
							$activity .= "<div class='previewTitlePosted'>";
							//$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
							$activity .= "<a target='_blank' href='".$info["link"]."'>";
							$activity .= "<span>".$info["linktitle"]."</span>";
							$activity .= "</a>";
							$activity .= "</div>";
							$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
							$activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
							$activity .= "</div>";
							$activity .= "<div style='clear: both'></div>";
							if(!empty($info["image"])) {
								$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
								$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /></a>";
								//$activity .= "<br />on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall </br>";
							}
						}
						else {
							$activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a> Posted ".$info["status"];
							//$activity = "Posted </br>". $info["status"];
							if(!empty($info["image"])) {
								$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/postonwall/original/".$info["image"]."' data-lightbox='".$info["image"]."'>";
								$activity .= "<img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."'/> </a>";
							}
						}
						if(!empty($info["video"])) {
							$activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
						}
						$activity .= "on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall";
                    }
				}
			}
            
          /*  else if($content == $this->config->item("profile_wall_post")) {
                if($uid == $info["uid"]) {
                	if($info["image"] == "") {
                        $activity = "Posted on self wall<br>".$this->_separateurl($info["status"]);//$info["status"];
                    }
                    else {
                        $activity = "</br>Posted ".$this->_separateurl($info["status"])."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> "." </br> on self wall";
                    }
                }
                else {
                    $where = array("id" => $uid);
                    $user = $this->communitymodel->getuser($where);
                    if(!empty($user)) {
                        $name = $user->user_name;
                        if(!empty($user->name)) {
                            $name = $user->name;
                        }
                        if($info["image"] == "") {
                            $activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a></br>Posted ".$this->_separateurl($info["status"])." on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall </br>";
                            //$activity = $info["status"]." Posted on wall by <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
                        }
                        else {
                            $activity = "<a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a></br>Posted ".$this->_separateurl($info["status"])."</br><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> "." </br> on <a href='".base_url()."community/profile/".$user->user_name."'>".$name."'s</a> wall";
                            //$activity = "Posted on ".$info["uname"]."profile wall".$info["status"]."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> ";
                            //$activity = $info["status"]."<br/><img src='".base_url()."public/frontend/images/postonwall/150x150/".$info["image"]."' /> "." Posted on wall by <a href='".base_url()."community/profile/".$info["uname"]."'>".$info["uname"]."</a>";
                        }
                    }
                }
            }*/
            //else if($this->uri->segment("2") == "newsfeed") {
            else if($content == $this->config->item("comment_on_groupwallpost")) {
                $activity = "Commented on </br>".$info["message"]." </br> under group <a href='".base_url()."community/group/".$info["gseo"]."'>".$info["gname"]."</a>.";
            }
            //}
                // public wall activities starts
            else if($content == $this->config->item("article")) {
                if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                    $activity = "Shared an <a href='".$info["link"]."' style='color: #A90101;'>article</a>";
                    $activity .= "<p>".$info["article"]."</p>";
                    /* $activity .= "</br><a href='".$info["link"]."' target='_blank' title='".$info["link"]."'>";
                    $activity .= "<div class='previewImagePosted'>";
                    if($info["isvideolink"] == "yes") {
                        $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                        //$activity .= "<span class='videoPostPlay'></span>";
                    }
                    else {
                        $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                    }
                    $activity .= "</div></a>";
                    $activity .= "</br><a href='".$info["link"]."' target='_blank' title='" . $info["linktitle"] ."'><strong>".$info["linktitle"]."</strong></a>";
                    $activity .= "</br><span>".$info["linkdescription"]."</span>"; */

                    $activity .= "<div class='previewImagesPosted'>";
                        $activity .= "<div class='previewImagePosted'>";
                            $activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
                            if($info["isvideolink"] == "yes") {
                                $activity .= "<span class='videoPostPlay'></span>";
                            }
                            $activity .= "</div>";
                        $activity .= "</div>";
                        $activity .= "<div class='previewContentPosted'>";
                            $activity .= "<div class='previewTitlePosted'>";
                            //$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                            $activity .= "<a target='_blank' href='".$info["link"]."'>";
                                $activity .= "<span>".$info["linktitle"]."</span>";
                            $activity .= "</a>";
                        $activity .= "</div>";
                        $activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                        $activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
                    $activity .= "</div>";
                    $activity .= "<div style='clear: both'></div>";

                    /* $src = $this->_seturlimage($info["link"]);
                    if(!empty($src)) {
                        $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                    } */

                    if(!empty($info["image"])) {
                        $activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/article/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/article/250x250/".$info["image"]."'/></a>";
                    }
                }
                else {
                    $activity = "Shared an article </br>".$info["article"];
                    if(!empty($info["image"])) {
                    	 $activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/article/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/article/250x250/".$info["image"]."'/></a>";
                    }
                }
    
                if(!empty($info["video"])) { 
                    $activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
                }
            }
            else if($content == $this->config->item("group")) {
                if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                    $activity = "Shared a <a href='".$info["link"]."' style='color: #A90101;'>group</a>";
                    $activity .= "<p>".$info["group"]."</p>";
                    /* $activity .= "</br><a href='".$info["link"]."' target='_blank' title='".$info["link"]."'>";
                    if($info["isvideolink"] == "yes") {
                        $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                        //$activity .= "<span class='videoPostPlay'></span>";
                    }
                    else {
                        $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                    }
                    $activity .= "</a>";
                    $activity .= "</br><a href='".$info["link"]."' target='_blank' title='" . $info["linktitle"] ."'><strong>".$info["linktitle"]."</strong></a>";
                    $activity .= "</br><span>".$info["linkdescription"]."</span>"; */

                    /* $src = $this->_seturlimage($info["link"]);
                    if(!empty($src)) {
                        $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                    } */

                    $activity .= "<div class='previewImagesPosted'>";
                        $activity .= "<div class='previewImagePosted'>";
                            $activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
                                if($info["isvideolink"] == "yes") {
                                    $activity .= "<span class='videoPostPlay'></span>";
                                }
                            $activity .= "</div>";
                        $activity .= "</div>";
                        $activity .= "<div class='previewContentPosted'>";
                            $activity .= "<div class='previewTitlePosted'>";
                            //$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                            $activity .= "<a target='_blank' href='".$info["link"]."'>";
                                $activity .= "<span>".$info["linktitle"]."</span>";
                            $activity .= "</a>";
                        $activity .= "</div>";
                        $activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                        $activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
                    $activity .= "</div>";
                    $activity .= "<div style='clear: both'></div>";

                    if(!empty($info["image"])) {
                        $activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/group/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/group/250x250/".$info["image"]."'/></a>";
                    }
                }
                else {
                    $activity = "Shared a group".$info["group"];
                    if(!empty($info["image"])) {
                    	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/group/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                        $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/group/250x250/".$info["image"]."'/> </a>";
                    }
                }

                if(!empty($info["video"])) {
                    $activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
                }
            }
            else if($content == $this->config->item("competition")) {
                if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                $activity = "Posted an <a href='".$info["link"]."' style='color: #A90101;'>competition</a>";
                $activity .= "<p>".$info["competition"]."</p>";
                /* $activity .= "</br><a href='".$info["link"]."' target='_blank' title='".$info["link"]."'>";
                if($info["isvideolink"] == "yes") {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                    //$activity .= "<span class='videoPostPlay'></span>";
                }
                else {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                }
                $activity .= "</a>";
                $activity .= "</br><a href='".$info["link"]."' target='_blank' title='" . $info["linktitle"] ."'><strong>".$info["linktitle"]."</strong></a>";
                $activity .= "</br><span>".$info["linkdescription"]."</span>"; */

                /* $src = $this->_seturlimage($info["link"]);
                if(!empty($src)) {
                    $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                } */
                $activity .= "<div class='previewImagesPosted'>";
                    $activity .= "<div class='previewImagePosted'>";
                        $activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
                        if($info["isvideolink"] == "yes") {
                            $activity .= "<span class='videoPostPlay'></span>";
                        }
                    $activity .= "</div>";
                $activity .= "</div>";
                $activity .= "<div class='previewContentPosted'>";
                    $activity .= "<div class='previewTitlePosted'>";
                    //$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                        $activity .= "<a target='_blank' href='".$info["link"]."'>";
                            $activity .= "<span>".$info["linktitle"]."</span>";
                        $activity .= "</a>";
                    $activity .= "</div>";
                    $activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                    $activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
                $activity .= "</div>";
                $activity .= "<div style='clear: both'></div>";

                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/competition/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/competition/250x250/".$info["image"]."'/></a>";
                }
            }
            else {
                $activity = "Posted an competition </br>".$info["competition"];
                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/competition/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/competition/250x250/".$info["image"]."'/> </a>";
                }
            }

            if(!empty($info["video"])) {
                $activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
            }
        }
        else if($content == $this->config->item("event")) {
            if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                $activity = "Posted an <a href='".$info["link"]."' style='color: #A90101;'>event</a>";
                $activity .= "<p>".$info["event"]."</p>";
                /* $activity .= "</br><a href='".$info["link"]."' target='_blank' title='".$info["link"]."'>";
                if($info["isvideolink"] == "yes") {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                    //$activity .= "<span class='videoPostPlay'></span>";
                }
                else {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                }
                $activity .= "</a>";
                $activity .= "</br><a href='".$info["link"]."' target='_blank' title='" . $info["linktitle"] ."'><strong>".$info["linktitle"]."</strong></a>";
                $activity .= "</br><span>".$info["linkdescription"]."</span>"; */

                $activity .= "<div class='previewImagesPosted'>";
                    $activity .= "<div class='previewImagePosted'>";
                        $activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
                        if($info["isvideolink"] == "yes") {
                            $activity .= "<span class='videoPostPlay'></span>";
                        }
                    $activity .= "</div>";
                $activity .= "</div>";
                $activity .= "<div class='previewContentPosted'>";
                    $activity .= "<div class='previewTitlePosted'";
                    //$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                        $activity .= "<a target='_blank' href='".$info["link"]."'>";
                            $activity .= "<span>".$info["linktitle"]."</span>";
                        $activity .= "</a>";
                    $activity .= "</div>";
                    $activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                    $activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
                $activity .= "</div>";
                $activity .= "<div style='clear: both'></div>";

                /* $src = $this->_seturlimage($info["link"]);
                if(!empty($src)) {
                    $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                } */

                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/event/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/event/250x250/".$info["image"]."'/></a>";
                }
            }
            else {
                $activity = "Posted an event".$info["event"];
                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/event/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/event/250x250/".$info["image"]."'/> </a>";
                }
            }

            if(!empty($info["video"])) {
                $activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
            }
        }
        else if($content == $this->config->item("advertisement")) {
            if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                $activity = "Posted an <a href='".$info["link"]."' style='color: #A90101;'>advertisement</a>";
                $activity .= "<p>".$info["advertisement"]."</p>";

                /* $activity .= "</br><a href='".$info["link"]."' target='_blank' title='".$info["link"]."'>";
                if($info["isvideolink"] == "yes") {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                    //$activity .= "<span class='videoPostPlay'></span>";
                }
                else {
                    $activity .= "<img src='".$info["linkimage"]."' width='130' height='100' />";
                }
                $activity .= "</a>";
                $activity .= "</br><a href='".$info["link"]."' target='_blank' title='" . $info["linktitle"] ."'><strong>".$info["linktitle"]."</strong></a>";
                $activity .= "</br><span>".$info["linkdescription"]."</span>"; */

                $activity .= "<div class='previewImagesPosted'>";
                    $activity .= "<div class='previewImagePosted'>";
                        $activity .= "<img src='".$info["linkimage"]."' class='imgIframe'/>";
                        if($info["isvideolink"] == "yes") {
                            $activity .= "<span class='videoPostPlay'></span>";
                        }
                    $activity .= "</div>";
                $activity .= "</div>";
                $activity .= "<div class='previewContentPosted'>";
                    $activity .= "<div class='previewTitlePosted'>";
                    //$activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                        $activity .= "<a target='_blank' href='".$info["link"]."'>";
                            $activity .= "<span>".$info["linktitle"]."</span>";
                        $activity .= "</a>";
                    $activity .= "</div>";
                    $activity .= "<div class='previewUrlPosted'>".$info["link"]."</div>";
                    $activity .= "<div class='previewDescriptionPosted'>".$info["linkdescription"]."</div>";
                $activity .= "</div>";
                $activity .= "<div style='clear: both'></div>";

                /* $src = $this->_seturlimage($info["link"]);
                if(!empty($src)) {
                    $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                } */

                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/advertisement/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/advertisement/250x250/".$info["image"]."'/></a>";
                }
            }
            else {
                $activity = "Posted an advertisement </br>".$info["advertisement"];
                if(!empty($info["image"])) {
                	$activity .= "<div class='preview_post_title'>Image</div><a href='".base_url()."public/frontend/images/publicwall/image/advertisement/".$info["image"]."' data-lightbox='".$info["image"]."'>";
                    $activity .= "<img src='".base_url()."public/frontend/images/publicwall/image/advertisement/250x250/".$info["image"]."'/> </a>";
                }
            }

            if(!empty($info["video"])) {
                $activity .= "<div class='preview_post_title'>Video</div>".$info["video"];
            }
        }
            /* else if($content == $this->config->item("image")) {
                $activity = "Shared </br><img src='".base_url()."public/frontend/images/publicwall/image/250x250/".$info["image"]."' width='250' height='250' />";
            }
            else if($content == $this->config->item("video")) {
                $activity = "Shared video </br>".$info["video"];
            }
            else if($content == $this->config->item("link")) {
                if(strpos($info["link"], "://") !== false || strpos($info["link"], "http") !== false || strpos($info["link"], "https") !== false) {
                    $src = $this->_seturlimage($info["link"]);
                    $activity = "Shared <a href='".$info["link"]."'>link</a>";
                    if(!empty($src)) {
                        $activity .= "</br><a id='urlcontent' href='".$info["link"]."' title='".$info["link"]."' class='livepreview'><img src='".$src."' height='50' /></a>";
                    }
                }
            } */
            // public wall activities ends
        }

        return $activity;
    }

    function _timeago($date) {
        if(empty($date)) {
            // no date provided
            return "";
        }

        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array("60","60","24","7","4.35","12","10");

        $now = time();
        $unix_date = strtotime($date);

        // check validity of date
        if(empty($unix_date)) {
            // bad date
            return "";
        }

        // is it future date or past date
        if($now > $unix_date) {
            $difference = $now - $unix_date;
            $tense = "ago";
        }
        else {
            $difference = $unix_date - $now;
            $tense = "from now";
        }

        for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
            $difference /= $lengths[$j];
        }

        $difference = round($difference);

        if($difference != 1) {
            $periods[$j].= "s";
        }

        return "$difference $periods[$j] {$tense}";
    }

    /**
    * Function is used to search the members
    */
    function searchmember() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_search")) {

            $name = trim($this->input->post("username"));
            $county_id = $this->input->post("country");
            $city = trim($this->input->post("city"));

            $advancesearch = array();

            if($name != "") {
                $where = array("user_name" =>$name);
                $user = $this->communitymodel->getuser($where);
                if(isset($user->id)) {
                    $advancesearch['uid'] = $user->id;
                }
            }
            if($county_id != "0") {
                $advancesearch['country'] = $county_id;
            }
            if($city != "") {
                $advancesearch['town'] = $city;
            }
            $data["members"] = $this->communitymodel->getadvancesearchmembers($advancesearch);
            $country = $this->communitymodel->getallcountries();
            if(isset($country) &&  $country != "") {
                $data["country"] = $country;
            }
        }
        else {
            $country = $this->communitymodel->getallcountries();
            if(isset($country) &&  $country != "") {
                $data["country"] = $country;
            }
            $data["members"] = $this->communitymodel->getrandommembers();
        }

        $data["page"] = "community/searchmember";
        $this->load->view("template/newtemplate", $data);
    }

    /**
    * Function is used to update the aboutme section on profile page
    */
    function aboutme() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_updabtme")) {
            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $where = array("uid" => $uid);
            $aboutme = $this->communitymodel->getabout($where);

            if(isset($aboutme) && $aboutme != "") {
                $about = array(
                                "town" => $this->input->post("town"),
                                "iamprivateorbusiness" => $this->input->post("iamprivateorbusiness"),
                                "businessteyhave" => $this->input->post("businessteyhave"),
                                "cookingskill " => $this->input->post("cookingskill"),
                                "website" => $this->input->post("website"),
                                "blog" => $this->input->post("blog"),
                                "favmeal" => $this->input->post("favmeal"),
                                "favfoodshow" => $this->input->post("favfoodshow"),
                                "favchef" => $this->input->post("favchef"),
                                "tvshow" => $this->input->post("tvshow"),
                                "whoim" => $this->input->post("whoim")
                            );

                $array = array();
                if($this->input->post("smedia_fb")) {
                    $array['facebook'] = $this->input->post("smedia_fb");
                }

                if($this->input->post("smedia_tw")) {
                    $array['twitter'] = $this->input->post("smedia_tw");
                }

                if($this->input->post("smedia_li")) {
                    $array['linkedin'] = $this->input->post("smedia_li");
                }

                if($this->input->post("smedia_gp")) {
                    $array['googleplus'] = $this->input->post("smedia_gp");
                }

                if($this->input->post("smedia_yt")) {
                    $array['youtube'] = $this->input->post("smedia_yt");
                }

                if($this->input->post("smedia_dig")) {
                    $array['digg'] = $this->input->post("smedia_dig");
                }

                if($this->input->post("smedia_vm")) {
                    $array['vimeo'] = $this->input->post("smedia_vm");
                }

                if($this->input->post("smedia_pt")) {
                    $array['pinterest'] = $this->input->post("smedia_pt");
                }

                if(count($array)>0) {
                	$about['socialmedia'] = base64_encode(serialize($array));
                    //$about['socialmedia'] = serialize($array);
                }
                else {
                    $about['socialmedia'] = "";
                }

                $where = array("id" => $aboutme->id);
                $this->communitymodel->updateaboutme($about, $where);

                $where = array("id" => $aboutme->uid );
                $user = $this->communitymodel->getuser($where);

                if(isset($user) && $user != "") {
                    $userinfo = array(
                                        "name" => $this->input->post("name"),
                                        "country_id" => $this->input->post("country")
                                    );

                    /*$where = array(
                                    "id" => $uid
                                    );*/

                    $this->communitymodel->updateuser($userinfo, $where);
                }
            }

            /*$user = $this->communitymodel->getuser($where);
                if(isset($user) && $user != ""){
                $userinfo = array(
                                "name" => $this->input->post("name"),
                                "country_id" => $this->input->post("country")
                            );
                $where = array(
                            "id" => $uid
                        );

                $this->communitymodel->updateuser($userinfo, $where);
            }*/
            
            redirect("community");
        }
        else {
            $uid = $this->db_session->userdata("id");
            $where = array("uid" => $uid);

            $aboutme = $this->communitymodel->getabout($where);
            if(isset($aboutme) &&  $aboutme != "") {
                if(!empty($aboutme->socialmedia)) {
                    //$socialmedia = unserialize($aboutme->socialmedia);
                    $socialmedia = unserialize(base64_decode($aboutme->socialmedia));
					
                    foreach($socialmedia as $key=>$val) {
                        if($key == 'facebook')  {
                            $array['smedia_fb'] = $val;
                        }
                        else {
                            $array['smedia_fb'] = '';
                        }
    
                        if($key == 'twitter') {
                            $array['smedia_tw'] = $val;
                        }
                        else {
                            $array['smedia_tw'] = '';
                        }
    
                        if($key == 'linkedin') {
                            $array['smedia_li'] = $val;
                        }
                        else {
                            $array['smedia_li'] = '';
                        }
    
                        if($key == 'googleplus') {
                            $array['smedia_gp'] = $val;
                        }
                        else {
                            $array['smedia_gp'] = '';
                        }
    
                        if($key == 'youtube') {
                            $array['smedia_yt'] = $val;
                        }
                        else {
                            $array['smedia_yt'] = '';
                        }
    
                        if($key == 'digg') {
                            $array['smedia_dig'] = $val;
                        }
                        else {
                            $array['smedia_dig'] = '';
                        }
    
                        if($key == 'vimeo') {
                            $array['smedia_vm'] = $val;
                        }
                        else {
                            $array['smedia_vm'] = '';
                        }
    
                        if($key == 'pinterest') {
                            $array['smedia_pt'] = $val;
                        }
                        else {
                            $array['smedia_pt'] = '';
                        }
                    }
                }
                else {
                    $array = array('smedia_fb'=>'', 'smedia_tw'=>'', 'smedia_li'=>'', 'smedia_gp'=>'', 'smedia_yt'=>'', 'smedia_dig'=>'', 'smedia_vm'=>'', 'smedia_pt'=>'');
                }

                $aboutme->socialmedia = $array; 
                $data["aboutme"] = $aboutme;
            }
            $where = array("id" => $uid);
            $user = $this->communitymodel->getuser($where);
            if(isset($user) &&  $user != "") {
                $data["user"] = $user;
            }

            $country = $this->communitymodel->getallcountries();
            if(isset($country) &&  $country != "") {
                $data["country"] = $country;
            }

            $data["page"] = "community/updateaboutme";
            $this->load->view("template/newtemplate", $data);
        }
    }

    /**
    * Function is used to search the groups
    */
    function searchgroup() {
        $this->freakauth_light->check();
        if($this->input->post('search_btn')) {
            $user_name = $this->db_session->userdata("user_name");

            $where = array("user_name" => $user_name);
            $user = $this->communitymodel->getuser($where);
            $data["user"] = $user;

            $groupname = trim($this->input->post("search"));
            $searchgroups = $this->communitymodel->getsearchgroup($groupname);
            if(isset($searchgroups) && $searchgroups !="") {
                $data["searchgroups"] = $searchgroups;
            }
            $group = $this->communitymodel->getallgroups();
            if(isset($group) && $group !="") {
                $data["groups"] = $group;
            }
            $data["page"] = "community/serchgroup";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            redirect("community/groups");
            /**$group = $this->communitymodel->getallgroups();
            if(isset($group) && $group !=""){
            $data["groups"] = $group;
            }
            $getcontent = "group";
            $activities = $this->communitymodel->getallgroupsactivity($getcontent);
            if(isset($activities) && $activities != "") {
        
            foreach ($activities as $activity) {
            $array = (array) $activity;
        
            $where = array(
            "id" => $activity->uid
            );
            $activityuser = $this->communitymodel->getuser($where);
            $userimg = "noavatar.png";
        
            if(isset($activityuser) && $activityuser != "") {
            $array["name"] = $activityuser->name;
            $array["user_name"] = $activityuser->user_name;
            if($activityuser->image != "") {
            $userimg = $activityuser->image;
            }
            }
        
            $array["image"] = $userimg;
            $array["content"] = $this->_getgroupactivity( $activity->content, $activity->info);
            $array["timeago"] = $this->_timeago($activity->date);
        
            $where = array(
            "aid" => $activity->id
            );
            $communitycomments = $this->communitymodel->getcommunitycomments($where);
            $newcommunitycomments = array();
        
            if(isset($communitycomments) && $communitycomments != "") {
            foreach ($communitycomments as $communitycomment) {
            $communityarray = (array) $communitycomment;
            $communityarray["timeago"] = $this->_timeago($communitycomment->date);;
        
            $communityobject = (object) $communityarray;
            $newcommunitycomments[] = $communityobject;
            }
            }
        
            $array["communitycomments"] = $newcommunitycomments;
        
            $object = (object) $array;
        
            $newactivities[] = $object;
            }
        
            for($i = 0; $i < count($activities); $i++) {
            $activities[$i] = $newactivities[$i];
            }
            }
        
            $data["activities"] = $activities;
        
            $data["page"] = "community/allgroups";
            $this->load->view("template/newtemplate", $data);**/
        }
    }

    /* function to show list of liked recipes if approved*/
    /*function likes() {
    $this->load->library("pagination");

    $config["base_url"] = base_url()."community/likes";
    $config["uri_segment"] = 3;
    $config["per_page"] = 5;
    $config["full_tag_open"] = "<p>";
    $config["full_tag_close"] = "</p>";
    $config["cur_tag_open"] = "<b class='current'>";
    $config["cur_tag_close"] = "</b>";
    $config["next_link"] = "&gt";
    $config["prev_link"] = "&lt";

    $uid = $this->db_session->userdata("id");
    $likes = $this->crudmodel->getlikesbyuserid($uid);

    foreach($likes as $like ){
    $where[] = $like->recipeid;
    }
    $query = $this->crudmodel->getalllikedrecipes($where);

    $config["total_rows"] = $query->num_rows();
    $this->pagination->initialize($config);

    $query->free_result();
    //echo "test1";
    $page = $this->uri->segment(3, 0);

    $limit = array(
    "start" => $config["per_page"],
    "end" => $page
    );

    if($this->input->post("sbt_search")) {

    $search = array(
    "title" => $this->input->post("search")
    );

    $data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

    //$query = $this->crudmodel->getallrecipes($limit);
    }
    else {

    //$data["recipes"] = $this->crudmodel->getrecipes($where, $limit);
    $data["recipes"] = $this->crudmodel->getlikedrecipes($where, $limit);
    }

    $data["categories"] = $this->crudmodel->getallcategories();
    $data["top5recipes"] = $this->crudmodel->gettop5recipes();

    if($this->db_session->userdata("id") != "") {
    $data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
    }

    $data["pagination_links"] = $this->pagination->create_links();
    //echo "test2";
    $data["page"] = "pages/home";
    $this->load->view("template/template", $data);
    }

    /* function to show list of recipes submitted by user*/
    /*function recipes() {

    $this->load->library("pagination");

    $config["base_url"] = base_url()."community/recipes";
    $config["uri_segment"] = 3;
    $config["per_page"] = 5;
    $config["full_tag_open"] = "<p>";
    $config["full_tag_close"] = "</p>";
    $config["cur_tag_open"] = "<b class='current'>";
    $config["cur_tag_close"] = "</b>";
    $config["next_link"] = "&gt";
    $config["prev_link"] = "&lt";

    $where = array(
    //"approved" => "1",
    "uid" => $this->db_session->userdata("id")
    );

    $query = $this->crudmodel->getallrecipes($where);

    $config["total_rows"] = $query->num_rows();
    $this->pagination->initialize($config);

    $query->free_result();
    //echo "test1";
    $page = $this->uri->segment(3, 0);

    $limit = array(
    "start" => $config["per_page"],
    "end" => $page
    );

    if($this->input->post("sbt_search")) {

    $search = array(
    "title" => $this->input->post("search")
    );

    $data["recipes"] = $this->crudmodel->getsearchrecipes($search, $limit);

    //$query = $this->crudmodel->getallrecipes($limit);
    }
    else {
    $data["recipes"] = $this->crudmodel->getrecipes($where, $limit);

    //if(count($data["recipes"])) {
    //$data["rating"] = $this->crudmodel->avarageratingbyid($data["recipes"][0]->ratingid);
    //}
    //$data["userimage"] = $this->crudmodel->getuserdetailsbyid();
    }

    $data["categories"] = $this->crudmodel->getallcategories();
    $data["top5recipes"] = $this->crudmodel->gettop5recipes();

    if($this->db_session->userdata("id") != "") {
    $data["books"] = $this->crudmodel->getbooksbyuserid($this->db_session->userdata("id"));
    }

    $data["pagination_links"] = $this->pagination->create_links();
    //echo "test2";
    $data["page"] = "pages/home";
    $this->load->view("template/template", $data);
    }*/

    /**
    * This function is used to show list of followers of the user
    */
    function followers() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                        "user_name" => $user_name
                    );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            $data["user"] = $user;
            //$limit="all";
            $group = $this->communitymodel->getallgroupsbyuserid($user->id);
            if(isset($group) && $group !="") {
                $data["groups"] = $group;
            }
            $data["followers"] = $this->communitymodel->getalluserfollowers($user->id);
            $data["followerscount"] = count($data["followers"]);
            $data["followings"] = $this->communitymodel->getalluserfollowings($user->id);
            $data["usersonline"] = $this->_getonlineusers();

            $data["page"] = "community/followers";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }

    /**
    * This function is used to show list of all friends
    */
    function contacts() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                    "user_name" => $user_name
                );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {

            //$data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
            $data["loadleftside"] = true;

            //$where = array('user_name'=>base64_encode($this->db_session->userdata("user_name")));
            //$data["membership"] = $this->communitymodel->getmembership($where);
            $where = array("user_name" => base64_encode($user->user_name));
            $data["membership"] = $this->communitymodel->getmembership($where);

            $where = array(
                            "uid" => $user->id
                        );
            $data["contacts"] = $this->communitymodel->getcontact($where);
            //$data["contactscount"] = count($data["contacts"]);

            $data["usersonline"] = $this->_getonlineusers();

            $data["user"] = $user;

            //$data["page"] = "community/followers";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/contacts";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }

        /* $id = $this->uri->segment("3");
        if($id > 0) {
        //$limit="all";
        $group = $this->communitymodel->getallgroupsbyuserid($id);
        if(isset($group) && $group !="") {
        $data["groups"] = $group;
        }
    
        $where = array('user_name'=>base64_encode($this->db_session->userdata("user_name")));
        $data["membership"] = $this->communitymodel->getmembership($where);
    
        $where=array("uid"=>$id);
        $data["contacts"] = $this->communitymodel->getcontact($where);
        $data["contactscount"] = count($data["contacts"]);
    
        $data["usersonline"] = $this->_getonlineusers();
        $data["page"] = "community/followers";
        $this->load->view("template/newtemplate", $data);
        }
        else{
        redirect("community");
        } */
    }

    /**
    * This function is used to show the detail list of favourite blogs
    */
    function favouriteblogs() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                    "user_name" => $user_name
                );
        $user = $this->communitymodel->getuser($where);
		if($this->input->post("filter")) {
			$uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;
            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }
                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }
            $data["user"] = $user;
            $data["favoriteblogs"] = $this->communitymodel->getcommonfilter($this->input->post("filter"),'favoriteblogs',$user->id);
            $data["favoriteblogscount"] = count($data["favoriteblogs"]);
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/favouritebloglist";
            $this->load->view("template/newtemplate", $data);
			
		}elseif(!empty($user)) {
            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $limit = "all";
            $data["favoriteblogs"] = $this->communitymodel->getallfavoriteblogsbyuserid($user->id, $limit);
            $data["favoriteblogscount"] = count($data["favoriteblogs"]);

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/favouritebloglist";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }
	
	function editfavouriteblogs() {
		//echo "ok";exit;
		$this->freakauth_light->check();
		
        if($this->input->post("sbt_update")) {
            $image = "";

            if($_FILES["userfile"]["name"] != "") {
                $bloguploadpath = $this->config->item("blog_upload_path");

                $config = array(
                                    "upload_path" => $bloguploadpath,
                                    "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
    
                    $image_data = $this->upload->data();

                    $imagestypes = array(
                                        "blog_50x50_upload_path" => $this->config->item("blog_50x50_upload_path"),
                                        "blog_25x25_upload_path" => $this->config->item("blog_25x25_upload_path")
                                    );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 100;
                        $heigth = 100;
                        if($imagetype == $this->config->item("blog_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("blog_25x25_upload_path")) {
                            $width = 25;
                            $heigth = 25;
                        }
    
                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ration" => true,
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
    
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            
			$blog["name"] = $this->input->post("blogname");
			$blog["url"] = $this->input->post("blogurl");
			$blog["comment"] = $this->input->post("blogcomment");
			if(isset($image) && $image!= ""){
				$blog["picture"] = $image;
			}
			$blog["rating"] =  $this->input->post("blograting");
			$blog["date"] = date("Y-m-d H:i:s");
			
           	$where = array("id" => $this->input->post("blogid"));
			
            if($this->communitymodel->updatefavoriteblog($where,$blog)) {
            	redirect("community/favouriteblogs");
            }
          }
        //redirect("community");
	}

    /**
    * This function is used to show the detail list of favourite wineries
    */
    function favouritewineries() {
        $this->freakauth_light->check();
		
		$this->load->model("wineries/winemodel");
        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
            "user_name" => $user_name
        );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {
            //$data = $this->_gettopboxcontent($user);
            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;
            //$data["notifications"] = $this->_getnotifications();

            $where = array(
                    "uid" => $user->id
                );

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $data["favouritewineries"] = $this->communitymodel->getallfavouritewineriesbyuser($user_name);

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/favouritewineries";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }
	
    /**
    * This function is used to show the detail list of favourite restaurants
    */
    /* function favouriterestaurants() {
    $this->freakauth_light->check();

    $user_name = $this->uri->segment("3");

    if(!empty($user_name)) {
    $where = array("user_name" => $user_name);
    $user = $this->communitymodel->getuser($where);

    if(!empty($user)) {
    $data = $this->_gettopboxcontent($user);

    $uid = $this->db_session->userdata("id");
    $data["uid"] = $uid;

    $data["notifications"] = $this->_getnotifications();

    $where = array("uid" => $user->id);
    //$data["images"] = $this->communitymodel->getuserimages($where);

    $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

    $data["made"] = $this->communitymodel->getallmadebyuserid($user->id,6);

    $data["favorites"] = $this->communitymodel->getallfavoriterecipesbyuserid($user->id,6);

    $data["favoriteblogs"] = $this->communitymodel->getallfavoriteblogsbyuserid($user->id);

    $data["favouritewineries"] = $this->communitymodel->getallfavouritewineriesbyuser($user->user_name);

    $data["favoriterestaurants"] = $this->communitymodel->getallfavoriterestaurantbyuser($user->user_name);

    $data["outsiderecipes"] = $this->communitymodel->getalloutsiderecipesbyuserid($user->id);

    //$data["onlinevideos"] = $this->communitymodel->getallonlinevideosbyuserid($user->id);
    $data["videogallery"] = $this->communitymodel->getvideogallery($user->id);

    $data["liqureandspirits"] = $this->communitymodel->getliqureandspiritsbyuserid($user->id);

    $data["drinkrecipes"] = $this->communitymodel->getalldrinkrecipesbyuserid($user->id);

    $data["commborecipes"] = $this->crudmodel->getrecipes();

    $data["winenbeers"] = $this->communitymodel->getallwinenbeerbyuserid($user->id);

    $data["recipereviews"] = $this->crudmodel->getrecipereviewsbyuserid($user->id);

    $data["usersonline"] = $this->_getonlineusers();

    $where = array("uid" => $user->id);
    $data["settings"] = $this->communitymodel->getsettings($where);

    $data["isowner"] = false;
    if($user->id == $uid) {
    $data["isowner"] = true;
    $data["types"] = $this->crudmodel->getalltypes();
    }
    if(!$data["isowner"]) {
    $where = array("uid" => $uid);
    $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
    if(!$data["isfriend"]) {
    $where = array("uid" => $user->id);
    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
    }

    $where = array("uid" => $user->id);
    $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);

    }

    //$where = array('user_name'=>base64_encode($user->user_name));
    //$data["membership"] = $this->communitymodel->getmembership($where);

    $data["user"] = $user;

    $group = $this->communitymodel->getallgroupsbyuserid($user->id);
    if(isset($group) && $group !=""){
    $data["groups"] = $group;
    }
    $limit="all";
    $data["favouriterestaurants"] = $this->communitymodel->getallfavoriterestaurantbyuser($user_name,$limit);
    $data["favouriterestaurantscount"] = count($data["favouriterestaurants"]);

    $where = array('user_name'=>base64_encode($this->db_session->userdata("user_name")));
    $data["membership"] = $this->communitymodel->getmembership($where);
    }

    $data["page"] = "community/favouriterestaurants";//"community/recipeboxes";
    $this->load->view("template/newtemplate", $data);
    }
    else{
    redirect("community");
    }
    } */

    function favouriterestaurants() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array("user_name" => $user_name);
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["notifications"] = $this->_getnotifications();

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $where = array(
                        "uid" => $user->id
                    );
            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $limit="all";
            $data["favouriterestaurants"] = $this->communitymodel->getallfavoriterestaurantbyuser($user_name,$limit);
            $data["favouriterestaurantscount"] = count($data["favouriterestaurants"]);

            $where = array("user_name"=>base64_encode($this->db_session->userdata("user_name")));
            $data["membership"] = $this->communitymodel->getmembership($where);

            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/favouriterestaurants";
            $this->load->view("template/newtemplate", $data);
        }
        else {
            $this->index();
        }
    }

    /**
    * This function is used to show the detail list of collection of out side recipes
    */
    function outsiderecipescollection() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                        "user_name" => $user_name
                    );
        $user = $this->communitymodel->getuser($where);
		
		//this if for filter by rating, date, name
		if($this->input->post("filter")) {
			$uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;
            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }
                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }
            $data["user"] = $user;
            $data["outsiderecipes"] = $this->communitymodel->getcommonfilter($this->input->post("filter"),'outsiderecipes',$user->id);
			
			$data["categories"] = $this->crudmodel->getallcategories();
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/outsiderecipelist";
            $this->load->view("template/newtemplate", $data);
			
		}elseif(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;
			
			// get recipes as per categories
			
			if($this->uri->segment("4") == ""){
				
				$limit = "all";
				$data["outsiderecipes"] = $this->communitymodel->getalloutsiderecipesbyuserid($user->id, $limit);
				$data["categories"] = $this->crudmodel->getallcategories();
				
			}else{
				
				$category = $this->uri->segment("4");
				$cid = $this->crudmodel->getcategoryidbycategoryname($category);
				$where = array( "categoryid" => $cid,
								"uid" => $user->id
							);
				
				$data["outsiderecipes"] = $this->communitymodel->getoutsiderecipesbycat($where);
				$data["categories"] = $this->crudmodel->getallcategories();
			}
            
            //$data["favoriteblogscount"] = count($data["favoriteblogs"]);
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/outsiderecipelist";
            $this->load->view("template/newtemplate", $data);

            /* $group = $this->communitymodel->getallgroupsbyuserid($user->id);
            if(isset($group) && $group !="") {
                $data["groups"] = $group;
            }
            $limit = "all";
            $data["outsiderecipes"] = $this->communitymodel->getalloutsiderecipesbyuserid($user->id, $limit);
            //$data["outsiderecipes"] = count($data["outsiderecipes"]);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }

	function updateoutsiderecipe() {
		
		$this->freakauth_light->check();
		
        if($this->input->post("sbt_update")) {
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
            	$outrecipesuploadpath = $this->config->item("outsiderecipes_upload_path");
                $config = array(
                                    "upload_path" => $outrecipesuploadpath,
                                    "allowed_types" => "jpg|jpeg|gif|png"
                                );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);
            
                if($this->upload->do_upload()) {

                    $image_data = $this->upload->data();

                    $imagestypes = array(
                                            "outsiderecipes_50x50_upload_path" => $this->config->item("outsiderecipes_50x50_upload_path"),
                                            "outsiderecipes_100x100_upload_path" => $this->config->item("outsiderecipes_100x100_upload_path"),
                                            "outsiderecipes_168x168_upload_path" => $this->config->item("outsiderecipes_168x168_upload_path")
                                        );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
    
                        $width = 336;
                        $heigth = 336;
    
                        if($imagetype == $this->config->item("outsiderecipes_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("outsiderecipes_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("outsiderecipes_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
    
                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );
    
                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $recipe["name"] = $this->input->post("recipename");
			$recipe["categoryid"] = $this->input->post("categoryid");
			$recipe["url"] = $this->input->post("recipeurl");
			$recipe["comment"] = $this->input->post("recipecomment");
			if(isset($image) && $image!= ""){
				$recipe["picture"] = $image;
			}
			$recipe["rating"] =  $this->input->post("reciperating");
			$recipe["date"] = date("Y-m-d H:i:s");
			
           	$where = array("id" => $this->input->post("outrecipeid"));
			
            if($this->communitymodel->updateoutsiderecipes($where,$recipe)) {
            	redirect("community/outsiderecipescollection");
            }
          }
       }

    /**
    * This function is used to show the detail list of collection of online videos
    */
    function onlinevideocollection() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                        "user_name" => $user_name
                    );
        $user = $this->communitymodel->getuser($where);
		
		//this if for filter by rating, date, name
		if($this->input->post("filter")) {
			$uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;
            $data["onlinevideos"] = $this->communitymodel->getcommonfilter($this->input->post("filter"),'onlinevideos',$user->id);
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/videocollectionlist";
            $this->load->view("template/newtemplate", $data);
			
		}elseif(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $limit = "all";
            $data["onlinevideos"] = $this->communitymodel->getallonlinevideosbyuserid($user->id, $limit);

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/videocollectionlist";
            $this->load->view("template/newtemplate", $data);

            /* $uid = $user->id;
        
            $group = $this->communitymodel->getallgroupsbyuserid($uid);
            if(isset($group) && $group !="") {
            $data["groups"] = $group;
            }
        
            $limit = "all";
            $data["onlinevideos"] = $this->communitymodel->getallonlinevideosbyuserid($uid, $limit);
            //$data["outsiderecipes"] = count($data["outsiderecipes"]);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }
	
	function updateonlinevideo() {
		
		$this->freakauth_light->check();
		
		if($this->input->post("sbt_update")) {
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $onlinevideouploadpath = $this->config->item("onlinevideo_upload_path");

                $config = array(
                                "upload_path" => $onlinevideouploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {

                    $image_data = $this->upload->data();

                    $imagestypes = array(
                        "onlinevideo_50x50_upload_path" => $this->config->item("onlinevideo_50x50_upload_path"),
                        "onlinevideo_100x100_upload_path" => $this->config->item("onlinevideo_100x100_upload_path"),
                        "onlinevideo_168x168_upload_path" => $this->config->item("onlinevideo_168x168_upload_path")
                    );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 336;
                        $heigth = 336;
                        if($imagetype == $this->config->item("onlinevideo_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("onlinevideo_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("onlinevideo_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }

                        $config = array(
                            "source_image" => $image_data["full_path"],
                            "new_image" => $imagetype,
                            "maintain_ration" => true,
                            "quality" => "100%",
                            "width" => $width,
                            "height" => $heigth
                        );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
            }

            $uid = $this->db_session->userdata("id");
            $video["name"] = $this->input->post("videoname");
			$video["url"] = $this->input->post("videourl");
			$video["comment"] = $this->input->post("videocomment");
			if(isset($image) && $image!= ""){
				$video["picture"] = $image;
			}
			$video["rating"] =  $this->input->post("videorating");
			$video["date"] = date("Y-m-d H:i:s");
			
			$where = array("id" => $this->input->post("outvideoid"));
					
            if($this->communitymodel->updateonlinevideos($where,$video)) {
            	redirect("community/onlinevideocollection");
            }
          }
       }

    /**
    * This function is used to show the detail list of collection of wine Beer
    */
    function winebeercollection() {
    	$this->freakauth_light->check();
		
		$user_name = $this->uri->segment("3");
		
		if(empty($user_name)) {
			$user_name = $this->db_session->userdata("user_name");
		}
		$where = array(
						"user_name" => $user_name
					);
		$user = $this->communitymodel->getuser($where);
		
		//this is for filter by rating, date, name
		if($this->input->post("filter")) {
			$uid = $this->db_session->userdata("id");
			$data["uid"] = $uid;
			
			$data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
			
			$data["isowner"] = false;
			if($user->id == $uid) {
				$data["isowner"] = true;
			}
			if(!$data["isowner"]) {
				$where = array("uid" => $uid);
				$data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
				
				if(!$data["isfriend"]) {
					$where = array("uid" => $user->id);
					$data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
				}
				
				$where = array("uid" => $user->id);
				$data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
			}
			
			$data["user"] = $user;
			$data["winenbeers"] = $this->communitymodel->getcommonfilter($this->input->post("filter"),'winenbeer',$user->id);
			$data["categories"] = $this->communitymodel->getwinecategory();
			$where = array(
                            "user_name" => base64_encode($user->user_name)
					);
			$data["membership"] = $this->communitymodel->getmembership($where);
			$data["commborecipes"] = $this->crudmodel->getrecipes();
			$data["page"] = "community/columnstwo";
			$data["column2"] = "community/template/listviews/winebeercollectionlist";
			$this->load->view("template/newtemplate", $data);
			
		}elseif(!empty($user)) {
			
			$uid = $this->db_session->userdata("id");
			$data["uid"] = $uid;
			$data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
			$data["isowner"] = false;
			
			if($user->id == $uid) {
				$data["isowner"] = true;
				//$data["types"] = $this->crudmodel->getalltypes();
			}
			if(!$data["isowner"]) {
				$where = array("uid" => $uid);
				$data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
				if(!$data["isfriend"]) {
					$where = array("uid" => $user->id);
					$data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
				}
				$where = array("uid" => $user->id);
				$data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
			}
			
			$data["user"] = $user;
			// get winebeer by its categories
			if($this->uri->segment("4") == ""){
				$limit = "all";
				$data["winenbeers"] = $this->communitymodel->getallwinenbeerbyuserid($user->id, $limit);
				$data["categories"] = $this->communitymodel->getwinecategory();
			}else{
				$category = $this->uri->segment("4");
				$cid = $this->communitymodel->getwinecatidbycategoryname($category);
				$where = array( "winebeer" => $cid,
								"uid" => $user->id
						);
				$data["winenbeers"] = $this->communitymodel->getwinebeerbycat($where);
				$data["categories"] = $this->communitymodel->getwinecategory();
			}
			
			$where = array( "user_name" => base64_encode($user->user_name));
			$data["membership"] = $this->communitymodel->getmembership($where);
			
			$data["commborecipes"] = $this->crudmodel->getrecipes();
			//$data["page"] = "community/recipeboxes";
			$data["page"] = "community/columnstwo";
			$data["column2"] = "community/template/listviews/winebeercollectionlist";
			$this->load->view("template/newtemplate", $data);
			
			/* $uid = $user->id;
        
            $group = $this->communitymodel->getallgroupsbyuserid($uid);
            if(isset($group) && $group !="") {
            $data["groups"] = $group;
            }
        
            $limit = "all";
            $data["winenbeers"] = $this->communitymodel->getallwinenbeerbyuserid($uid, $limit);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }
	
	function updatewinebeer() {
		//echo "ok"; exit;
		$this->freakauth_light->check();

		if($this->input->post("sbt_update")) {
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $winebeeruploadpath = $this->config->item("winebeer_upload_path");

                $config = array(
                                "upload_path" => $winebeeruploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {

                    $image_data = $this->upload->data();

                    $imagestypes = array(
                                            "winebeer_50x50_upload_path" => $this->config->item("winebeer_50x50_upload_path"),
                                            "winebeer_100x100_upload_path" => $this->config->item("winebeer_100x100_upload_path"),
                                            "winebeer_168x168_upload_path" => $this->config->item("winebeer_168x168_upload_path")
                                        );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 336;
                        $heigth = 336;
                        if($imagetype == $this->config->item("winebeer_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("winebeer_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("winebeer_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ration" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
            }

            $uid = $this->db_session->userdata("id");
            $wine["name"] = $this->input->post("winename");
			$wine["url"] = $this->input->post("wineurl");
			$wine["comment"] = $this->input->post("winecomment");
			if(isset($image) && $image!= ""){
				$wine["picture"] = $image;
			}
			$wine["rating"] =  $this->input->post("winerating");
			$wine["winebeer"] = $this->input->post("winebeer");
			$wine["recipeid"] = $this->input->post("selectfood");
			$wine["date"] = date("Y-m-d H:i:s");
			
			$where = array("id" => $this->input->post("winebeerid"));
					
            if($this->communitymodel->updatewinenbeer($where,$wine)) {
            	redirect("community/winebeercollection");
            }
          }
       }

    /**
    * This function is used to show the detail list of collection of liqure and spirits
    */
    function liqurespiritcollection() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                        "user_name" => $user_name
                );
        $user = $this->communitymodel->getuser($where);
		
		if($this->input->post("filter")) {
			
			$uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;
        
            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
        
            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }
    
                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }
    
            $data["user"] = $user;
            $data["liqurenspirits"] = $this->communitymodel->getcommonfilter($this->input->post("filter"),'liquernspirits',$user->id);
    
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
            
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/liqurespiritlist";
            $this->load->view("template/newtemplate", $data);
			
		}elseif(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;
        
            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);
        
            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }
    
                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }
    
            $data["user"] = $user;
    
            $limit = "all";
            $data["liqurenspirits"] = $this->communitymodel->getliqureandspiritsbyuserid($user->id, $limit);
    
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
    
            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/liqurespiritlist";
            $this->load->view("template/newtemplate", $data);
    
            /* $uid = $user->id;
        
            $group = $this->communitymodel->getallgroupsbyuserid($uid);
            if(isset($group) && $group !="") {
            $data["groups"] = $group;
            }
        
            $limit = "all";
            $data["liqurenspirits"] = $this->communitymodel->getliqureandspiritsbyuserid($uid, $limit);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }
	
	function updateliqurespirit() {
		//echo "ok"; exit;
		$this->freakauth_light->check();
		
		if($this->input->post("sbt_update")) {
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $liqurespirituploadpath = $this->config->item("liqurespirit_upload_path");

                $config = array(
                                "upload_path" => $liqurespirituploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
                    $image_data = $this->upload->data();
                    $imagestypes = array(
                                            "liqurespirit_168x168_upload_path" => $this->config->item("liqurespirit_168x168_upload_path"),
                                            "liqurespirit_100x100_upload_path" => $this->config->item("liqurespirit_100x100_upload_path"),
                                            "liqurespirit_50x50_upload_path" => $this->config->item("liqurespirit_50x50_upload_path")
                                        );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 336;
                        $heigth = 336;
                        if($imagetype == $this->config->item("liqurespirit_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
                        else if($imagetype == $this->config->item("liqurespirit_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("liqurespirit_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
            }

            $uid = $this->db_session->userdata("id");
            $liqure["uid"] = $uid;
            $liqure["name"] = $this->input->post("liqurename");
			$liqure["url"] = $this->input->post("liqureurl");
			$liqure["comment"] = $this->input->post("liqurecomment");
			if(isset($image) && $image!= ""){
				$liqure["picture"] = $image;
			}
			$liqure["rating"] =  $this->input->post("liqurerating");
			$liqure["date"] = date("Y-m-d H:i:s");
			
			$where = array("id" => $this->input->post("liqureid"));
					
            if($this->communitymodel->updateliqureandspirits($where,$liqure)) {
            	redirect("community/liqurespiritcollection/");
            }
          }
       }

    /**
    * This function is used to show the detail list of collection of Drink Recipes
    */
    function drinkrecipecollection() {
    	$this->freakauth_light->check();
		
		$user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
                    "user_name" => $user_name
                );
        $user = $this->communitymodel->getuser($where);
		
		if($this->input->post("filter")){
			$uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;
        	$data["drinkrecipes"] =  $this->communitymodel->getcommonfilter($this->input->post("filter"),'drinkrecipes',$user->id);
			//print_r($data["drinkrecipes"]); exit;
        	$data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/drinkrecipelist";
            $this->load->view("template/newtemplate", $data);
			
        }elseif(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $limit = "all";
            $data["drinkrecipes"] = $this->communitymodel->getalldrinkrecipesbyuserid($user->id, $limit);

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/drinkrecipelist";
            $this->load->view("template/newtemplate", $data);

            /* $uid = $user->id;
        
            $group = $this->communitymodel->getallgroupsbyuserid($uid);
            if(isset($group) && $group !="") {
            $data["groups"] = $group;
            }
        
            $limit = "all";
            $data["drinkrecipes"] = $this->communitymodel->getalldrinkrecipesbyuserid($uid, $limit);
        
            //$where = array('user_name' => base64_encode($this->db_session->userdata("user_name")));
            //$data["membership"] = $this->communitymodel->getmembership($where);
            $where = array("user_name"=>base64_encode($this->db_session->userdata("user_name")));
            $data["membership"] = $this->communitymodel->getmembership($where);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }

	function updatedrinknrecipes() {
		//echo "ok"; exit;
		$this->freakauth_light->check();
		
		if($this->input->post("sbt_update")) {
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $drinknrecipeuploadpath = $this->config->item("drinknrecipe_upload_path");

                $config = array(
                                "upload_path" => $drinknrecipeuploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                                );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
                    $image_data = $this->upload->data();
                    $imagestypes = array(
                                            "drinknrecipe_50x50_upload_path" => $this->config->item("drinknrecipe_50x50_upload_path"),
                                            "drinknrecipe_100x100_upload_path" => $this->config->item("drinknrecipe_100x100_upload_path"),
                                            "drinknrecipe_168x168_upload_path" => $this->config->item("drinknrecipe_168x168_upload_path")
                                        );
                    $this->load->library("image_lib");
                    foreach ($imagestypes as $imagetype) {
                        $width = 200;
                        $heigth = 200;

                        if($imagetype == $this->config->item("drinknrecipe_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
                        if($imagetype == $this->config->item("drinknrecipe_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("drinknrecipe_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "width" => $width,
                                        "height" => $heigth,
                                        "quality" => "100%"

                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }

                    $image = $image_data["file_name"];
                }
            }
            $uid = $this->db_session->userdata("id");
            $drink["uid"] = $uid;
            $drink["name"] = $this->input->post("drinkname");
			$drink["url"] = $this->input->post("drinkurl");
			$drink["comment"] = $this->input->post("drinkcomment");
			if(isset($image) && $image!= ""){
				$drink["picture"] = $image;
			}
			$drink["rating"] =  $this->input->post("drinkrating");
			$drink["date"] = date("Y-m-d H:i:s");
			$where = array("id" => $this->input->post("drinkid"));
					
            if($this->communitymodel->updatedrinkrecipe($where,$drink)) {
            	redirect("community/drinkrecipecollection/");
            }
          }
       }
	
    /**
    * This function is used to show image gallery
    */
    function imagegallery() {
        $this->freakauth_light->check();

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
            "user_name" => $user_name
        );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
                //$data["types"] = $this->crudmodel->getalltypes();
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;

            $imagegallery = $this->communitymodel->getimagegallery($user->id);

            /* $newimagegallery = array();
            if(!empty($imagegallery)) {
            foreach($imagegallery as $image) {
            $imagearray = (array) $image;
        
            $where = array(
            "id" => $image->aid
            );
            $activity = $this->communitymodel->getactivity($where);
            if(!empty($activity)) {
            $info = unserialize($activity->info);
            $imagearray["content"] = $info["status"];
            }
        
            $imageobject = (object) $imagearray;
        
            $newimagegallery[] = $imageobject;
            }
        
            $count = count($imagegallery);
            for($i=0; $i < $count; $i++) {
            $imagegallery[$i] = $newimagegallery[$i];
            }
            } */

            $data["imagegallery"] = $imagegallery;

            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);

            //$data["page"] = "community/recipeboxes";
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/imagegallery";
            $this->load->view("template/newtemplate", $data);

            /* $uid = $user->id;
        
            $group = $this->communitymodel->getallgroupsbyuserid($uid);
            if(isset($group) && $group !="") {
            $data["groups"] = $group;
            }
        
            $limit = "all";
            $data["drinkrecipes"] = $this->communitymodel->getalldrinkrecipesbyuserid($uid, $limit);
        
            //$where = array('user_name' => base64_encode($this->db_session->userdata("user_name")));
            //$data["membership"] = $this->communitymodel->getmembership($where);
            $where = array("user_name"=>base64_encode($this->db_session->userdata("user_name")));
            $data["membership"] = $this->communitymodel->getmembership($where);
        
            $data["page"] = "community/recipeboxes";
            $this->load->view("template/newtemplate", $data); */
        }
        else {
            $this->index();
        }
    }
	
	/**
    * This function is used to show video gallery
    */
    function videogallery() {
        $this->freakauth_light->check();
		
		/*$this->load->library("pagination");

		$config["base_url"] = base_url()."community/videogallery/admin/";
		$config["uri_segment"] = 4;
		$config["per_page"] = 1;
		$config["full_tag_open"] = "<p>";
		$config["full_tag_close"] = "</p>";
		$config["cur_tag_open"] = "<b class='current'>";
		$config["cur_tag_close"] = "</b>";
		$config["next_link"] = "&gt";
		$config["prev_link"] = "&lt";*/
		

        $user_name = $this->uri->segment("3");

        if(empty($user_name)) {
            $user_name = $this->db_session->userdata("user_name");
        }
        $where = array(
            "user_name" => $user_name
        );
        $user = $this->communitymodel->getuser($where);

        if(!empty($user)) {

            $uid = $this->db_session->userdata("id");
            $data["uid"] = $uid;

            $data["aboutme"] = $this->communitymodel->getuseraboutinfo($user->id);

            $data["isowner"] = false;
            if($user->id == $uid) {
                $data["isowner"] = true;
            }
            if(!$data["isowner"]) {
                $where = array("uid" => $uid);
                $data["isfriend"] = $this->communitymodel->isfriend($where, $uid, $user->id);
                if(!$data["isfriend"]) {
                    $where = array("uid" => $user->id);
                    $data["isrequested"] = $this->communitymodel->isfriendrequested($where, $uid);
                }

                $where = array("uid" => $user->id);
                $data["isfollow"] = $this->communitymodel->isfollow($where, $uid, $user->id);
            }

            $data["user"] = $user;
			$data["videogallery"] = $this->communitymodel->getvideogallery($user->id);
			
			/*$config["total_rows"] = count($data["videogallery"]);
			$this->pagination->initialize($config);
			$data["pagination_links"] = $this->pagination->create_links();*/
            
            $where = array(
                            "user_name" => base64_encode($user->user_name)
                        );
            $data["membership"] = $this->communitymodel->getmembership($where);
			
            $data["page"] = "community/columnstwo";
            $data["column2"] = "community/template/listviews/videogallerylisting";
            $this->load->view("template/newtemplate", $data);
		}
        else {
            $this->index();
        }
    }

    /**
    * This function is used to add blog data into favoriteblog table
    */
    function addblog() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addblog")) {
            //exit();
            $image = "";

            if($_FILES["userfile"]["name"] != "") {
                $bloguploadpath = $this->config->item("blog_upload_path");

                $config = array(
                                    "upload_path" => $bloguploadpath,
                                    "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
    
                    $image_data = $this->upload->data();

                    $imagestypes = array(
                                        "blog_50x50_upload_path" => $this->config->item("blog_50x50_upload_path"),
                                        "blog_100x100_upload_path" => $this->config->item("blog_100x100_upload_path"),
                                        "blog_168x168_upload_path" => $this->config->item("blog_168x168_upload_path")
                                    );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 336;
                        $heigth = 336;
                        if($imagetype == $this->config->item("blog_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("blog_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("blog_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
    
                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
    
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $blog = array(
                            "uid" => $uid,
                            "name" => $this->input->post("blogname"),
                            "url" => $this->input->post("blogurl"),
                            "comment" => $this->input->post("blogcomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("blograting"),
                            "date" => $date
                        );

            $blogid = $this->communitymodel->addfavoriteblog($blog);
            if($blogid > 0) {
                        redirect("community");
            }
            else {
                $data["fail"] = "Fail to add new blog. Please try again.";
                $data["page"] = "community/profile";
                $this->load->view("template/newtemplate", $data);
            }
        }
        redirect("community");
    }

    /**
    * This function is used to add outsiderecipe data into outsiderecipes table
    */
    function addoutsiderecipes() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addrecipe")) {
            //alert('added'); exit();
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $outrecipesuploadpath = $this->config->item("outsiderecipes_upload_path");
                $config = array(
                                    "upload_path" => $outrecipesuploadpath,
                                    "allowed_types" => "jpg|jpeg|gif|png"
                                );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);
            
                if($this->upload->do_upload()) {

                    $image_data = $this->upload->data();

                    $imagestypes = array(
                        "outsiderecipes_50x50_upload_path" => $this->config->item("outsiderecipes_50x50_upload_path"),
                        "outsiderecipes_100x100_upload_path" => $this->config->item("outsiderecipes_100x100_upload_path"),
                        "outsiderecipes_168x168_upload_path" => $this->config->item("outsiderecipes_168x168_upload_path")
                    );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
    
                        $width = 336;
                        $heigth = 336;
    
                        if($imagetype == $this->config->item("outsiderecipes_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("outsiderecipes_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("outsiderecipes_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
    
                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );
    
                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $recipe = array(
                            "uid" => $uid,
                            "name" => $this->input->post("recipename"),
                            "categoryid" => $this->input->post("categoryid"),
                            "url" => $this->input->post("recipeurl"),
                            "comment" => $this->input->post("recipecomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("reciperating"),
                            "date" => $date
                        );
            //$recipeid=0;
            $recipeid = $this->communitymodel->addoutsiderecipes($recipe);
            if($recipeid > 0) {
                redirect("community");
            }
            else {
            $data["fail"] = "Fail to add new outside recipe. Please try again.";
            $data["page"] = "community/profile";
            $this->load->view("template/newtemplate", $data);
            }
        }
        redirect("community");
    }

    /**
    * This function is used to add online video data into onlinevideo table
    */
    function addonlinevideo() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addvideo")) {
            //alert('added'); exit();
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $onlinevideouploadpath = $this->config->item("onlinevideo_upload_path");

                $config = array(
                                "upload_path" => $onlinevideouploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
                    $image_data = $this->upload->data();
                    $imagestypes = array(
                                        "onlinevideo_168x168_upload_path" => $this->config->item("onlinevideo_168x168_upload_path"),
                                        "onlinevideo_100x100_upload_path" => $this->config->item("onlinevideo_100x100_upload_path"),
                                        "onlinevideo_50x50_upload_path" => $this->config->item("onlinevideo_50x50_upload_path")
                                    );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 200;
                        $heigth = 200;
                        if($imagetype == $this->config->item("onlinevideo_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        if($imagetype == $this->config->item("onlinevideo_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("onlinevideo_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }
                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "quality" => "100%",
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }

                    $image = $image_data["file_name"];
                }

                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $video = array(
                            "uid" => $uid,
                            "name" => $this->input->post("videoname"),
                            "url" => $this->input->post("videourl"),
                            "comment" => $this->input->post("videocomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("videorating"),
                            "date" => $date
                        );
            //$recipeid=0;
            $videoid = $this->communitymodel->addonlinevideos($video);
            if($videoid > 0) {
                redirect("community");
            }
            /*else {
            $data["fail"] = "Fail to add new outside recipe. Please try again.";
            $data["page"] = "community/profile";
            $this->load->view("template/newtemplate", $data);
            }*/
        }
        redirect("community");
    }

    /**
    * This function is used to add liqure and spirits data into liqurenspirits table
    */
    function addliquerspirits() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addliqure")) {
            //alert('added'); exit();
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $liqurespirituploadpath = $this->config->item("liqurespirit_upload_path");

                $config = array(
                                "upload_path" => $liqurespirituploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
                    $image_data = $this->upload->data();
                    $imagestypes = array(
                                            "liqurespirit_50x50_upload_path" => $this->config->item("liqurespirit_50x50_upload_path"),
                                            "liqurespirit_25x25_upload_path" => $this->config->item("liqurespirit_25x25_upload_path")
                                        );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 100;
                        $heigth = 100;
                        if($imagetype == $this->config->item("liqurespirit_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("liqurespirit_25x25_upload_path")) {
                            $width = 25;
                            $heigth = 25;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ration" => true,
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $liqure = array(
                            "uid" => $uid,
                            "name" => $this->input->post("liqurename"),
                            "url" => $this->input->post("liqureurl"),
                            "comment" => $this->input->post("liqurecomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("liqurerating"),
                            "date" => $date
                        );
            //$recipeid=0;
            $liqureid = $this->communitymodel->addliqureandspirits($liqure);
            if($liqureid > 0) {
                redirect("community");
            }
            /*else {
            $data["fail"] = "Fail to add new outside recipe. Please try again.";
            $data["page"] = "community/profile";
            $this->load->view("template/newtemplate", $data);
            }*/
        }
        redirect("community");
    }

    /**
    * This function is used to add Drink and Recipe data into drinknrecipe table
    */
    function adddrinknrecipes() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_adddrink")) {
            //alert('added'); exit();
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $drinknrecipeuploadpath = $this->config->item("drinknrecipe_upload_path");

                $config = array(
                                "upload_path" => $drinknrecipeuploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                                );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {
                    $image_data = $this->upload->data();
                    $imagestypes = array(
                                            "drinknrecipe_50x50_upload_path" => $this->config->item("drinknrecipe_50x50_upload_path"),
                                            "drinknrecipe_25x25_upload_path" => $this->config->item("drinknrecipe_25x25_upload_path")
                                        );
                    $this->load->library("image_lib");
                    foreach ($imagestypes as $imagetype) {
                        $width = 100;
                        $heigth = 100;
                        if($imagetype == $this->config->item("drinknrecipe_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("drinknrecipe_25x25_upload_path")) {
                            $width = 25;
                            $heigth = 25;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ration" => true,
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }

                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $drink = array(
                            "uid" => $uid,
                            "name" => $this->input->post("drinkname"),
                            "url" => $this->input->post("drinkurl"),
                            "comment" => $this->input->post("drinkcomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("drinkrating"),
                            "date" => $date
                        );
            $drinkid = $this->communitymodel->adddrinkrecipes($drink);
            if($drinkid > 0) {
                redirect("community");
            }
            /*else {
                $data["fail"] = "Fail to add new outside recipe. Please try again.";
                $data["page"] = "community/profile";
                $this->load->view("template/newtemplate", $data);
            }*/
        }
        redirect("community");
    }

    /**
    * This function is used to add Wine and beer pairing data into weennbeer table
    */
    function addwinenbeer() {
        $this->freakauth_light->check();

        if($this->input->post("sbt_addwinenbeer")) {
            //alert('added'); exit();
            $image = "";
            if($_FILES["userfile"]["name"] != "") {
                $winebeeruploadpath = $this->config->item("winebeer_upload_path");

                $config = array(
                                "upload_path" => $winebeeruploadpath,
                                "allowed_types" => "jpg|jpeg|gif|png"
                            );

                $filename = $_FILES["userfile"]["name"];
                $filename = explode(".", $filename);
                $filename[0] = $filename[0].time().".".$filename[1];
                $_FILES["userfile"]["name"] = $filename[0];

                $this->load->library("upload", $config);

                if($this->upload->do_upload()) {

                    $image_data = $this->upload->data();

                    $imagestypes = array(
                                            "winebeer_50x50_upload_path" => $this->config->item("winebeer_50x50_upload_path"),
                                            "winebeer_100x100_upload_path" => $this->config->item("winebeer_100x100_upload_path"),
                                            "winebeer_168x168_upload_path" => $this->config->item("winebeer_168x168_upload_path")
                                        );

                    $this->load->library("image_lib");

                    foreach ($imagestypes as $imagetype) {
                        $width = 336;
                        $heigth = 336;

                        if($imagetype == $this->config->item("winebeer_50x50_upload_path")) {
                            $width = 50;
                            $heigth = 50;
                        }
                        else if($imagetype == $this->config->item("winebeer_100x100_upload_path")) {
                            $width = 100;
                            $heigth = 100;
                        }
                        else if($imagetype == $this->config->item("winebeer_168x168_upload_path")) {
                            $width = 168;
                            $heigth = 168;
                        }

                        $config = array(
                                        "source_image" => $image_data["full_path"],
                                        "new_image" => $imagetype,
                                        "maintain_ratio" => true,
                                        "width" => $width,
                                        "height" => $heigth
                                    );

                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    }
                    $image = $image_data["file_name"];
                }
                //$this->upload->display_errors();
            }

            $uid = $this->db_session->userdata("id");
            $date = date("Y-m-d H:i:s");

            $wine = array(
                            "uid" => $uid,
                            "name" => $this->input->post("winename"),
                            "url" => $this->input->post("wineurl"),
                            "comment" => $this->input->post("winecomment"),
                            "picture" => $image,
                            "rating" => $this->input->post("winerating"),
                            "winebeer" => $this->input->post("winebeer"),
                            "recipeid" => $this->input->post("selectfood"),
                            "date" => $date
                        );
            //$recipeid=0;
            $wineid = $this->communitymodel->addwinenbeer($wine);
            if($wineid > 0) {
                redirect("community");
            }
            /*else {
            $data["fail"] = "Fail to add new outside recipe. Please try again.";
            $data["page"] = "community/profile";
            $this->load->view("template/newtemplate", $data);
            }*/
        }
        redirect("community");
    }

    /**
    * This function is used to show the terms & condition page.
    */
    function termsandconditions() {
        $data["page"] = "community/termsncondition";
        $this->load->view("template/template", $data);
    }

    /**
    * This function is used to show the datapolicy page.
    */
    function datapolicy() {
        $data["page"] = "community/datapolicy";
        $this -> load -> view("template/template", $data);
    }
    
    /**
    * function to show the online users
    */
    function _getonlineusers() {

        $query = $this -> communitymodel -> get_all_session_data();
        $onlineusers = array();
        foreach ($query->result() as $row) {
            $udata = unserialize($row -> session_data);
            if (isset($udata['id'])) {
                $onlineusers[] = $udata['id'];
                //$datd['user_name'] = $udata['user_name'];
            }
        }
        return $onlineusers;
    }
    /**
    * function is used to call community newfooter
    */
    function commonfooter() {
        $this -> load -> view("template/modernfooter/onlinenow");
        $this -> load -> view("template/modernfooter/justadded");
        $this -> load -> view("template/modernfooter/justreviewed");
        $this -> load -> view("template/modernfooter/justloved");
    }
    
    /**
    * function to get url for new feed js function
    */
    function getnewsfeedurl($url = null) {
        if ($url != null) {//$url=$_GET['url'];
            echo $url;
            //echo file_get_contents($url);
        }
    }
	
	function winerypicks(){
			$this->load->model("wineries/winemodel");
			$table = "wine_details";
			$where = array("ourpicks"=>"1");
			$orderby = "";
			$limit = "5";
			$data["ourpicks"] = $this->winemodel->getwinedetails($table, $where, $orderby, $limit);
			$this->load->view("wineries/templates/ourpickssidebar",$data);
	}
	
	function restaurantpicks(){
			$this->load->model("wineries/winemodel");
			$table = "rest_details";
			$where = array("ourpicks"=>"1");
			$orderby = "";
			$limit = "5";
			$data["ourpicks"] = $this->restmodel->getrestdetails($table, $where, $orderby, $limit);
			$this->load->view("restaurants/templates/ourpickssidebar",$data);
	}
	    
	function winehighestrated(){
			$rating = array();
			$this->load->model("wineries/winemodel");
			$wineries = $this->winemodel->getwineryids();
			foreach($wineries as $winery){
				$rating[$winery->id] = round($this->winemodel->takerating($winery->id));
			}
			arsort($rating);
			//print_r($rating);
			foreach($rating as $wineryid=>$rating){
					$where = array("id"=>$wineryid);
				 	$mostrated[]	= $this->winemodel->getwinerydetails($where);
			}
			$mostrated = array_slice($mostrated,0,5);
			$data["mostrated"] = $mostrated;
			
			// print_r($ratingorder);exit;
			// $table = "wine_details";
			// $where = "";
			// $orderby = array("rating","desc");
			// $limit = "5";
			// $data["mostrated"] = $this->winemodel->getwinedetails($table,$where,$orderby,$limit);
	    	// print_r($ourpicks);
			$this->load->view("wineries/templates/mostratedsidebar",$data);
	}
	function resthighestrated(){
			$rating = array();
			$this->load->model("wineries/winemodel");
			$this->load->model("restaurants/restaurantmodel");
			$wineries = $this->restaurantmodel->getrestaurantids();
			foreach($wineries as $winery){
				$rating[$winery->id] = round($this->restaurantmodel->takerating($winery->id));
			}
			arsort($rating);
			//print_r($rating);
			foreach($rating as $wineryid=>$rating){
					$where = array("id"=>$wineryid);
				 	$mostrated[]	= $this->restaurantmodel->getrestaurantsdetails($where);
			}
			$mostrated = array_slice($mostrated,0,5);
			$data["mostrated"] = $mostrated;
			$this->load->view("restaurants/templates/mostratedsidebar",$data);
	}
	function restmostpopular(){
			$table = "rest_details";
			$where = array("mostpopular"=>"1");
			$orderby = "";
			$limit = "5";
			$data["ourpicks"] = $this->restmodel->getrestdetails($table, $where, $orderby, $limit);
			$this->load->view("restaurants/templates/mostpopularsidebar",$data);
	}
	function winemostpopular(){
			$this->load->model("wineries/winemodel");
			$table = "wine_details";
			$where = array("mostpopular"=>"1");
			$orderby = "";
			$limit = "5";
			$data["mostpopulars"] = $this->winemodel->getwinedetails($table, $where, $orderby, $limit);
			$this->load->view("wineries/templates/mostpopularsidebar",$data);
	}
		
    }
?>