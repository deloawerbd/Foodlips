<?php
/*this class is specially used for restaurants ajax request */
class Restaurantsrequesthandler extends Controller {

	function Restaurantsrequesthandler() {
		parent :: Controller();
		$this->load->helper("url");
		$this->load->model("restaurants/restaurantmodel","restmodel");
	}

	/**
	 * function to get states by countryid
	 */
	 function getstatesbycountry() {
	 	if($this->input->post("countryid")){
	 		$response = array();

			$where = array('country_id' => $this->input->post("countryid"));

			$states = $this->restmodel->getstatesbycountryid($where);
			if(!empty($states)){
				$temparr["msg"] = "success";
				foreach($states as $state) {
					$temparr["id"] = $state->id;
					$temparr["name"] = $state->state_name;
					array_push($response,$temparr);
				}
			}else{
				$temparr["msg"] = "datanotfound";
				array_push($response, $temparr);

			}

			echo json_encode(array("states" => $response));
	 	}
	 }

	 function getcitiesbystate(){
	 	if($this->input->post("stateid")){
	 		$response = array();
			$stateid = $this->input->post("stateid");
			$temparr["stateid"] = $stateid;
	 		if(!is_numeric($stateid)){
	 			$where = array("state_name"=>$stateid);
	 			$stateid = $this->restmodel->getstateidbyname($where);

				$temparr["stateid"] = $stateid;
	 		}
			$where = array('stateid' => $stateid);
			$cities = $this->restmodel->getcitieswhere($where);
			if(!empty($cities)){
				$temparr["msg"] = "success";
				foreach($cities as $city) {
					$temparr["id"] = $city->id;
					$temparr["name"] = $city->name;
					array_push($response,$temparr);
				}
			}else{
				$temparr["msg"] = "datanotfound";
				array_push($response, $temparr);
			}
			echo json_encode(array("cities" => $response));
	 	}

	 }


	/**
	 * This function is uesd to upload restaurant images to specified location
	 */

	function uploadimage() {

		$response = array();

		$restaurantuploadpath = $this->config->item("restaurant_upload_home");

		$config = array(
							"upload_path" => $restaurantuploadpath,
							"allowed_types" => "jpg|jpeg|gif|png"
						);
		$filename = $_FILES["userfile"]["name"];
		$filename = explode(".", $filename);
		$filename[0] = $filename[0].time().".".$filename[1];
		$_FILES["userfile"]["name"] = $filename[0];

		$this->load->library("upload", $config);

		if($this->upload->do_upload()) {

			$image_data = $this->upload->data();

			$imagestypes = array(
									"restaurant_index_path" => $this->config->item("restaurant_index_path"),
									"restaurant_650x350_path" => $this->config->item("restaurant_650x350_path"),
									"restaurant_275x198_path" => $this->config->item("restaurant_275x198_path"),
									"restaurant_100x100_path" => $this->config->item("restaurant_100x100_path")
								);

			$this->load->library("image_lib");

			foreach ($imagestypes as $imagetype) {

				$width = 100;
				$heigth = 100;

				if($imagetype == $this->config->item("restaurant_index_path")) {

					$width = 1004;
					$heigth = 500;

				}else if($imagetype == $this->config->item("restaurant_650x350_path")) {

					$width = 650;
					$heigth = 350;

				}else if($imagetype == $this->config->item("restaurant_275x198_path")) {

					$width = 275;
					$heigth = 198;

				}else if($imagetype == $this->config->item("restaurant_100x100_path")) {

					$width = 100;
					$heigth = 100;

				}

				$config = array(
									"source_image" => $image_data["full_path"],
									"new_image" => $imagetype,
									"maintain_ration" => true,
									"width" => $width,
									"height" => $heigth
								);
				$this->image_lib->initialize($config);
				$this->image_lib->resize();
			}

			$temparr["images"] = $image_data["file_name"];
			$temparr["msg"] = "success";
			array_push($response, $temparr);
			echo json_encode(array("images" => $response));
		}else {
			$temparr["msg"] = "fail";
			array_push($response, $temparr);
			echo json_encode(array("images" => $response));
		}
	}


	/**
	 * This function is used to delete the uploaded image
	 */
	 function deleteimage() {

	 	$filename = $this->input->post("filename");

		$filename = trim($filename);
		if(isset($filename) && $filename != "") {
			$response = array();

			$uploadpath = $this->config->item("restaurant_upload_home");
			$temparr["path"] = $uploadpath;

			if(file_exists($uploadpath."/".$filename)) {
				unlink($uploadpath."/".$filename);

				$uploadpath = $this->config->item("restaurant_index_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_650x350_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_275x198_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_100x100_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$temparr["msg"] = "success";
				array_push($response, $temparr);
				echo json_encode(array("images" => $response));
			} else {
				$temparr["msg"] = "not found";
				array_push($response, $temparr);
				echo json_encode(array("images" => $response));
			}
		}
	}

	/**
	 * function to make comment on restaurant
	 */
	function commentonrestaurant() {

		if($this->input->post("restaurantid") && $this->input->post("comment") && $this->input->post("somekey") == "somekey"){
			$response = array();
			$rid = $this->input->post("restaurantid");
			$comment = $this->input->post("comment");
			$uid = $this->db_session->userdata("id");

			if($rid > 0 && $uid > 0){
				$date = date("Y-m-d H:i:s");
				$restaurantcomment = array(
											"uid" => $uid,
											"rid" => $rid,
											"comment" => $comment,
											"date" => $date
										);
				if($this->restmodel->addrestaurantcomment($restaurantcomment) > 0) {
					$where = array("id" => $uid);
					$this->load->model("communitymodel");
					$user = $this->communitymodel->getuser($where);

					// here just creating an array to pass to javascript
					// so that we can show or add new comment to comment container
					$userimg = "noavatar.png";
					$temparr["uid"] = $uid;
					if(!empty($user->name)) {
						$temparr["name"] = $user->name;
					}
					$temparr["user_name"] = $user->user_name;
					if($user->image != "") {
						$userimg = $user->image;
					}
					$temparr["image"] = $userimg;
					$temparr["comment"] = $comment;
					$temparr["timeago"] = $this->_timeago($date);
					$temparr["msg"] = "success";
				}
			}else {
				$temparr["msg"] = "fail";
			}
			array_push($response,$temparr);
			echo json_encode(array("comments" => $response));
		}
	}

	/**
	 * This function is used to get activity time ago in format.
	 * @param $date, the date actitivity to calculate.
	 * @param $info, the information of actitivity done.
	 * @return timeago, calculated time difference.
	 */
	function _timeago($date) {
		if(empty($date)) {
			// no date provided
			return "";
		}

		$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
		$lengths = array("60","60","24","7","4.35","12","10");

		$now = time();
		$unix_date = strtotime($date);

		// check validity of date
		if(empty($unix_date)) {
			// bad date
			return "";
		}

		// is it future date or past date
		if($now > $unix_date) {
			$difference = $now - $unix_date;
			$tense = "ago";
		}
		else {
			$difference = $unix_date - $now;
			$tense = "from now";
		}

		for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
			$difference /= $lengths[$j];
		}

		$difference = round($difference);

		if($difference != 1) {
			$periods[$j].= "s";
		}

		return "$difference $periods[$j] {$tense}";
	}

	/**
	 * Function to add extra photos of restaurant
	 */
	 // function addextraphotos(){
	 	// $uid = $this->db_session->userdata("id");
	 	// if($this->input->post("rid") != "" && $uid != ""){
	 		// $response = array();
			// $rid = $this->input->post("rid");
//
			// $where = array("rid" => $rid,
							// "uid" => $uid);
//
	 		// if($this->restmodel->getrestaurantsextrainfo($where) > 0){
	 			// $info = $this->restmodel->getrestaurantsextrainfo($where);
//
				// if($this->is_serial($info[0]->restaurant_img)){
					// $images = unserialize($info[0]->restaurant_img);
					// $images = is_array($this->input->post("imagearray")) ? serialize(array_merge($images,$this->input->post("imagearray"))) : serialize(array_merge($images,array($this->input->post("imagearray"))));
					// //print_r($images);
				// }else if($info[0]->restaurant_img == ""){
					// $images = serialize($this->input->post("imagearray"));
				// }
				// //update record
				// if($this->restmodel->updaterestaurantseaxtrainfo($where,array("restaurant_img" => $images))){
					// $temparr["msg"] = "success";
				// }else{
					// $temparr["msg"] = "fail";
				// }
			// }else{
	 			// $restaurantsphotos = array(
										// "rid" => $rid,
										// "uid" => $uid,
										// "restaurant_img" => serialize($this->input->post("imagearray")),
										// "date" => date("Y-m-d H:i:s"),
										// "ip" => $_SERVER["REMOTE_ADDR"]
									// );
				// if($this->restmodel->addrestaurantsextarinfo($restaurantsphotos) > 0){
					// $temparr["msg"] = "success";
				// }else{
					// $temparr["msg"] = "fail";
				// }
			// }
			// array_push($response,$temparr);
			// echo json_encode(array("restaurant" => $response));
		// }
	// }
	function addextraphotos(){
	 	$uid = $this->db_session->userdata("id");
		$role = $this->db_session->userdata("role");
		$response = array();
		$segment3 = $this->input->post("segment3");
		$rid = $this->input->post("rid");
	 	if($this->input->post("rid") != "" && $uid != ""){
	 		//for admin,extra photos will get added directly into rest_details table else rest_extra_info table
	 		if($role=="admin"){
				if($segment3=="venue"){
					$where = array("rid" => $rid);
			 		if($this->restmodel->getrestextrainfoapi($where) > 0){
			 			$info = $this->restmodel->getrestextrainfoapi($where);

						if($this->is_serial($info[0]->restaurant_img)){
							$images = unserialize($info[0]->restaurant_img);
							$images = is_array($this->input->post("imagearray")) ? serialize(array_merge($images,$this->input->post("imagearray"))) : serialize(array_merge($images,array($this->input->post("imagearray"))));
							//print_r($images);
						}else if($info[0]->restaurant_img == ""){
							$images = serialize($this->input->post("imagearray"));
						}
						//update record
						if($this->restmodel->updateresteaxtrainfoapi($where,array("restaurant_img" => $images))){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
					}else{
			 			$restaurantsphotos = array(
												"rid" => $rid,
												"uid" => $uid,
												"restaurant_img" => serialize($this->input->post("imagearray")),
												"date" => date("Y-m-d H:i:s"),
												"ip" => $_SERVER["REMOTE_ADDR"],
											);
						if($this->restmodel->addrestextarinfoapi($restaurantsphotos) > 0){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
					}

				}else{

			    	$where = array("id" => $rid);
					//print_r($this->restmodel->getrestaurantsdetails($where));exit;
			 		if($this->restmodel->getrestaurantscount($where)>0){
			 			$info = $this->restmodel->getrestaurantsdetails($where);

						if($this->is_serial($info->images)){
							$images = unserialize($info->images);
							$images = is_array($this->input->post("imagearray")) ? serialize(array_merge($images,$this->input->post("imagearray"))) : serialize(array_merge($images,array($this->input->post("imagearray"))));
							//print_r($images);
						}else if($info->images == ""){
							$images = serialize($this->input->post("imagearray"));
						}
						//update record
						if($this->restmodel->updaterestaurant($where,array("images" => $images))){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
					}
				}

	 		}else{
					$where = array("rid" => $rid,
								"uid" => $uid);
			 		if($this->restmodel->getrestaurantsextrainfo($where) > 0){
			 			$info = $this->restmodel->getrestaurantsextrainfo($where);
						if($this->is_serial($info[0]->restaurant_img)){
							$images = unserialize($info[0]->restaurant_img);
							$images = is_array($this->input->post("imagearray")) ? serialize(array_merge($images,$this->input->post("imagearray"))) : serialize(array_merge($images,array($this->input->post("imagearray"))));
							//print_r($images);
						}else if($info[0]->restaurant_img == ""){
							$images = serialize($this->input->post("imagearray"));
						}
						//update record
						if($this->restmodel->updaterestaurantseaxtrainfo($where,array("restaurant_img" => $images))){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
					}else{
						if($segment3=="venue"){
							$datalocation = "api";
						}else{
							$datalocation = "database";
						}
			 			$restaurantsphotos = array(
												"rid" => $rid,
												"uid" => $uid,
												"restaurant_img" => serialize($this->input->post("imagearray")),
												"date" => date("Y-m-d H:i:s"),
												"ip" => $_SERVER["REMOTE_ADDR"],
												"datalocation"=>$datalocation
											);
						if($this->restmodel->addrestaurantsextarinfo($restaurantsphotos) > 0){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
				}
	 		}
	 		array_push($response,$temparr);
			echo json_encode(array("restaurant" => $response));
		}
	}
	// function to add extra features of restaurants
	// function addextrafeatures(){
		// $uid = $this->db_session->userdata("id");
		// $response = array();
		// $rid = $this->input->post("rid");
	 	// if($this->input->post("rid") != "" && $uid != ""){
			// $where = array("rid" => $rid,
							// "uid" => $uid);
	 		// if($this->restmodel->getrestaurantsextrainfo($where) > 0){
	 			// $info = $this->restmodel->getrestaurantsextrainfo($where);
//
				// if($this->is_serial($info[0]->featureid)){
					// $features = unserialize($info[0]->featureid);
					// $features = is_array($this->input->post("selfeature")) ? serialize(array_merge($features,$this->input->post("selfeature"))) : serialize(array_merge($features,array($this->input->post("selfeature"))));
				// }else if($info[0]->featureid == ""){
					// $features = serialize($this->input->post("selfeature"));
				// }
				// //update record
				// if($this->restmodel->updaterestaurantseaxtrainfo($where,array("featureid" => $features))){
					// $temparr["msg"] = "success";
				// }else{
					// $temparr["msg"] = "fail";
				// }
			// }else{
	 			// $restaurantsfeatures = array(
										// "rid" => $rid,
										// "uid" => $uid,
										// "featureid" => serialize($this->input->post("selfeature")),
										// "date" => date("Y-m-d H:i:s"),
										// "ip" => $_SERVER["REMOTE_ADDR"]
									// );
				// if($this->restmodel->addrestaurantsextarinfo($restaurantsfeatures) > 0){
					// $temparr["msg"] = "success";
				// }else{
					// $temparr["msg"] = "fail";
				// }
			// }
			// array_push($response,$temparr);
			// echo json_encode(array("restaurant" => $response));
		// }
	// }

	function addextrafeatures(){
		$role = $this->db_session->userdata("role");
		$uid = $this->db_session->userdata("id");
		$segment3 = $this->input->post("segment3");
		$rid = $this->input->post("rid");
		$response = array();
		if($role == "admin"){
			if($segment3 == "venue"){
				$where = array("rid"=>$rid);
				if($this->restmodel->getrestextrainfoapi($where)>0){
					$info = $this->restmodel->getrestextrainfoapi($where);
					if($this->is_serial($info[0]->featureid)){
							$features = unserialize($info[0]->featureid);
							$features = is_array($this->input->post("selfeature")) ? (array_merge($features,$this->input->post("selfeature"))) : (array_merge($features,array($this->input->post("selfeature"))));
							$features = array_unique($features);
							$features = serialize($features);
					}else if($info[0]->featureid == ""){
							$features = serialize($this->input->post("selfeature"));
					}
						//update record
					if($this->restmodel->updateresteaxtrainfoapi($where,array("featureid" => $features))){
						$temparr["msg"] = "success";
					}else{
						$temparr["msg"] = "fail";
					}
				}else{
					$feature = serialize($this->input->post("selfeature"));
					$data = array("rid"=>$rid,
								  "uid"=>$uid,
								  "featureid"=>$feature,
								  "date" => date("Y-m-d H:i:s"),
								  "ip" => $_SERVER["REMOTE_ADDR"]);
				  	if($this->restmodel->addrestextarinfoapi($data)){
				  		$temparr["msg"] = "success";
				  	}else{
				  		$temparr["msg"] = "fail";
				  	}
				}
			}else{
				$where = array("id" => $rid);
		 		if($this->restmodel->getrestaurantscount($where) > 0){
		 			$info = $this->restmodel->getrestaurantsdetails($where);

					if($this->is_serial($info->featureid)){
						$features = unserialize($info->featureid);
						$features = is_array($this->input->post("selfeature")) ? (array_merge($features,$this->input->post("selfeature"))) : (array_merge($features,array($this->input->post("selfeature"))));
						//print_r($images);
						$features = array_unique($features);
						$features = serialize($features);
					}else if($info->featureid == ""){
						$features = serialize($this->input->post("selfeature"));
					}
					//update record
					if($this->restmodel->updaterestaurant($where,array("featureid" => $features))){
						$temparr["msg"] = "success";
					}else{
						$temparr["msg"] = "fail";
					}
				}
			}
		}else{
			$where = array("rid" => $rid,
						"uid" => $uid);
	 		if($this->restmodel->getrestaurantsextrainfo($where) > 0){
	 			$info = $this->restmodel->getrestaurantsextrainfo($where);
				if($this->is_serial($info[0]->featureid)){
					$features = unserialize($info[0]->featureid);
					$features = is_array($this->input->post("selfeature")) ? (array_merge($features,$this->input->post("selfeature"))) : (array_merge($features,array($this->input->post("selfeature"))));
					$features = array_unique($features);
					$features = serialize($features);
					//print_r($images);
				}else if($info[0]->featureid == ""){
					$features = serialize($this->input->post("selfeature"));
				}
				//update record

				if($this->restmodel->updaterestaurantseaxtrainfo($where,array("featureid" => $features))){
					$temparr["msg"] = "success";
				}else{
					$temparr["msg"] = "fail";
				}
			}else{
				if($segment3=="venue"){
							$datalocation = "api";
						}else{
							$datalocation = "database";
						}
	 			$restaurantsphotos = array(
										"rid" => $rid,
										"uid" => $uid,
										"featureid" => serialize($this->input->post("selfeature")),
										"date" => date("Y-m-d H:i:s"),
										"ip" => $_SERVER["REMOTE_ADDR"],
										"datalocation"=>$datalocation
									);
				if($this->restmodel->addrestaurantsextarinfo($restaurantsphotos) > 0){
					$temparr["msg"] = "success";
				}else{
					$temparr["msg"] = "fail";
				}
		}

		}
			array_push($response,$temparr);
		    echo json_encode(array("restaurant" => $response));
	}
	// function to rate the restaurant
	function rate(){
		if($this->input->post("rating") && $this->input->post("rid")) {
			$rid = $this->input->post("rid");
			$where = array(
							"uid" => $this->db_session->userdata("id"),
							"rid" => $rid
						);
			$rating = array(
							"uid" => $this->db_session->userdata("id"),
							"rid" => $rid,
							"rating" => $this->input->post("rating"),
							"date" => date("Y-m-d H:i:s"),
						);
			$response = array();

			if($this->restmodel->isratingexist($where)) {
				if($this->restmodel->updaterating($where, $rating)) {
					$temparr["msg"] = "updated";
				}else {
					$temparr["msg"] = "fail";
				}
			}else {
				if($this->restmodel->addrating($rating) > 0) {
					$temparr["msg"] = "success";
				}else {
					$temparr["msg"] = "fail";
				}
			}
			array_push($response, $temparr);
			echo json_encode(array("rating" => $response));
		}
	}

	//function to check is srting serialize return result
	function is_serial($data) {
		return (@unserialize($data) !== false);
	}

	//This function is used to add restaurant in to favorite restaurants list
	function addtofavorites() {
		$response = array();
		if($this->input->post("rid") != "") {
			$restaurantid = $this->input->post("rid");
			$where = array(
							"restaurantid" => $restaurantid,
							"uid" => $this->db_session->userdata("id")
						);
			if($this->restmodel->isfavorite($where)) {
				$temparr["msg"] = "alreadyadded";
			}else {
				if($this->input->post("venueimage") != "" || $this->input->post("venuetitle") != "" ){
					$favorite = array (
									"restaurantid" => $restaurantid,
									"uid" => $this->db_session->userdata("id"),
									"isvenue" => "1",
									"image_url" => $this->input->post("venueimage"),
									"venue_title" => $this->input->post("venuetitle"),
									"user_name" => $this->db_session->userdata("user_name"),
									"date" => date("y-m-d H:i:s")
								);
				}else{
					$favorite = array (
									"restaurantid" => $restaurantid,
									"uid" => $this->db_session->userdata("id"),
									"user_name" => $this->db_session->userdata("user_name"),
									"date" => date("y-m-d H:i:s")
							);

				}

				if($this->restmodel->addtofavorites($favorite) > 0) {
					//temporary commented if needed in newsfeed simply uncomment this code
					/*$info = array(
									"restaurantid" => $restaurantid,
									"uid" => $this->db_session->userdata("id"),
									"date" => date("y-m-d H:i:s")
								);
					$activity = array(
										"uid" => $this->db_session->userdata("id"),
										"content" => "favorite_restaurant",
										"info" => serialize($info),
										"date" => date("Y-m-d H:i:s")
									);
					$this->load->model("communitymodel");
					$this->communitymodel->addactivity($activity);*/
					$temparr["msg"] = "success";
				}else {
					$temparr["msg"] = "fail";
				}
			}
			array_push($response, $temparr);
			echo json_encode(array("favorite" => $response));
		}else {
			$temparr["msg"] = "notfound";
			array_push($response, $temparr);
			echo json_encode(array("favorite" => $response));
		}
	}

	 function deletesavedimage() {

	 	$filename = $this->input->post("filename");
		$id = $this->input->post("id");

		$filename = trim($filename);
		$id = trim($id);
		if(isset($filename) && $filename != "") {
			$response = array();

			$uploadpath = $this->config->item("restaurant_upload_home");
			$temparr["path"] = $uploadpath;

			if(file_exists($uploadpath."/".$filename)) {
				unlink($uploadpath."/".$filename);

				$uploadpath = $this->config->item("restaurant_index_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_650x350_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_275x198_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}

				$uploadpath = $this->config->item("restaurant_100x100_path");
				if(file_exists($uploadpath."/".$filename)) {
					unlink($uploadpath."/".$filename);
				}
				$newarray = array();
				$where = array("id"=>$id);
				$restaurants =  $this->restmodel->getrestaurantsdetails($where);
				// print_r($wineries);
				$images = unserialize($restaurants->images);
				/*foreach($images as $image){
					if($image != $filename){
						$newarray[] =	$image;
					}
				}*/
				$images = array_diff($images, array($filename));
				// $newarray = serialize($newarray);
				$newarray = serialize($images);
				$data = array("images"=>$newarray);
				$where = array("id"=>$id);
				$this->restmodel->updaterestaurant($where, $data);
				$temparr["msg"] = "success";
				array_push($response, $temparr);
				echo json_encode(array("images" => $response));
			} else {
				$temparr["msg"] = "not found";
				array_push($response, $temparr);
				echo json_encode(array("images" => $response));
			}
		}
	}
	function mailtofriend(){
		$response = array();
		$this->load->library("email");
		$this->email->clear();
		$sendto = $this->input->post("sendto");
		$subject = $this->input->post("subject");
		$body = $this->input->post("body");
		$this->email->from("info@foodlips.com","Foodlips");
		$this->email->to("$sendto");
		$this->email->subject($subject);
		$this->email->message($body);
		if($this->email->send()){
			$temparr["msg"] = "success";
		}else{
			$temparr["msg"] = "fail";
		}
		array_push($response, $temparr);
		echo json_encode(array("restaurant"=>$response));
	}

	function addopeninghours(){
		$response = array();
		$rid = $this->input->post("rid");
		$uid = $this->input->post("uid");
		$days = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");
		foreach($days as $day){
			$breakfast = '0';
			$lunch = '0';
			$dinner = '0';
			$checkedarray = $this->input->post($day);
			$opening_time = $checkedarray['opening_time'];
			$closing_time = $checkedarray['closing_time'];
			if(!empty($checkedarray)){
				if(in_array('breakfast',$checkedarray) && $opening_time != '25' && $closing_time != '25'){
					$breakfast = '1';
			 	}
				if(in_array('lunch',$checkedarray) && $opening_time != '25' && $closing_time != '25'){
					$lunch = '1';
				}
				if(in_array('dinner',$checkedarray) && $opening_time != '25' && $closing_time != '25'){
					$dinner = '1';
				}

				if($opening_time == '26' || $closing_time == '26'){
					$breakfast = '1';
					$lunch = '1';
					$dinner = '1';
				}
				$data = array("rid"=>$rid,
							  "uid"=>$uid,
							  "day"=>$day,
							  "breakfast"=>$breakfast,
							  "lunch"=>$lunch,
							  "dinner"=>$dinner,
							  "openingtime"=>$opening_time,
							  "closingtime"=>$closing_time,
							  );
			  	$where = array('rid'=>$rid,'day'=>$day);
			  	if($this->restmodel->isOpeningHoursexists($where)){
			  		$where = array('rid'=>$rid,
								   'day'=>$day);
			  		$updateid = $this->restmodel->updateOpeningHours($data,$where);
					$insertid = 1;
			  	}else{
			  		$insertid = $this->restmodel->insertopeninghours($data);
			  	}

				if($insertid > 0){
					$temparr["msg"] = "success";
				}else{
					$temparr["msg"] = "fail";
				}
			}
		}
		array_push($response, $temparr);
		echo json_encode(array("restaurant"=>$response));

	}

	function addmenu(){
		$uid = $this->db_session->userdata("id");
		$role = $this->db_session->userdata("role");
		$response = array();
		$segment3 = $this->input->post("segment3");
		$rid = $this->input->post("rid");
		$new_breakfast_images = $this->input->post("breakfastarray");
		//print_r($new_breakfast_images);
		$new_lunch_images = $this->input->post("luncharray");
		//print_r($new_lunch_images)
		$new_dinner_images = $this->input->post("dinnerarray");
		$where = array("rid" => $rid,
					   "uid" => $uid);
			 		if($this->restmodel->getrestaurantsextrainfo($where) > 0){
			 			$info = $this->restmodel->getrestaurantsextrainfo($where);
						if($this->is_serial($info[0]->breakfast)){
							$images = unserialize($info[0]->breakfast);
							if(!empty($new_breakfast_images)){
								$breakfast = serialize(array_merge($images,$new_breakfast_images));
							}else{
								$breakfast = $info[0]->breakfast;
							}
							//$breakfast = is_array($this->input->post("breakfastarray")) ? serialize(array_merge($images,$this->input->post("breakfastarray"))) : serialize(array_merge($images,array($this->input->post("breakfastarray"))));
							//print_r($images);
						}else{
							if(!empty($new_breakfast_images)){
								$breakfast = serialize($new_breakfast_images);
							}else{
								$breakfast="";
							}

						}
						if($this->is_serial($info[0]->lunch)){
							$images = unserialize($info[0]->lunch);
							if(!empty($new_lunch_images)){
								$lunch = serialize(array_merge($images,$new_lunch_images));
							}else{
								$lunch = $info[0]->lunch;
							}
							//$breakfast = is_array($this->input->post("breakfastarray")) ? serialize(array_merge($images,$this->input->post("breakfastarray"))) : serialize(array_merge($images,array($this->input->post("breakfastarray"))));
							//print_r($images);
						}else{
							if(!empty($new_lunch_images)){
								$lunch = serialize($new_lunch_images);
							}else{
								$lunch="";
							}

						}
						if($this->is_serial($info[0]->dinner)){
							$images = unserialize($info[0]->dinner);
							if(!empty($new_dinner_images)){
								$dinner = serialize(array_merge($images,$new_dinner_images));
							}else{
								$dinner = $info[0]->dinner;
							}
							//$breakfast = is_array($this->input->post("breakfastarray")) ? serialize(array_merge($images,$this->input->post("breakfastarray"))) : serialize(array_merge($images,array($this->input->post("breakfastarray"))));
							//print_r($images);
						}else{
							if(!empty($new_dinner_images)){
								$dinner = serialize($new_dinner_images);
							}else{
								$dinner="";
							}

						}
						// if($this->is_serial($info[0]->lunch)){
							// $images = unserialize($info[0]->lunch);
							// // $lunch = is_array($this->input->post("luncharray")) ? serialize(array_merge($images,$this->input->post("luncharray"))) : serialize(array_merge($images,array($this->input->post("luncharray"))));
							// $lunch = serialize(array_merge($images,$this->input->post("luncharray")));
							// //print_r($images);
						// }else{
							// $lunch = serialize($this->input->post("luncharray"));
						// }
						// if($this->is_serial($info[0]->dinner)){
							// $images = unserialize($info[0]->dinner);
							// $dinner = is_array($this->input->post("dinnerarray")) ? serialize(array_merge($images,$this->input->post("dinnerarray"))) : serialize(array_merge($images,array($this->input->post("dinnerarray"))));
							// //print_r($images);
						// }else if($info[0]->restaurant_img == ""){
							// $dinner = serialize($this->input->post("dinnerarray"));
						// }
						//update record
						$data = array("breakfast"=>$breakfast,
									  "lunch"=>$lunch,
									  "dinner"=>$dinner
									  );
						if($this->restmodel->updaterestaurantseaxtrainfo($where,$data)){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
					}else{
						if($segment3=="venue"){
							$datalocation = "api";
						}else{
							$datalocation = "database";
						}
			 			$restaurantsphotos = array(
												"rid" => $rid,
												"uid" => $uid,
												"breakfast" =>!empty($new_breakfast_images)?serialize($new_breakfast_images):"",
												"lunch"=>!empty($new_lunch_images)?serialize($new_lunch_images):"",
												"dinner"=>!empty($new_dinner_images)?serialize($new_dinner_images):"",
												"date" => date("Y-m-d H:i:s"),
												"ip" => $_SERVER["REMOTE_ADDR"],
												"datalocation"=>$datalocation
											);
						if($this->restmodel->addrestaurantsextarinfo($restaurantsphotos) > 0){
							$temparr["msg"] = "success";
						}else{
							$temparr["msg"] = "fail";
						}
				}
					array_push($response, $temparr);
					echo json_encode(array("restaurant"=>$response));
	}
	// function to rate the restaurant
	function like(){
		//if(!empty($this->input->post("like")) && $this->input->post("rid")) {
			$rid = $this->input->post("rid");
			$where = array(
							"uid" => $this->db_session->userdata("id"),
							"rid" => $rid
						);
			$rating = array(
							"uid" => $this->db_session->userdata("id"),
							"rid" => $rid,
							"liked" => $this->input->post("like"),
							"date" => date("Y-m-d H:i:s"),
						);
			$response = array();

			if($this->restmodel->islikeexist($where)) {
				if($this->restmodel->updatelike($where, $rating)) {
					$temparr["msg"] = "updated";
				}else {
					$temparr["msg"] = "fail";
				}
			}else {
				if($this->restmodel->addlike($rating) > 0) {
					$temparr["msg"] = "success";
				}else {
					$temparr["msg"] = "fail";
				}
			}
			array_push($response, $temparr);
			echo json_encode(array("rating" => $response));
		}
	function editsuggestionsformrest(){
		$response = array();
		$rid = $this->input->post("restidsuggestion");
		$address = $this->input->post("address");
		$website = $this->input->post("website");
		$facebook = $this->input->post("facebook");
		$twitter = $this->input->post("twitter");
		$contact = $this->input->post("contact");
		$timing = $this->input->post("timing");
		$uid = $this->db_session->userdata("id");
		$data = array();
		$data['uid'] = $uid;
		$data['rid'] = $rid;
		if($this->db_session->userdata("role")=="admin"){

			$data['isapproved'] = '1';
			$data['approval_date'] = date("Y-m-d H:i:s");
		}
		if(!empty($address)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Address"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Address';
			$data['suggested'] = $address;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}

		}
		if(!empty($website)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Website"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Website';
			$data['suggested'] = $website;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}

		}
		if(!empty($facebook)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Facebook"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Facebook';
			$data['suggested'] = $facebook;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}

		}
		if(!empty($twitter)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Twitter"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Twitter';
			$data['suggested'] = $twitter;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}

		}
		if(!empty($contact)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Phone"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Phone';
			$data['suggested'] = $contact;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}
		}
		if(!empty($timing)){
			if($this->db_session->userdata("role")=="admin"){
				$where = array("rid"=>$rid,
								"name"=>"Opening Hours"
							   );
			    $udpatedata = array("isapproved"=>"0");
				$this->restmodel->updatesuggestions($udpatedata,$where);
			}
			$data['name'] = 'Opening Hours';
			$data['suggested'] = $timing;
			if($this->restmodel->addsuggestion($data) > 0) {
				$temparr["msg"] = "success";
			}else {
				$temparr["msg"] = "fail";
			}
		}
		array_push($response, $temparr);
		echo json_encode(array("suggestions" => $response));
	}
	//}

	function getcities_and_states() {
		    $results = $this->restmodel->getallcities_of_country($data["country"]->id);
			echo json_encode($results);
	}

    public function ajax_search()
    {
        $result = array();
        if (!empty($result)) {
            foreach ($result as $row):
                echo "<li><a href='#'>" . $row->name . "</a></li>";
            endforeach;
        }
        else {
            echo "<li> <em> Not found ... </em> </li>";
        }
    }
}
?>