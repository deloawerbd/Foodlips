<?php
class Content extends Controller {

    function Content() {
			parent::Controller();

			$this->load->helper("url");
			$this->load->helper("form");
			$this->load->model("communitymodel");
		}
		function privacy_policy(){
			$data["page"] = "pages/privacy_policy";
			$this->load->view("template/template", $data);
		}
		function terms_and_conditions(){
			$data["page"] = "pages/terms_and_conditions";
			$this->load->view("template/template", $data);
		}

    //https://www.foodlips.com/shared/privacy-policy
	//https://www.foodlips.com/shared/terms-and-conditions

}
?>