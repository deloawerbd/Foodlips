<?php

class Home_model extends Model {

    // ------------------------------------------------------------------------
    /**
     * initialises the class inheriting the methods of the class Model 
     *
     * @return Usermodel
     */
    function Home_model() {
        parent::Model();
    }

    function get_slides() {
        return $this->db->order_by('id desc')
                        ->get('home')->result_array();
    }

}
