<?php 
Class Recipemodel extends Model {
	
	function Recipemodel() {
		parent::Model();
	}
///////////////////Start category///////////////////////////////
	
	function getnoofrowsfromcategory() {
		$query=$this->db->get('categories');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedcategory($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('categories',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		} 
	}
	
	function getcategory() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("categories");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getcategorynamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("categories");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function getcategorybyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("categories");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addcategory($data) {
		$this->db->limit(1);
		if($this->db->insert('categories', $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editcategorybyid($id,$data) {
		$this->db->set($data);
		$this->db->where('id',$id);
		$this->db->limit(1);
		if($this->db->update('categories')) {
			return true;
		}else {
			return false;
		}
	}
	
	function deletecategorybyid($id) {
		$this->db->where('id', $id);
		$this->db->limit(1);
		if($this->db->delete('categories')){
			return true;
		} 
		return false;
	}
	
///////////////////End category///////////////////////////////
///////////////////Start Course///////////////////////////////
	
	function getnoofrowsfromcourse() {
		$query=$this->db->get('courses');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedcourse($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('courses',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		} 
	}
	
	function getcoursenamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("courses");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function getcourse() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("courses");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getcoursebyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("courses");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addcourse($data) {
		$this->db->limit(1);
		if($this->db->insert('courses', $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editcoursebyid($id,$data) {
		$this->db->set($data);
		$this->db->where('id',$id);
		$this->db->limit(1);
		if($this->db->update('courses')) {
			return true;
		}else {
			return false;
		}
	}
	
	function deletecoursebyid($id) {
		$this->db->where('id', $id);
		$this->db->limit(1);
		if($this->db->delete('courses')){
			return true;
		} 
		return false;
	}
///////////////////End Course///////////////////////////////
///////////////////End Type////////////////////////////////

	function getnoofrowsfromtype() {
		$query=$this->db->get('types');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedtype($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('types',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		} 
	}

	function gettypeamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("types");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function gettypes() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("types");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function gettypebyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("types");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addtype($data) {
		$this->db->limit(1);
		if($this->db->insert("types", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function edittypebyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("types")) {
			return true;
		}else {
			return false;
		}
	}
	
	function deletetypebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("types")) {
			return true;
		} 
		return false;
	}
///////////////////End Type///////////////////////////////////
///////////////////Start Cuisine//////////////////////////////

	function getnoofrowsfromcuisine() {
		$query=$this->db->get('cuisines');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedcuisine($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('cuisines',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		} 
	}

	function getcuisinesnamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this -> db -> get("cuisines");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}

	function getcuisines() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("cuisines");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getcuisinebyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("cuisines");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addcuisine($data) {
		$this->db->limit(1);
		if($this->db->insert("cuisines", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editcuisinebyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("cuisines")) {
			return true;
		}else {
			return false;
		}
	}
	
	function deletecuisinebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("cuisines")) {
			return true;
		} 
		return false;
	}
///////////////////End Cuisine////////////////////////////////
///////////////////Start Season///////////////////////////////

	function getnoofrowsfromseason() {
		$query=$this->db->get('seasons');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedseason($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('seasons',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		} 
	}

	function getseasonnamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("seasons");
		if ($query -> num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function getseasons() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("seasons");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getseasonbyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("seasons");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addseason($data) {
		$this->db->limit(1);
		if($this->db->insert("seasons", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editseasonbyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("seasons")) {
			return true;
		}else {
			return false;
		}
	}
	
	function deleteseasonbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("seasons")) {
			return true;
		} 
		return false;
	}
///////////////////End Season////////////////////////////////
///////////////////Start Method///////////////////////////////

	function getnoofrowsfrommethod() {
		$query=$this->db->get('methods');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedmethod($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('methods',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		}
	}

	function getmethodnamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("methods");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function getmethods() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("methods");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getmethodbyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("methods");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addmethod($data) {
		$this->db->limit(1);
		if($this->db->insert("methods", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editmethodbyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("methods")) {
			return true;
		}else {
			return false;
		}
	}
	
	function deletemethodbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("methods")) {
			return true;
		} 
		return false;
	}
///////////////////End Method/////////////////////////////////
///////////////////Start Ingredients//////////////////////////

	function getnoofrowsfromingredient() {
		$query=$this->db->get('ingredients');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedingredient($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('ingredients',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		}
	}

	function getingredientnamebyid($id) {
		$this->db->select("name");
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query = $this->db->get("ingredients");
		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->name;
		}
	}
	
	function getingredients() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("ingredients");
		if ($query->num_rows()!= 0) {
			$result = $query->result();
			return $result;
		} 
	}
	
	function getingredientbyid($id) {
		$this->db->limit("1");
		$this->db->where("id", $id);
		$query =$this->db->get("ingredients");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function addingredient($data) {
		$this->db->limit(1);
		if($this->db->insert("ingredients", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editingredientbyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("ingredients")) {
			return true;
		}else {
			return false;
		}
	}
	
	function deleteingredientbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("ingredients")) {
			return true;
		} 
		return false;
	}
	
///////////////////End Ingredients////////////////////////////
///////////////////Start Recipe///////////////////////////////

	function getnoofrowsfromrecipe() {
		$query=$this->db->get('recipes');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedrecipe($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('recipes',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		}
	}

	function getrecipes() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("recipes");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function getrecipesbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		$query = $this->db->get("recipes");
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
			
	function deleterecipe($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("recipes")) {
			return true;
		} 
		return false;
		
	}
	
	function updaterecipe($id,$data) {
		$this->db->where("id",$id);
		$this->db->limit("1");
		if($this->db->update("recipes",$data)) {
			return true;
		}
		return false;
	}
	
	function updateallrecipe($data) {
		if($this->db->update("recipes", $data)) {
			return true;
		}
		return false;
	}
	
	function getrecipebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		$query = $this->db->get("recipes");
		if($query->num_rows() !=0 ) { 
			$result = $query->result();
				return $result[0];
		}
	}
	
	function getrecipenamebyid($id) {
		$this->db->select("title");
		$this->db->where("id", $id);
		$this->db->limit(1);
		$query = $this->db->get("recipes");
		if($query->num_rows()!=0) { 
			$result = $query->result();
			return $result[0]->title;
		}
	}
	
	function getrecipeimagebyid($id) {
		$this->db->select("images");
		$this->db->where("id", $id);
		$this->db->limit(1);
		$query = $this->db->get("recipes");
		if($query->num_rows()!=0) { 
			$result = $query->result();
			return $result[0]->images;
		}
	}
	
	
	
///////////////////End Recipe/////////////////////////////////
///////////////////Start Comments/////////////////////////////

	function getnoofrowsfromcomment() {
		$query=$this->db->get('comments');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getlimitedcomment($limit) {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('comments',$limit["start"],$limit["end"]);
		if($query->num_rows()!= 0) {
			return $query->result();	
		}
	}

	function getcomments() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("comments");
		if($query->num_rows()!= 0) { 
			$result = $query->result();
			return $result;
		}
	}
	
	function countnoofcomments($id) {
		$this->db->where_in("recipeid", $id);
		$query = $this->db->get("comments");
		return $query->num_rows(); 
	}
	
	function getcommentsbyrecipeid($id) {
		$this->db->where("recipeid", $id);
		$query = $this->db->get("comments");
		if($query->num_rows()!= 0) { 
			$result = $query->result();
			return $result;
		}
	}
	
	function getcommentsbyid($id) {
		$this->db->where("id", $id);
		$query = $this->db->get("comments");
		if($query->num_rows()!= 0) { 
			$result = $query->result();
			return $result[0];
		}
	}
	
	function deletecommentsbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("comments")){
			return true;
		} 
		return false;
	}
	
///////////////////End Comments/////////////////////////////////
/////////////////////Start User/////////////////////////////////

	function getusernamebyuid($uid) {
			$this->db->where("id", $uid);
			$query = $this->db->get("fa_user");
			if($query->num_rows()!= 0) { 
				$result = $query->result();
				return $result[0]->user_name;
			}
		}
	
////////////////////End User/////////////////////////////////////
////////////////////Start Home////////////////////////////////

	function getnoofrowsfromimage() {
		$query=$this->db->get('home');
		if($query->num_rows() != 0){
			return $query->num_rows();	
		}
	}
	
	function getimages() {
		$this->db->order_by("id", "desc");
		$query=$this->db->get('home');
		if($query->num_rows()!= 0) {
			return $query->result();	
		}
	}
	
	function addimage($data) {
		if($this->db->insert("home", $data)) {
			return true;
		}else {
			return false;
		}
	}
	
	function editimagebyid($id,$data) {
		$this->db->set($data);
		$this->db->where("id",$id);
		$this->db->limit(1);
		if($this->db->update("home")) {
			return true;
		}else {
			return false;
		}
	}
	
	function gethomebyid($id) {
		$this->db->where("id", $id);
		$query = $this->db->get("home");
		if($query->num_rows()!= 0) { 
			$result = $query->result();
			return $result;
		}
	}
	
	function deleteimagebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		if($this->db->delete("home")){
			return true;
		} 
		return false;
	}
	
////////////////////////////////End Home////////////////////
	
	/************************************************************/
	
	function getrecipe($where, $fields="") {
		$this->db->where($where);
		if(!empty($fields)) {
			$this->db->select($fields);
		}
		$this->db->limit(1);
		$query = $this->db->get("recipes");

		if ($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getvideo() {
		$query=$this->db->get('communityfrontvideo');
		if($query->num_rows()!= 0) {
			$result = $query->result();
			return $result[0];	
		}
	}
	
	function savevideo($data) {
			
		if(isset($data['id']) && !empty($data['id']))
		{
			$this->db->where('id', $data['id']);
			if($this->db->update('communityfrontvideo', $data))
			{
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else
		{		
			$this->db->insert('communityfrontvideo', $data);
			if($this->db->insert_id()>0)
			{
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
	}
	
}
?>