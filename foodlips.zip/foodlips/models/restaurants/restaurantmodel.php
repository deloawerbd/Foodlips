<?php
/**
 * This model is only used deal with resturants site
 */
 class Restaurantmodel extends Model {
 	
	//counstructor function
 	function Restaurantmodel() {
 		parent:: Model();
	}
	
	//get all countries
	function getallcountries($where) {
		$this->db->select("id,name,iso_3");
		$this->db->where_in("id",$where);
		$this->db->limit("31");
		$query = $this->db->get("countries");
			
		if($query->num_rows > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	function getallcities() {
		$this->db->select("id,name");
		$query = $this->db->get("cities");
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	function getallcities_of_country($country_id) {
		$this->db->select("t1.name As label, t1.id As value, t2.state_name As state");
		$this->db->from("cities t1");
		$this->db->limit(10,1);
		$this->db->join('state t2', 't2.id = t1.stateid');
		$this->db->where('t1.countryid = ' . $country_id . ' And t1.name IS NOT NULL');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	// get single country details
	function getcountry($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("countries");
		
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
	}
	
	//get states by country id 
	function getstatesbycountryid($where) {
		$this->db->where($where);
		$query = $this->db->get("state");
		
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result; 
		}
		return FALSE;
	}
	
	// get cities
	function getcities() {
		$query = $this->db->get("cities");
		if($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	// get cities where condition
	function getcitieswhere($where){
		$this->db->where($where);
		$query = $this->db->get("cities");
		if($query->num_rows()){
			return $query->result();
		}
		return FALSE;
	}
	
	// add latitude and longitude 
	function addlatlng($data,$where,$table){
		$this->db->set($data);
		$this->db->limit("1");
		$this->db->where($where);
		if($this->db->update($table)) {
			return true;
		}
		return FALSE;
	}
	
	//get cities lat lng
	function getlatlng($where,$table){
		$this->db->select("latitude,longitude");
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get($table);
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	//get getcuisines list as well as single cuisine
	function getcuisines($where) {
		if(isset($where) && is_array($where)){
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("rest_cuisine");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result[0];
			}
		}else{
			$query = $this->db->get("rest_cuisine");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result;
			}
		}
	}
	
	//get features by id or by array of id's
	function getfeaturebyid($where){
		if(is_array($where)){
			$this->db->where_in("id",$where);
		}else{
			$this->db->where("id",$where);
			$this->db->limit("1");
		}
		
		$query = $this->db->get("rest_features");
		if($query->num_rows() > 0 ){
			$result = $query->result();
			return $result;
		}
	}
	//get restaurants features
	function getfeatures() {
		$query = $this->db->get('rest_features');
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	//get restaurants prices
	function getprices($where){
		if(isset($where) && is_array($where)) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("rest_price");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result[0];
			}
		}else{
			$query = $this->db->get("rest_price");
		
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result;
			}
		}
	}
	
	//function to add new restaurant
	function addrestaurant($data) {
		if($this->db->insert("rest_details",$data)) {
			return $this->db->insert_id();
		}
		return FALSE;
	}
	
	//get single restaurants details
	function getrestaurantsdetails($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("rest_details");
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
		return FALSE;
	}
	
	//get single restaurants details
	function getrestaurantscount($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("rest_details");
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result;
		}
		return FALSE;
	}
	
	//get restaurant detail for pagination
	function getrestaurantsdetailforpagination($fields="*", $where=array(), $keyword,$searchprices,$searchfeatures,$searchcuisines,$feature="", $order_by="", $order="", $limit=array())
	{
		$whereflag = FALSE;
		//$this->output->enable_profiler(TRUE);
		//print_r($where);exit;	
		$this->db->select($fields);
		if(!empty($order_by) && !empty($order))
		{
			$this->db->orderby($order_by,$order);
		}
		if(!empty($limit))
		{
			$this->db->limit($limit["start"],$limit["end"]);
		}
		if(!empty($where))
		{
			$this->db->where($where);
		}
		//$this->db->like('(featureid','vit');//just to open the bracket
		if(!empty($feature))
		{	
			$this->db->like('featureid', $feature, 'none');
			//$searchparameters[] = array('featureid'=>$feature);
		}
		 $pricestring="";
		if(!empty($searchprices)){
			foreach($searchprices as $searchprice){
				$pricestring.= "price LIKE '%$searchprice%' OR ";
				//$searchparameters[] = array('price',$searchprice);
				//$this->db->or_like('price',$searchprice);
				// if($whereflag) {
					// $this->db->or_like('price',$searchprice);
				// } else {
					// $this->db->or_like('(price',$searchprice);
					// $whereflag = TRUE;
				// }
			}
		}
		$featurestring="";
		if(!empty($searchfeatures)){
			foreach($searchfeatures as $searchfeature){
				$featurestring.= "featureid LIKE '%$searchfeature%' OR ";
				//$this->db->or_like('featureid',$searchfeature);
				// if($whereflag) {
					// $this->db->or_like('featureid',$searchfeature);
				// } else {
					// $this->db->like('(featureid',$searchfeature);
					// $whereflag = TRUE;
				// }
			}
		}
		$cuisinestring="";
		if(!empty($searchcuisines)){
			foreach($searchcuisines as $searchcuisine){
				$cuisinestring.= "featureid LIKE '%$searchcuisine%' OR ";
				//$this->db->or_like('cuisineid',$searchcuisine);
				// if($whereflag) {
					// $this->db->or_like('cuisineid',$searchcuisine);
				// } else {
					// $this->db->like('(cuisineid',$searchcuisine);
					// $whereflag = TRUE;
				// }
			}
		}
		
		if(!empty($keyword)){
			$array = array('title' => $keyword, 'content' => $keyword, 'geo_address' => $keyword,'contact'=>$keyword,'website'=>$keyword,'special_offers'=>$keyword);
			//$this->db->or_like($array);
			
			// if($whereflag) {
				// //$array['special_offers'] = $array['special_offers'] .')';
				// $this->db->or_like('title',$keyword);
				// $this->db->or_like('content',$keyword);
				// $this->db->or_like('geo_address',$keyword);
				// $this->db->or_like('contact',$keyword);
				// $this->db->or_like('website',$keyword);
				// $this->db->or_like('special_offers',$keyword.')');
			// } else {
				// // $array['title'] = '('.$array['title'];
// // //				$array['special_offers'] = $array['special_offers'] .')';
				// // $this->db->or_like( $array . "");
				// // $whereflag = TRUE;
				// $this->db->or_like('(title',$keyword);
				// $this->db->or_like('content',$keyword);
				// $this->db->or_like('geo_address',$keyword);
				// $this->db->or_like('contact',$keyword);
				// $this->db->or_like('website',$keyword);
				// $this->db->or_like('special_offers',$keyword.')');
			// }			 
		}
		$this->db->where("($featurestring $pricestring $cuisinestring title LIKE '%$keyword%' OR content LIKE '%$keyword%' OR geo_address LIKE '%$keyword%' OR contact LIKE '%$keyword%' OR website LIKE '%$keyword%'OR special_offers LIKE '%$keyword%')", NULL, FALSE);//to close the bracket
		//$this->db->having('countryid',13); 
		$query = $this->db->get("rest_details");
		
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	
	function getrestaurantsdetailcountforpagination($field="*",$where=array(),$feature="")
	{
		if(!empty($where))
		{
			$this->db->where($where);
		}
		if(!empty($feature))
		{
			$this->db->like('featureid', $feature, 'none');
		}
		$query = $this->db->get("rest_details");
		return $query->num_rows();
	}
	
	//add restaurant comments
	function addrestaurantcomment($data){
		if($this->db->insert("rest_comments",$data)){
			return $this->db->insert_id();
		}
	}
	
	//add restaurants extar information
	function addrestaurantsextarinfo($data){
		if($this->db->insert("rest_extrainfo",$data)){
			return $this->db->insert_id();
		}
	}
	
	//get restaurants extra information 
	function getrestaurantsextrainfo($where){
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("rest_extrainfo");
		if($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	// function getrestaurantsextrainfoforapproval($field, $limit){
		// $this->db->select("rest_details.title, rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		// $this->db->from("rest_extrainfo");
		// $this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		// $this->db->where($field. " <> ''");
// //		$this->db->where($field. " != ''");
		// $this->db->limit($limit["start"],$limit["end"]);
		// $query = $this->db->get();
		// if($query->num_rows() != 0){
		// return $query->result();
		// }
	// }
	
	function getrestaurantsextrainfoforapproval($field, $limit){
		// $this->db->select("rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		// $this->db->from("rest_extrainfo");
		//$this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		$this->db->where($field. " <> ''");
//		$this->db->where($field. " != ''");
		$this->db->limit($limit["start"],$limit["end"]);
		$query = $this->db->get("rest_extrainfo");
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	function getrestaurantsextrainfocountforapproval($field){
		//$this->db->select("rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		//$this->db->from("rest_extrainfo");
		//$this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		$this->db->where($field. " <> ''");
		$query = $this->db->get("rest_extrainfo");
		return $query->num_rows();
	}
		
	// function getrestaurantsextrainfocountforapproval($field){
		// $this->db->select("rest_details.title, rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		// $this->db->from("rest_extrainfo");
		// $this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		// $this->db->where($field. " <> ''");
		// $query = $this->db->get();
		// return $query->num_rows();
	// }
		
	//update restaurants extra information
	function updaterestaurantseaxtrainfo($where,$data){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("rest_extrainfo")) {
			return true;
		}
		return FALSE;
	}
	
	//get restaurants
	function getrestaurants($where){
		$this->db->where($where);
		$query = $this->db->get("rest_details");
		
		if($query->num_rows()){
			return $query->result();
		}
		return FALSE;
	}
	
	//get comments of restaurants
	function getcomments($where){
		$this->db->where($where);
		$query = $this->db->get("rest_comments");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	//get restaurants neigbores restaurants from db
	function getneighborsrestaurants($latitude,$longitude){
		if($latitude != "" && $longitude != ""){
			$query = "SELECT title, seo, content, images, 3956 * 2 *
			ASIN(SQRT( POWER(SIN(($latitude - abs(latitude))*pi()/180/2),2)
			+COS($latitude*pi()/180 )*COS(abs(latitude)*pi()/180)
			*POWER(SIN(($longitude-longitude)*pi()/180/2),2)))
			as distance FROM rest_details WHERE
			longitude between ($longitude-50/abs(cos(radians($latitude))*69))
			and ($longitude+50/abs(cos(radians($latitude))*69))
			and latitude between ($latitude-(50/69))
			and ($latitude+(50/69))
			having distance < 50 ORDER BY distance limit 3;";
			$obj = $this->db->query($query);
			
			if($obj->num_rows() > 0){
				return $obj->result();
			}
		}
	}
	//function to add rating
	function addrating($data) {
		if($this->db->insert("rest_ratings", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	//check if already rated
	function isratingexist($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("rest_ratings");
		
		if($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	//update rating
	function updaterating($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("rest_ratings")) {
			return true;
		}
		return false;
	}
	
	//take restaurants rating
	function takerating($id) {
		$this->db->select_avg("rating");
		$this->db->where("rid", $id);
		
		$query = $this->db->get("rest_ratings");
		
		if($query->num_rows() > 0) {
			$row = $query->row();
			return $row->rating;
		}
	}
	
	// check if already rated
	function isfavorite($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("favoriterestaurant");
		if ($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	function addtofavorites($data) {
		if($this->db->insert("favoriterestaurant",$data)){
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function rowcount(){
		return $this->db->count_all("rest_details");
	}
	
	function getrestcount($where){
		$this->db->where($where);
		return $this->db->count_all("rest_details");
	}
	
	
	function getallrestaurantsdetails($limit){
		$this->db->orderby('id','desc');
		$query = $this->db->get("rest_details",$limit["start"],$limit["end"]);
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	function getrestaurantids(){
		$query = $this->db->get("rest_details");
		$query = $query->result();
		return $query;
	}
	//update restaurant details
	function updaterestaurant($where,$data) {
		$this->db->set($data);
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("rest_details")) {
			return true;
		}
		return false;
	}
	function getcheckedids(){
		$this->db->select("id");
		$this->db->where("ourpicks","1");
		$query = $this->db->get("rest_details");
		return $query->result();
	}
	
	function getcheckedmostpopularids(){
		$this->db->select("id");
		$this->db->where("mostpopular","1");
		$query = $this->db->get("rest_details");
		return $query->result();
	}
	
	function getrestdetails($table, $where, $orderby, $limit){
		if(isset($where) && !empty($where)) {
			$this->db->where($where);
		}
		if(isset($orderby) && !empty($orderby)) {
			$this->db->orderby($orderby);
		}
		if(isset($limit) && !empty($limit)) {
			$this->db->limit($limit);
		}
		$query = $this->db->get($table);
		if($query->num_rows()>0){
		return $query->result();
		//print_r($query->result);exit;
		}else{
			return false;
		}
	}
	
	//get category by id or by array of id's
	function getcategorybyid($where){
        if(isset($where) && is_array($where)) {
            $this->db->where($where);
		}
            $this->db->limit("1");
		
    		$query = $this->db->get("rest_category");
	       	if($query->num_rows() > 0 ){
		  	$result = $query->row();
			 return $result;
		    }
	}
	
	//get restaurants categories
	function getcategories() {
		$query = $this->db->get('rest_category');
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result;
		}
	}
	//get restaurants extra information from extra_info_api table
	function getrestextrainfoapi($where){
		$this->db->where($where);	
		$this->db->limit("1");
		$query = $this->db->get("rest_extrainfo_api");
		if($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	//update restaurants extra information in extra_info_api table
	function updateresteaxtrainfoapi($where,$data){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("rest_extrainfo_api")) {
			return true;
		}
		return FALSE;
	}
	//add restaurants extar information in extra_info_api table
	function addrestextarinfoapi($data){
		if($this->db->insert("rest_extrainfo_api",$data)){
			return $this->db->insert_id();
		}
	}
	function addcity($data){
		if($this->db->insert("cities",$data)){
			return $this->db->insert_id();
		}
	}
	function addstate($data){
		if($this->db->insert("state",$data)){
			return $this->db->insert_id();
		}
	}
	function addcountry($data){
		if($this->db->insert("countries",$data)){
			return $this->db->insert_id();
		}
	}
	
	function getcountryidbyname($where){
		$this->db->where($where);
		$query = $this->db->get('countries');
		if($query->num_rows() > 0){
			$name =  $query->row();
			return $name->id;
		}else{
			return FALSE;
		}
	}
	function getstateidbyname($where){
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get('state');
		if($query->num_rows() > 0){
			$name =  $query->row();
			return $name->id;
		}else{
			return FALSE;
		}
	}
	function iscountryexists($where){
		$this->db->where($where);
		$query = $this->db->get("countries");
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	function isstateexists($where){
		$this->db->where($where);
		$query = $this->db->get("state");
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	function gethours($where){
		if(!empty($where)){
			$this->db->where($where);	
		}
		$query = $this->db->get("hours");
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
	}
	function insertopeninghours($data){
		if($this->db->insert("rest_opening_hours",$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
		
	}
	function getopeninghours($where){
		if(!empty($where)){
			$this->db->where($where);	
		}
		$query = $this->db->get("rest_opening_hours");
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
	}
	function isOpeningHoursexists($where){
		$this->db->where($where);
		$query = $this->db->get('rest_opening_hours');
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	function updateOpeningHours($data,$where){
		$this->db->where($where);
		$this->db->update('rest_opening_hours',$data);
		
	}
	function getImages($rid){
		$this->db->where('rid',$rid);
		$query = $this->db->get('rest_extrainfo');
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return FALSE;
		}
	}
	function getCategoryIdForCuisine($where){
		$this->db->where($where);
		$query = $this->db->get("rest_cuisine");
		if($query->num_rows>0){
			$result =  $query->result();
			return $result[0]->category_id;
		}else{
			return false;
		}
	}
	function searchFreeKeyword($keyword,$table){
		$this->db->like("name",$keyword);
		$query = $this->db->get($table);
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return FALSE;
		}
	}
	function isCategoryPresent($categoryid){
		$this->db->where('category_id',$categoryid);
		$query = $this->db->get('rest_cuisine');
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	//function to add like
	function addlike($data) {
		if($this->db->insert("rest_likes", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	//check if already liked
	function islikeexist($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("rest_likes");
		
		if($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	//update like
	function updatelike($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("rest_likes")) {
			return true;
		}
		return false;
	}
	
	//count likes
	function countlike($where) {
		$this->db->where($where);
		$query = $this->db->get("rest_likes");
		if($query->num_rows() > 0) {
			 return $query->num_rows();
		}else{
			return false;
		}
	}
	function getlikebyuser($where){
		$this->db->where($where);
		$query = $this->db->get("rest_likes");
		if($query->num_rows()>0){
			$query = $query->row();
			return $query->liked;
		}else{
			return -1;
		}
		
	}
	//for suggestions
	function addsuggestion($data){
		if($this->db->insert("rest_suggestions",$data)){
			return $this->db->insert_id();
		}
		return FALSE;
	}
	
	function getsuggestions($where,$limit,$order_by){
		if(isset($where) && !empty($where)){
			$this->db->where($where);
		}
		if(isset($limit)&& is_array($limit)){
			$this->db->limit($limit["start"],$limit["end"]);
		}
		if(isset($order_by) && !empty($order_by)){
			$this->db->order_by("rid","asc");
			$this->db->order_by("name","asc");
		}
		
		$query = $this->db->get("rest_suggestions");
		
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
		
	}
	
	function updatesuggestions($data,$where){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("rest_suggestions")){
			return TRUE;
		}else{
			return FALSE;
		}
		
	}
	
	function resetprevapprovalforsuggestions($id){
		$this->db->where("id",$id);
		$this->db->get("rest_suggestions");
	}
	function deletesuggestions($where){
		$this->db->where($where);
		if($this->db->delete("rest_suggestions")){
			return TRUE;
		}else{
			return FALSE;
		}
	}
}
?>