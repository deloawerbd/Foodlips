<?php

	class Communitymodel extends Model {

		function Communitymodel() {
			parent::Model();
		}
		
        function getcisession($where, $wherenotin) {
            $this->db->where($where);
            $this->db->where_not_in("session_data", $wherenotin);
            $this->db->limit("1");

            $query = $this->db->get("ci_sessions");
            if($query->num_rows() > 0) {
                $result = $query->result();
                return $result[0];
            }
        }
        
		/** Functions are defined to use commonly defined by Muqeet Ahmed **/
        function addsettings($setting) {
			if($this->db->insert("settings", $setting)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getsettings($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("settings");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function updatesettings($setting, $where) {
			$this->db->set($setting);
			$this->db->where($where);
			
			if($this->db->update("settings")) {
				return true;
			}
			
			return false;
		}
		
		function addgroupactivity($activity){
			if($this->db->insert("groupsactivities", $activity)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		function addactivity($activity) {
			if($this->db->insert("activities", $activity)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getlatestactivities() {
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("activities");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getlatestactivitiesbyuser($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$this->db->limit("11");

			$query = $this->db->get("activities");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getlatest10activitiesbyuser($where,$start) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$this->db->limit("10", $start);
			$query = $this->db->get("activities");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getlatestactivitiesbyuserwherein($where,$start) {
			if(isset($where) && !empty($where)) {
				$this->db->where_in("uid",$where);
				$this->db->order_by("id", "desc");
				
				$this->db->limit('11', $start);
				
				$query = $this->db->get("activities");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		/*function getlatestactivitiesbyuserwherein($where,$start) {
			if(isset($where) && !empty($where)){
				$this->db->where_in("uid",$where);
				$this->db->order_by("id", "desc");
				
				$query = $this->db->get("activities");
				
				//if($query->num_rows() > 0) {
					//return $query->result();
				//}
				return $query;
			}
		}*/
		
		function getactivity($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("activities");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function addcommunitycomment($communitycomment) {
			if($this->db->insert("communitycomments", $communitycomment)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getcommunitycomments($where) {
			$this->db->where($where);
			$this->db->order_by("id", "asc");
			
			$query = $this->db->get("communitycomments");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function addcommunitylikes($communitylikes) {
			if($this->db->insert("activitylikes", $communitylikes)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function getlikecountsbyaid($aid) {
			$this->db->where("aid",$aid);

			$query = $this->db->get("activitylikes");

			if($query->num_rows() > 0) {
				return $query->num_rows();
			}
		}
		
		function getactivitylikes($where) {
			$this->db->where($where);

			$query = $this->db->get("activitylikes");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function isactivityliked($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("activitylikes");
			
			if ($query->num_rows() > 0) {
				return true;
			}
		return false;
		}
		function getunnotifiedactivities($where) {
			$this->db->where_in("uid",$where);
			$this->db->where("isnotified", "0");
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("activities");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function updateactivities($activity, $wherein) {
			$this->db->set($activity);
			$this->db->where_in("id", $wherein);
			
			if($this->db->update("activities")) {
				return true;
			}
			
			return false;
		}
		
		function updateactivity($activity, $where) {
			$this->db->set($activity);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("activities")) {
				return true;
			}
			
			return false;
		}
		
		function getfriendrequests($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("friendrequest");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getcontact($where) {
			$this->db->where($where);
			$this->db->limit("1");

			$query = $this->db->get("contacts");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function addfriendcontact($contact) {
			if($this->db->insert("contacts", $contact)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function updatecontact($contact, $where) {
			$this->db->set($contact);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("contacts")) {
				return true;
			}
			
			return false;
		}
		
		function getuser($where, $fields="") {
			if(!empty($fields)) {
				$this->db->select($fields);
			}
			$this->db->where($where);
			$this->db->limit("1");

			$query = $this->db->get("fa_user");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		 /*use to add user images into image table*/
		function adduserimages($images) {
			if($this->db->insert("image", $images)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function updateuserimages($data, $where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->update("image", $data)) {
				return true;
			}
			return false;
		}
		
		function getimagesbyuserid($uid) {
			$this ->db-> where("uid", $uid);
			$query = $this->db->get("image");
			if($query->num_rows() > 0) {
				$result = $query->result();
				$user = $result[0];
				return $user->images;
				//return $result[0];
			}
			else {
				return 0;
			}
		}
		
		function getuserimages($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("image");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getallrecipesbyuserid($uid) {
			$this->db->where("uid", $uid);
			$this->db->where("approved", "1");
			$this->db->order_by("id", "desc");
			$this->db->limit("6");

			$query = $this->db->get("recipes");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getrecipescountbyuserid($uid) {
			$this->db->where("uid", $uid);
			$this->db->where("approved", "1");

			$query = $this->db->get("recipes");

			return $query->num_rows();
		}
		
		function getallgroupsbyuserid($uid, $limit="") {
			
			$this->db->where("uid", $uid);
			$this->db->where("isdeleted", "0");
			$this->db->order_by("id", "desc");
			if(!empty($limit)) {
				$this->db->limit("$limit");
			}

			$query = $this->db->get("groups");

			if($query->num_rows() > 0) {
				return $query->result();
			}
				
			/* if(isset($uid) && $limit == "") {
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->where("isdeleted","0");
				$query = $this->db->get("groups");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if((isset($uid) && $limit == 6)) {
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->where("isdeleted","0");
				$this->db->limit("6");
				$query = $this->db->get("groups");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			} */
		}
		
		function getallreviewsbyuserid($uid) {
			$this->db->where("uid", $uid);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("reviews");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getreviewscountbyuserid($uid) {
			$this->db->where("uid", $uid);
			//$query = $this->db->get("reviews");
			$query = $this->db->get("comments");
			
			return $query->num_rows();
		}
		
		function getalluserfollowers($uid) {
			$this->db->where("uid", $uid);
			$this->db->limit("1");
			
			$query = $this->db->get("followers");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getalluserfollowings($uid) {
			$this->db->where("uid", $uid);
			$this->db->limit("1");
			
			$query = $this->db->get("followings");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getuseraboutinfo($uid) {
			$this->db->where("uid", $uid);
			$this->db->limit("1");
			
			$query = $this->db->get("about");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];  
			}
		}
		
		function getallmadebyuserid($uid,$limit) {
			if(isset($uid) && $limit == 6){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				$query = $this->db->get("made");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}else{
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("21");
				$query = $this->db->get("made");
				if($query->num_rows() > 0) {
					return $query->num_rows();
				}
			}
		}
		
		function getallfavoriterecipesbyuserid($uid,$limit) {
			if(isset($uid) && $limit == 6){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				$query = $this->db->get("favoriterecipes");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}else {
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("21");
				$query = $this->db->get("favoriterecipes");
				if($query->num_rows() > 0) {
					return $query->num_rows();
				}
			}
			
		}
		
		function getallfavoriteblogsbyuserid($uid, $limit="") {
			if(isset($uid) && $limit == "") {
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				$query = $this->db->get("favoriteblogs");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if((isset($uid) && $limit == "all")) {
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$query = $this->db->get("favoriteblogs");

				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}


		function getfavoriteblogsbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("favoriteblogs");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}


		function deletefavoriteblogbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("favoriteblogs")) {
				return true;
			}			
			return false;
		}
		
		function getallfavouritewineriesbyuser($user_name, $limit="") {
			$this->db->where("user_name", $user_name);
			$this->db->order_by("id", "desc");

			if(!empty($limit)) {
				$this->db->limit($limit);
			}
						
			$query = $this->db->get("favouritewineries");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getallfavoriterestaurantbyuser($user_name,$limit=NULL) {
			$this->db->where("user_name", $user_name);
			$this->db->order_by("id", "desc");
			if(!empty($limit))
			{
				$this->db->limit($limit);
			}
			else{
				$this->db->limit("6");
			}
			
			$query = $this->db->get("favoriterestaurant");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getalloutsiderecipesbyuserid($uid, $limit="") {
			if(isset($uid) && $limit == ""){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				$query = $this->db->get("outsiderecipes");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if(isset($uid) && $limit == "all"){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$query = $this->db->get("outsiderecipes");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		function getoutsiderecipesbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("outsiderecipes");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}
		
		function getoutsiderecipesbycat($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$query = $this->db->get("outsiderecipes");
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function deleteoutsiderecipesbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("outsiderecipes")) {
				return true;
			}			
			return false;
		}
		
		function getallonlinevideosbyuserid($uid, $limit="") {
			if(isset($uid) && $limit == ""){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				$query = $this->db->get("onlinevideos");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if(isset($uid) && $limit == "all"){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$query = $this->db->get("onlinevideos");
				
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		function getonlinevideobyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("onlinevideos");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}
		
		function deleteonlinevideobyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("onlinevideos")) {
				return true;
			}			
			return false;
			
		}
		
		function getwinenbeerbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("winenbeer");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}
		
		function deletewinenbeerbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("winenbeer")) {
				return true;
			}			
			return false;
		}
		
		function getvideogallery($uid) {
			$this->db->where(array("uid"=>$uid,"isvideo"=>"1"));
			$this->db->order_by("id", "desc");
			$query = $this->db->get("favoriterecipes");
			$videos = array();
			
			if($query->num_rows()>0)
			{
				foreach($query->result() as $video)
				{				
					$where = array("id"=>$video->recipeid);
					$recipies = $this->crudmodel->getrecipes($where);
					if(!empty($recipies[0]->video))
					{
						$videos[] = $recipies[0]->video;
					}				
				}
				//$videos = (object) $videos;
			}
			
			return $videos;
		}		
		function addgroup($group) {
			if($this->db->insert("groups", $group)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function isgroupexists($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				return true;
			}
			
			return false;
		}
		//get user joined group
		function getuserjoinedgroups($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("usersjoinedgroups");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		// get groups details by id array
		function getgroupwherein($where) {
			$this->db->where_in("id",$where);
			$this->db->order_by("id", "desc");
			//$this->db->where($where);
			//$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				//$result = $query->result();
				return $query->result(); 
			}
		}
		
		function getgroup($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getnewgroupbyuid($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getallgroups() {
			$this->db->order_by("id", "desc");
			$this->db->where("isdeleted", "0");
			$query = $this->db->get("groups");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getgroupscountbyuserid($uid) {
			$this->db->where("uid", $uid);
			$this->db->where("isdeleted", "0");
			$query = $this->db->get("groups");

			return $query->num_rows();
		}
		
		function mostpopulargroups(){
			$groups = $this->getallgroups();
			foreach($groups as $group){
				//$members = $group->members;
				$members = unserialize($group->members); 
				if(isset($members) && $members != ""){
					$count = count($members);
					$popular[$group->id] = $count;
				}
			}
			return $popular;
		}
		
		
		function updateuserjoinedgroups($groups,$where){
			$this->db->set($groups);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("usersjoinedgroups")) {
				return true;
			}
			return false;
		}
		
		function adduserjoinedgroups($groups) {
			$this->db->insert("usersjoinedgroups", $groups);
		}
		
		function updategroup($group, $where) {
			$this->db->set($group);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("groups")) {
				return true;
			}
			
			return false;
		}
		
		function addgroupwallpost($groupwallpost) {
			if($this->db->insert("groupwallpost", $groupwallpost)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getallgroupwallpost($where) {
			$this->db->where($where);
			//$this->db->limit("11");
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("groupwallpost");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getgroupwallpost($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupwallpost");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function deletegroupwallpost($where) {
			$this->db->where($where);
			$this->db->set("isdeleted","1");
			$this->db->limit("1");
			
			if($this->db->update("groupwallpost")) {
				return true;
			}
			
			return false;
		}
		
		
		function deletequestion($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->delete("groupquestion")) {
				return true;
			}
			
			return false;
			
		}
		
		function addquestion($topic) {
			if($this->db->insert("groupquestion", $topic)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getquestion($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupquestion");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getallquestions($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("groupquestion");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function addreply($reply) {
			if($this->db->insert("answer", $reply)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getallreply($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("answer");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getreply($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("answer");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function deletereply($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->delete("answer")) {
				return true;
			}
			
			return false;
		}
		
		function addfriendrequest($friendrequest) {
			if($this->db->insert("friendrequest", $friendrequest)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getallfriendrequest($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("friendrequest");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getfriendrequest($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("friendrequest");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function isfriendrequested($where, $requestid) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("friendrequest");
			if($query->num_rows() > 0) {
				$result = $query->result();
				$friendrequest = $result[0];
				
				if(isset($friendrequest) && $friendrequest != "") {
					$requsets = $friendrequest->requests;
					if($requsets != "") {
						if(in_array($requestid, unserialize($requsets))) {
							return true;
						}
					}
				}
			}
			
			return false;
		}
		
		function isfriend($where, $loginuid, $uid) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("contacts");
			
			$isfriend = false;
			
			// checking if login user is friend with visiting profile user.
			if($query->num_rows() > 0) {
				$result = $query->result();
				$contact = $result[0];
				if(isset($contact) && $contact != "") {
					if($contact->friends != "") {
						if(in_array($uid, unserialize($contact->friends))) {
							$isfriend = true;
						}
					}
				}
			}
			
			// checking if visiting profile user is friend with login user.
			// this vice verca checking is required.
			if(!$isfriend) {
				$where = array(
								"uid" => $uid
							);
				$this->db->where($where);
				$this->db->limit("1");
				$query = $this->db->get("contacts");
				if($query->num_rows() > 0) {
					$result = $query->result();
					$contact = $result[0];
					if(isset($contact) && $contact != "") {
						if($contact->friends != "") {
							if(in_array($loginuid, unserialize($contact->friends))) {
								return true;
							}
						}
					}
				}
			}
			else {
				return true;
			}
			
			return false;
		}
		
		function updatefriendrequest($data, $where) {
			$this->db->where($where);
			$this->db->set($data);
			$this->db->limit("1");
			
			if($this->db->update("friendrequest")) {
				return true;
			}
			
			return false;
		}
		
		function getallfriends($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("contacts");
			if($query->num_rows() > 0) {
				$result = $query->result();
				$contact = $result[0];
				if($contact->friends != "") {
					return unserialize($contact->friends);
				}
			}
		}
		
		function getnotification($where) {
			
			$this->db->where($where);
			
			$query = $this->db->get("notifications");
			
			if($query->num_rows() > 0) {
				
				return $query->result();
				
			}
		}

		function getgroupinvitation($where) {

			$this->db->where($where);

			$this->db->limit("1");

			$query = $this->db->get("notifications");

			

			if($query->num_rows() > 0) {

				$result = $query->result();

				return $result[0];

			}
		}		

		/**function getcontact($where) {

			$this->db->where($where);

			$this->db->limit("1");

			$query = $this->db->get("contacts");

			if($query->num_rows() > 0) {

				$result = $query->result();

				return $result[0];

			}

		}**/
		
		function getallcontact($where) {

			$this->db->where("uid", $where);

			$query = $this->db->get("contacts");

			if($query->num_rows() > 0) {

				return $query->result();

			}

		
		}

		function getuserfrnd($where) {

			$this->db->where($where);

			//$this->db->limit("1");

			$query = $this->db->get("fa_user");

			if($query->num_rows() > 0) {

			$result = $query->result();

			return $result[0];

			}

		}

		function getgroupowner($where) {
			$this->db->where($where);
			//$this->db->limit("1");
			
			$query = $this->db->get("fa_user");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}

		}
		
		function updatenotification($updatenotification, $where) {
			$this->db->set($updatenotification);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("notifications")) {
				return true;
			}
			
			return false;
			
		}

		function addinvitation($invites) {
			if($this->db->insert("groupinvitation", $invites)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
	   function addnotification($invites) {
			if($this->db->insert("notifications", $invites)) {
				return $this->db->insert_id();
			}
			return 0;
		}
	   
	   function isinvitationexists($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupinvitation");
			if($query->num_rows() > 0) {
				return true;
			}
			
			return false;
		}
		
		function getinvitation($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupinvitation");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}		
		
		function updategroupinvitation($invites, $where) {
			$this->db->set($invites);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("groupinvitation")) {
				return true;
			}
			
			return false;
		}
		
		function isnotificationexists($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("notifications");
			if($query->num_rows() > 0) {
				return true;
			}
			
			return false;
		}
		
		function getnotificationbyuser($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("notifications");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}		
		
		function updatenotifications($notification,$where) {
			$this->db->set($notification);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("notifications")) {
				return true;
			}
			
			return false;
		}
		
		/*function getallgroupsactivity($getcontent) {
			$this->db->order_by("id", "desc");
			//$this->db->limit("11");
			$this->db->like("content", $getcontent); 
			$query = $this->db->get("activities");
				if($query->num_rows() > 0) {
					return $query->result();
				}
		}*/
		
		function getallgroupsactivity() {
			$this->db->order_by("id", "desc");
			//$this->db->limit("11");
			//$this->db->like("content", $getcontent); 
			$query = $this->db->get("groupsactivities");
				if($query->num_rows() > 0) {
					return $query->result();
				}
		}
		  		  
		/* function isfriendrequestexists($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("friendrequest");
			if($query->num_rows() > 0) {
				return true;
			}
			
			return false;
		} */
		
		/* function getgroupmemberscount($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				$result = $query->result();
				$group = $result[0];
				
				if($group->members != "") {
					$members = explode(",", $group->members);
					return count($members);
				}
			}
			
			return 0;
		} */
		
		/* function getgroupvisibilty($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groups");
			if($query->num_rows() > 0) {
				$result = $query->result();
				$group = $result[0];
				return $group->visibility;
			}
		} */
		
		/*code for submitpoll*/
		
		function addpoll($poll){
			if($this->db->insert("poll", $poll)){
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function addpolloptions($options){
			if($this->db->insert("polloptions",$options)){
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function addpollvotes($votes){
			if($this->db->insert("votes",$votes)){
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function getallpolls($where){
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$query = $this->db->get("poll");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
			
		}
		
		function getoptionsbyid($where){
			$this->db->where($where);
			//$this->db->limit("1");
			$query = $this->db->get("polloptions");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getgroupwallpoll($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("poll");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function deletegroupwallpoll($where){
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->delete("poll")){
				$qid = $where['id'];
				$where = array(
								"qid" => $qid
							);
				$this->db->where($where);
				if($this->db->delete("polloptions")){
					return true;
				}
			}
			return false;
		}
		
		/*** Fucntion to add Set up a meet***/
		function addmeeting($meetingArray){
			$meetingArray['datecreated'] = date('Y-m-d H:i:s');
			$meetingArray['isdeleted'] = '0';
			if($this->db->insert("groupmeeting",$meetingArray)){
				return $this->db->insert_id();
			}
			return 0;
		}
		function updatemeeting($meetingArray,$where){
			$this->db->where($where);
			$meetingArray['datecreated'] = date('Y-m-d H:i:s');
			$meetingArray['isdeleted'] = '0';
			$this->db->set($meetingArray);
			$count = $this->db->update("groupmeeting");
			return $count;
			// if($this->db->update("groupmeeting")){
				// return $this->db->insert_id();
			// }
			// return 0;
		}
		function savemeetquestion($meetquestionArray){
			$meetquestionArray['postdate'] = date('Y-m-d H:i:s');
			$meetquestionArray['isdeleted'] = '0';
			if($this->db->insert("groupmeetquestions",$meetquestionArray)){
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function getallmeets($where){
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("groupmeeting");
			
			if($query->num_rows() > 0){
				return $query->result();
			}
		}
		
		function getmeetdetails($where){
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("groupmeeting");
			
			if($query->num_rows() > 0){
				return $query->row();
			}
		}
		
		function getallmeetsquestions($where) {
			$this->db->where($where);
			
			$query = $this->db->get("groupmeetquestions");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getallmeetsbyuserid($uid, $limit="") {
			if(isset($uid)){
				$groupMeets = array();
				$this->db->where(array("uid"=>$uid,"isdeleted"=>'0'));
				$this->db->order_by("id", "desc");
				
				$query = $this->db->get("groupmeeting");

				if($query->num_rows() > 0){
					foreach($query->result() as $meet){
						$groupMeets[] = $meet;
					}
				}
				
				$this->db->where(array("isdeleted"=>'0'));
				$queryGroup = $this->db->get("groups");
				
				foreach($queryGroup->result() as $resultGroup){
					if(!empty($resultGroup->members)){
						$membersArray = unserialize($resultGroup->members);
						if(count($membersArray)>0){
							if(in_array($uid, $membersArray)){
								
								$this->db->where(array("gid"=>$resultGroup->id,"isdeleted"=>'0'));
								$member_group_meets = $this->db->get("groupmeeting");
								$member_group_meets->num_rows()."<br>";
								
								if($member_group_meets->num_rows()>0){
									foreach($member_group_meets->result() as $meet){
										$groupMeets[] = $meet;
									}
								}								
							}
						}
					}
				}
				
				if(count($groupMeets)>0){
					return $groupMeets;
				}
				else{
					return null;
				}
			}
		}
		
		function getmeetscount($uid){
			if(isset($uid) && !empty($uid))
			{
				$totalgroupmeets = 0;
				$this->db->where(array("uid"=>$uid,"isdeleted"=>'0'));
				$this->db->order_by("id", "desc");
				
				$own_group_meets = $this->db->get("groupmeeting");
				$totalgroupmeets = $totalgroupmeets + $own_group_meets->num_rows();
				
				$this->db->where(array("isdeleted"=>'0'));
				$queryGroup = $this->db->get("groups");
				
				foreach($queryGroup->result() as $resultGroup)
				{
					if(!empty($resultGroup->members))
					{
						$membersArray = unserialize($resultGroup->members);
						if(count($membersArray)>0)
						{
							if(in_array($uid, $membersArray))
							{
								$this->db->where(array("gid"=>$resultGroup->id,"isdeleted"=>'0'));
								$member_group_meets = $this->db->get("groupmeeting");
								$member_group_meets->num_rows()."<br>";
								if($member_group_meets->num_rows()>0)
								{
									$totalgroupmeets = $totalgroupmeets + $member_group_meets->num_rows();
								}								
							}
						}
					}
				}
				return $totalgroupmeets;
			}
		}
		
		function getgroupmeet($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupmeeting");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getgroupmeetquestions($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupmeetquestions");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
			
		function deletegroupmeet($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("groupmeeting");
			
			$result = $query->result();
			if($result[0]->uid == $this->db_session->userdata("id"))
			{
				$update['isdeleted'] = '1';

				$this->db->where($where);
				$this->db->limit("1");
				if($this->db->update("groupmeeting",$update)) {
					return true;
				}
				return false;
			}
			return false;
		}
		
		function deletegroupmeetcomments($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("groupmeetquestions");
			
			$result = $query->result();
			if($result[0]->uid == $this->db_session->userdata("id"))
			{
				$update['isdeleted'] = '1';

				$this->db->where($where);
				$this->db->limit("1");
				if($this->db->update("groupmeetquestions",$update)) {
					return true;
				}
				return false;
			}
			return false;
		}
		
		function updatetable($table, $where, $update)
		{
			if(!empty($table) && !empty($where) && !empty($update))
			{
				$this->db->where($where);
				if($this->db->update($table,$update)) {
					return true;
				}
				return false;
			}
			return false;
		}
		
		 /*********** Profile wall   *********/ 
		 
		function addprofilewallpost($profilewallpost) {
			if($this->db->insert("whatsonyourmind", $profilewallpost)) {
				return $this->db->insert_id();
			}
			
			return 0;
		} 
		 
		/*********  Followers and following   **********/ 
		
		function addfollowers($followers) {
			if($this->db->insert("followers", $followers)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
				
		function addfollowings($followings) {
			if($this->db->insert("followings", $followings)) {
				return $this->db->insert_id();
			}
			
			return 0; 
		}
		
		function getfollowers($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("followers");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function updatefollowers($newfollower, $where) {
			$this->db->set($newfollower);
			$this->db->where($where);
			
			if($this->db->update("followers")) {
				return true;
			}
			
			return false;
		}
		
		function getallfollowers() {
			$this->db->order_by("id", "desc");
			$query = $this->db->get("followers");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function mostpopularmembers(){
			$allmembers = $this->getallfollowers();
			foreach($allmembers as $members){
				$followers = unserialize($members->followers); 
				if(isset($followers) && $followers != ""){
					$count = count($followers);
					$popularmembers[$members->uid] = $count;
				}
			}
			return $popularmembers;
		}
		
		function getfollowing($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("followings");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		function updatefollowing($newfollowings, $where) {
			$this->db->set($newfollowings);
			$this->db->where($where);
			
			if($this->db->update("followings")) {
				return true;
			}
			
			return false;
		}
		
		function isfollow($where, $loginuid, $uid) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("followers");
			
			$isfollow = false;
			
			// checking if login user is already followed by visited profile user.
			if($query->num_rows() > 0) {
				$result = $query->result();
				$followers = $result[0];
				if(isset($followers) && $followers != "") {
					if($followers->followers != "") {
						if(in_array($uid, unserialize($followers->followers))) {
							$isfollow = true;
						}
					}
				}
			}
			
			// checking if visiting profile user is follow with login user.
			// this vice verca checking is required.
			if(!$isfollow) {
				$where = array(
								"uid" => $uid
							);
				$this->db->where($where);
				$this->db->limit("1");
				$query = $this->db->get("followers");
				if($query->num_rows() > 0) {
					$result = $query->result();
					$followers = $result[0];
					if(isset($followers) && $followers != "") {
						if($followers->followers != "") {
							if(in_array($loginuid, unserialize($followers->followers))) {
								return true;
							}
						}
					}
				}
			}
			else {
				return true;
			}
			
			return false;
		}
		/**********    update about me     ***/
		function updateuser($user, $where) {
			$this->db->set($user);
			$this->db->where($where);
			
			if($this->db->update("fa_user")) {
				return true;
			}
			
			return false;
		}
		
		function updateaboutme($aboutme, $where) {
			$this->db->set($aboutme);
			$this->db->where($where);
			
			if($this->db->update("about")) {
				return true;
			}
			
			return false; 
		}
		
		function getabout($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("about");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}	 		  
		
		function getallcountries(){
			//$this->db->order_by("id", "desc");
			$query = $this->db->get("fa_country");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getcountryname($where) {
			$this->db->where("id" ,$where);
			$this->db->limit("1");
			
			$query = $this->db->get("fa_country");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		 /*********** Group wall post comment   *********/ 
		function addgroupcomment($groupwallcomment) {
			if($this->db->insert("groupcomments", $groupwallcomment)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		function getgroupwallpostcomment($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("groupcomments");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		
		function getgroupcomment($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			$query = $this->db->get("groupcomments");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		function deletegroupwallpostcomment($where) {
			$this->db->where($where);
			$this->db->set("isdeleted","1");
			$this->db->limit("1");
			
			if($this->db->update("groupcomments")) {
				return true;
			}
			
			return false;
		}
		function updateisdeletedgroup($updategroup, $where) {
			$this->db->set($updategroup);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("groups")) {
				return true;
			}
			
			return false;
			
		}						
	
		function getsearchgroup($groupname) {
			$this->db->order_by("id", "desc");
			$this->db->like("name",$groupname); 
			$query = $this->db->get("groups");
				if($query->num_rows() > 0) {
					return $query->result();
				}
		}
		
		function getvotes($where) {
			$this->db->where($where);
			$query = $this->db->get("votes");
			
			if($query->num_rows() > 0) {
				//return $query->result();
				return $query->num_rows();
			}
		}
		
		/*******Myrecipebox Blog and other section ******/
		
		function addfavoriteblog($blog) {
			if($this->db->insert("favoriteblogs", $blog)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function addoutsiderecipes($recipe){
			if($this->db->insert("outsiderecipes", $recipe)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function addonlinevideos($video){
			if($this->db->insert("onlinevideos", $video)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function updatefavoriteblog($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("favoriteblogs")) {
				return true;
			}
			return false;
		}
		
		function updateoutsiderecipes($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("outsiderecipes")) {
				return true;
			}
			return false;
		}
		
		function updateonlinevideos($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("onlinevideos")) {
				return true;
			}
			return false;
		}
		/****My drink box****/
		
		function getliqureandspiritsbyuserid($uid, $limit=""){
			if(isset($uid) && $limit==""){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				
				$query = $this->db->get("liquernspirits");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if(isset($uid) && $limit=="all"){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				
				$query = $this->db->get("liquernspirits");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		function addliqureandspirits($liqure){
			if($this->db->insert("liquernspirits", $liqure)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function updateliqureandspirits($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("liquernspirits")) {
				return true;
			}
			return false;
		}
		
		function getliqurespiritbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("liquernspirits");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}
		
		function deleteliqurespiritbyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("liquernspirits")) {
				return true;
			}			
			return false;
		}
		
		function getalldrinkrecipesbyuserid($uid, $limit="") {
			if(isset($uid) && $limit==""){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				
				$query = $this->db->get("drinkrecipes");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			if(isset($uid) && $limit== "all"){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("21");
				$query = $this->db->get("drinkrecipes");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		function adddrinkrecipes($drink){
			if($this->db->insert("drinkrecipes", $drink)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function updatedrinkrecipe($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("drinkrecipes")) {
				return true;
			}
			return false;
		}
		
		function getdrinkrecipebyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("drinkrecipes");
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result["0"];
			}
		}
		
		
		function deletedrinkrecipebyid($where) {
			$this->db->where($where);
			$this->db->limit("1");
			if($this->db->delete("drinkrecipes")) {
				return true;
			}			
			return false;
		}
		
		function getcommonfilter($value, $table, $uid) {
			if(isset($uid) && isset($value) && isset($table)){
				switch ($value) {
					case "date" :
						switch ($table) {
							case "drinkrecipes" :
								
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "liquernspirits" :
								
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "winenbeer" :
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "onlinevideos" :
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "outsiderecipes" :
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "favoriteblogs" :
								$this->db->where("uid", $uid);
								$this->db->order_by("date", "desc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
						}
					break;
					
					case "rating" :
						switch ($table) {
							
							case "drinkrecipes" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
								
							case "liquernspirits" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "winenbeer" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "onlinevideos" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "outsiderecipes" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
								
							case "favoriteblogs" :
								$this->db->where("uid", $uid);
								$this->db->order_by("rating", "desc");
								
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
						}
					break;
					
					case "alpha" :
						switch ($table) {
							
							case "drinkrecipes" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
								
							case "liquernspirits" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "winenbeer" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "onlinevideos" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
							
							case "outsiderecipes" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
								
							case "favoriteblogs" :
								$this->db->where("uid", $uid);
								$this->db->order_by("lower(name)", "asc");
								$query = $this->db->get($table);
								
								if($query->num_rows() > 0) {
									return $query->result();
								}
							break;
						}
					break;
				}
			}
		}
		
		function getallwinenbeerbyuserid($uid,$limit=""){
			if(isset($uid) && $limit == ""){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				$this->db->limit("6");
				
				$query = $this->db->get("winenbeer");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
			else if(isset($uid) && $limit == "all"){
				$this->db->where("uid", $uid);
				$this->db->order_by("id", "desc");
				
				$query = $this->db->get("winenbeer");
				if($query->num_rows() > 0) {
					return $query->result();
				}
			}
		}
		
		function getwinebeerbycat($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$query = $this->db->get("winenbeer");
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		function getwinecategory(){
			$this->db->order_by("id", "desc");
			$query = $this->db->get("winecategory");
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getwinecatidbycategoryname($name) {
			$this->db->select("id");
			$this->db->where("name", $name);
			$this->db->limit("1");
			$query = $this->db->get("winecategory");
			if ($query->num_rows() != 0) {
				$result = $query->result();
				return $result[0]->id;
			}
		}
		
		function addwinenbeer($wine){
			if($this->db->insert("winenbeer", $wine)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function updatewinenbeer($where,$data){
			$this->db->set($data);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("winenbeer")) {
				return true;
			}
			return false;
		}
		
		function addmeal($meal) {
			if($this->db->insert("mealplanner", $meal)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function updatemeal($newmeal, $where) {
			$this->db->set($newmeal);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("mealplanner")) {
				return true;
			}
			
			return false;
		}
		
		function deletemeal($where) {
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->delete("mealplanner")) {
				return true;
			}
			return false;
		}
		
		function getmeal($where) {
			$this->db->where($where);
			
			$query = $this->db->get("mealplanner");
			
			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function getallmeals($where) {
			$this->db->where($where);
			
			$query = $this->db->get("mealplanner");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function addmessage($message) {
			if($this->db->insert("messages", $message)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getmessages($where, $groupby = "", $orderby = "") {
			$this->db->where($where);
			
			
			if(!empty($groupby)) {
				$this->db->group_by($groupby);
			}
			
			if(!empty($orderby) && is_array($orderby)) {
				//$this->db->order_by("id", "desc");
				$this->db->order_by($orderby["field"], $orderby["order"]);
			}
			
			$query = $this->db->get("messages");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
						
		function getnewmsgs()
		{
			$id = $this->db_session->userdata("id");
			$this->db->where(array('ownerid'=>$id, 'isread'=>'0'));
			$this->db->order_by("id","desc");	
			$query = $this->db->get("messages");
			
			return $query->result();
		}
		
		function addmessagesreply($messagereply) {
			if($this->db->insert("messagesreply", $messagereply)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getmessagesreplies($where) {
			$this->db->where($where);
			$this->db->order_by("date", "asec");
			
			$query = $this->db->get("messagesreply");
			
			if($query->num_rows() > 0) {
				//return $query->result();
				$messagesreplies = $query->result();
				if(isset($messagesreplies) && !empty($messagesreplies)) {
					
					$newmessagesreply = array();
					$todays = date("Y-m-d");
					foreach($messagesreplies as $messagereply) {
						$array = (array) $messagereply;
						$messagereplydate = date("Y-m-d", strtotime($messagereply->date));
						if($messagereplydate == $todays) {
							$array["timeago"] = $this->_timeago($messagereply->date);
						}
						else {
							$array["timeago"] = date("Y-m-d", strtotime($messagereply->date));
						}
						
						$object = (object) $array;
						$newmessagesreply[] = $object;
					}
					
					for($i = 0; $i < count($messagesreplies); $i++) {
						$messagesreplies[$i] = $newmessagesreply[$i];
					}
				}
				
				return $messagesreplies;
			}
		}
		
		function updatemessages($where)
		{
			$data = array('isnotified'=>'1','isread'=>'1');
			$this->db->where($where);
			$this->db->update("messages",$data);
		}

		
		function updatemessage($messages, $where) {
			$this->db->set($messages);
			$this->db->where($where);
			
			if($this->db->update("messages")) {
				return true;
			}
			
			return false;
		}
		
		function _timeago($date) {
			if(empty($date)) {
				// no date provided
				return "";
			}
		 	
			$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
			$lengths = array("60","60","24","7","4.35","12","10");
			 
			$now = time();
			$unix_date = strtotime($date);
			 
			// check validity of date
			if(empty($unix_date)) {
				// bad date
				return "";
			}
			 
			// is it future date or past date
			if($now > $unix_date) {
				$difference = $now - $unix_date;
				$tense = "ago";
			}
			else {
				$difference = $unix_date - $now;
				$tense = "from now";
			}
			 
			for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
				$difference /= $lengths[$j];
			}
			 
			$difference = round($difference);
			 
			if($difference != 1) {
				$periods[$j].= "s";
			}
			 
			return "$difference $periods[$j] {$tense}";
		}
		
		function getadvancesearchmembers($where) {
			$this->db->or_where($where);
			$this->db->order_by("id", "desc");
			
			$query = $this->db->get("about");
			if ($query->num_rows() != 0) {
					return $query->result();
			}
		}
		/**
		 * get random user
		 */
		function getrandommembers() {
			$this->db->order_by('id', 'RANDOM');
			 $this->db->limit(4);
			 $query = $this->db->get('fa_user');
			 return $query->result();
		}
		/**
		 * used to get only user names 
		 */
		function getusernames($where) {
			$this->db->like_where($where);
			//$this->db->order_by("id", "desc");
			
			$query = $this->db->get("fa_user");
			if ($query->num_rows() != 0) {
					return $query->result();
			}
		}
		
		function get_autocomplete($uname, $countryid) {
			$this->db->select("id,name,user_name,image,email");
			
			if(isset($uname) && $uname != "") {
				$this->db->like("name", $uname);
			}
			if($countryid != 0) {
				$this->db->or_where("country_id", $countryid);
			}
			
			$query = $this->db->get("fa_user", 10);
			if ($query->num_rows() != 0) {
				return $query->result();
			}
		}
		
		/**
		 * function to get online users
		 */
		 function get_all_session_data() {
		 	$query = $this->db->select('session_data')->get('ci_sessions');
			return $query;
		}

		
		function addshare($share) {
			if($this->db->insert("share", $share)) {
				return $this->db->insert_id();
			}
			
			return 0;
		} 
		
		/* function addmembershiphistory($membershiphistory) {
			if($this->db->insert("membershiphistory", $membershiphistory)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function addmembership($membership) {
			if($this->db->insert("membership", $membership)) {
				return $this->db->insert_id();
			}
			
			return 0;
		} */
		
		function updatemembership($where, $membership) {
			$this->db->set($membership);
			$this->db->where($where);
			$this->db->limit("1");
			
			if($this->db->update("membership")) {
				return true;
			}
			
			return false;
		}
		
		function getmembership($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");
			$this->db->limit("1");

			$query = $this->db->get("membership");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function addpublicwallactivity($activity) {
			if($this->db->insert("publicwallactivities", $activity)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getpublicwallactivities($like=null,$where=null,$sort=null) {
			if($like!=null){
				$this->db->like($like);
			}
			if($where!=null){
				$this->db->where($where);
			}
			if($sort!=null){
				if($sort=='alpahbatical'){
					$this->db->order_by("category", "asc"); 
				}elseif($sort=='asc'){
					$this->db->order_by("id", $sort);
				}elseif($sort=='desc'){
					$this->db->order_by("id", $sort);
				}
			}else{
				$this->db->order_by("id", "desc");
			}

			$query = $this->db->get("publicwallactivities");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getpublicwallactivity($where) {
			$this->db->where($where);
			$this->db->limit("1");

			$query = $this->db->get("publicwallactivities");

			if($query->num_rows() > 0) {
				$result = $query->result();
				return $result[0];
			}
		}
		
		function addpublicwallcomment($communitycomment) {
			if($this->db->insert("publicwallcomments", $communitycomment)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getpublicwallcomments($where) {
			$this->db->where($where);
			$this->db->order_by("id", "desc");

			$query = $this->db->get("publicwallcomments");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function ispublicawallactivityliked($where) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("publicwalllikes");

			if ($query->num_rows() > 0) {
				return true;
			}
			
			return false;
		}
		
		function addpublicwalllikes($publicwalllike) {
			if($this->db->insert("publicwalllikes", $publicwalllike)) {
				return $this->db->insert_id();
			}
			return 0;
		}
		
		function getpublicwalllikes($where) {
			$this->db->where($where);

			$query = $this->db->get("publicwalllikes");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getpublicwalllikecounts($where) {
			$this->db->where($where);

			$query = $this->db->get("publicwalllikes");

			if($query->num_rows() > 0) {
				return $query->num_rows();
			}
		}
		
		function addimagegallery($imagegallery) {
			if($this->db->insert("imagegallery", $imagegallery)) {
				return $this->db->insert_id();
			}
			
			return 0;
		}
		
		function getimagegallery($uid, $limit="") {
			$this->db->where("uid", $uid);
			$this->db->order_by("id", "desc");
			
			if(!empty($limit)) {
				$this->db->limit($limit);
			}
			
			$query = $this->db->get("imagegallery");

			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		
		function getallimagegallery() {
			
		}
	}
	
?>