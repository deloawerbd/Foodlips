<?php
class Winemodel extends Model {
	
	function Winemodel(){
		parent:: Model();
	}
	//add winery details
	function addwinery($data){
		if($this->db->insert("wine_details",$data)){
			return $this->db->insert_id();
		}
		return FALSE;
	}
	//add wineries extra information
	function addwineriesextarinfo($data){
		if($this->db->insert("wine_extrainfo",$data)){
			return $this->db->insert_id();
		}
	}
	//get wineries extra information 
	function getwineriesextrainfo($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_extrainfo");
		if($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	// function getwineriesextrainfocountforapproval($field){
		// $this->db->select("wine_details.title, wine_extrainfo.id, wine_extrainfo.wid, wine_extrainfo.uid, wine_extrainfo.winery_img, wine_extrainfo.featureid");
		// $this->db->from("wine_extrainfo");
		// $this->db->join("wine_details",'wine_details.id = wine_extrainfo.wid');
		// $this->db->where($field. " <> ''");
		// $query = $this->db->get();
		// return $query->num_rows();
	// }
// 	
	// function getwineriesextrainfoforapproval($field, $limit){
		// $this->db->select("wine_details.title, wine_extrainfo.id, wine_extrainfo.wid, wine_extrainfo.uid, wine_extrainfo.winery_img, wine_extrainfo.featureid");
		// $this->db->from("wine_extrainfo");
		// $this->db->join("wine_details",'wine_details.id = wine_extrainfo.wid');
		// $this->db->where($field. " <> ''");
// //		$this->db->where($field. " != ''");
		// $this->db->limit($limit["start"],$limit["end"]);
		// $query = $this->db->get();
		// if($query->num_rows() != 0){
		// return $query->result();
		// }
	// }
	
	function getwineriesextrainfoforapproval($field, $limit){
		 //$this->db->select("rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		// $this->db->from("rest_extrainfo");
		//$this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		$this->db->where($field. " <> ''");
//		$this->db->where($field. " != ''");
		$this->db->limit($limit["start"],$limit["end"]);
		$query = $this->db->get("wine_extrainfo");
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	function getwineriesextrainfocountforapproval($field){
		//$this->db->select("rest_extrainfo.id, rest_extrainfo.rid, rest_extrainfo.uid, rest_extrainfo.restaurant_img, rest_extrainfo.featureid");
		//$this->db->from("rest_extrainfo");
		//$this->db->join("rest_details",'rest_details.id = rest_extrainfo.rid');
		$this->db->where($field. " <> ''");
		$query = $this->db->get("wine_extrainfo");
		return $query->num_rows();
	}
	function getcheckedmostpopularids(){
		$this->db->select("id");
		$this->db->where("mostpopular","1");
		$query = $this->db->get("wine_details");
		return $query->result();
	}
	
	//update wineries extra information
	function updatewinerieseaxtrainfo($where,$data){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("wine_extrainfo")) {
			return true;
		}
		return FALSE;
	}
	
	//get wineries features
	function getfeatures() {
		$query = $this->db->get('rest_features');
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	//add winery comments
	function addwinerycomment($data){
		if($this->db->insert("wine_comments",$data)){
			return $this->db->insert_id();
		}
	}
	
	//get comments of winery
	function getcomments($where){
		$this->db->where($where);
		$query = $this->db->get("wine_comments");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	//function to add rating
	function addrating($data) {
		if($this->db->insert("wine_ratings", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	//check if already rated
	function isratingexist($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_ratings");
		
		if($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	//update rating
	function updaterating($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("wine_ratings")) {
			return true;
		}
		return false;
	}
	
	//take restaurants rating
	function takerating($id) {
		$this->db->select_avg("rating");
		$this->db->where("wid", $id);
		
		$query = $this->db->get("wine_ratings");
		
		if($query->num_rows() > 0) {
			$row = $query->row();
			return $row->rating;
		}
	}
	
    //get single winery details
	function getwinerydetails($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_details");
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
		return FALSE;
	}
	
	//get features by id or by array of id's
	// function getfeaturebyid($where){
		// if(is_array($where)){
			// $this->db->where_in("id",$where);
		// }else{
			// $this->db->where("id",$where);
			// $this->db->limit("1");
		// }
// 		
		// $query = $this->db->get("wine_features");
		// if($query->num_rows() > 0 ){
			// $result = $query->result();
			// return $result;
		// }
	// }
	
	//get wineries neigboures wineries from db
	function getneighborswineries($latitude,$longitude){
		if($latitude != "" && $longitude != ""){
			$query = "SELECT title, seo, content, images, 3956 * 2 *
			ASIN(SQRT( POWER(SIN(($latitude - abs(latitude))*pi()/180/2),2)
			+COS($latitude*pi()/180 )*COS(abs(latitude)*pi()/180)
			*POWER(SIN(($longitude-longitude)*pi()/180/2),2)))
			as distance FROM wine_details WHERE
			longitude between ($longitude-50/abs(cos(radians($latitude))*69))
			and ($longitude+50/abs(cos(radians($latitude))*69))
			and latitude between ($latitude-(50/69))
			and ($latitude+(50/69))
			having distance < 50 ORDER BY distance limit 3;";
			$obj = $this->db->query($query);
			
			if($obj->num_rows() > 0){
				return $obj->result();
			}
		}
	}
	
	// check if already exsist in favorite
	function isfavorite($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("favouritewineries");
		if ($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	function addtofavorites($data) {
		if($this->db->insert("favouritewineries",$data)){
			return $this->db->insert_id();
		}
		return 0;
	}
	
	//get single wineries details
	function getwineriesdetails($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_details");
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
		return FALSE;
	}
	
	function getwineriescount($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_details");
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result;
		}
		return FALSE;
	}
	
	//get winery detail for pagination
	function getwineriesdetailforpagination($fields="*", $where=array(),$keyword,$searchfeatures,$feature="", $order_by="", $order="", $limit=array())
	{
		$this->db->select($fields);
		if(!empty($order_by) && !empty($order))
		{
			$this->db->orderby($order_by,$order);
		}
		if(!empty($limit))
		{
			$this->db->limit($limit["start"],$limit["end"]);
		}
		if(!empty($where))
		{
			$this->db->where($where);
		}
		if(!empty($feature))
		{
			$this->db->like('featureid', $feature, 'none');
		}
		$featurestring="";
		if(!empty($searchfeatures)){
			foreach($searchfeatures as $searchfeature){
				$featurestring.= "featureid LIKE '%$searchfeature%' OR ";
			}
		}
		$this->db->where("($featurestring title LIKE '%$keyword%' OR content LIKE '%$keyword%' OR geo_address LIKE '%$keyword%' OR contact LIKE '%$keyword%' OR website LIKE '%$keyword%'OR special_offers LIKE '%$keyword%')", NULL, FALSE);//to close the bracket
		$query = $this->db->get("wine_details");
		
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	
	function getwineriesdetailcountforpagination($field="*",$where=array())
	{
		if(!empty($where))
		{
			$this->db->where($where);
		}
		$query = $this->db->get("wine_details");
		return $query->num_rows();
	}
	
	
	//by majid
	
	//get wineries
	function getwineries($where){
		$this->db->where($where);
		$query = $this->db->get("wine_details");
		
		if($query->num_rows()){
			return $query->result();
		}
		return FALSE;
	}
	
		//get getcuisines list as well as single cuisine
	function getcuisines($where) {
		if(isset($where) && is_array($where)){
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("rest_cuisine");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result[0];
			}
		}else{
			$query = $this->db->get("rest_cuisine");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result;
			}
		}
	}
	
		function getfeaturebyid($where){
		if(is_array($where)){
			$this->db->where_in("id",$where);
		}else{
			$this->db->where("id",$where);
			$this->db->limit("1");
		}
		
		$query = $this->db->get("rest_features");
		if($query->num_rows() > 0 ){
			$result = $query->result();
			return $result;
		}
	}
		
	//get wineries prices
	function getprices($where){
		if(isset($where) && is_array($where)) {
			$this->db->where($where);
			$this->db->limit("1");
			$query = $this->db->get("rest_price");
			
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result[0];
			}
		}else{
			$query = $this->db->get("rest_price");
		
			if($query->num_rows() > 0){
				$result = $query->result();
				return $result;
			}
		}
	}
	
	// get single country details
	function getcountry($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("countries");
		
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
	}
	// get single state details
	function getstate($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("state");
		
		if($query->num_rows() > 0){
			$result = $query->result();
			return $result[0];
		}
	}
	
	function rowcount(){
		return $this->db->count_all("wine_details");
	}
	
	function getallwineriesdetails($limit){
		$this->db->orderby('id','desc');
		$query = $this->db->get("wine_details",$limit["start"],$limit["end"]);
		if($query->num_rows() != 0){
		return $query->result();
		}
	}
	
	//update wine details
	function updatewinery($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("wine_details")) {
			return true;
		}
		return false;
	}
	
	function updatepicks($where,$data,$table){
		$this->db->set($data);
		if(!empty($where)&&isset($where)){
			$this->db->where($where);
		}
		//$this->db->limit("1");
		if($this->db->update($table)){
		return true;
		}else{
			return false;
		}
	}

	function updatemostpopular($where,$data,$table){
		$this->db->set($data);
		if(!empty($where)&&isset($where)){
			$this->db->where($where);
		}
		//$this->db->limit("1");
		if($this->db->update($table)){
		return true;
		}else{
			return false;
		}
	}
	
	function doSQL($sql) {
		
		if(!empty($sql)) {
			return $this->db->query($sql);
		}
		
		return FALSE;
	}

	function getpickscount($table){
		$this->db->where("ourpicks","1");
		$query =  $this->db->get($table);
		return $query->num_rows();
	}
	
	function getmostpopularcount($table){
		$this->db->where("mostpopular","1");
		$query =  $this->db->get($table);
		return $query->num_rows();
	}
	
	function getwinedetails($table, $where, $orderby, $limit){
		if(isset($where) && !empty($where)) {
			$this->db->where($where);
		}
		if(isset($orderby) && !empty($orderby)) {
			$this->db->orderby($orderby);
		}
		if(isset($limit) && !empty($limit)) {
			$this->db->limit($limit);
		}
		$query = $this->db->get($table);
		if($query->num_rows()>0){
		return $query->result();
		//print_r($query->result);exit;
		}else{
			return false;
		}
	}
	
	function mostrated(){
		
	}
	
	function getwineryids(){
		$query = $this->db->get("wine_details");
		$query = $query->result();
		return $query;
	}
	// updaterating in winedetails
	function updateratinginwinedetails($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		$this->db->limit("1");
		if($this->db->update("wine_ratings")) {
			return true;
		}
		return false;
	}
	function getcheckedids(){
		$this->db->select("id");
		$this->db->where("ourpicks","1");
		$query = $this->db->get("wine_details");
		return $query->result();
	}
		//get category by id or by array of id's
	function getcategorybyid($where){
		if(is_array($where)){
			$this->db->where_in("id",$where);
		}else{
			$this->db->where("id",$where);
			$this->db->limit("1");
		}
		
		$query = $this->db->get("rest_category");
		if($query->num_rows() > 0 ){
			$result = $query->row();
			return $result;
		}
	}
	
	//get restaurants categories
	function getcategories() {
		$query = $this->db->get('rest_category');
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result;
		}
	}
	//get restaurants extra information from extra_info_api table
	function getwineextrainfoapi($where){
		$this->db->where($where);	
		$this->db->limit("1");
		$query = $this->db->get("wine_extrainfo_api");
		if($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	
	//update restaurants extra information in extra_info_api table
	function updatewineeaxtrainfoapi($where,$data){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("wine_extrainfo_api")) {
			return true;
		}
		return FALSE;
	}
	//add restaurants extar information in extra_info_api table
	function addwineextarinfoapi($data){
		if($this->db->insert("wine_extrainfo_api",$data)){
			return $this->db->insert_id();
		}
	}
	function gethours($where){
		if(!empty($where)){
			$this->db->where($where);	
		}
		$query = $this->db->get("hours");
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
	}
	function insertopeninghours($data){
		if($this->db->insert("wine_opening_hours",$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
		
	}
	function getopeninghours($where){
		if(!empty($where)){
			$this->db->where($where);	
		}
		$query = $this->db->get("wine_opening_hours");
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
	}
	function isOpeningHoursexists($where){
		$this->db->where($where);
		$query = $this->db->get('wine_opening_hours');
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	function updateOpeningHours($data,$where){
		$this->db->where($where);
		$this->db->update('wine_opening_hours',$data);
		
	}
	function getImages($wid){
		$this->db->where('wid',$wid);
		$query = $this->db->get('wine_extrainfo');
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return FALSE;
		}
	}
	function searchFreeKeyword($keyword,$table){
		$this->db->like("name",$keyword);
		$query = $this->db->get($table);
		if($query->num_rows()>0){
			//print_r($query->result());exit;
			return $query->result();
		}else{
			return FALSE;
		}
	}
	//function to add like
	function addlike($data) {
		if($this->db->insert("wine_likes", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	//check if already liked
	function islikeexist($where) {
		$this->db->where($where);
		$this->db->limit("1");
		$query = $this->db->get("wine_likes");
		
		if($query->num_rows() > 0) {
			return true;
		}
		return false;
	}
	
	//update like
	function updatelike($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("wine_likes")) {
			return true;
		}
		return false;
	}
	
	//count likes
	function countlike($where) {
		$this->db->where($where);
		$query = $this->db->get("wine_likes");
		if($query->num_rows() > 0) {
			 return $query->num_rows();
		}else{
			return false;
		}
	}
	function getlikebyuser($where){
		$this->db->where($where);
		$query = $this->db->get("wine_likes");
		if($query->num_rows()>0){
			$query = $query->row();
			return $query->liked;
		}else{
			return -1;
		}
		
	}
	
	//for suggestions
	function addsuggestion($data){
		if($this->db->insert("wine_suggestions",$data)){
			return $this->db->insert_id();
		}
		return FALSE;
	}
	
	function getsuggestions($where,$limit,$order_by){
		if(isset($where) && !empty($where)){
			$this->db->where($where);
		}
		if(isset($limit)&& is_array($limit)){
			$this->db->limit($limit["start"],$limit["end"]);
		}
		if(isset($order_by) && !empty($order_by)){
			$this->db->order_by("wid","asc");
			$this->db->order_by("name","asc");
		}
		
		$query = $this->db->get("wine_suggestions");
		
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
		
	}
	
	function updatesuggestions($data,$where){
		$this->db->set($data);
		$this->db->where($where);
		if($this->db->update("wine_suggestions")){
			return TRUE;
		}else{
			return FALSE;
		}
		
	}
	
	function resetprevapprovalforsuggestions($id){
		$this->db->where("id",$id);
		$this->db->get("wine_suggestions");
	}
	function deletesuggestions($where){
		$this->db->where($where);
		if($this->db->delete("wine_suggestions")){
			return TRUE;
		}else{
			return FALSE;
		}
	}
}
?>