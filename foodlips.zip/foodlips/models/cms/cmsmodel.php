<?php

class Cmsmodel extends Model {
	
	function Cmsmodel() {
		parent::Model();
		$this->output->enable_profiler(TRUE);
	}
}

?>