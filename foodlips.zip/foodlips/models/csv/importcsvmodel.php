<?php
 class Importcsvmodel extends Model {
 	function Importcsvmodel(){
 		parent::Model();
 	}
	
	function isEntryExists($where,$table){
		$this->db->where($where);
		$query = $this->db->get($table);
		if($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
		
	}
	
	function getUserIdByName($where,$table){
		$this->db->where($where);
		$query = $this->db->get($table);
		if($query->num_rows()>0){
			$name =  $query->row();
			return $name->id;
		}else{
			return FALSE;
		}
	}
	function addItem($table,$data) {
		if($this->db->insert($table,$data)) {
			return $this->db->insert_id();
		}
		return FALSE;
	}
 }
 
 ?>