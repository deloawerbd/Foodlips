<?php

class Crudmodel extends Model {

	function Crudmodel() {
		parent::Model();
	}

	function getuserdetailsbyid() {
		$this->db->where("id",$this->db_session->userdata('id'));
		$query = $this->db->get("fa_user");

		if ($query->num_rows() != 0) {
			$result = $query->row();
			return $result->image;
		}
	}
	
	function getuser($where) {
		$this->db->where($where);
		$this->db->limit("1");

		$query = $this->db->get("fa_user");

		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getcategoryname() {
		$this->db->order_by("id", "desc");
		$query = $this->db->get("categories");

		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		}
	}
	
	function getcategoryidbycategoryname($name) {
		$this->db->select("id");
		$this->db->where("name", $name);
		$this->db->limit("1");

		$query = $this->db->get("categories");

		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->id;
		}
	}
	
	/* function getcategorynamebyrecipeid($id) {
		$this->db->select("name");
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("categories");
		
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		}
		else {
			return NULL;
		}
	} */
	
	function getcommentsbyrecipeid($id) {
		$this->db->where("recipeid", $id);
		$this->db->order_by("id", "desc");

		$query = $this->db->get("comments");

		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getreviewsbyrecipeid($id) {
		$this->db->where("recipeid", $id);
		$this->db->order_by("id", "desc");

		$query = $this->db->get("reviews");

		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function isvaliddata($data) {
		//print_r($data);
		$this->db->where($data);
		$this->db->limit(1);
		$query = $this->db->get("fa_user");
		if($query->num_rows() != 0) {
			$result = $query->result();
			if(count($result)) {
				return true;
			}
		}
		return false;
	}
	
	/* function adduser($signup,$user,$email) {
		$this->db->where("email",$email);
		$query=$this->db->get("fa_user");
		if($query->num_rows() != 0) { 
			return FALSE;
		}else {
			$this->db->insert('fa_user',$signup);
			return $this->db->insert_id();
		}
	} */
	
	/* function getcoursenamebyid($id) {
		$this -> db -> select("name");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("courses");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		} else {
			return NULL;
		}

	} */

	/* function getcuisinesnamebyid($id) {
		$this -> db -> select("name");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("cuisines");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		} else {
			return NULL;
		}

	} */

	/* function gettypeamebyid($id) {
		$this -> db -> select("name");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("types");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		} else {
			return NULL;
		}

	} */

	/* function getmethodnamebyid($id) {
		$this -> db -> select("name");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("methods");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		} else {
			return NULL;
		}

	} */

	/* function getseasonnamebyid($id) {
		$this -> db -> select("name");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("seasons");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> name;
		} else {
			return NULL;
		}

	} */

	function avarageratingbyid($id) {
		$this -> db -> select("rating");
		$this -> db -> limit("1");
		$this -> db -> where("id", $id);
		$query = $this -> db -> get("ratings");
		if ($query -> num_rows() != 0) {
			$result = $query -> row();
			return $result -> rating;
		} else {
			return NULL;
		}
	}

	function getrecipedetailsbycatid($id) {
		$this -> db -> where("categoryid", $id);
		$query = $this -> db -> get("recipes");
		if ($query -> num_rows() != 0) {
			$result = $query -> result();
			return $result;

		} else {
			return NULL;
		}
	}
	
	function getimagesbyid($id) {
		$this -> db -> where("id", $id);
		$query = $this->db->get("recipes");
		if($query->num_rows() != 0) {
			$result = $query->result();
			$recipes = $result[0];
			return $recipes->images;
		} else {
			return NULL;
		}
	}
	
	function getcomentbyid($id) {
		$this -> db -> where("id", $id);
		$query = $this->db->get("comments");
		if($query->num_rows() != 0) {
			$result = $query->result();
			$comment = $result[0];
			return $comment;
		} else {
			return NULL;
		}
	}
	function getallcoments() {
		$this->db->order_by("id", "desc"); 
		$query = $this->db->get("comments");
		if($query->num_rows() != 0) {
			$result = $query->result();
			return $result;
		} else {
			return NULL;
		}
	} 
	
	function getallcategories() {
		$this->db->order_by("name", "asc"); 
		$query = $this->db->get("categories");

		if($query->num_rows() > 0) {
			return $query->result();	
		}
	}
	
	function getallcourses() {
			$query = $this->db->get('courses');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}	

function getalltypes() {
		$query=$this->db->get('types');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}
function getallcuisines() {
		
		$query = $this->db->get('cuisines');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}

	function getallseasons() {
		$query = $this->db->get('seasons');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}
	
	function getallmethods() {
		$query = $this->db->get('methods');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}

	function getallingredient() {
		$query = $this->db->get('ingredients');
			if($query->num_rows()!= 0){
			
				return $query->result();	
			}else {
				return FALSE;
			}
	}
	
	function updaterecipe($data, $where) {
		if(!is_array($where)) {
			$this->db->where("id", $where);
		}
		else {
			$this->db->where($where);
		}
		$this->db->limit(1);
		
		if($this->db->update("recipes", $data)) {
			return true;
		}
		
		return false;
	}
	
	function getrecipebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit(1);
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows()) { 
			$result = $query->result();
			if(count($result)) {
				return $result[0];
			}
		}
	}
	
	function getrecipeofday($fields="") {
		if(!empty($fields)) {
			$this->db->select($fields);
		}
		$this->db->where("recipeofday", "1");
		$this->db->limit(1);

		$query = $this->db->get("recipes");

		if($query->num_rows()) { 
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getrecipebytitleandcategoryid($where) {
		$this->db->where($where);
		$this->db->limit(1);
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows()) { 
			$result = $query->result();
			if(count($result)) {
				return $result[0];
			}
		}
	}
	
	function getcategory() {
		$this->db->where('categoryid', $this->uri->segment(3));
		$query = $this->db->get('recipes');
		return $query->result();
	}
	
	/* function getrecipeimagesbyid($id) {
		$this->db->where("id",$id);
		$query=$this->db->get('recipes');
		$row = $query->row();
		return $row->images;
	} */
	
	function getimages() {
		$this->db->select('*');
		$this -> db -> limit(5);
		$query=$this->db->get("recipes");
		return $query->result();
	}
	
	
	/*********************************************************************************************************************************************************************/
	
	function isnewrecipeadded() {
		$this->db->where("isnew", "0");
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() != 0) {
			return true;
		}
		return false;
	}
	
	function getallnewrecipes() {
		$this->db->where("isnew", "0");
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function getalllikedrecipes($where = "", $limit = ""){
		if(isset($where) && is_array($where)) {
			$this->db->where_in("id",$where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		return $query;
	}
	
	/* function getalltriedrecipes($where = "", $limit = ""){
		if(isset($where) && is_array($where)) {
			$this->db->where_in("id",$where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		return $query;
	} */
	
	function getalltriedrecipes($where) {
		$this->db->where($where);

		$query = $this->db->get("made");
		return $query->result();
	}
	
	function getallfavouriterecipes($where) {
		$this->db->where($where);

		$query = $this->db->get("favoriterecipes");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallcommentsandreviews($where) {
		$this->db->where($where);

		$query = $this->db->get("comments");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	/*function getallreviewrecipes($where) {
		$this->db->where($where);

		$query = $this->db->get("reviews");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}*/
	
	function getalllikesrecipes($where) {
		$this->db->where($where);

		$query = $this->db->get("likes");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	/**
	 * To get only result
	 */
	function getlikedrecipes($where = "", $limit = "") {
		if(isset($where) && is_array($where)) {
			$this->db->where_in("id",$where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		$this->db->order_by("id", "desc");
		
		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function gettriedrecipes($where = "", $limit = "") {
		if(isset($where) && is_array($where)) {
			$this->db->where_in("id",$where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		$this->db->order_by("id", "desc");
		
		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	/**
	 * To get full query
	 */
	function getallrecipes($where = "", $limit = "") {
		if(isset($where) && is_array($where)) {
			$this->db->where($where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		return $query;
	}
	
	/* get recipes by its type in alpabetiacl oreder*/
	
	function getrecipebytype($where="") {
		if(isset($where) && is_array($where)){
			$this->db->where($where);
		}
		$this->db->order_by('title asc'); 
		
		$query = $this->db->get("recipes");

		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	/**
	 * To get only result
	 */
	function getrecipes($where = "", $limit = "") {
		if(isset($where) && is_array($where)) {
			$this->db->where($where);
		}
		else {
			$this->db->where("approved", "1");
		}
		
		$this->db->order_by("id", "desc");

		if(isset($limit) && is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$query = $this->db->get("recipes");

		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function getrecipeswherein($wherein, $limit = "", $isquery=false) {
		$this->db->where("approved", "1");
		$this->db->where_in("id", $wherein);

		if(!empty($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		if($isquery) {
			return $query;
		}
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getrecipe($where) {
		$this->db->where($where);
		$this->db->limit("1");

		$query = $this->db->get("recipes");

		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getsearchrecipes($search, $limit = "") {
		$this->db->like($search);
		$this->db->where("approved", "1");
		
		if(is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function getadvancesearchrecipes($advancesearch, $from, $to, $limit = "") {
		if(count($advancesearch)) {
			$this->db->like($advancesearch);
		}
		
		if($from != "") {
			$this->db->where("date > ", $from);
		}
		
		if($to != "") {
			$this->db->where("date < ", $to);
		}
		
		if(is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$this->db->where("approved", "1");
		$this->db->order_by("id", "desc");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function getrecipeimages($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			$row = $query->row();
			return $row->images;
		}
	} 
	
	function getbookrecipesbyrecipeids($where) {
		$this->db->where_in("id", $where);
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
	function getbookrecipeidsbybookid($bookid) {
		$this->db->where("id", $bookid);
		$this->db->limit("1");
		
		$query = $this->db->get("books");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			$book = $result[0];
			
			return $book->recipeid;
		}
	}
	
	function getbookidbyname($name) {
		$this->db->where("name", $name);
		$this->db->limit("1");
		
		$query = $this->db->get("books");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			$book = $result[0];
			
			return $book->id;
		}
	}
	
	function addrecipe($data) {
 		if($this->db->insert('recipes', $data)) {
	 		return $this->db->insert_id();
 		}
		
		return 0;
	}
	
	function deleterecipe($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->delete("recipes")) {
			return true;
		}
		
		return false;
	}
	
	function isrecipeexistsinlast10mins($where, $datetime) {
		$this->db->where($where);
		$this->db->where("date >", $datetime);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() != 0) {
			return true;
		}
		return false;
	}
	
	function updaterecipeinlast10mins($where, $data, $datetime) {
		$this->db->set($data);
		$this->db->where($where);
		$this->db->where("date >", $datetime);
		$this->db->limit("1");
		
		if($this->db->update("recipes")) {
			return true;
		}
		return false;
	}
	
	function getrecipeinlast10mins($where, $datetime) {
		$this->db->where($where);
		$this->db->where("date >", $datetime);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() != 0) {
			$result = $query->result();
			if(count($result)) {
				return $result[0];
			}
		}
	}
	
	//query to get recipes by category id to display recipes you may like 
	function getrecipesbycategoryid($categoryid) {
		$this->db->where("categoryid", $categoryid);
		$this->db->where("approved", "1");
		$this->db->order_by("id","desc");
		$this->db->limit('5');
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() >= 5) {
			return $query->result();
		}else{
			$this->db->where("approved", "1");
			$this->db->order_by("id", "desc");
			$this->db->limit("5");
			
			$query = $this->db->get("recipes");
			return $query->result();
		}
	}
	
	function getallrecipesbycategoryid($categoryid, $limit = "") {
		$this->db->where("categoryid", $categoryid);
		$this->db->where("approved", "1");
		
		if(is_array($limit)) {
			$this->db->limit($limit["start"], $limit["end"]);
		}
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}		
	
	function gettop5recipes() {
		$this->db->order_by("rating", "desc");
		$this->db->limit("5");
		
		$query = $this->db->get("ratings");
		
		if($query->num_rows() > 0) {
			
			$ratings = $query->result();
			
			$where = array();
			
			foreach($ratings as $rating) {
				$where[] = $rating->recipeid;
			}
			
			$this->db->where_in("id", $where);
			
			$query = $this->db->get("recipes");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		else {
			$this->db->order_by("id", "desc");
			$this->db->limit("5");
			
			$query = $this->db->get("recipes");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
	}
	
	function gettop3recipes() {
		
		$this->db->order_by("rating", "desc");
		$this->db->limit("5");
		
		$query = $this->db->get("ratings");
		
		if($query->num_rows() > 0) {
			
			$ratings = $query->result();
			
			$where = array();
			
			foreach($ratings as $rating) {
				$where[] = $rating->recipeid;
			}
			$this->db->where_in("id", $where);
			
			$query = $this->db->get("recipes");
			
			if($query->num_rows() > 0) {
				return $query->result();
				//print_r($query->result());exit;
				
			}
			
		}
		else {
			$this->db->order_by("id", "desc");
			$this->db->limit("5");
			
			$query = $this->db->get("recipes");
			
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
	}
	
	function getcommentcountbyrecipeid($recipeid) {
		$this->db->where("recipeid", $recipeid);
		
		$query = $this->db->get("comments");
		return $query->num_rows();
	}
	
	function getreviewscountbyrecipeid($recipeid) {
		$this->db->where("recipeid", $recipeid);
		
		$query = $this->db->get("reviews");
		return $query->num_rows();
	}
	
	function getlikecountbyrecipeid($recipeid) {
		$this->db->where("recipeid", $recipeid);
		
		$query = $this->db->get("likes");
		return $query->num_rows();
	}
	
	function getlikecountbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("likes");
		return $query->num_rows();
	}
	
	function getlikecountbyuid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("likes");
		if($query->num_rows() > 0){
			return $query;
		}
	}
	
	function getlikesbyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("likes");
		
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	function getmadesbyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("made");

		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	function getfavouritebyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("favoriterecipes");
		
		if($query->num_rows() > 0){
			return $query->result();
		}
	}
	
	function getmadecountbyrecipeid($recipeid) {
		$this->db->where("recipeid", $recipeid);
		
		$query = $this->db->get("made");
		return $query->num_rows();
	}
	
	function getuserimgbyuid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("fa_user");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			$user = $result[0];
			return $user->image;
		}
	}
	
	function getuserbyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("fa_user");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getuserbyemail($email) {
		$this->db->where("email", $email);
		$this->db->limit("1");
		
		$query = $this->db->get("fa_user");
		
		if($query->num_rows() != 0) {
			$result = $query->result();
			if(count($result)) {
				return $result[0];
			}
		}
	}
	
	function getuserbycommentid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("comments");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			$comment = $result[0];
			if(count($comment)) {
				return $this->getuserbyid($comment->uid);
			}
		}
		
		return "";
	}
	
	function getuserbyreviewid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("reviews");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			$review = $result[0];
			if(count($review)) {
				return $this->getuserbyid($review->uid);
			}
		}
		
		return "";
	}
	
	function getcategorynamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("categories");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	function getcoursenamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("courses");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	function gettypenamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("types");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	
	function getcuisinesnamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("cuisines");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	function getseasonnamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("seasons");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	function getmethodnamebyid($id) {
		$this->db->where("id", $id);
		$this->db->limit("1");
		
		$query = $this->db->get("methods");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			return $result[0]->name;
		}
	}
	
	function getcategorynamebyrecipeid($recipeid) {
		$this->db->where("id", $recipeid);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			$recipe = $result[0];
			return $this->getcategorynamebyid($recipe->categoryid);
		}
	}
	
	function getrecipetitlebyid($recipeid) {
		$this->db->where("id", $recipeid);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			$recipe = $result[0];
			return $recipe->title;
		}
	}
	
	function getusernamebyrecipeid($recipeid) {
		$this->db->where("id", $recipeid);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if ($query->num_rows() != 0) {
			$result = $query->result();
			$recipe = $result[0];
			$user = $this->getuserbyid($recipe->uid);
			return $user->user_name;
		}
	}
	
	function addlike($data) {
		if($this->db->insert("likes", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function addmade($data) {
		if($this->db->insert("made", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function addtofavorites($data) {
		if($this->db->insert("favoriterecipes",$data)){
			return $this->db->insert_id();
		}
		return 0;
	}
	function addcomment($data) {
		if($this->db->insert("comments", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function addreview($data) {
		if($this->db->insert("reviews", $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function updatereview($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("reviews")) {
			return true;
		}
		return false;
	}
	
	function isliked($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("likes");
		
		if ($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function ismade($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("made");
		
		if ($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function isfavorite($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("favoriterecipes");
		
		if ($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function addrating($data) {
		if($this->db->insert("ratings", $data)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function isratingexistsating($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("ratings");
		
		if($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function updaterating($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		
		if($this->db->update("ratings")) {
			return true;
		}
		
		return false;
	}
	
	function takerating($id) {
		$this->db->select_avg("rating");
		$this->db->where("recipeid", $id);
		
		$query = $this->db->get("ratings");
		
		if($query->num_rows() > 0) {
			$row = $query->row();
			return $row->rating;
		}
	}
	
	function iscommentnotified($where) {
		$this->db->where($where);
		
		$query = $this->db->get("comments");
		
		if($query->num_rows() == 0) {
			return true;
		}
		
		return false;
	}
	
	function updatecomment($where, $data) {
		$this->db->set($data);
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("comments")) {
			return true;
		}
		
		return false;
	}
	
	function getuserrecipes($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getusernamebyid($id) {
		$user = $this->getuserbyid($id);
		
		if(isset($user)) {
			return $user->user_name;
		}
	}
	
	function addbook($data) {
		if($this->db->insert("books", $data)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function isalreadyinbook($where, $recipeid) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("books");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			$book = $result[0];
			
			if($book->recipeid != "") {
				$recipeids = $book->recipeid;
				$recipeids = explode(",", $recipeids);
				
				foreach($recipeids as $id) {
					if($recipeid == $id) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	function isbookexsits($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("books");
		
		if($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function getbooksbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("books");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getbookbyidnuid($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("books");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function updatebook($where, $book) {
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("books", $book)) {
			return true;
		}
		
		return false;
	}
	
	function getnonimportedcommonusers() {
		$this->db->where("recipeimported", "0");
		
		$query = $this->db->get("commonusers");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getnewpasswordcommonusers() {
		$query = $this->db->query("SELECT * FROM commonusers WHERE newpassword != '' AND recipepasswordupdate = '0'");
		//echo "data: "; print_r($query->result()); exit();
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function isuserexsits($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("fa_user");
		
		if($query->num_rows() != 0) {
			return true;
		}
		return false;
	}
	
	function adduser($data) {
		$this->db->insert('fa_user', $data);
	}
	
	function updatecommonuser($data, $where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("commonusers", $data)) {
			return true;
		}
		
		return false;
	}
	
	/* function getnamebyuid($recipeuid) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("commonusers");
		
		if($query->num_rows() != 0) {
			$result = $query->result();
			$commonuser = $result[0];
			return $commonuser->name;
		}
	} */
	
	function getingredientdetails($recipeid) {
		$this->db->where("id", $recipeid);
		$this->db->limit("1");
		
		$query = $this->db->get("recipes");
		
		if($query->num_rows() != 0) {
			$result = $query->result();
			$recipe = $result[0];
			return $recipe->ingredientdetails;
		}
	}
	
	/************* Crons *************/
	
	function getallnotnotified($table, $where) {
		$this->db->where($where);
		$this->db->limit("10");
		
		$query = $this->db->get($table);
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function updatenotification($table, $ids, $data) {
		$this->db->where_in("id", $ids);
		
		if($this->db->update($table, $data)) {
			return true;
		}
		
		return false;
	}
	
	/***********Shopping List  ****************/
	
	function addshoppinglist($data) {
		
		if($this->db->insert("shoppinglist", $data)) {
			return $this->db->insert_id();;
		}
		
		return 0;
	}
	
	function isshoppinglistexsist($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get('shoppinglist');
		if($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function updateshoppinglist($data, $where) {
		
		$this->db->set($data);
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("shoppinglist")) {
			return true;
		}
		
		return false;
	}
	
	function deleteshoppedrecipe($where) {
		$this->db->where($where);
		$this->db->limit("1");
		if($this->db->delete("shoppinglist")) {
			return true;
		}
		return false;
	}
	
	/* function addtoshoppinglist($data,$recipeid,$uid) {
		
		$this->db->where('recipeid',$recipeid );
		$query = $this->db->get('shoppinglist');
		
		if($query->num_rows() > 0) {
			$this->db->where('recipeid',$recipeid );
			$this->db->update('shoppinglist',$data);
			return true;
		}else {
			$this->db->insert('shoppinglist',$data);
		
			return true;
		}
	} */
	
	function getshoppinglistbyuserid($id) {
		$this->db->where("uid", $id);
		$query = $this->db->get("shoppinglist");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getshoppinglistbyrecipeid($recipeid) {
		$this->db->where("recipeid", $recipeid);
		$this->db->limit("1");
		
		$query = $this->db->get("shoppinglist");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	/* function getrecipebyrecipeid($recipeid) {
		$this->db->where("id",$recipeid);
		$query = $this->db->get("recipes");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	} */
	
	function getingredientsbyrecipeid($recipeid) {
		$this->db->where("recipeid",$recipeid);
		$query = $this->db->get("shoppinglist");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getfeaturedmember() {
		
		$query = $this->db->query("SELECT *, count(uid) FROM recipes WHERE approved = '1'");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			
			return $result[0];
		}
	}
	
	function getrecipecountbyuid($uid) {
		$this->db->where("uid", $uid);
		$this->db->where("approved", "1");
		$query = $this->db->get("recipes");
		
		return $query->num_rows();
	}
	
	//function for Admin Special
	
	function getadminspecial(){
		$con = mysqli_connect('localhost','foodlips_admin','Ms-lD6Wb!fD8', 'foodlips_blog') or die('Could not connect to server');
		
		if (mysqli_connect_errno()) {
			echo "Failed to connect to host: localhost db: foodlips_blog" . mysqli_connect_error();
		}
		$query = 'SELECT meta_id,post_id,meta_key FROM wp_postmeta WHERE meta_key LIKE "AdminSpecial" order by post_id desc LIMIT 1';
		//$query = 'SELECT meta_key FROM wp_postmeta where post_id=184';
		/*$post_query = 'select * from wp_posts where id = 187 ';
		$test = mysqli_query($con,$post_query);
		//echo "data:";print_r($test);
		if($result = mysqli_query($con, $post_query)) {
			if(count($result) > 0) {
				while($row = mysqli_fetch_row($result)) {
					echo"Data"; print_r($row);
				}
			}
			mysqli_close($con);
		}*/
		if($result = mysqli_query($con, $query)) {
			if(count($result) > 0) {
				while($row = mysqli_fetch_row($result)) {
					return $row;
					//echo "<br>data";print_r($row);
				}
			}
			mysqli_close($con);
		}
	}
	
	/************************************** COMMUNITY ********************************************/
	
	/* function addactivity($activity) {
		if($this->db->insert("activities", $activity)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function getuser($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("fa_user");
		
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getallrecipesbyuserid($uid) {
		$this->db->where("uid", $uid);
		$this->db->where("approved", "1");
		$query = $this->db->get("recipes");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallgroupsbyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("groups");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallreviewsbyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("reviews");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getreviewscountbyuserid($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("reviews");
		
		return $query->num_rows();
	}
	
	function getalluserfollowers($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("followers");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getalluserfollowings($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("followings");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getuseraboutinfo($uid) {
		$this->db->where("uid", $uid);
		$query = $this->db->get("about");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallactivities() {
		$query = $this->db->get("activities");
		
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallmadebyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("made");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallfavoriterecipesbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("favoriterecipes");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallfavoriteblogsbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("favoriteblogs");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getalloutsiderecipesbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("outsiderecipes");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getallonlinevideosbyuserid($uid) {
		$this->db->where("uid", $uid);
		
		$query = $this->db->get("onlinevideos");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function addgroup($group) {
		if($this->db->insert("groups", $group)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function isgroupexists($where) {
		$this->db->where($where);
		
		$query = $this->db->get("groups");
		if($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	}
	
	function getgroup($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("groups");
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
		
		return false;
	}
	
	function getallgroups() {
		$query = $this->db->get("groups");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function updategroup($group, $where) {
		$this->db->set($group);
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->update("groups")) {
			return true;
		}
		
		return false;
	}
	
	function addgroupwallpost($groupwallpost) {
		if($this->db->insert("groupwallpost", $groupwallpost)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function getallgroupwallpost($where) {
		$this->db->where($where);
		
		$query = $this->db->get("groupwallpost");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getgroupwallpost($where) {
		$this->db->where($where);
		
		$query = $this->db->get("groupwallpost");
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function deletegroupwallpost($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->delete("groupwallpost")) {
			return true;
		}
		
		return false;
	}
	
	function addtopic($topic) {
		if($this->db->insert("grouptopic", $topic)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function gettopic($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("grouptopic");
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function getalltopics($where) {
		$this->db->where($where);
		
		$query = $this->db->get("grouptopic");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function addreply($reply) {
		if($this->db->insert("reply", $reply)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function getallreply($where) {
		$this->db->where($where);
		
		$query = $this->db->get("reply");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getreply($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("reply");
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function deletereply($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		if($this->db->delete("reply")) {
			return true;
		}
		
		return false;
	}
	
	function addfriendrequest($friendrequest) {
		if($this->db->insert("friendrequest", $friendrequest)) {
			return $this->db->insert_id();
		}
		
		return 0;
	}
	
	function getallfriendrequest($where) {
		$this->db->where($where);
		
		$query = $this->db->get("friendrequest");
		if($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function getfriendrequest($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("friendrequest");
		if($query->num_rows() > 0) {
			$result = $query->result();
			return $result[0];
		}
	}
	
	function isfriendrequested($where, $requestid) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("friendrequest");
		if($query->num_rows() > 0) {
			$result = $query->result();
			$friendrequest = $result[0];
			
			if(isset($friendrequest) && $friendrequest != "") {
				$requsets = $friendrequest->requests;
				if($requsets != "") {
					if(in_array($requestid, unserialize($requsets))) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	function isfriend($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("contacts");
		if($query->num_rows() > 0) {
			return true; 
		}
		
		return false;
	} */
	
	/* function isfriendrequestexists($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("friendrequest");
		if($query->num_rows() > 0) {
			return true;
		}
		
		return false;
	} */
	
	/* function updatefriendrequest($data, $where) {
		$this->db->where($where);
		$this->db->set($data);
		$this->db->limit("1");
		
		if($this->db->update("friendrequest")) {
			return true;
		}
		
		return false;
	} */
	
	/* function getgroupmemberscount($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("groups");
		if($query->num_rows() > 0) {
			$result = $query->result();
			$group = $result[0];
			
			if($group->members != "") {
				$members = explode(",", $group->members);
				return count($members);
			}
		}
		
		return 0;
	} */
	
	/* function getgroupvisibilty($where) {
		$this->db->where($where);
		$this->db->limit("1");
		
		$query = $this->db->get("groups");
		if($query->num_rows() > 0) {
			$result = $query->result();
			$group = $result[0];
			return $group->visibility;
		}
	} */
	
	function getrecipereviewsbyuserid($uid,$limit="") {
		if(isset($uid) && $limit == ""){
			$this->db->where("uid", $uid);
			$this->db->order_by("id", "desc");
			$this->db->limit("6");
			//$query = $this->db->get("reviews");
			$query = $this->db->get("comments");
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
		else if(isset($uid) && $limit == "all") {
			$this->db->where("uid", $uid);
			$this->db->order_by("id", "desc");
			
			//$query = $this->db->get("reviews");
			$query = $this->db->get("comments");
			if($query->num_rows() > 0) {
				return $query->result();
			}
		}
	}
	
	function addrestaurantinfo($data){
		if($this->db->insert('restaurentinfo', $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function addwineryinfo($data) {
		if($this->db->insert('wineryextrainfo', $data)) {
			return $this->db->insert_id();
		}
		return 0;
	}
	
	function getrecipebytypeorcategory($where = "",$or=""){
		if(isset($where) && is_array($where)){
			$this->db->where($where);
		}
		if(isset($or) && is_array($or)){
			$this->db->or_where($or);
		}
		$this->db->order_by('title', 'asc'); 
		
		$query = $this->db->get("recipes");

		if ($query->num_rows() != 0) {
			return $query->result();
		}
	}
	
}
?>